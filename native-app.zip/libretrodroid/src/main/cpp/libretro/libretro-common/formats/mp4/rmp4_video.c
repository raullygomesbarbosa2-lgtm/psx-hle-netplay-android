/* Copyright  (C) 2010-2026 The RetroArch team
 *
 * ---------------------------------------------------------------------
 * The following license statement only applies to this file (rmp4_video.c).
 * ---------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 * DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE,
 * ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* MP4 video-to-image glue: rmp4 demuxer + rh264/rh265/rvp8/rvp9
 * decoders exposed through the still-image and streaming-animation
 * contracts that image_transfer.c dispatches on (see rmp4_video.h).
 * The structure mirrors rwebm_video.c with the demuxer swapped and
 * H.264 (avc1, with its avcC extradata) and H.265 (hvc1/hev1, with
 * hvcC) added to the codec dispatch. */

#include <stdlib.h>
#include <string.h>

#if defined(__SSE2__)
#include <emmintrin.h>
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
#include <arm_neon.h>
#endif

#include <retro_inline.h>

#include <formats/image.h>
#include <formats/rmp4.h>
#include <formats/rvp8.h>
#ifdef HAVE_RVP9
#include <formats/rvp9.h>
#include <formats/rvp9_config.h>
#include <formats/rvp9_color.h>
#include <formats/rvp9_hw.h>
#endif
/* The 10-bit / HDR I420->RGB blits are shared (image_hdr_blit.c) but still
 * declared in rwebm_video.h; the implementation is demuxer-independent.
 * Included outside the HAVE_RVP9 guard because the H.265 Main10 arm of
 * the render switch uses the same blits regardless of rvp9. */
#include <formats/rwebm_video.h>
#include <formats/rh264.h>
#include <formats/rh265.h>
#include <formats/rmp4_video.h>
#include <formats/image_blit_bands.h>
#include <formats/image_yuv_blit.h>
#include <formats/video_hw_frame.h>
#ifdef HAVE_RAV1
#include <formats/rav1_hw_stream.h>
#endif
#include <features/features_cpu.h>

/* The demuxer's bounded sample table supplies presentation timestamps
 * without lookahead decoding or reading media bytes. */

/* A VP9 superframe carries at most 8 sub-frames. */
#define RMP4_VIDEO_MAX_SUPER    8

#ifdef HAVE_RAV1
typedef struct rmp4_av1_hdr_point
{
   rav1_hdr_metadata_t hdr;
   uint32_t sample;
} rmp4_av1_hdr_point_t;
#endif

struct rmp4_video_stream
{
   rmp4_t      *demux;
   rmp4_packet pending_packet;
   size_t pending_floor;
   const uint8_t *input;
   size_t input_len, input_avail;
   int pending, waiting;
   rvp8_video  *vp8;
#ifdef HAVE_RVP9
   rvp9_dec    *vp9;
   rvp9_hw_session_t *vp9_hw;
   rvp9_hw_backend_t vp9_backend;
   rvp9_hdr vp9_probe_header, vp9_initial_header;
   int vp9_initial_valid;
   video_color_metadata_t vp9_native_color;
   size_t vp9_sizes[RMP4_VIDEO_MAX_SUPER], vp9_offset;
   uint32_t vp9_sample;
   int vp9_active, vp9_count, vp9_index, vp9_last_show;
   int vp9_submitted, vp9_discard, vp9_restart;
   video_color_metadata_t vp9_color;
   int vp9_have_config;
   rvp9_config_t vp9_config;
#endif
   rh264_video *h264;
   rh265_video *h265;
   rh265_output_timing_t h265_timing;
   int64_t h265_timestamp, h265_display_timestamp;
   size_t h265_probe_offset, h265_probe_need, h265_need_lo, h265_need_hi;
   uint32_t h265_decode_sample, h265_probe_sample;
   int h265_picture_pending, h265_timing_active, h265_have_time, h265_ahead;
#ifdef HAVE_RAV1
   rav1_hw_stream_t *av1;
   uint8_t *av1_sequence_bytes;
   size_t av1_sequence_size;
   rav1_hdr_metadata_t av1_hdr_initial, av1_hdr_seed;
   rmp4_av1_hdr_point_t *av1_hdr_points;
   rav1_hdr_metadata_t av1_hdr_scanned;
   size_t av1_hdr_count, av1_hdr_capacity, av1_hdr_scan_offset;
   size_t av1_hdr_scan_need;
   uint32_t av1_hdr_scan_sample, av1_decode_sample;
   rav1_sequence_t av1_hdr_probe_sequence;
   size_t av1_hdr_probe_offset;
   uint32_t av1_hdr_probe_sample;
   int av1_hdr_initial_set, av1_hdr_probe_started;
#endif
   uint32_t hw_marker;
   uint32_t    *frame;      /* width * height ABGR words              */
   uint32_t    *out;        /* caller's frame to blit into instead of
                               'frame'; NULL for the stream's own    */
   void        *blit_pool;  /* tpool_t the blit's row bands run on   */
   unsigned     out_stride; /* caller row stride in pixels, 0: width */
   unsigned     blit_bands; /* how many; <= 1 blits on this thread   */
   int64_t     *ts;         /* pre-scanned packet timestamps (ns)     */
   int          ts_count;   /* entries stored in ts                   */
   int          num_frames; /* total video packets in the stream      */
   int          disp_idx;   /* ordinal of the next displayed picture  */
   int          seek_state, seek_target, seek_scan;
   int64_t      seek_position_us;
   int64_t      movie_seek_target_ns;
   /* The displayed picture most recently produced by a step.  Its
    * planes stay inside the decoder until the next decode or drain
    * call, so colour conversion into 'frame' is deferred to
    * rmp4_video_stream_render and never happens at all for frames a
    * caller passes over with rmp4_video_stream_skip (this replaces
    * the old seek-only 'catchup' blit suppression). */
   int          rndr_kind;     /* 0 none, 1 vp8, 2 vp9, 3 h264, 4 h265 */
   int          rndr_vp9_show; /* fbs index of the vp9 picture       */
   int completed;
   int          wait_key;   /* a reference failed; hold out for a key */
   int          catchup;    /* dropping droppable pictures to catch up */
   int          track;      /* index of the chosen video track        */
   video_mastering_display_t mastering;
   unsigned     max_cll, max_fall;
   rwebm_video_hdr_tone_t tone;
   unsigned     primaries;
   unsigned     matrix;     /* matrix coefficients; 0 untagged        */
   unsigned     transfer;   /* transfer characteristics              */
   unsigned     range;      /* container or SPS full-range flag      */
   enum rmp4_codec codec;
   unsigned     width;
   unsigned     height;
   int          want10;     /* caller requested 10-bit output         */
   int          is10;       /* last decoded frame written as 10-bit    */
   int          want_fp16;  /* caller takes linear scRGB half floats
                               for an HDR source, into 'out'         */
   int          is_fp16;    /* last decoded frame written so          */
   int          emit_argb;  /* emit ARGB words instead of the default
                               R,G,B,A memory order (8-bit paths)     */
   struct texture_planar borrowed_planar; /* decoder-owned, until next step */
   int          want_planar; /* 0: RGB, 1: I420, 2: borrow, 3: tight borrow */
   unsigned     planar_yuv; /* IMAGE_YUV_FLAG_* of the last such frame */
   int          want_hw;    /* H.264/HEVC/VP9/AV1 on the hardware backend */
   /* The hardware frame of the picture the last step produced
    * (rndr_kind 5), and whether the caller has yet to take it: one
    * passed over is given back to the decoder. */
   video_hw_frame_t hwf;
   int          hwf_untaken;
};

/* Still-image decode progress across sliced process calls. */
enum
{
   RMP4_VIDEO_STILL_IDLE = 0,    /* nothing in progress (or done)      */
   RMP4_VIDEO_STILL_SCAN,        /* stream open, pre-scan running      */
   RMP4_VIDEO_STILL_DECODE       /* decoding to the first shown frame  */
};

/* Container packets walked per pre-scan slice of the sliced still
 * path: cheap header parses, sized so a slice stays well under a
 * display frame even on weak hardware while the full bounded scan
 * still completes in a handful of slices. */
#define RMP4_VIDEO_SCAN_SLICE    1024

struct rmp4_video
{
   const uint8_t *buf;
   size_t         len;
   /* The stream opened for the still frame, kept so a caller that wants
    * to continue the video as an animation can detach it instead of
    * re-opening (and re-pre-scanning) the file.  Owned by this handle
    * until rmp4_video_detach_stream; closed by rmp4_video_free
    * otherwise.  Borrows 'buf', which must outlive it either way.
    * While still_stage is not IDLE this holds the partially-opened
    * stream the sliced still decode is building. */
   rmp4_video_stream_t *stream;
   int            still_stage; /* enum above */
   int            want10;     /* caller requested 10-bit thumbnail output */
   int            last_10bit; /* last processed frame was XRGB2101010 */
   int            want_fp16;  /* caller takes half floats for HDR      */
   int            last_fp16;  /* last processed frame was half floats  */
   /* An HDR still's frame: width * height 8-byte pixels the stream
    * renders into from the decode stage on, handed out as the still -
    * the canvas and its copy are skipped. NULL otherwise. */
   uint16_t      *still_fp16;
   /* Bytes of 'buf' actually read so far, for decoding a still from a
    * file whose read is in progress: 0 means fully resident (the
    * default; set_buf_ptr keeps it), and the still decode returns
    * IMAGE_PROCESS_WAIT instead of erroring when it runs into the
    * wall.  Raised by rmp4_video_set_avail. */
   size_t         avail;
   int            partial;    /* set_avail was called: 'avail' is live
                                 (0 is a valid value - nothing read
                                 yet - so it cannot double as the
                                 unset sentinel) */
};

static int rmp4_video_ts_cmp(const void *a, const void *b)
{
   int64_t x = *(const int64_t*)a, y = *(const int64_t*)b;
   return (x > y) - (x < y);
}

/* ------------------------------------------------------------------ */
/* Limited-range I420 -> ABGR words (memory R,G,B,A on LE).            */
/* 8-bit coefficient sets, <<8: {re, gd, ge, bd}, same values as the   */
/* webm converter. Untagged content defaults to BT.601 below 720 lines */
/* and BT.709 at or above, matching industry convention.               */
/* ------------------------------------------------------------------ */
static const int16_t rmp4_video_coef_601[4]  = { 409, 100, 208, 516 };
static const int16_t rmp4_video_coef_709[4]  = { 459,  55, 136, 541 };
static const int16_t rmp4_video_coef_2020[4] = { 431,  48, 167, 548 };

static const int16_t rmp4_video_full_601[4]  = { 359, 88, 183, 454 };
static const int16_t rmp4_video_full_709[4]  = { 403, 48, 120, 475 };
static const int16_t rmp4_video_full_2020[4] = { 377, 42, 146, 482 };

static const int16_t *rmp4_video_coefs(unsigned matrix, unsigned height, int range)
{
   switch (matrix)
   {
      case 1:            return range ? rmp4_video_full_709 : rmp4_video_coef_709;
      case 5: case 6:    return range ? rmp4_video_full_601 : rmp4_video_coef_601;
      case 9: case 10:   return range ? rmp4_video_full_2020 : rmp4_video_coef_2020;
      default:           return height >= 720
                            ? (range ? rmp4_video_full_709 : rmp4_video_coef_709)
                            : (range ? rmp4_video_full_601 : rmp4_video_coef_601);
   }
}

static INLINE uint32_t rmp4_video_yuv_px(int y, int u, int v,
      const int16_t *k, int range, int argb)
{
   int c = (range ? 256 : 298) * (y - (range ? 0 : 16));
   int d = u - 128;
   int e = v - 128;
   int r = (c + k[0] * e + 128) >> 8;
   int g = (c - k[1] * d - k[2] * e + 128) >> 8;
   int b = (c + k[3] * d + 128) >> 8;
   if (r < 0)
      r = 0;
   else if (r > 255)
      r = 255;
   if (g < 0)
      g = 0;
   else if (g > 255)
      g = 255;
   if (b < 0)
      b = 0;
   else if (b > 255)
      b = 255;
   if (argb)
      return 0xFF000000u
           | ((uint32_t)r << 16)
           | ((uint32_t)g << 8)
           |  (uint32_t)b;
   return 0xFF000000u
        | ((uint32_t)b << 16)
        | ((uint32_t)g << 8)
        |  (uint32_t)r;
}

#if defined(__SSE2__)
/* 8 pixels per iteration with pmaddwd pairs. Bit-exact with the scalar
 * path: pmaddwd/paddd/psrad reproduce the integer arithmetic (psrad is
 * an arithmetic shift, as the scalar's >> is on int), and the
 * packs/packus saturation chain is exactly the scalar's clamp - the
 * pre-clamp channel range (about -223..481 for 8-bit input) fits int16
 * without distortion. */
static void rmp4_video_yuv_row_sse2(uint32_t *dr,
      const uint8_t *yr, const uint8_t *ur, const uint8_t *vr, unsigned w,
      const int16_t *k, int range, int argb)
{
   const __m128i k16   = _mm_set1_epi16(range ? 0 : 16);
   const __m128i k128  = _mm_set1_epi16(128);
   const __m128i zero  = _mm_setzero_si128();
   const __m128i ones  = _mm_set1_epi16(1);
   const __m128i a255  = _mm_set1_epi8((char)0xFF);
   /* Packs two int16 coefficients into the int32 lane pmaddwd expects,
    * without shifting a negative value (all arithmetic unsigned). */
#define RMP4_PAIR16(hi, lo) \
   ((int32_t)(((uint32_t)(uint16_t)(int16_t)(hi) << 16) \
            |  (uint32_t)(uint16_t)(int16_t)(lo)))
   const __m128i c_r   = _mm_set1_epi32(RMP4_PAIR16( k[0], range ? 256 : 298));
   const __m128i c_g1  = _mm_set1_epi32(RMP4_PAIR16(-k[1], range ? 256 : 298));
   const __m128i c_g2  = _mm_set1_epi32(RMP4_PAIR16( 128, -k[2]));
   const __m128i c_b   = _mm_set1_epi32(RMP4_PAIR16( k[3], range ? 256 : 298));
#undef RMP4_PAIR16
   const __m128i rnd   = _mm_set1_epi32(128);
   unsigned i;

   for (i = 0; i + 8 <= w; i += 8)
   {
      int32_t utmp, vtmp;
      __m128i y8, ysub, u4, v4, d, e;
      __m128i ye_lo, ye_hi, yd_lo, yd_hi, e1_lo, e1_hi;
      __m128i r_lo, r_hi, g_lo, g_hi, b_lo, b_hi;
      __m128i r16, g16, b16, r8, g8, b8, rg, ba;

      /* ysub: 8 x i16, range-adjusted luma */
      y8   = _mm_loadl_epi64((const __m128i*)(yr + i));
      ysub = _mm_sub_epi16(_mm_unpacklo_epi8(y8, zero), k16);
      /* d/e: 4 chroma samples each duplicated to 8 x i16, minus 128
       * (memcpy avoids an unaligned int load) */
      memcpy(&utmp, ur + (i >> 1), sizeof(utmp));
      memcpy(&vtmp, vr + (i >> 1), sizeof(vtmp));
      u4 = _mm_cvtsi32_si128(utmp);
      v4 = _mm_cvtsi32_si128(vtmp);
      d  = _mm_sub_epi16(
            _mm_unpacklo_epi8(_mm_unpacklo_epi8(u4, u4), zero), k128);
      e  = _mm_sub_epi16(
            _mm_unpacklo_epi8(_mm_unpacklo_epi8(v4, v4), zero), k128);

      ye_lo = _mm_unpacklo_epi16(ysub, e);
      ye_hi = _mm_unpackhi_epi16(ysub, e);
      yd_lo = _mm_unpacklo_epi16(ysub, d);
      yd_hi = _mm_unpackhi_epi16(ysub, d);
      e1_lo = _mm_unpacklo_epi16(e, ones);
      e1_hi = _mm_unpackhi_epi16(e, ones);

      /* matrix and rounding */
      r_lo = _mm_srai_epi32(_mm_add_epi32(
            _mm_madd_epi16(ye_lo, c_r), rnd), 8);
      r_hi = _mm_srai_epi32(_mm_add_epi32(
            _mm_madd_epi16(ye_hi, c_r), rnd), 8);
      /* g = (298*ysub - 100*d - 208*e + 128) >> 8
       *   = (madd(ysub,d; 298,-100) + madd(e,1; -208,128)) >> 8 */
      g_lo = _mm_srai_epi32(_mm_add_epi32(
            _mm_madd_epi16(yd_lo, c_g1), _mm_madd_epi16(e1_lo, c_g2)), 8);
      g_hi = _mm_srai_epi32(_mm_add_epi32(
            _mm_madd_epi16(yd_hi, c_g1), _mm_madd_epi16(e1_hi, c_g2)), 8);
      /* b = (298*ysub + 516*d + 128) >> 8 */
      b_lo = _mm_srai_epi32(_mm_add_epi32(
            _mm_madd_epi16(yd_lo, c_b), rnd), 8);
      b_hi = _mm_srai_epi32(_mm_add_epi32(
            _mm_madd_epi16(yd_hi, c_b), rnd), 8);

      /* Saturating packs implement the 0..255 clamp */
      r16 = _mm_packs_epi32(r_lo, r_hi);
      g16 = _mm_packs_epi32(g_lo, g_hi);
      b16 = _mm_packs_epi32(b_lo, b_hi);
      r8  = _mm_packus_epi16(r16, r16);
      g8  = _mm_packus_epi16(g16, g16);
      b8  = _mm_packus_epi16(b16, b16);

      /* Interleave to memory order R,G,B,A (ABGR words), or B,G,R,A
       * (ARGB words) when the caller asked for ARGB: the swap costs
       * only operand selection, the arithmetic is shared. */
      rg  = _mm_unpacklo_epi8(argb ? b8 : r8, g8);
      ba  = _mm_unpacklo_epi8(argb ? r8 : b8, a255);
      _mm_storeu_si128((__m128i*)(dr + i),
            _mm_unpacklo_epi16(rg, ba));
      _mm_storeu_si128((__m128i*)(dr + i + 4),
            _mm_unpackhi_epi16(rg, ba));
   }
   for (; i < w; i++)
      dr[i] = rmp4_video_yuv_px(yr[i], ur[i >> 1], vr[i >> 1], k, range, argb);
}
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
/* NEON translation of the SSE2 kernel above: identical integer
 * arithmetic (widening multiply-accumulate into i32, arithmetic shift,
 * saturating narrows for the clamp), so results are byte-identical to
 * the scalar path. */
static void rmp4_video_yuv_row_neon(uint32_t *dr,
      const uint8_t *yr, const uint8_t *ur, const uint8_t *vr, unsigned w,
      const int16_t *kc, int range, int argb)
{
   const int16x8_t k16  = vdupq_n_s16(range ? 0 : 16);
   const int16x8_t k128 = vdupq_n_s16(128);
   const int32x4_t rnd  = vdupq_n_s32(128);
   unsigned i;

   for (i = 0; i + 8 <= w; i += 8)
   {
      uint8x8_t y8, u8, v8;
      int16x8_t ysub, d, e;
      int32x4_t c_lo, c_hi, r_lo, r_hi, g_lo, g_hi, b_lo, b_hi;
      int16x8_t r16, g16, b16;
      uint8x8x4_t out;
      uint8_t utmp[8], vtmp[8];
      unsigned k;

      y8   = vld1_u8(yr + i);
      ysub = vsubq_s16(vreinterpretq_s16_u16(vmovl_u8(y8)), k16);
      for (k = 0; k < 4; k++)
      {
         utmp[2*k] = utmp[2*k+1] = ur[(i >> 1) + k];
         vtmp[2*k] = vtmp[2*k+1] = vr[(i >> 1) + k];
      }
      u8 = vld1_u8(utmp);
      v8 = vld1_u8(vtmp);
      d  = vsubq_s16(vreinterpretq_s16_u16(vmovl_u8(u8)), k128);
      e  = vsubq_s16(vreinterpretq_s16_u16(vmovl_u8(v8)), k128);

      /* range-adjusted luma and rounding */
      c_lo = vmlal_n_s16(rnd, vget_low_s16(ysub),  range ? 256 : 298);
      c_hi = vmlal_n_s16(rnd, vget_high_s16(ysub), range ? 256 : 298);

      r_lo = vshrq_n_s32(vmlal_n_s16(c_lo, vget_low_s16(e),   kc[0]), 8);
      r_hi = vshrq_n_s32(vmlal_n_s16(c_hi, vget_high_s16(e),  kc[0]), 8);
      g_lo = vshrq_n_s32(vmlsl_n_s16(vmlsl_n_s16(c_lo,
               vget_low_s16(d),  kc[1]), vget_low_s16(e),  kc[2]), 8);
      g_hi = vshrq_n_s32(vmlsl_n_s16(vmlsl_n_s16(c_hi,
               vget_high_s16(d), kc[1]), vget_high_s16(e), kc[2]), 8);
      b_lo = vshrq_n_s32(vmlal_n_s16(c_lo, vget_low_s16(d),   kc[3]), 8);
      b_hi = vshrq_n_s32(vmlal_n_s16(c_hi, vget_high_s16(d),  kc[3]), 8);

      /* Saturating narrows implement the 0..255 clamp */
      r16 = vcombine_s16(vqmovn_s32(r_lo), vqmovn_s32(r_hi));
      g16 = vcombine_s16(vqmovn_s32(g_lo), vqmovn_s32(g_hi));
      b16 = vcombine_s16(vqmovn_s32(b_lo), vqmovn_s32(b_hi));

      /* R,G,B,A memory order, or B,G,R,A for ARGB words. */
      out.val[0] = vqmovun_s16(argb ? b16 : r16);
      out.val[1] = vqmovun_s16(g16);
      out.val[2] = vqmovun_s16(argb ? r16 : b16);
      out.val[3] = vdup_n_u8(0xFF);
      vst4_u8((uint8_t*)(dr + i), out);
   }
   for (; i < w; i++)
      dr[i] = rmp4_video_yuv_px(yr[i], ur[i >> 1], vr[i >> 1], kc, range, argb);
}
#endif

/* 4:4:4: one chroma sample per luma sample, so the row kernels above,
 * which pair each chroma sample with two luma samples, do not apply;
 * the scalar conversion runs per sample instead.  Rare enough (an
 * H.264 High 4:4:4 recording) not to warrant its own SIMD rows. */
static void rmp4_video_blit_yuv444(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h,
      const uint8_t *y, int ys,
      const uint8_t *u, const uint8_t *v, int uvs,
      unsigned matrix, int range, int argb)
{
   const int16_t *k = rmp4_video_coefs(matrix, h, range);
   unsigned j, i;
   for (j = 0; j < h; j++)
   {
      const uint8_t *yr = y + (size_t)j * ys;
      const uint8_t *ur = u + (size_t)j * uvs;
      const uint8_t *vr = v + (size_t)j * uvs;
      uint32_t      *dr = dst + (size_t)j * dst_stride;
      for (i = 0; i < w; i++)
         dr[i] = rmp4_video_yuv_px(yr[i], ur[i], vr[i], k, range, argb);
   }
}

/* Any bit depth above 8 at any subsampling, to 8-bit ARGB: the samples
 * are scaled down to eight bits and converted as the 8-bit path does.
 * This is the SDR route for high-bit-depth H.264 (10-bit 4:2:0 with a
 * PQ / HLG transfer takes the shared HDR blits instead, as H.265 and
 * VP9 do).  Scalar; such streams are rare enough not to warrant SIMD. */
static void rmp4_video_blit_yuv_hbd(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h,
      const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      int chsh, int cvsh, int bd, unsigned matrix, int range, int argb)
{
   const int16_t *k = rmp4_video_coefs(matrix, h, range);
   int sh = bd - 8;
   unsigned j, i;
   for (j = 0; j < h; j++)
   {
      const uint16_t *yr = y + (size_t)j * ys;
      const uint16_t *ur = u + (size_t)(j >> cvsh) * uvs;
      const uint16_t *vr = v + (size_t)(j >> cvsh) * uvs;
      uint32_t       *dr = dst + (size_t)j * dst_stride;
      for (i = 0; i < w; i++)
         dr[i] = rmp4_video_yuv_px(yr[i] >> sh, ur[i >> chsh] >> sh,
               vr[i >> chsh] >> sh, k, range, argb);
   }
}

static void rmp4_video_blit_yuv(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h,
      const uint8_t *y, int ys,
      const uint8_t *u, const uint8_t *v, int uvs,
      unsigned matrix, int cvsh, int range, int argb)
{
   const int16_t *k = rmp4_video_coefs(matrix, h, range);
   unsigned j;
   for (j = 0; j < h; j++)
   {
      const uint8_t *yr = y + (size_t)j * ys;
      const uint8_t *ur = u + (size_t)(j >> cvsh) * uvs;
      const uint8_t *vr = v + (size_t)(j >> cvsh) * uvs;
      uint32_t      *dr = dst + (size_t)j * dst_stride;
#if defined(__SSE2__)
      rmp4_video_yuv_row_sse2(dr, yr, ur, vr, w, k, range, argb);
#elif defined(__ARM_NEON) || defined(__ARM_NEON__)
      rmp4_video_yuv_row_neon(dr, yr, ur, vr, w, k, range, argb);
#else
      {
         unsigned i;
         for (i = 0; i < w; i++)
            dr[i] = rmp4_video_yuv_px(yr[i], ur[i >> 1], vr[i >> 1], k, range, argb);
      }
#endif
   }
}

/* ------------------------------------------------------------------ */
/* VP9 superframe index (parsed from the trailing marker byte).        */
/* Returns the number of sub-frames and their sizes; 1 = whole chunk.  */
/* ------------------------------------------------------------------ */
#ifdef HAVE_RVP9
static int rmp4_video_vp9_superframe(const uint8_t *data, size_t size,
      size_t *sizes, int max_frames)
{
   uint8_t marker;
   int frames, bytes_per_size, i, k;
   size_t index_size, total;
   const uint8_t *x;

   if (size < 2)
      goto whole;
   marker = data[size - 1];
   if ((marker & 0xe0) != 0xc0)
      goto whole;
   frames         = (marker & 0x7) + 1;
   bytes_per_size = ((marker >> 3) & 0x3) + 1;
   index_size     = 2 + (size_t)frames * bytes_per_size;
   if (size < index_size || data[size - index_size] != marker)
      goto whole;
   if (frames > max_frames)
      goto whole;
   x     = data + size - index_size + 1;
   total = 0;
   for (i = 0; i < frames; i++)
   {
      size_t sz = 0;
      for (k = 0; k < bytes_per_size; k++)
         sz |= (size_t)*x++ << (k * 8);
      sizes[i] = sz;
      total   += sz;
   }
   if (total > size - index_size)
      goto whole;
   return frames;

whole:
   sizes[0] = size;
   return 1;
}
#endif

/* ------------------------------------------------------------------ */
/* Decoder lifecycle                                                   */
/* ------------------------------------------------------------------ */
static bool rmp4_video_hw_color_allowed(const rmp4_video_stream_t *s)
{
   if (rmp4_video_stream_is_hdr(s))
      return (s->matrix == 0 || s->matrix == 1 || s->matrix == 9)
         && (s->primaries == 0 || s->primaries == 2
               || s->primaries == 1 || s->primaries == 9);
   return (s->matrix == 0 || s->matrix == 1 || s->matrix == 5 || s->matrix == 6)
      && !rmp4_video_stream_is_hdr(s);
}

static void rmp4_video_hevc_color(rmp4_video_stream_t *s, const rmp4_track *t)
{
   rh265_video_color_t color;
   unsigned pps;
   if (!t) return;
   s->primaries = t->color_primaries;
   s->matrix = t->matrix_coefficients;
   s->transfer = t->transfer_characteristics;
   s->range = t->full_range;
   for (pps = 0; pps < 64; pps++)
      if (!rh265_video_get_color(s->h265, pps, &color))
      {
         if (color.description_present)
         {
            if (!t->color_description_present || t->color_primaries == 2)
               s->primaries = color.primaries;
            if (!t->color_description_present || t->matrix_coefficients == 2)
               s->matrix = color.matrix == 2 ? 0 : color.matrix;
            if (!t->color_description_present || t->transfer_characteristics == 2)
               s->transfer = color.transfer == 2 ? 0 : color.transfer;
         }
         if (!t->range_present && color.video_signal_present)
            s->range = color.full_range;
         break;
      }
}

#ifdef HAVE_RAV1
static bool rmp4_video_av1_retain(void *user,
      const rav1_sequence_t *sequence, const rav1_obu_t *obu)
{
   rmp4_video_stream_t *s = (rmp4_video_stream_t*)user;
   (void)sequence;
   return rav1_hw_stream_retain_config(
         &s->av1_sequence_bytes, &s->av1_sequence_size, obu);
}

static bool rmp4_video_av1_open(rmp4_video_stream_t *s)
{
   const rmp4_track *t = rmp4_get_track(s->demux, s->track);
   rav1_config_t config;
   rav1_sequence_t *seq;
   if (!t ||
       !rav1_config_parse(&config, t->codec_private, t->codec_private_size))
      return false;
   if (s->av1_sequence_bytes)
   {
      size_t offset = 0;
      if (rav1_obu_next(&config.sequence, s->av1_sequence_bytes,
               s->av1_sequence_size, &offset, true) != 1)
         return false;
   }
   s->av1 = (rav1_hw_stream_t *)calloc(1, sizeof(*s->av1));
   if (!s->av1)
      return false;
   rav1_hw_stream_init(s->av1, NULL);
   s->av1->retain_sequence = rmp4_video_av1_retain;
   s->av1->sequence_user = s;
   seq = &s->av1->sequence;
   if (!rav1_config_sequence(seq, &config) || seq->max_width != s->width ||
       seq->max_height != s->height)
      goto fail;
   if (t->color_description_present &&
       ((seq->color_primaries != 2 && t->color_primaries != 2 &&
         seq->color_primaries != t->color_primaries) ||
        (seq->matrix_coefficients != 2 && t->matrix_coefficients != 2 &&
         seq->matrix_coefficients != t->matrix_coefficients) ||
        (seq->transfer_characteristics != 2 &&
         t->transfer_characteristics != 2 &&
         seq->transfer_characteristics != t->transfer_characteristics)))
      goto fail;
   if (t->range_present && t->full_range != seq->color_range)
      goto fail;
   s->primaries = seq->color_primaries != 2
      ? seq->color_primaries : t->color_primaries;
   s->matrix = seq->matrix_coefficients != 2
                   ? seq->matrix_coefficients
                   : (t->matrix_coefficients == 2 ? 0 : t->matrix_coefficients);
   s->transfer = seq->transfer_characteristics != 2
                     ? seq->transfer_characteristics
                     : t->transfer_characteristics;
   s->range = seq->color_range;
   if (!rav1_hdr_metadata_config(&s->av1->hdr, &config))
      goto fail;
   s->av1_hdr_seed = s->av1->hdr;
   if (s->av1_hdr_initial_set) s->av1->hdr = s->av1_hdr_initial;
   s->av1->sequence_obu = config.sequence;
   s->av1->color.primaries = s->primaries;
   s->av1->color.transfer = s->transfer;
   s->av1->color.matrix = s->matrix;
   s->av1->color.range = s->range ? 2 : 1;
   s->av1->color.mastering = s->mastering;
   s->av1->color.max_cll = s->max_cll;
   s->av1->color.max_fall = s->max_fall;
   if (!rav1_hdr_metadata_merge(&s->av1->color, &s->av1->hdr)
         || !rmp4_video_hw_color_allowed(s)
         || !rav1_hw_stream_open_sequence(s->av1))
      goto fail;
   return true;
fail:
   rav1_hw_stream_close(s->av1);
   free(s->av1);
   s->av1 = NULL;
   return false;
}
#endif

#ifdef HAVE_RVP9
static bool rmp4_video_vp9_configure(rmp4_video_stream_t *s,
      const rmp4_track *track)
{
   video_color_metadata_t color;
   memset(&color, 0, sizeof(color));
   color.primaries = track->color_primaries;
   color.transfer = track->transfer_characteristics;
   color.matrix = track->matrix_coefficients;
   color.range = track->range_present ? (track->full_range ? 2 : 1) : 0;
   color.mastering = track->mastering;
   color.max_cll = track->max_cll;
   color.max_fall = track->max_fall;
   if (track->codec_private_size)
   {
      if (!rvp9_config_parse(track->codec_private, track->codec_private_size,
               &s->vp9_config)
            || !rvp9_config_apply_color(&s->vp9_config, &color, &color))
         return false;
      s->vp9_have_config = 1;
   }
   if (s->vp9_have_config && s->vp9_config.bit_depth != 10
         && (color.transfer == 16 || color.transfer == 18))
      return false;
   s->vp9_color = color;
   s->primaries = color.primaries;
   s->transfer = color.transfer;
   s->matrix = color.matrix;
   s->range = color.range == 2;
   return true;
}

static bool rmp4_video_vp9_header_color(const rmp4_video_stream_t *s,
      const rvp9_hdr *header, video_color_metadata_t *color)
{
   const rvp9_config_t *config = &s->vp9_config;
   if (s->vp9_have_config
         && (config->profile != header->profile
               || config->bit_depth != header->bit_depth
               || config->full_range != header->color_range
               || header->subsampling_x != (config->chroma != 3)
               || header->subsampling_y != (config->chroma < 2)))
      return false;
   return rvp9_color_resolve(header, &s->vp9_color, color);
}

static bool rmp4_video_vp9_color(rmp4_video_stream_t *s)
{
   video_color_metadata_t color;
   if (!rmp4_video_vp9_header_color(s, &s->vp9->hd, &color))
      return false;
   s->primaries = color.primaries;
   s->transfer = color.transfer;
   s->matrix = color.matrix;
   s->range = color.range == 2;
   return true;
}
#endif

#ifdef HAVE_RVP9
static bool rmp4_video_vp9_open_hw(rmp4_video_stream_t *s)
{
   rvp9_hw_session_t *candidate;
   rvp9_hw_backend_t backend;
   rvp9_hw_ops_t ops;
   video_color_metadata_t color;
   rmp4_packet packet;
   size_t sizes[RMP4_VIDEO_MAX_SUPER];
   int found;
   if (!rmp4_video_hw_color_allowed(s))
      return false;
   candidate = (rvp9_hw_session_t *)calloc(1, sizeof(*candidate));
   if (!candidate)
      return false;
   found = s->vp9_initial_valid;
   if (found)
      candidate->pending.header = s->vp9_initial_header;
   else
   {
      found = rmp4_select_track_sample(s->demux, s->track, 0)
         && rmp4_read_packet(s->demux, &packet) == 1;
      rmp4_rewind(s->demux);
      if (found)
      {
         rmp4_video_vp9_superframe(packet.data, packet.size,
               sizes, RMP4_VIDEO_MAX_SUPER);
         found = sizes[0] && !rvp9_parse_frame_header(packet.data, sizes[0],
               NULL, NULL, &candidate->pending.header);
      }
      if (found)
      {
         s->vp9_initial_header = candidate->pending.header;
         s->vp9_initial_valid = 1;
      }
   }
   if (!found || candidate->pending.header.frame_type
         || candidate->pending.header.w != (int)s->width
         || candidate->pending.header.h != (int)s->height
         || !rmp4_video_vp9_header_color(s,
               &candidate->pending.header, &color)
         || ((color.transfer == 16 || color.transfer == 18)
               && candidate->pending.header.bit_depth != 10)
         || !rvp9_hw_backend_open_config(&candidate->pending.header,
               &color, s->vp9_have_config ? &s->vp9_config : NULL,
               10, &ops, &backend))
   {
      free(candidate);
      return false;
   }
   if (!rvp9_hw_session_init_mode(candidate, &ops, 10, backend.packet_decoder))
   {
      backend.close(&ops);
      free(candidate);
      return false;
   }
   s->vp9_hw = candidate;
   s->vp9_backend = backend;
   s->vp9_native_color = color;
   s->primaries = color.primaries;
   s->transfer = color.transfer;
   s->matrix = color.matrix;
   s->range = color.range == 2;
   return true;
}
#endif

static bool rmp4_video_stream_open_decoder(rmp4_video_stream_t *s)
{
   switch (s->codec)
   {
#ifdef HAVE_RAV1
      case RMP4_CODEC_AV1:
         return !s->want_hw || rmp4_video_av1_open(s);
#endif
      case RMP4_CODEC_VP8:
         if (!(s->vp8 = rvp8_video_open()))
            return false;
         return true;
#ifdef HAVE_RVP9
      case RMP4_CODEC_VP9:
         if (s->want_hw && rmp4_video_vp9_open_hw(s))
            return true;
         if (!(s->vp9 = (rvp9_dec*)calloc(1, sizeof(*s->vp9))))
            return false;
         rvp9_set_tile_pool(s->vp9, s->blit_pool, s->blit_bands);
         return true;
#endif
      case RMP4_CODEC_H264:
      {
         const rmp4_track *t = rmp4_get_track(s->demux, s->track);
         if (!(s->h264 = rh264_video_open()))
            return false;
         rh264_video_set_skip_nonref(s->h264, s->catchup);
         if (s->blit_pool && s->blit_bands > 1)
            rh264_video_set_thread_pool(s->h264, s->blit_pool, (int)s->blit_bands);
         if (t && t->codec_private && t->codec_private_size)
            rh264_video_set_extradata(s->h264, t->codec_private,
                  t->codec_private_size);
         if (s->want_hw)
            rh264_video_set_hw(s->h264, 1);
         return true;
      }
      case RMP4_CODEC_H265:
      {
         const rmp4_track *t = rmp4_get_track(s->demux, s->track);
         if (!(s->h265 = rh265_video_open()))
            return false;
         if (s->want_hw)
            rh265_video_retain_parameter_sets(s->h265);
         if (t && t->codec_private && t->codec_private_size)
            rh265_video_set_extradata(s->h265, t->codec_private,
                  t->codec_private_size);
         rmp4_video_hevc_color(s, t);
         rh265_video_set_thread_pool(s->h265, s->blit_pool, s->blit_bands);
         rh265_video_set_skip_nonref(s->h265, s->catchup);
         if (s->want_hw && rmp4_video_hw_color_allowed(s))
            rh265_video_set_hw(s->h265, 1);
         return true;
      }
      default:
         break;
   }
   return false;
}

/* A hardware frame the caller never took goes back to the decoder. */
static void rmp4_video_hwf_drop(rmp4_video_stream_t *s)
{
   if (s->hwf_untaken)
      video_hw_frame_abandon(&s->hwf);
   s->hwf_untaken = 0;
}

/* The picture the decoder just showed on the backend: kept for
 * the caller to take. -1 when the frame cannot stand for the track. */
static int rmp4_video_hwf_take(rmp4_video_stream_t *s)
{
   video_hw_frame_t f;
   unsigned yuv = 0;
   if ((s->h265 ? rh265_video_hw_frame(s->h265, &f)
         : rh264_video_hw_frame(s->h264, &f)) != 0)
      return -1;
   rmp4_video_hwf_drop(s);
   /* the track's size is the frame's: a picture smaller cannot be one */
   if (f.width < s->width || f.height < s->height)
   {
      video_hw_frame_abandon(&f);
      return -1;
   }
   f.width  = s->width;
   f.height = s->height;
   if (     s->matrix == 1
         || (s->matrix != 5 && s->matrix != 6 && s->height >= 720))
      yuv |= IMAGE_YUV_FLAG_BT709;
   if (s->range)
      yuv |= IMAGE_YUV_FLAG_FULL_RANGE;
   f.yuv          = yuv;
   f.color.mastering = s->mastering;
   f.color.max_cll = s->max_cll;
   f.color.max_fall = s->max_fall;
   f.color.primaries = s->primaries;
   f.color.transfer = s->transfer;
   f.color.matrix = s->matrix;
   f.color.range = s->range ? 2 : 1;
   s->hwf         = f;
   s->hwf_untaken = 1;
   s->rndr_kind   = 5;
   return 0;
}

static int rmp4_video_h265_output(rmp4_video_stream_t *s, int discard)
{
   if (!discard)
      return rmp4_video_hwf_take(s);
   rmp4_video_hwf_drop(s);
   s->rndr_kind = 0;
   return 0;
}

static void rmp4_video_stream_close_decoder(rmp4_video_stream_t *s)
{
   rmp4_video_hwf_drop(s);
#ifdef HAVE_RAV1
   if (s->av1)
   {
      rav1_hw_stream_close(s->av1);
      free(s->av1);
      s->av1 = NULL;
   }
#endif
   if (s->vp8)
   {
      rvp8_video_close(s->vp8);
      s->vp8 = NULL;
   }
#ifdef HAVE_RVP9
   s->vp9_active = 0;
   s->vp9_sample = 0;
   s->vp9_restart = 0;
   if (s->vp9_hw)
   {
      rvp9_hw_session_cancel(s->vp9_hw);
      s->vp9_backend.close(&s->vp9_hw->ops);
      free(s->vp9_hw);
      s->vp9_hw = NULL;
   }
   if (s->vp9)
   {
      rvp9_free(s->vp9);
      free(s->vp9);
      s->vp9 = NULL;
   }
#endif
   if (s->h264)
   {
      rh264_video_close(s->h264);
      s->h264 = NULL;
   }
   if (s->h265)
   {
      rh265_video_close(s->h265);
      s->h265 = NULL;
   }
}

/* ------------------------------------------------------------------ */
/* Streaming animation                                                 */
/* ------------------------------------------------------------------ */

/* Staged open, mirroring the WebM glue, so the sliced still-image path
 * can spread the work over several calls:
 *   begin      demuxer + track selection + timestamp-table allocation
 *   scan_step  up to max_packets of the bounded pre-scan
 *   finish     validate, sort composition times, rewind, decoder +
 *              frame-canvas allocation
 * rmp4_video_stream_open composes all three for callers that want the
 * one-shot behaviour. */

static rmp4_video_stream_t *rmp4_video_stream_open_begin(
      const uint8_t *buf, size_t len, size_t avail, int *need_more,
      size_t *need_lo, size_t *need_hi, int allow_hw)
{
   rmp4_video_stream_t *s;
   const rmp4_track *trk = NULL;
   int i, num_tracks;

   (void)allow_hw;
   if (need_more)
      *need_more = 0;
   if (!buf || !len)
      return NULL;

   if (!(s = (rmp4_video_stream_t*)calloc(1, sizeof(*s))))
      return NULL;

   if (!(s->demux = rmp4_open_memory_avail(buf, len, avail, need_more,
         need_lo, need_hi)))
      goto fail;

   /* The video timeline and seek table are immutable after open. */
   if (!rmp4_index_complete(s->demux))
   {
      if (need_more) *need_more = 1;
      goto fail;
   }

   s->input = buf;
   s->input_len = len;
   s->input_avail = avail > len ? len : avail;

   /* Pick the first video track whose codec we can decode. */
   s->track   = -1;
   num_tracks = rmp4_num_tracks(s->demux);
   for (i = 0; i < num_tracks; i++)
   {
      const rmp4_track *t = rmp4_get_track(s->demux, i);
      if (!t || t->type != RMP4_TRACK_VIDEO)
         continue;
      if (t->width < 1 || t->height < 1)
         continue;
      if (t->codec != RMP4_CODEC_VP8
#ifdef HAVE_RVP9
          && t->codec != RMP4_CODEC_VP9
#endif
          && t->codec != RMP4_CODEC_H264
          && t->codec != RMP4_CODEC_H265
#ifdef HAVE_RAV1
          && !(allow_hw && t->codec == RMP4_CODEC_AV1)
#endif
         )
         continue;
      s->track  = i;
      s->codec  = t->codec;
      s->mastering = t->mastering;
      s->max_cll = t->max_cll;
      s->max_fall = t->max_fall;
      s->primaries = t->color_primaries;
      s->matrix   = t->matrix_coefficients;
      s->transfer = t->transfer_characteristics;
      s->range    = t->full_range;
      trk       = t;
      break;
   }
   if (s->track < 0)
      goto fail;
#ifdef HAVE_RVP9
   if (s->codec == RMP4_CODEC_VP9 && !rmp4_video_vp9_configure(s, trk))
      goto fail;
#endif

   s->width  = trk->width;
   s->height = trk->height;

   {
      uint32_t count = 0;
      if (!rmp4_track_pts(s->demux, s->track, &count) || !count
            || sizeof(*s->ts) > SIZE_MAX / (size_t)count)
         goto fail;
      if (!(s->ts = (int64_t*)malloc((size_t)count * sizeof(*s->ts))))
         goto fail;
   }

   return s;

fail:
   rmp4_video_stream_close(s);
   return NULL;
}

/* Copy the demuxer's bounded sample table without reading media.
 * At most max_packets timestamps per call (<= 0 means no limit).
 * Returns 1 when complete, 0 when another slice is needed. */
static int rmp4_video_stream_scan_step(rmp4_video_stream_t *s,
      int max_packets)
{
   /* Timestamps come straight from the moov sample tables - the old
    * packet walk produced exactly these values (it recorded
    * pkt.timestamp for the video track only, in cursor order) but
    * went through rmp4_read_packet, which now gates on each sample's
    * media bytes being resident; the tables need no media bytes at
    * all, so a partially-read file can pre-scan the moment its moov
    * is parsed. */
   uint32_t       count = 0;
   const int64_t *pts   = rmp4_track_pts(s->demux, s->track, &count);
   int            walked = 0;

   if (!pts)
      return 1;
   while ((uint32_t)s->ts_count < count)
   {
      if (max_packets > 0 && walked >= max_packets)
         return 0;
      s->ts[s->ts_count] = pts[s->ts_count];
      s->ts_count++;
      s->num_frames++;
      walked++;
   }
   return 1;
}

static int rmp4_video_stream_open_finish(rmp4_video_stream_t *s)
{
   if (s->num_frames < 1)
      return -1;
   /* The sample table lists composition times in decode order; with
    * B-frames the decoder hands pictures out reordered by those times,
    * so sort them into the presentation timeline the displayed frames
    * actually follow. Without this a 30 fps recording with a reorder
    * depth of two was paced 133/0/0/66 ms instead of 33 ms a frame. */
   qsort(s->ts, (size_t)s->ts_count, sizeof(*s->ts), rmp4_video_ts_cmp);
   rmp4_rewind(s->demux);

   if (!rmp4_video_stream_open_decoder(s))
      return -1;

   if ((size_t)s->width > SIZE_MAX / sizeof(uint32_t) / s->height)
      return -1;

   return 0;
}

rmp4_video_stream_t *rmp4_video_stream_open(const uint8_t *buf,
      size_t len)
{
   rmp4_video_stream_t *s;

   if (!(s = rmp4_video_stream_open_begin(buf, len, len, NULL,
         NULL, NULL, 0)))
      return NULL;
   rmp4_video_stream_scan_step(s, 0);
   if (rmp4_video_stream_open_finish(s) != 0)
   {
      rmp4_video_stream_close(s);
      return NULL;
   }
   return s;
}

static rmp4_video_stream_t *rmp4_video_stream_open_avail_internal(const uint8_t *buf,
      size_t len, size_t avail, int *need_more,
      size_t *need_lo, size_t *need_hi, int allow_hw)
{
   rmp4_video_stream_t *s;

   if (need_more)
      *need_more = 0;
   if (!(s = rmp4_video_stream_open_begin(buf, len, avail, need_more,
         need_lo, need_hi, allow_hw)))
      return NULL;
   /* The pre-scan reads the moov sample tables (no media bytes), so
    * once the open itself succeeded it always completes. */
   rmp4_video_stream_scan_step(s, 0);
   if (rmp4_video_stream_open_finish(s) != 0)
   {
      rmp4_video_stream_close(s);
      return NULL;
   }
   return s;
}

rmp4_video_stream_t *rmp4_video_stream_open_avail(const uint8_t *buf,
      size_t len, size_t avail, int *need_more, size_t *need_lo, size_t *need_hi)
{
   return rmp4_video_stream_open_avail_internal(buf, len, avail, need_more,
         need_lo, need_hi, 0);
}

rmp4_video_stream_t *rmp4_video_stream_open_hw_avail(const uint8_t *buf,
                                                     size_t len, size_t avail,
                                                     int *need_more,
                                                     size_t *need_lo,
                                                     size_t *need_hi)
{
   return rmp4_video_stream_open_avail_internal(buf, len, avail, need_more,
                                                need_lo, need_hi, 1);
}

bool rmp4_video_stream_audio_track(const rmp4_video_stream_t *s,
      unsigned ordinal, video_audio_track_t *out)
{
   int i;
   enum rmp4_language_kind kind;
   if (!out) return false;
   memset(out, 0, sizeof(*out));
   if (!s) return false;
   for (i = 0; i < rmp4_num_tracks(s->demux); i++)
   {
      const rmp4_track *track = rmp4_get_track(s->demux, i);
      if (!track || track->type != RMP4_TRACK_AUDIO) continue;
      if (ordinal)
      {
         ordinal--;
         continue;
      }
      out->index = i;
      out->sample_rate = track->sample_rate;
      out->channels = track->channels;
      out->codec_id = track->codec_id;
      out->language = rmp4_get_track_language(s->demux, i,
            &out->language_size, &kind);
      if (kind == RMP4_LANGUAGE_MDHD)
         out->language_kind = VIDEO_AUDIO_LANGUAGE_MP4_PACKED;
      else if (kind == RMP4_LANGUAGE_BCP47)
         out->language_kind = VIDEO_AUDIO_LANGUAGE_TEXT;
      switch (track->codec)
      {
         case RMP4_CODEC_AAC: out->codec = VIDEO_AUDIO_AAC; break;
         case RMP4_CODEC_AC3: out->codec = VIDEO_AUDIO_AC3; break;
         case RMP4_CODEC_OPUS: out->codec = VIDEO_AUDIO_OPUS; break;
         case RMP4_CODEC_VORBIS: out->codec = VIDEO_AUDIO_VORBIS; break;
         default: break;
      }
      return true;
   }
   return false;
}

void rmp4_video_stream_close(rmp4_video_stream_t *s)
{
   if (!s)
      return;
   rmp4_video_stream_close_decoder(s);
   if (s->demux)
      rmp4_close(s->demux);
#ifdef HAVE_RAV1
   free(s->av1_hdr_points);
   free(s->av1_sequence_bytes);
#endif
   free(s->ts);
   free(s->frame);
   free(s);
}

void rmp4_video_stream_get_info(const rmp4_video_stream_t *s,
      unsigned *width, unsigned *height, int *num_frames, int *loop_count)
{
   if (!s)
      return;
   if (width)
      *width      = s->width;
   if (height)
      *height     = s->height;
   if (num_frames)
      *num_frames = s->num_frames;
   if (loop_count)
      *loop_count = 0;   /* video loops indefinitely */
}

void rmp4_video_stream_set_argb(rmp4_video_stream_t *s, int argb)
{
   if (s)
      s->emit_argb = argb ? 1 : 0;
}

/* Display duration of packet 'idx', in ms, from the pre-scanned
 * timestamp table; 0 when unknown (caller applies its default). */
static int rmp4_video_duration_ms(const rmp4_video_stream_t *s, int idx)
{
   /* Quantise against the accumulated timeline, not per delta: flooring
    * each delta independently loses the fractional millisecond every
    * frame - a 33.333 ms (30 fps) stream came out 33+33+33..., running
    * one percent fast and drifting further each loop. Differencing the
    * floored absolute times emits 33/33/34 so the sum stays within a
    * millisecond of the container's timeline. */
   int64_t t0, t1;
   if (idx + 1 < s->ts_count)
   { t0 = s->ts[idx]; t1 = s->ts[idx + 1]; }
   else if (s->ts_count >= 2)
   { t0 = s->ts[s->ts_count - 2]; t1 = s->ts[s->ts_count - 1]; }
   else
      return 0;
   if (t1 <= t0)
      return 0;
   return (int)(t1 / 1000000 - t0 / 1000000);
}

static int rmp4_video_timestamp_index(const rmp4_video_stream_t *s, int64_t time)
{
   int lo = 0, hi = s->ts_count;
   while (lo < hi)
   {
      int mid = lo + (hi - lo) / 2;
      if (s->ts[mid] < time) lo = mid + 1;
      else hi = mid;
   }
   return lo;
}

static int rmp4_video_h265_probe(rmp4_video_stream_t *s,
      const int64_t *pts)
{
   const rmp4_track *track = rmp4_get_track(s->demux, s->track);
   rh265_slice_info_t slice;
   size_t begin, end, length = 0, bytes;
   unsigned i, width, type;
   int ret;
   if (!track || track->codec_private_size < 22) return -1;
   width = 1 + (track->codec_private[21] & 3);
   if (!rmp4_track_sample_span(s->demux, s->track, s->h265_probe_sample,
            &begin, &end) || s->h265_probe_offset > end - begin) return -1;
   begin += s->h265_probe_offset;
   if (begin == end)
   {
      s->h265_probe_sample++;
      s->h265_probe_offset = s->h265_probe_need = 0;
      return 0;
   }
   if (end - begin < width + 2) return -1;
   s->h265_need_lo = begin;
   s->h265_need_hi = begin + width + 2;
   if (s->h265_need_hi > s->input_avail) return 2;
   for (i = 0; i < width; i++) length = (length << 8) | s->input[begin + i];
   if (length < 2 || length > end - begin - width) return -1;
   begin += width;
   type = (s->input[begin] >> 1) & 63;
   if (type > 31)
   {
      s->h265_probe_offset += width + length;
      return 0;
   }
   bytes = s->h265_probe_need ? s->h265_probe_need : 256;
   if (bytes > length) bytes = length;
   s->h265_need_hi = begin + bytes;
   if (s->h265_need_hi > s->input_avail) return 2;
   ret = rh265_video_get_slice(s->h265, s->input + begin, bytes, &slice);
   if (ret < 0)
   {
      if (bytes == length || bytes >= 65536) return -1;
      s->h265_probe_need = bytes * 2;
      return 0;
   }
   ret = rh265_video_output_timing_advance(s->h265, &s->h265_timing,
         &slice, pts[s->h265_probe_sample], s->h265_timestamp);
   s->h265_probe_sample++;
   s->h265_probe_offset = s->h265_probe_need = 0;
   return ret < 0 ? -1 : 0;
}

static int rmp4_video_h265_picture(rmp4_video_stream_t *s, int *duration_ms)
{
   rh265_output_timing_t *timing = &s->h265_timing;
   uint32_t count = 0;
   const int64_t *pts = rmp4_track_pts(s->demux, s->track, &count);
   unsigned budget = 16;
   if (!pts) return -1;
   if (!s->h265_timing_active)
   {
      if (rh265_video_output_timing(s->h265, s->h265_timestamp, timing)) return -1;
      s->h265_probe_sample = s->h265_decode_sample;
      s->h265_probe_offset = s->h265_probe_need = 0;
      s->h265_timing_active = 1;
   }
   while (!timing->next_valid && s->h265_probe_sample < count && budget--)
   {
      int ret = rmp4_video_h265_probe(s, pts);
      if (ret < 0) return -1;
      if (ret == 2)
      {
         s->waiting = RMP4_VIDEO_WAIT_INPUT;
         return 2;
      }
   }
   if (!timing->next_valid && s->h265_probe_sample < count)
   {
      s->waiting = RMP4_VIDEO_WAIT_DECODER;
      return 2;
   }
   if (!timing->next_valid)
   {
      unsigned i;
      for (i = 0; i < timing->count; i++)
         if (timing->pending[i] > s->h265_timestamp
               && (!timing->next_valid || timing->pending[i] < timing->next_timestamp))
         {
            timing->next_timestamp = timing->pending[i];
            timing->next_valid = 1;
         }
   }
   s->disp_idx = timing->next_valid
      ? rmp4_video_timestamp_index(s, timing->next_timestamp) : s->ts_count;
   if (duration_ms)
   {
      if (timing->next_valid)
      {
         int64_t delta = timing->next_timestamp / 1000000
            - s->h265_timestamp / 1000000;
         *duration_ms = delta > 0 && delta <= 2147483647 ? (int)delta : 0;
      }
      else *duration_ms = rmp4_video_duration_ms(s, s->ts_count - 1);
   }
   s->h265_have_time = 1;
   s->h265_display_timestamp = s->h265_timestamp;
   s->h265_picture_pending = s->h265_timing_active = 0;
   s->h265_need_lo = s->h265_need_hi = 0;
   return 1;
}

#ifdef HAVE_RAV1
static int rmp4_video_av1_hdr_point(rmp4_video_stream_t *s, uint32_t sample);

static int rmp4_video_av1_learn_hdr(rmp4_video_stream_t *s)
{
   if (s->av1_decode_sample != s->av1_hdr_scan_sample) return 1;
   if (!s->av1_hdr_count)
   {
      s->av1_hdr_scanned = s->av1_hdr_seed;
      if (!rmp4_video_av1_hdr_point(s, 0)) return 0;
   }
   s->av1_hdr_scanned = s->av1->hdr;
   if (!rmp4_video_av1_hdr_point(s, s->av1_decode_sample + 1)) return 0;
   s->av1_hdr_scan_offset = s->av1_hdr_scan_need = 0;
   s->av1_hdr_scan_sample++;
   return 1;
}

static int rmp4_video_av1_result(rmp4_video_stream_t *s,
      int ret, video_hw_frame_t *frame)
{
   if (ret == RAV1_HW_STREAM_FRAME)
   {
      if (frame->width != s->width || frame->height != s->height)
      {
         video_hw_frame_abandon(frame);
         return -1;
      }
      if (s->matrix == 1)
         frame->yuv |= IMAGE_YUV_FLAG_BT709;
      else
         frame->yuv &= ~IMAGE_YUV_FLAG_BT709;
      frame->color.mastering = s->mastering;
      frame->color.max_cll = s->max_cll;
      frame->color.max_fall = s->max_fall;
      frame->color.primaries = s->primaries;
      frame->color.transfer = s->transfer;
      frame->color.matrix = s->matrix;
      frame->color.range = s->range ? 2 : 1;
      if (!rav1_hdr_metadata_merge(&frame->color, &s->av1->output_hdr))
      {
         video_hw_frame_abandon(frame);
         s->av1->error = -1;
         return -1;
      }
      rmp4_video_hwf_drop(s);
      s->hwf = *frame;
      s->hwf_untaken = 1;
      s->rndr_kind = 5;
      return 3;
   }
   if (ret == RAV1_HW_STREAM_DISCARDED)
   {
      rmp4_video_hwf_drop(s);
      s->rndr_kind = 0;
      return 3;
   }
   if (ret == RAV1_HW_STREAM_PROGRESS || ret == RAV1_HW_STREAM_PENDING)
      return 4;
   if (ret == RAV1_HW_STREAM_BUSY)
      return 2;
   return ret;
}

static int rmp4_video_av1_packet(rmp4_video_stream_t *s, const rmp4_packet *pkt,
                                 int discard)
{
   video_hw_frame_t frame;
   int ret;
   if (!s->av1)
      return -1;
   if (!s->av1->packet && rav1_hw_stream_begin(s->av1, pkt->data, pkt->size))
      return -1;
   ret = rav1_hw_stream_step(s->av1, &frame, discard != 0);
   if (ret == RAV1_HW_STREAM_END)
   {
      if (!rmp4_video_av1_learn_hdr(s))
      {
         s->av1->error = -1;
         return -1;
      }
      s->av1_decode_sample++;
   }
   if (!s->av1_hdr_initial_set &&
       (ret == RAV1_HW_STREAM_FRAME || ret == RAV1_HW_STREAM_DISCARDED
             || ret == RAV1_HW_STREAM_PENDING))
   {
      s->av1_hdr_initial = s->av1->output_hdr;
      s->av1_hdr_initial_set = 1;
   }
   return rmp4_video_av1_result(s, ret, &frame);
}

static int rmp4_video_av1_output(rmp4_video_stream_t *s, int discard, int terminal)
{
   video_hw_frame_t frame;
   int ret = terminal ? rav1_hw_stream_finish(s->av1, &frame, discard != 0)
                      : rav1_hw_stream_output(s->av1, &frame, discard != 0);
   return rmp4_video_av1_result(s, ret, &frame);
}
#endif

/* Decode one demuxed packet into s->frame. Returns 1 when a picture was
 * produced, 0 when the packet decoded but is not displayed, -1 on a
 * decode error. */
#ifdef HAVE_RVP9
static int rmp4_video_vp9_hw_packet(rmp4_video_stream_t *s,
      const rmp4_packet *packet, int discard)
{
   int ret;
   if (s->vp9_restart)
   {
      ret = s->vp9_backend.restart(s->vp9_hw->ops.decoder);
      if (ret)
         return ret > 0 ? 2 : -1;
      s->vp9_restart = 0;
   }
   if (!s->vp9_active)
   {
      size_t offset = 0;
      int i;
      s->vp9_count = rmp4_video_vp9_superframe(packet->data,
            packet->size, s->vp9_sizes, RMP4_VIDEO_MAX_SUPER);
      s->vp9_last_show = -1;
      for (i = 0; i < s->vp9_count; i++)
      {
         if (!s->vp9_sizes[i] || s->vp9_sizes[i] > packet->size - offset)
            return -1;
         if (packet->data[offset] & 0x0a)
            s->vp9_last_show = i;
         offset += s->vp9_sizes[i];
      }
      s->vp9_index = s->vp9_submitted = 0;
      s->vp9_offset = 0;
      s->vp9_discard = discard;
      s->vp9_active = 1;
   }
   if (s->vp9_discard != discard)
      return -1;
   if (s->vp9_index < s->vp9_count)
   {
      if (!s->vp9_submitted)
      {
         if (!s->vp9_hw->phase)
         {
            video_color_metadata_t color;
            int dims[RVP9_REF_FRAMES * 2];
            unsigned i;
            for (i = 0; i < RVP9_REF_FRAMES; i++)
            {
               dims[i * 2] = s->vp9_hw->reference_slots[i] >= 0
                  ? s->vp9_hw->header.w : 0;
               dims[i * 2 + 1] = s->vp9_hw->reference_slots[i] >= 0
                  ? s->vp9_hw->header.h : 0;
            }
            ret = rvp9_parse_frame_header(packet->data + s->vp9_offset,
                  s->vp9_sizes[s->vp9_index], &s->vp9_hw->header,
                  dims, &s->vp9_probe_header);
            if (ret < 0 || (!ret
                  && (!rmp4_video_vp9_header_color(s, &s->vp9_probe_header, &color)
                     || color.primaries != s->vp9_native_color.primaries
                     || color.transfer != s->vp9_native_color.transfer
                     || color.matrix != s->vp9_native_color.matrix
                     || color.range != s->vp9_native_color.range)))
               return -1;
         }
         ret = rvp9_hw_session_submit(s->vp9_hw,
               packet->data + s->vp9_offset, s->vp9_sizes[s->vp9_index]);
         if (ret > 0)
            return 2;
         if (ret < 0)
            return -1;
         s->vp9_submitted = 1;
      }
      if (s->vp9_hw->output_slot >= 0
            && (discard || s->vp9_index < s->vp9_last_show))
         rvp9_hw_session_discard_output(s->vp9_hw);
      s->vp9_offset += s->vp9_sizes[s->vp9_index++];
      s->vp9_submitted = 0;
      /* Yield between coded pictures, retaining the packet's input floor. */
      if (s->vp9_index < s->vp9_count)
         return 4;
   }
   if (s->vp9_backend.drain && s->vp9_sample + 1 >= (uint32_t)s->num_frames)
   {
      ret = s->vp9_backend.drain(s->vp9_hw->ops.decoder, discard != 0);
      if (ret < 0)
         return -1;
   }
   if (s->vp9_hw->output_slot >= 0)
   {
      video_hw_frame_t frame;
      ret = rvp9_hw_session_output(s->vp9_hw, &frame);
      if (ret > 0)
         return 2;
      if (ret < 0)
         return -1;
      frame.color = s->vp9_native_color;
      if (frame.color.matrix == 1)
         frame.yuv |= IMAGE_YUV_FLAG_BT709;
      else
         frame.yuv &= ~IMAGE_YUV_FLAG_BT709;
      if (frame.color.range == 2)
         frame.yuv |= IMAGE_YUV_FLAG_FULL_RANGE;
      else
         frame.yuv &= ~IMAGE_YUV_FLAG_FULL_RANGE;
      rmp4_video_hwf_drop(s);
      s->hwf = frame;
      s->hwf_untaken = 1;
      s->rndr_kind = 5;
   }
   s->vp9_active = 0;
   s->vp9_sample++;
   return s->vp9_last_show >= 0 ? 1 : 0;
}
#endif

static int rmp4_video_decode_packet(rmp4_video_stream_t *s,
      const rmp4_packet *pkt, int discard)
{
   /* Decoder-owned planes expire on decode; an exported lease stays
    * valid until a replacement picture arrives or the caller takes it. */
   (void)discard;
#ifdef HAVE_RAV1
   if (s->codec == RMP4_CODEC_AV1)
      return rmp4_video_av1_packet(s, pkt, discard);
#endif
   if (s->rndr_kind != 5)
      s->rndr_kind = 0;
#ifdef HAVE_RVP9
   if (s->vp9_hw)
      return rmp4_video_vp9_hw_packet(s, pkt, discard);
#endif
   /* A decoder can be absent if the re-open in rewind hit OOM. */
   if (!s->vp8
#ifdef HAVE_RVP9
       && !s->vp9
#endif
       && !s->h264
       && !s->h265
      )
      return -1;
#ifdef HAVE_RVP9
   if (s->codec == RMP4_CODEC_VP9)
   {
      size_t sizes[RMP4_VIDEO_MAX_SUPER];
      const uint8_t *frame = pkt->data;
      int nf = rmp4_video_vp9_superframe(pkt->data, pkt->size,
            sizes, RMP4_VIDEO_MAX_SUPER);
      int i, r, show, last_show = -1;
      for (i = 0; i < nf; i++)
      {
         r = rvp9_decode_frame(s->vp9, frame, sizes[i], &show);
         if (r < 0 || !rmp4_video_vp9_color(s))
            return -1;
         if (show >= 0)
            last_show = show;
         frame += sizes[i];
      }
      if (last_show >= 0)
      {
         s->rndr_kind     = 2;
         s->rndr_vp9_show = last_show;
         return 1;
      }
      return 0;
   }
#endif
   if (s->codec == RMP4_CODEC_VP8)
   {
      /* VP8 frame tag: bit 4 of byte 0 is show_frame. */
      int shown = (pkt->size > 0) && (pkt->data[0] & 0x10);
      if (rvp8_video_decode(s->vp8, pkt->data, pkt->size) != 0)
         return -1;
      if (!shown)
         return 0;
      s->rndr_kind = 1;
      return 1;
   }
   if (s->codec == RMP4_CODEC_H264)
   {
      /* rh264 reconstructs Baseline through High profile (CAVLC and
       * CABAC entropy coding), handing pictures out in display order.
       * Anything it still cannot handle is skipped rather than
       * aborting the stream, holding the last good picture until the
       * next key frame restarts the prediction chain. A key frame
       * that fails to decode is a real error. */
      {
         int dec;
         /* Once any frame in a prediction chain fails (e.g. an
          * entropy-coding mode this decoder refuses), the pictures the
          * following inter frames predict from are not the ones the
          * encoder used, and decoding them anyway produces drifting
          * garbage. Freeze on the last good picture until the next key
          * frame restarts the chain cleanly. */
         if (s->wait_key && !pkt->keyframe)
         {
            s->disp_idx++;  /* the sample's presentation slot is gone */
            return 0;
         }
         dec = rh264_video_decode(s->h264, pkt->data, pkt->size);
         if (dec == 2)
            return 2;
         if (dec < 0)
         {
            if (pkt->keyframe)
               return -1;
            s->wait_key = 1;
            return 0;
         }
         s->wait_key = 0;
         if (dec == 0)   /* consumed; picture held for display reordering */
         {
            /* Unless it was passed over to catch up: then its slot on
             * the timeline has gone by, like a refused picture's, and
             * the durations of what follows are read from theirs. */
            if (rh264_video_dropped(s->h264))
               s->disp_idx++;
            return 0;
         }
      }
      if (rh264_video_is_hw(s->h264))
         return rmp4_video_hwf_take(s) == 0 ? 1 : -1;
      /* Planes stay valid until the next decode; defer conversion. */
      if (!rh264_video_plane(s->h264, 0, NULL, NULL, NULL))
         return -1;
      s->rndr_kind = 3;
      return 1;
   }
   if (s->codec == RMP4_CODEC_H265)
   {
      /* rh265 reconstructs Main-profile pictures (intra, P and B with
       * display reordering), handing pictures out in display order.
       * Anything it still cannot handle (tiles, 4:2:2) is
       * skipped rather than aborting the stream, holding the last good
       * picture until the next key frame restarts the prediction
       * chain.  A key frame that fails to decode is a real error. */
      int dec;
      if (s->wait_key && !pkt->keyframe)
      {
         s->disp_idx++;  /* the sample's presentation slot is gone */
         s->h265_decode_sample++;
         return 0;
      }
      dec = discard
         ? rh265_video_decode_timed_discard(s->h265, pkt->data, pkt->size,
               pkt->timestamp, &s->h265_timestamp)
         : (s->h265_ahead ? rh265_video_decode_timed_ahead
               : rh265_video_decode_timed)(s->h265, pkt->data, pkt->size,
               pkt->timestamp, &s->h265_timestamp);
      if (dec == 2) return 2;
      if (dec == 3) return rmp4_video_h265_output(s, discard) == 0 ? 3 : -1;
      s->h265_decode_sample++;
      if (dec < 0)
      {
         if (pkt->keyframe)
            return -1;
         s->wait_key = 1;
         return 0;
      }
      s->wait_key = 0;
      if (dec == 0)   /* consumed; picture held for display reordering */
      {
         if (rh265_video_dropped(s->h265))
            s->disp_idx++; /* passed over: its slot has gone by */
         return 0;
      }
      if (rh265_video_is_hw(s->h265))
         return rmp4_video_h265_output(s, discard) == 0 ? 1 : -1;
      /* Planes stay valid until the next decode; defer conversion. */
      if (!rh265_video_plane(s->h265, 0, NULL, NULL, NULL))
         return -1;
      s->rndr_kind = 4;
      return 1;
   }
   return -1;
}

/* Advance by exactly one of the chosen track's packets (skipping other
 * tracks' packets, which are header reads only), or by one drained
 * reorder-queue picture once the packets are exhausted.  Returns 1
 * when a displayed picture was consumed (render it on demand), 0 when
 * the packet decoded but is not displayed, 2 when the next packet's
 * bytes or decoder capacity are unavailable (retry later),
 * -1 at the end of a pass or on a
 * decode error. */
static int rmp4_video_stream_step(rmp4_video_stream_t *s,
      int *duration_ms, int discard)
{
   rmp4_packet pkt;
   int drained = -1;
#ifdef HAVE_RVP9
   int vp9_eof = 0;
#endif
#ifdef HAVE_RAV1
   int av1_eof = 0;
#endif

   if (s->h265_picture_pending)
      return rmp4_video_h265_picture(s, duration_ms);

   for (;;)
   {
      int r;
      if (s->pending)
      {
         pkt = s->pending_packet;
         r = 1;
      }
      else
      {
         s->pending_floor = rmp4_consumed(s->demux);
         r = rmp4_read_packet(s->demux, &pkt);
      }
      if (r == RMP4_READ_AGAIN)
         /* The sample's bytes are not buffered yet.  Do NOT fall
          * through to the drain below: packets remain, and flushing
          * the H.264 reorder queue now would present its held
          * pictures early and out of order. */
      {
#ifdef HAVE_RAV1
         if (s->av1 && s->av1->backend.drain)
         {
            int output = rmp4_video_av1_output(s, discard, 0);
            if (output < 0) return -1;
            if (output == 3)
            {
               if (duration_ms) *duration_ms = rmp4_video_duration_ms(s, s->disp_idx);
               s->disp_idx++;
               return 1;
            }
         }
#endif
         s->waiting = RMP4_VIDEO_WAIT_INPUT;
         return 2;
      }
      if (r != 1)
      {
         if (r < 0) return -1;
#ifdef HAVE_RVP9
         vp9_eof = r == 0;
#endif
#ifdef HAVE_RAV1
         av1_eof = r == 0;
#endif
         break;
      }
      if (pkt.track != s->track)
         continue;
      r = rmp4_video_decode_packet(s, &pkt, discard);
      if (r == 2 || r == 3 || r == 4)
      {
         s->pending_packet = pkt;
         s->pending = 1;
         if (r == 4)
            return 0;
         if (r == 2)
         {
            s->waiting = RMP4_VIDEO_WAIT_DECODER;
            return 2;
         }
         if (s->h265)
         {
            s->h265_picture_pending = 1;
            return rmp4_video_h265_picture(s, duration_ms);
         }
         if (duration_ms) *duration_ms = rmp4_video_duration_ms(s, s->disp_idx);
         s->disp_idx++;
         return 1;
      }
      s->pending = 0;
      if (r < 0)
         return -1;      /* decode error: end the animation */
      if (r == 0)
         return 0;       /* non-shown frame                  */
      if (s->h265)
      {
         s->h265_picture_pending = 1;
         return rmp4_video_h265_picture(s, duration_ms);
      }
      if (duration_ms)
         *duration_ms = rmp4_video_duration_ms(s, s->disp_idx);
      s->disp_idx++;
      return 1;
   }
#ifdef HAVE_RAV1
   if (s->av1)
   {
      int output;
      if (!av1_eof) return -1;
      output = rmp4_video_av1_output(s, discard, 1);
      if (output == 2)
      {
         s->waiting = RMP4_VIDEO_WAIT_DECODER;
         return 2;
      }
      if (output == 3)
      {
         if (duration_ms) *duration_ms = rmp4_video_duration_ms(s, s->disp_idx);
         s->disp_idx++;
         return 1;
      }
      s->completed = output == 0;
      return -1;
   }
#endif
#ifdef HAVE_RVP9
   if (s->vp9_hw)
   {
      if (!vp9_eof)
         return -1;
      if (s->vp9_backend.drain)
      {
         int ret = s->vp9_backend.drain(s->vp9_hw->ops.decoder, discard != 0);
         if (ret < 0)
            return -1;
         if (ret > 0)
         {
            s->waiting = RMP4_VIDEO_WAIT_DECODER;
            return 2;
         }
      }
      s->completed = 1;
      return -1;
   }
#endif
   /* Out of packets. Display reordering can leave the last few pictures
    * queued inside the H.264 decoder; hand them out before ending the
    * pass, one per call, on the same presentation clock. */
   if (s->h264 && (drained = rh264_video_drain(s->h264)) == 2)
   {
      s->waiting = RMP4_VIDEO_WAIT_DECODER;
      return 2;
   }
   if (s->h264 && drained < -1)
      return -1;
   if (s->h264 && drained == 0)
   {
      s->rndr_kind = 0;   /* the drain replaced the current picture */
      if (rh264_video_is_hw(s->h264))
      {
         if (rmp4_video_hwf_take(s) != 0)
            return -1;
         if (duration_ms)
            *duration_ms = rmp4_video_duration_ms(s, s->disp_idx);
         s->disp_idx++;
         return 1;
      }
      if (rh264_video_plane(s->h264, 0, NULL, NULL, NULL))
      {
         s->rndr_kind = 3;
         if (duration_ms)
            *duration_ms = rmp4_video_duration_ms(s, s->disp_idx);
         s->disp_idx++;
         return 1;
      }
   }
   if (s->h265 && (drained = discard
            ? rh265_video_drain_timed_discard(s->h265, &s->h265_timestamp)
            : rh265_video_drain_timed(s->h265, &s->h265_timestamp)) == 2)
   {
      s->waiting = RMP4_VIDEO_WAIT_DECODER;
      return 2;
   }
   if (s->h265 && drained < -1)
      return -1;
   if (s->h265 && drained == 0)
   {
      s->rndr_kind = 0;   /* the drain replaced the current picture */
      if (rh265_video_is_hw(s->h265))
      {
         if (rmp4_video_h265_output(s, discard) != 0) return -1;
         s->h265_picture_pending = 1;
         return rmp4_video_h265_picture(s, duration_ms);
      }
      if (rh265_video_plane(s->h265, 0, NULL, NULL, NULL))
      {
         s->rndr_kind = 4;
         s->h265_picture_pending = 1;
         return rmp4_video_h265_picture(s, duration_ms);
      }
   }
   s->completed = 1;
   return -1;             /* end of one pass */
}

static int rmp4_video_stream_advance(rmp4_video_stream_t *s,
      int *duration_ms, int discard)
{
   int r;
   int64_t started = 0;
   int bounded;

   if (!s)
      return -1;
   bounded = s->h265_ahead && s->h265 && rh265_video_is_hw(s->h265);
   s->completed = 0;
   s->waiting = 0;
#ifdef HAVE_RAV1
   bounded |= s->codec == RMP4_CODEC_AV1;
#endif
#ifdef HAVE_RVP9
   bounded |= s->vp9_hw != NULL;
#endif
   if (bounded)
      started = cpu_features_get_time_usec();

   /* Retry later for input or decoder capacity, without spinning. */
   while ((r = rmp4_video_stream_step(s, duration_ms, discard)) == 0)
   {
      if (bounded && cpu_features_get_time_usec() - started >= 4000)
      {
         s->waiting = RMP4_VIDEO_WAIT_DECODER;
         return 2;
      }
   }
   if (r != 2)
      s->waiting = RMP4_VIDEO_WAIT_NONE;
   return r;
}

int rmp4_video_stream_skip(rmp4_video_stream_t *s, int *duration_ms)
{
   return rmp4_video_stream_advance(s, duration_ms, 0);
}

int rmp4_video_stream_discard(rmp4_video_stream_t *s, int *duration_ms)
{
   int ret = rmp4_video_stream_advance(s, duration_ms, 1);
   if (s && ret == 1)
   {
      rmp4_video_hwf_drop(s);
      s->rndr_kind = 0;
   }
   return ret;
}

int rmp4_video_stream_waiting(const rmp4_video_stream_t *s)
{
   return s && s->waiting;
}

enum rmp4_video_wait_reason rmp4_video_stream_wait_reason(
      const rmp4_video_stream_t *s)
{
   return s ? (enum rmp4_video_wait_reason)s->waiting : RMP4_VIDEO_WAIT_NONE;
}

void rmp4_video_stream_set_decode_ahead(rmp4_video_stream_t *s, int enable)
{
   if (s)
      s->h265_ahead = enable != 0;
}

int rmp4_video_stream_set_hw(rmp4_video_stream_t *s, int enable)
{
#ifdef HAVE_RAV1
   if (s && s->codec == RMP4_CODEC_AV1)
   {
      if (!enable || s->av1)
         return s->av1 != NULL;
      s->want_hw = 1;
      if (s->disp_idx || s->rndr_kind || s->pending)
         rmp4_video_stream_rewind(s);
      else
         rmp4_video_av1_open(s);
      if (!s->av1)
         s->want_hw = 0;
      return s->av1 != NULL;
   }
#endif
#ifdef HAVE_RVP9
   if (s && s->codec == RMP4_CODEC_VP9)
   {
      if (!enable || s->vp9_hw)
         return s->vp9_hw != NULL;
      s->want_hw = 1;
      rmp4_video_stream_rewind(s);
      if (!s->vp9_hw)
         s->want_hw = 0;
      return s->vp9_hw != NULL;
   }
#endif
   if (!s || (s->codec != RMP4_CODEC_H264 && s->codec != RMP4_CODEC_H265))
      return 0;
   if (!enable)
      return s->h265 ? rh265_video_is_hw(s->h265)
         : s->h264 && rh264_video_is_hw(s->h264);
   /* Exported frames carry the source color metadata. Importers handle
    * PQ/HLG or refuse the image, preserving the software fallback. */
   if (!rmp4_video_hw_color_allowed(s))
      return 0;
   if (s->want_hw)
      return s->h265 ? rh265_video_is_hw(s->h265)
         : s->h264 && rh264_video_is_hw(s->h264);
   s->want_hw = 1;
   /* HEVC setup needs a fresh parse retaining the parameter NALs.
    * An already-running stream also restarts before changing backends. */
   if (s->h265 || s->disp_idx || s->rndr_kind)
      rmp4_video_stream_rewind(s);
   else if (s->h264)
      rh264_video_set_hw(s->h264, 1);
   return s->h265 ? rh265_video_is_hw(s->h265)
         : s->h264 && rh264_video_is_hw(s->h264);
}

void rmp4_video_stream_stop_hw(rmp4_video_stream_t *s)
{
   if (!s) return;
   s->want_hw = 0;
   rmp4_video_stream_rewind(s);
}

int rmp4_video_stream_hw_frame(rmp4_video_stream_t *s,
      video_hw_frame_t *out)
{
   if (!s || s->h265_picture_pending || s->rndr_kind != 5 || !s->hwf_untaken || !out)
      return 0;
   *out           = s->hwf;
   s->hwf_untaken = 0;
   return 1;
}

int rmp4_video_stream_set_output_stride(rmp4_video_stream_t *s,
      uint32_t *out, unsigned stride)
{
   if (!s)
      return 0;
   if (!stride)
      stride = s->width;
   if (out && (stride < s->width
            || (s->height && (size_t)stride > SIZE_MAX / 8 / s->height)))
      return 0;
   s->out        = out;
   s->out_stride = out ? stride : 0;
   return 1;
}

void rmp4_video_stream_set_output(rmp4_video_stream_t *s, uint32_t *out)
{
   rmp4_video_stream_set_output_stride(s, out, 0);
}

void rmp4_video_stream_set_want_fp16(rmp4_video_stream_t *s, int want)
{
   if (s)
      s->want_fp16 = want ? 1 : 0;
}

int rmp4_video_stream_is_fp16(const rmp4_video_stream_t *s)
{
   return s && s->is_fp16;
}

int rmp4_video_stream_is_hdr(const rmp4_video_stream_t *s)
{
   return s && (s->transfer == 16 || s->transfer == 18);
}

/* 8-bit 4:2:0 by the sample entry, in a matrix the planes' consumer
 * knows (BT.601 or BT.709; BT.2020 needs a wider format). */
int rmp4_video_stream_can_planar(const rmp4_video_stream_t *s)
{
   const rmp4_track *t;
   if (     !s || rmp4_video_stream_is_hdr(s)
         || s->matrix == 9 || s->matrix == 10
         || !(t = rmp4_get_track(s->demux, s->track)))
      return 0;
   switch (s->codec)
   {
      case RMP4_CODEC_VP8:
         return 1;
#ifdef HAVE_RVP9
      case RMP4_CODEC_VP9:
         return s->vp9_have_config && s->vp9_config.bit_depth == 8
            && s->vp9_config.chroma < 2;
#endif
      case RMP4_CODEC_H264:
         return rh264_avcc_is_420_8bit(t->codec_private,
               t->codec_private_size);
      case RMP4_CODEC_H265:
         return rh265_hvcc_is_420_8bit(t->codec_private,
               t->codec_private_size);
      default:
         break;
   }
   return 0;
}

int rmp4_video_stream_set_planar(rmp4_video_stream_t *s, int planar)
{
   if (!s || (planar && !rmp4_video_stream_can_planar(s)))
      return 0;
   s->want_planar = planar;
   s->borrowed_planar.planes[0] = NULL;
   return 1;
}

const struct texture_planar *rmp4_video_stream_borrowed_planar(
      const rmp4_video_stream_t *s)
{
   return s && (s->want_planar == 2 || s->want_planar == 3)
      && s->borrowed_planar.planes[0]
      ? &s->borrowed_planar : NULL;
}

unsigned rmp4_video_stream_planar_yuv(const rmp4_video_stream_t *s)
{
   return s ? s->planar_yuv : 0;
}

void *rmp4_video_stream_h264(rmp4_video_stream_t *s)
{
   return s ? (void*)s->h264 : NULL;
}

void *rmp4_video_stream_h265(rmp4_video_stream_t *s)
{
   return s ? (void*)s->h265 : NULL;
}

void rmp4_video_stream_set_catchup(rmp4_video_stream_t *s, int behind)
{
   if (!s)
      return;
   s->catchup = behind ? 1 : 0;
   if (s->h264)
      rh264_video_set_skip_nonref(s->h264, s->catchup);
   if (s->h265)
      rh265_video_set_skip_nonref(s->h265, s->catchup);
}

void rmp4_video_stream_set_blit_pool(rmp4_video_stream_t *s,
      void *pool, unsigned bands)
{
   if (!s)
      return;
   s->blit_pool  = pool;
   s->blit_bands = bands;
#ifdef HAVE_RVP9
   /* VP9 tile columns decode on the same pool, one per thread. */
   if (s->vp9)
      rvp9_set_tile_pool(s->vp9, pool, bands);
#endif
   /* H.265 WPP rows likewise. */
   if (s->h265)
      rh265_video_set_thread_pool(s->h265, pool, bands);
   /* H.264 has no rows to split; its pictures decode concurrently
    * instead, one per thread, each waiting on the rows of the ones it
    * predicts from. */
   if (s->h264)
      rh264_video_set_thread_pool(s->h264, pool, (int)bands);
}

/* The blit as a row-band job (image_blit_bands): every parameter of
 * the frame's blit, with the row offset applied to the plane and
 * destination pointers per band. The matrix is resolved before the
 * split so a band's height does not pick the coefficients. */
typedef struct
{
   uint32_t *dst;
   const void *y, *u, *v;
   unsigned dst_stride, w;
   int ys, uvs;
   int chsh, cvsh, bd;
   unsigned matrix, transfer, range, primaries, max_cll;
   const rwebm_video_hdr_tone_t *tone;
   int argb;
   int kind;  /* 0: 8-bit yuv (cvsh), 1: 8-bit 4:4:4, 2: hbd to 8-bit,
                 3: webm hbd to 8-bit, 4: webm 10-bit, 5: HDR to scRGB
                 half floats, rows of dst_stride 8-byte pixels */
} rmp4_blit_ctx_t;

static void rmp4_video_blit_rows(void *arg, unsigned row0, unsigned rows)
{
   const rmp4_blit_ctx_t *c = (const rmp4_blit_ctx_t*)arg;
   uint32_t *dst            = c->dst + (size_t)row0 * c->dst_stride;
   size_t crow              = (size_t)row0 >> c->cvsh;
   switch (c->kind)
   {
      case 0:
         rmp4_video_blit_yuv(dst, c->dst_stride, c->w, rows,
               (const uint8_t*)c->y + (size_t)row0 * c->ys, c->ys,
               (const uint8_t*)c->u + crow * c->uvs,
               (const uint8_t*)c->v + crow * c->uvs, c->uvs,
               c->matrix, c->cvsh, c->range, c->argb);
         break;
      case 1:
         rmp4_video_blit_yuv444(dst, c->dst_stride, c->w, rows,
               (const uint8_t*)c->y + (size_t)row0 * c->ys, c->ys,
               (const uint8_t*)c->u + (size_t)row0 * c->uvs,
               (const uint8_t*)c->v + (size_t)row0 * c->uvs, c->uvs,
               c->matrix, c->range, c->argb);
         break;
      case 2:
         rmp4_video_blit_yuv_hbd(dst, c->dst_stride, c->w, rows,
               (const uint16_t*)c->y + (size_t)row0 * c->ys, c->ys,
               (const uint16_t*)c->u + crow * c->uvs,
               (const uint16_t*)c->v + crow * c->uvs, c->uvs,
               c->chsh, c->cvsh, c->bd, c->matrix, c->range, c->argb);
         break;
      case 3:
         rwebm_video_blit_i420_hbd_tone(dst, c->dst_stride, c->w, rows,
               (const uint16_t*)c->y + (size_t)row0 * c->ys, c->ys,
               (const uint16_t*)c->u + crow * c->uvs,
               (const uint16_t*)c->v + crow * c->uvs, c->uvs,
               c->matrix, c->transfer, c->range ? 2 : 1,
               c->max_cll, c->primaries, c->argb, c->tone);
         break;
      case 4:
         rwebm_video_blit_i420_10bit_tone(dst, c->dst_stride, c->w, rows,
               (const uint16_t*)c->y + (size_t)row0 * c->ys, c->ys,
               (const uint16_t*)c->u + crow * c->uvs,
               (const uint16_t*)c->v + crow * c->uvs, c->uvs,
               c->matrix, c->transfer, c->range ? 2 : 1,
               c->max_cll, c->primaries, c->tone);
         break;
      default:
         rwebm_video_blit_i420_fp16_color(
               (uint16_t*)c->dst + (size_t)row0 * c->dst_stride * 4,
               c->dst_stride, c->w, rows,
               (const uint16_t*)c->y + (size_t)row0 * c->ys, c->ys,
               (const uint16_t*)c->u + crow * c->uvs,
               (const uint16_t*)c->v + crow * c->uvs, c->uvs,
               c->matrix, c->transfer, c->range ? 2 : 1, c->primaries);
         break;
   }
}

/* An HDR source, for a caller that takes linear light into its own
 * frame: the 10-bit arms blit it as scRGB half floats, no tone map. */
static int rmp4_video_wants_fp16(const rmp4_video_stream_t *s)
{
   return s->want_fp16 && s->out
      && (s->transfer == 16 || s->transfer == 18);
}

/* Run row bands against one immutable stream-owned PQ table. Metadata
 * changes rebuild it on this thread before any worker can read it. */
static void rmp4_video_blit_frame(rmp4_video_stream_t *s,
      rmp4_blit_ctx_t *c, unsigned h)
{
   c->primaries = s->primaries;
   c->max_cll = video_color_tonemap_peak_nits(c->transfer,
         s->max_cll, &s->mastering);
   c->tone = &s->tone;
   if (c->kind > 2 && c->kind < 5 && c->transfer == 16
         && (!s->tone.ready || s->tone.peak != c->max_cll))
      rwebm_video_hdr_tone_init(&s->tone, c->max_cll);
   if (c->kind <= 2 && !(c->matrix == 1 || c->matrix == 5
            || c->matrix == 6 || c->matrix == 9 || c->matrix == 10))
      c->matrix = h >= 720 ? 1 : 5;
   image_blit_bands(s->blit_pool, s->blit_bands, h, 1u << c->cvsh,
         rmp4_video_blit_rows, c);
}

#define RMP4_BLIT_CTX(c, s_, dst_, w_, y_, u_, v_, ys_, uvs_, kind_, argb_) \
   do { \
      (c).dst        = (dst_); \
      (c).dst_stride = (s_)->out && (s_)->out_stride \
         ? (s_)->out_stride : (s_)->width; \
      (c).w          = (unsigned)(w_); \
      (c).y          = (y_); \
      (c).u          = (u_); \
      (c).v          = (v_); \
      (c).ys         = (ys_); \
      (c).uvs        = (uvs_); \
      (c).chsh       = 1; \
      (c).cvsh       = 1; \
      (c).bd         = 8; \
      (c).matrix     = (s_)->matrix; \
      (c).transfer   = (s_)->transfer; \
      (c).range      = (s_)->range; \
      (c).kind       = (kind_); \
      (c).argb       = (argb_); \
   } while (0)

void rmp4_video_stream_set_avail(rmp4_video_stream_t *s, size_t avail)
{
   if (s)
   {
      s->input_avail = avail > s->input_len ? s->input_len : avail;
      rmp4_set_avail(s->demux, avail);
   }
}

size_t rmp4_video_stream_media_floor(rmp4_video_stream_t *s)
{
   return s ? rmp4_media_floor(s->demux) : 0;
}

int rmp4_video_stream_seek_span(rmp4_video_stream_t *s,
      size_t *lo, size_t *hi)
{
#ifdef HAVE_RAV1
   size_t begin, end, need;
   if (!s || !lo || !hi || s->seek_state != 5
         || s->av1_hdr_scan_sample >= (uint32_t)s->seek_scan
         || !rmp4_track_sample_span(s->demux, s->track,
            s->av1_hdr_scan_sample, &begin, &end)
         || s->av1_hdr_scan_offset > end - begin)
      return 0;
   begin += s->av1_hdr_scan_offset;
   need = s->av1_hdr_scan_need > 10 ? s->av1_hdr_scan_need : 10;
   *lo = begin;
   *hi = end - begin > need ? begin + need : end;
   return 1;
#else
   (void)s; (void)lo; (void)hi;
   return 0;
#endif
}

size_t rmp4_video_stream_consumed(rmp4_video_stream_t *s)
{
   size_t lo, hi, consumed;
   if (rmp4_video_stream_seek_span(s, &lo, &hi)) return lo;
   if (!s) return 0;
   consumed = s->pending ? s->pending_floor : rmp4_consumed(s->demux);
   if (s->h265_picture_pending && s->h265_need_hi
         && s->h265_need_lo < consumed) consumed = s->h265_need_lo;
   return consumed;
}

void rmp4_video_stream_read_span(const rmp4_video_stream_t *s,
      size_t *lo, size_t *hi)
{
   if (s && s->h265_picture_pending && s->h265_need_hi > s->input_avail)
   {
      if (lo) *lo = s->h265_need_lo;
      if (hi) *hi = s->h265_need_hi;
      return;
   }
   rmp4_read_span(s && !s->pending ? s->demux : NULL, lo, hi);
}

int64_t rmp4_video_stream_duration_ns(rmp4_video_stream_t *s)
{
   return (s && s->demux) ? rmp4_duration_ns(s->demux) : 0;
}

/* The shown picture's 8-bit 4:2:0 planes where they lie in the decoder
 * and the IMAGE_YUV_FLAG_* of the matrix and range the RGB blit would
 * use: 0 for a picture that is not so, or in BT.2020. */
static int rmp4_video_shown_planes(const rmp4_video_stream_t *s,
      const uint8_t *planes[3], unsigned strides[3],
      unsigned *width, unsigned *height, unsigned *yuv)
{
   const uint8_t *y = NULL, *u = NULL, *v = NULL;
   int ys = 0, uvs = 0, w = 0, h = 0, cw = 0, ch = 0;
   unsigned matrix = s->matrix;
   if (s->h265_picture_pending)
      return 0;
   switch (s->rndr_kind)
   {
      case 1:
         y = rvp8_video_plane(s->vp8, 0, &ys,  &w,  &h);
         u = rvp8_video_plane(s->vp8, 1, &uvs, &cw, &ch);
         v = rvp8_video_plane(s->vp8, 2, &uvs, &cw, &ch);
         break;
#ifdef HAVE_RVP9
      case 2:
      {
         const rvp9_fb *fb = &s->vp9->fbs[s->rndr_vp9_show];
         if (     s->vp9->hd.bit_depth != 8
               || !s->vp9->hd.subsampling_x || !s->vp9->hd.subsampling_y)
            return 0;
         y   = fb->y;
         u   = fb->u;
         v   = fb->v;
         ys  = s->vp9->ys;
         uvs = s->vp9->uvs;
         w   = fb->w;
         h   = fb->h;
         cw  = (w + 1) / 2;
         ch  = (h + 1) / 2;
         break;
      }
#endif
      case 3:
         if (rh264_video_bit_depth(s->h264) != 8)
            return 0;
         y = rh264_video_plane(s->h264, 0, &ys,  &w,  &h);
         u = rh264_video_plane(s->h264, 1, &uvs, &cw, &ch);
         v = rh264_video_plane(s->h264, 2, &uvs, &cw, &ch);
         break;
      case 4:
         if (rh265_video_bit_depth(s->h265) != 8)
            return 0;
         y = rh265_video_plane(s->h265, 0, &ys,  &w,  &h);
         u = rh265_video_plane(s->h265, 1, &uvs, &cw, &ch);
         v = rh265_video_plane(s->h265, 2, &uvs, &cw, &ch);
         break;
      default:
         return 0;
   }
   if (     !y || !u || !v || w <= 0 || h <= 0
         || cw != (w + 1) / 2 || ch != (h + 1) / 2)
      return 0;
   if ((unsigned)w > s->width)
      w = (int)s->width;
   if ((unsigned)h > s->height)
      h = (int)s->height;
   if (!(matrix == 1 || matrix == 5 || matrix == 6
            || matrix == 9 || matrix == 10))
      matrix = h >= 720 ? 1 : 5;
   if (matrix == 9 || matrix == 10)
      return 0;
   planes[0]  = y;
   planes[1]  = u;
   planes[2]  = v;
   strides[0] = (unsigned)ys;
   strides[1] = strides[2] = (unsigned)uvs;
   *width     = (unsigned)w;
   *height    = (unsigned)h;
   *yuv       = (matrix == 1 ? IMAGE_YUV_FLAG_BT709 : 0)
      | (s->range ? IMAGE_YUV_FLAG_FULL_RANGE : 0);
   return 1;
}

int rmp4_video_stream_planes(const rmp4_video_stream_t *s,
      const uint8_t *planes[3], unsigned strides[3],
      unsigned *width, unsigned *height, unsigned *yuv)
{
   return s && planes && strides && width && height && yuv
      && rmp4_video_shown_planes(s, planes, strides, width, height, yuv);
}

/* The shown picture's planes copied into the caller's frame as packed
 * I420. */
static const uint32_t *rmp4_video_render_planar(rmp4_video_stream_t *s)
{
   const uint8_t *planes[3];
   unsigned strides[3], w, h, yuv;
   if (!rmp4_video_shown_planes(s, planes, strides, &w, &h, &yuv))
      return NULL;
   s->borrowed_planar.planes[0] = NULL;
   if ((s->want_planar == 2 || s->want_planar == 3)
         && w == s->width && h == s->height
         && (s->want_planar == 2 || (strides[0] == w
               && strides[1] == (w + 1) / 2)))
   {
      unsigned i;
      for (i = 0; i < 3; i++)
      {
         s->borrowed_planar.planes[i] = planes[i];
         s->borrowed_planar.strides[i] = strides[i];
      }
      s->borrowed_planar.chroma_step = 1;
      s->borrowed_planar.yuv = yuv;
   }
   else
      image_yuv_420_pack((uint8_t*)s->out, s->width, s->height,
            planes[0], strides[0], planes[1], planes[2], strides[1], w, h);
   s->planar_yuv = yuv;
   return s->out;
}

const uint32_t *rmp4_video_stream_render(rmp4_video_stream_t *s)
{
   uint32_t *dst;
   if (!s || s->h265_picture_pending)
      return NULL;
   s->is_fp16 = 0;
   if (s->want_planar && s->out && s->rndr_kind != 5)
      return rmp4_video_render_planar(s);
   dst        = s->out ? s->out : s->frame;
   if (!dst && s->rndr_kind >= 1 && s->rndr_kind <= 4)
   {
      s->frame = (uint32_t*)malloc((size_t)s->width * s->height
            * sizeof(uint32_t));
      if (!(dst = s->frame))
         return NULL;
   }
   switch (s->rndr_kind)
   {
      case 5:  /* on the GPU: nothing to convert here, the frame is
                * taken with rmp4_video_stream_hw_frame */
         return dst ? dst : &s->hw_marker;
      case 1:  /* VP8: planes valid until the next decode call */
      {
         const uint8_t *y, *u, *v;
         int ys, uvs, w, h, cw, ch;
         y = rvp8_video_plane(s->vp8, 0, &ys, &w, &h);
         u = rvp8_video_plane(s->vp8, 1, &uvs, &cw, &ch);
         v = rvp8_video_plane(s->vp8, 2, &uvs, &cw, &ch);
         if (!y || !u || !v)
            return NULL;
         if ((unsigned)w > s->width)
            w = (int)s->width;
         if ((unsigned)h > s->height)
            h = (int)s->height;
         {
            rmp4_blit_ctx_t c;
            RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 0, s->emit_argb);
            rmp4_video_blit_frame(s, &c, (unsigned)h);
         }
         return dst;
      }
#ifdef HAVE_RVP9
      case 2:  /* VP9: the recorded show buffer */
      {
         const rvp9_fb *fb = &s->vp9->fbs[s->rndr_vp9_show];
         unsigned w = (unsigned)fb->w < s->width  ? (unsigned)fb->w : s->width;
         unsigned h = (unsigned)fb->h < s->height ? (unsigned)fb->h : s->height;
         if (s->vp9->hd.bit_depth == 10)
         {
            /* Colour metadata comes from the sample entry and coded header;
             * untagged files pass zeros and the shared blit picks
             * HD-appropriate defaults (BT.2020-ncl for PQ, BT.709/601 by
             * resolution), matching untagged webm content. Without this
             * branch the 10-bit (uint16) planes were handed to the 8-bit
             * blit and mis-decoded. */
            rmp4_blit_ctx_t c;
            if (rmp4_video_wants_fp16(s))
            {
               RMP4_BLIT_CTX(c, s, dst, w, fb->y, fb->u, fb->v,
                     s->vp9->ys, s->vp9->uvs, 5, 0);
               s->is_fp16 = 1;
            }
            else if (s->want10)
            {
               RMP4_BLIT_CTX(c, s, dst, w, fb->y, fb->u, fb->v,
                     s->vp9->ys, s->vp9->uvs, 4, 0);
               s->is10 = 1;
            }
            else
               RMP4_BLIT_CTX(c, s, dst, w, fb->y, fb->u, fb->v,
                     s->vp9->ys, s->vp9->uvs, 3, s->emit_argb ? 0 : 1);
            rmp4_video_blit_frame(s, &c, h);
         }
         else
         {
            rmp4_blit_ctx_t c;
            RMP4_BLIT_CTX(c, s, dst, w, fb->y, fb->u, fb->v,
                  s->vp9->ys, s->vp9->uvs, 0, s->emit_argb);
            rmp4_video_blit_frame(s, &c, h);
         }
         return dst;
      }
#endif
      case 3:  /* H.264: planes valid until the next decode or drain */
      {
         const uint8_t *y, *u, *v;
         int ys, uvs, w, h, cw, ch;
         y = rh264_video_plane(s->h264, 0, &ys,  &w,  &h);
         u = rh264_video_plane(s->h264, 1, &uvs, &cw, &ch);
         v = rh264_video_plane(s->h264, 2, &uvs, &cw, &ch);
         if (!y || !u || !v)
            return NULL;
         if ((unsigned)w > s->width)
            w = (int)s->width;
         if ((unsigned)h > s->height)
            h = (int)s->height;
         if (rh264_video_bit_depth(s->h264) > 8)
         {
            /* High 10 and friends: uint16_t samples, stride in
             * samples.  10-bit 4:2:0 goes where H.265 Main10 goes -
             * the shared HDR blits, XRGB2101010 when the caller asked
             * for it; anything else scales down to the 8-bit path. */
            int bd = rh264_video_bit_depth(s->h264);
            rmp4_blit_ctx_t c;
            if (bd == 10 && cw < w && ch < h)
            {
               if (rmp4_video_wants_fp16(s))
               {
                  RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 5, 0);
                  s->is_fp16 = 1;
               }
               else if (s->want10)
               {
                  RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 4, 0);
                  s->is10 = 1;
               }
               else
                  RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 3,
                        s->emit_argb ? 0 : 1);
            }
            else
            {
               RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 2, s->emit_argb);
               c.chsh = (cw < w) ? 1 : 0;
               c.cvsh = (ch < h) ? 1 : 0;
               c.bd   = bd;
            }
            rmp4_video_blit_frame(s, &c, (unsigned)h);
            return dst;
         }
         {
            rmp4_blit_ctx_t c;
            if (cw >= w)   /* 4:4:4: luma-sized chroma */
            {
               RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 1, s->emit_argb);
               c.chsh = 0;
               c.cvsh = 0;
            }
            else
            {
               RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 0, s->emit_argb);
               c.cvsh = (ch < h) ? 1 : 0;
            }
            rmp4_video_blit_frame(s, &c, (unsigned)h);
         }
         return dst;
      }
      case 4:  /* H.265: planes valid until the next decode or drain */
      {
         const uint8_t *y, *u, *v;
         int ys, uvs, w, h, cw, ch;
         y = rh265_video_plane(s->h265, 0, &ys,  &w,  &h);
         u = rh265_video_plane(s->h265, 1, &uvs, &cw, &ch);
         v = rh265_video_plane(s->h265, 2, &uvs, &cw, &ch);
         if (!y || !u || !v)
            return NULL;
         if ((unsigned)w > s->width)
            w = (int)s->width;
         if ((unsigned)h > s->height)
            h = (int)s->height;
         if (rh265_video_bit_depth(s->h265) == 10)
         {
            /* Main10: the plane pointers reference uint16_t samples
             * with the stride in samples; hand them to the shared
             * high-bit-depth blits exactly as the VP9 arm does. */
            rmp4_blit_ctx_t c;
            if (rmp4_video_wants_fp16(s))
            {
               RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 5, 0);
               s->is_fp16 = 1;
            }
            else if (s->want10)
            {
               RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 4, 0);
               s->is10 = 1;
            }
            else
               RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 3,
                     s->emit_argb ? 0 : 1);
            rmp4_video_blit_frame(s, &c, (unsigned)h);
            return dst;
         }
         /* rh265 is 4:2:0 only, so the chroma-vertical-shift argument
          * the H.264 arm derives is always 1 here; keep the same
          * derivation anyway so the two arms stay textually parallel. */
         {
            rmp4_blit_ctx_t c;
            RMP4_BLIT_CTX(c, s, dst, w, y, u, v, ys, uvs, 0, s->emit_argb);
            c.cvsh = (ch < h) ? 1 : 0;
            rmp4_video_blit_frame(s, &c, (unsigned)h);
         }
         return dst;
      }
      default:
         break;
   }
   return NULL;
}

const uint32_t *rmp4_video_stream_next(rmp4_video_stream_t *s,
      int *duration_ms)
{
   if (!s)
      return NULL;
   if (rmp4_video_stream_advance(s, duration_ms, 0) != 1)
      return NULL;
   return rmp4_video_stream_render(s);
}

int rmp4_video_stream_completed(const rmp4_video_stream_t *s)
{
   return s && s->completed;
}

void rmp4_video_stream_rewind(rmp4_video_stream_t *s)
{
   if (!s)
      return;
   s->completed = 0;
   s->pending = s->waiting = s->seek_state = 0;
   s->h265_decode_sample = 0;
   s->h265_picture_pending = s->h265_timing_active = s->h265_have_time = 0;
   s->h265_need_lo = s->h265_need_hi = 0;
#ifdef HAVE_RAV1
   s->av1_hdr_probe_started = 0;
   s->av1_decode_sample = 0;
#endif
   rmp4_video_hwf_drop(s);
   s->rndr_kind = 0;   /* decoder reset invalidates the planes */
   rmp4_rewind(s->demux);
   s->disp_idx = 0;
   s->wait_key = 0;
#ifdef HAVE_RVP9
   if (s->vp9_hw && s->want_hw && s->vp9_backend.restart)
   {
      rvp9_hw_session_restart(s->vp9_hw);
      s->vp9_restart = 1;
      s->vp9_active = 0;
      s->vp9_sample = 0;
      return;
   }
#endif
   /* The stream restarts at a key frame, so a fresh decoder (empty
    * reference chain, default probabilities) is the correct state. */
#ifdef HAVE_RAV1
   if (s->want_hw && s->av1 && rav1_hw_stream_restart(s->av1))
   {
      s->av1->hdr = s->av1_hdr_initial_set
         ? s->av1_hdr_initial : s->av1_hdr_seed;
      return;
   }
#endif
   if (s->want_hw && s->h264 && rh264_video_restart_hw(&s->h264))
      return;
   rmp4_video_stream_close_decoder(s);
   rmp4_video_stream_open_decoder(s);
}

int64_t rmp4_video_stream_presentation_delay_ns(const rmp4_video_stream_t *s)
{
   const rmp4_track *track;
   if (!s || !s->demux) return 0;
   track = rmp4_get_track(s->demux, s->track);
   return track ? track->presentation_delay_ns : 0;
}

static int64_t rmp4_video_stream_movie_time_ns(const rmp4_video_stream_t *s,
      int index)
{
   const int64_t maximum = (int64_t)((~(uint64_t)0) >> 1);
   int64_t first, time, delta, delay;
   if (!s || index < 0 || index >= s->ts_count) return -1;
   first = s->ts[0]; time = s->ts[index];
   if (time < first || (first < 0 && time > maximum + first)) return -1;
   delta = time - first;
   delay = rmp4_video_stream_presentation_delay_ns(s);
   if (delay < 0 || delta > maximum - delay) return -1;
   return delay + delta;
}

int64_t rmp4_video_stream_frame_time_ns(const rmp4_video_stream_t *s)
{
   if (s && s->h265)
      return s->h265_have_time ? rmp4_video_stream_movie_time_ns(s,
            rmp4_video_timestamp_index(s, s->h265_display_timestamp)) : -1;
   return s ? rmp4_video_stream_movie_time_ns(s, s->disp_idx - 1) : -1;
}

int64_t rmp4_video_stream_next_end_time_ns(const rmp4_video_stream_t *s)
{
   int64_t delay, ms;
   if (!s || s->disp_idx < 0 || s->disp_idx >= s->ts_count - 1)
      return -1;
   delay = rmp4_video_stream_presentation_delay_ns(s);
   ms = s->ts[s->disp_idx + 1] / 1000000 - s->ts[0] / 1000000;
   if (delay < 0 || ms < 0 || ms > (INT64_MAX - delay) / 1000000)
      return -1;
   return delay + ms * 1000000;
}

int rmp4_video_stream_seek_movie_begin_ns(rmp4_video_stream_t *s, int64_t ns)
{
   const int64_t maximum = (int64_t)((~(uint64_t)0) >> 1);
   int64_t delay, delta, first;
   if (!s || !s->ts_count) return 0;
   if (ns < 0) ns = 0;
   s->movie_seek_target_ns = ns;
   delay = rmp4_video_stream_presentation_delay_ns(s);
   delta = ns > delay ? ns - delay : 0;
   first = s->ts[0];
   if (first > 0 && delta > maximum - first) delta = maximum;
   else delta += first;
   return rmp4_video_stream_seek_begin_ns(s, delta);
}

int rmp4_video_stream_seek_movie_step(rmp4_video_stream_t *s,
      int64_t *position_us)
{
   int64_t time, last;
   int result = rmp4_video_stream_seek_step(s, NULL);
   if (position_us) *position_us = 0;
   if (result != 1) return result;
   time = rmp4_video_stream_movie_time_ns(s, s->disp_idx);
   last = rmp4_video_stream_movie_time_ns(s, s->ts_count - 1);
   if (time < 0 || last < 0) return -1;
   /* Seeking within an empty interval preserves movie/audio position.
    * The next picture can still lie in the future, or in the tail. */
   if (s->movie_seek_target_ns < time || s->movie_seek_target_ns > last)
      time = s->movie_seek_target_ns;
   if (position_us) *position_us = time / 1000;
   return 1;
}

int64_t rmp4_video_stream_span_ms(const rmp4_video_stream_t *s)
{
   if (!s || s->ts_count < 2)
      return 0;
   return (int64_t)((s->ts[s->ts_count - 1] - s->ts[0]) / 1000000);
}

#ifdef HAVE_RAV1
/* Points describe metadata entering a sample, not leaving its first picture. */
static int rmp4_video_av1_hdr_point(rmp4_video_stream_t *s, uint32_t sample)
{
   rmp4_av1_hdr_point_t *points;
   size_t capacity;
   if (s->av1_hdr_count && !memcmp(&s->av1_hdr_scanned,
            &s->av1_hdr_points[s->av1_hdr_count - 1].hdr,
            sizeof(s->av1_hdr_scanned)))
      return 1;
   if (s->av1_hdr_count == s->av1_hdr_capacity)
   {
      capacity = s->av1_hdr_capacity ? s->av1_hdr_capacity * 2 : 8;
      if (capacity < s->av1_hdr_capacity
            || capacity > (size_t)-1 / sizeof(*points)) return 0;
      points = (rmp4_av1_hdr_point_t*)realloc(s->av1_hdr_points,
            capacity * sizeof(*points));
      if (!points) return 0;
      s->av1_hdr_points = points;
      s->av1_hdr_capacity = capacity;
   }
   s->av1_hdr_points[s->av1_hdr_count].sample = sample;
   s->av1_hdr_points[s->av1_hdr_count++].hdr = s->av1_hdr_scanned;
   return 1;
}

static const rav1_hdr_metadata_t *rmp4_video_av1_hdr_at(
      const rmp4_video_stream_t *s, uint32_t sample)
{
   size_t lo = 0, hi = s->av1_hdr_count;
   while (lo < hi)
   {
      size_t mid = lo + (hi - lo) / 2;
      if (s->av1_hdr_points[mid].sample <= sample) lo = mid + 1;
      else hi = mid;
   }
   return lo ? &s->av1_hdr_points[lo - 1].hdr : &s->av1_hdr_seed;
}

/* Only OBU headers and metadata payloads need resident storage. */
static int rmp4_video_av1_scan_hdr(rmp4_video_stream_t *s)
{
   rav1_obu_t obu;
   size_t begin, end, lo, hi, next;
   int ret;
   if (!s->av1_hdr_count)
   {
      s->av1_hdr_scanned = s->av1_hdr_seed;
      if (!rmp4_video_av1_hdr_point(s, 0)) return -1;
   }
   if (!rmp4_track_sample_span(s->demux, s->track,
            s->av1_hdr_scan_sample, &begin, &end)
         || !rmp4_video_stream_seek_span(s, &lo, &hi)) return -1;
   if (hi > s->input_avail)
   {
      s->waiting = RMP4_VIDEO_WAIT_INPUT;
      return 0;
   }
   next = s->av1_hdr_scan_offset;
   ret = rav1_obu_next(&obu, s->input + begin, end - begin, &next, true);
   if (ret < 0) return -1;
   if (!ret)
   {
      if (!rmp4_video_av1_hdr_point(s, s->av1_hdr_scan_sample + 1)) return -1;
      s->av1_hdr_scan_offset = s->av1_hdr_scan_need = 0;
      s->av1_hdr_scan_sample++;
      return 2;
   }
   if (obu.temporal_id || obu.spatial_id) return -1;
   if (obu.type == 5)
   {
      s->av1_hdr_scan_need = obu.size;
      if (begin + next > s->input_avail)
      {
         s->waiting = RMP4_VIDEO_WAIT_INPUT;
         return 0;
      }
      if (rav1_hdr_metadata_obu(&s->av1_hdr_scanned, &obu) < 0) return -1;
   }
   s->av1_hdr_scan_offset = next;
   s->av1_hdr_scan_need = 0;
   return 0;
}

/* One resident OBU per call; 2 yields a new byte frontier to the feeder. */
static int rmp4_video_av1_probe_hdr(rmp4_video_stream_t *s)
{
   rmp4_packet packet;
   rav1_obu_t obu;
   int ret;
   if (!s->av1_hdr_probe_started)
   {
      rmp4_video_stream_rewind(s);
      if (!s->av1) return -1;
      s->av1_hdr_initial = s->av1->hdr;
      s->av1_hdr_probe_sequence = s->av1->sequence;
      s->av1_hdr_probe_offset = 0;
      s->av1_hdr_probe_sample = 0;
      s->av1_hdr_probe_started = 1;
      s->seek_state = 4;
      if (!rmp4_select_track_sample(s->demux, s->track, 0)) return -1;
      return 2;
   }
   /* Re-reading the selected sample checks its current resident bound. */
   if (!rmp4_select_track_sample(s->demux, s->track, s->av1_hdr_probe_sample))
      return -1;
   if (!s->pending) s->pending_floor = rmp4_consumed(s->demux);
   ret = rmp4_read_packet(s->demux, &packet);
   if (ret == RMP4_READ_AGAIN)
   {
      s->waiting = RMP4_VIDEO_WAIT_INPUT;
      return 0;
   }
   if (ret != 1 || packet.track != s->track) return -1;
   s->pending_packet = packet;
   s->pending = 1;
   ret = rav1_obu_next(&obu, packet.data, packet.size,
         &s->av1_hdr_probe_offset, true);
   if (ret < 0) return -1;
   if (!ret)
   {
      s->pending = 0;
      s->av1_hdr_probe_offset = 0;
      s->av1_hdr_probe_sample++;
      if (!rmp4_select_track_sample(s->demux, s->track, s->av1_hdr_probe_sample))
         return -1;
      return 2;
   }
   if (obu.temporal_id || obu.spatial_id) return -1;
   if (obu.type == 1)
   {
      if (!rav1_sequence_parse(&s->av1_hdr_probe_sequence,
               obu.payload, obu.payload_size)) return -1;
   }
   else if (obu.type == 5)
   {
      if (rav1_hdr_metadata_obu(&s->av1_hdr_initial, &obu) < 0) return -1;
   }
   else if (obu.type == 3 || obu.type == 6)
   {
      rav1_frame_prefix_t frame;
      rav1_bits_t bits;
      bits.data = obu.payload;
      bits.size = obu.payload_size;
      bits.byte = 0;
      bits.bit = bits.failed = 0;
      if (!rav1_frame_prefix_parse(&frame, &bits, &s->av1_hdr_probe_sequence,
               0, 0, obu.type == 6)) return -1;
      if (frame.show_existing || frame.show_frame)
      {
         s->av1_hdr_initial_set = 1;
         s->pending = 0;
         s->av1_hdr_probe_started = 0;
         return 1;
      }
   }
   return 0;
}
#endif

int rmp4_video_stream_seek_begin_ns(rmp4_video_stream_t *s, int64_t ns)
{
   int lo = 0, hi;
   if (!s || s->ts_count <= 0)
      return 0;
   s->completed = 0;
   if (ns < 0) ns = 0;
   hi = s->ts_count;
   while (lo < hi)
   {
      int mid = lo + (hi - lo) / 2;
      if (s->ts[mid] <= ns)
         lo = mid + 1;
      else
         hi = mid;
   }
   s->seek_target = lo ? lo - 1 : 0;
   s->seek_scan = s->seek_target;
   s->seek_state = 1;
#ifdef HAVE_RAV1
   s->av1_hdr_probe_started = 0;
   if (s->codec == RMP4_CODEC_AV1 && !s->av1_hdr_initial_set)
      s->seek_state = 4;
#endif
   s->waiting = RMP4_VIDEO_WAIT_NONE;
   return 1;
}

int rmp4_video_stream_seek_step(rmp4_video_stream_t *s, int64_t *position_us)
{
   if (position_us) *position_us = 0;
   if (!s || !s->seek_state)
      return -1;
#ifdef HAVE_RAV1
   if (s->seek_state == 5)
   {
      int64_t started = cpu_features_get_time_usec();
      unsigned budget = 32;
      s->waiting = RMP4_VIDEO_WAIT_NONE;
      do
      {
         int ret;
         if (s->av1_hdr_scan_sample >= (uint32_t)s->seek_scan)
         {
            s->seek_state = 1;
            return 0;
         }
         ret = rmp4_video_av1_scan_hdr(s);
         if (ret < 0) goto failed;
         if (ret == 2 || s->waiting) return 0;
         if (cpu_features_get_time_usec() - started >= 4000) break;
      } while (--budget);
      return 0;
   }
   if (s->seek_state == 4)
   {
      int64_t started = cpu_features_get_time_usec();
      unsigned budget = 32;
      s->waiting = RMP4_VIDEO_WAIT_NONE;
      do
      {
         int ret = rmp4_video_av1_probe_hdr(s);
         if (ret < 0) goto failed;
         if (ret == 2) return 0;
         if (ret == 1)
         {
            s->seek_state = 1;
            return 0;
         }
         if (s->waiting || cpu_features_get_time_usec() - started >= 4000)
            break;
      } while (--budget);
      return 0;
   }
#endif
   if (s->seek_state == 1)
   {
      uint32_t count = 0;
      const int64_t *pts = rmp4_track_pts(s->demux, s->track, &count);
      unsigned budget = 256;
      if (!pts || (uint32_t)s->seek_scan >= count)
         goto failed;
      while (budget--)
      {
         int key = rmp4_track_sample_key(s->demux, s->track,
               (uint32_t)s->seek_scan);
         if (key < 0)
            goto failed;
         if (key && pts[s->seek_scan] <= s->ts[s->seek_target])
         {
            int lo = 0, hi = s->ts_count;
            int sample = s->seek_scan;
            int64_t start_ns = pts[sample];
#ifdef HAVE_RAV1
            if (s->codec == RMP4_CODEC_AV1
                  && s->av1_hdr_scan_sample < (uint32_t)sample)
            {
               s->pending = 0;
               s->seek_state = 5;
               if (!rmp4_select_track_sample(s->demux, s->track,
                        s->av1_hdr_scan_sample)) goto failed;
               return 0;
            }
#endif
            rmp4_video_stream_rewind(s);
#ifdef HAVE_RAV1
            if (s->av1)
            {
               s->av1_decode_sample = (uint32_t)sample;
               s->av1->hdr = *rmp4_video_av1_hdr_at(s, (uint32_t)sample);
            }
#endif
#ifdef HAVE_RVP9
            s->vp9_sample = (uint32_t)sample;
#endif
            if (!rmp4_select_track_sample(s->demux, s->track,
                     (uint32_t)sample))
               goto failed;
            while (lo < hi)
            {
               int mid = lo + (hi - lo) / 2;
               if (s->ts[mid] < start_ns) lo = mid + 1;
               else hi = mid;
            }
            s->disp_idx = lo;
            s->h265_decode_sample = (uint32_t)sample;
            s->seek_state = 2;
            return 0;
         }
         if (!s->seek_scan)
            goto failed;
         s->seek_scan--;
      }
      return 0;
   }
   if (s->seek_state == 2 && s->disp_idx < s->seek_target)
   {
      int r;
      unsigned budget = 1;
#ifdef HAVE_RAV1
      int64_t started = 0;
      if (s->codec == RMP4_CODEC_AV1)
      {
         budget = 32;
         started = cpu_features_get_time_usec();
      }
#endif
      do
      {
         s->waiting = RMP4_VIDEO_WAIT_NONE;
         r = rmp4_video_stream_step(s, NULL, 1);
         if (r < 0)
            goto failed;
         if (r == 1)
         {
            rmp4_video_hwf_drop(s);
            s->rndr_kind = 0;
         }
         if (r == 2 || s->disp_idx >= s->seek_target)
            break;
#ifdef HAVE_RAV1
         if (s->codec == RMP4_CODEC_AV1 &&
               cpu_features_get_time_usec() - started >= 4000)
            break;
#endif
      } while (--budget);
      if (s->disp_idx < s->seek_target)
         return 0;
   }
   if (s->disp_idx >= s->ts_count)
      goto failed;
   if (s->seek_state != 3)
      s->seek_position_us = s->ts[s->disp_idx] / 1000;
   s->seek_state = 3;
   s->waiting = RMP4_VIDEO_WAIT_NONE;
   if (position_us) *position_us = s->seek_position_us;
   return 1;
failed:
#ifdef HAVE_RAV1
   if (s->seek_state == 4 || s->seek_state == 5)
   {
      if (s->seek_state == 5)
      {
         s->av1_hdr_scan_offset = s->av1_hdr_scan_need = 0;
         s->av1_hdr_scanned = *rmp4_video_av1_hdr_at(s, s->av1_hdr_scan_sample);
      }
      s->pending = s->av1_hdr_probe_started = 0;
      if (s->av1) s->av1->error = -1;
   }
#endif
   s->seek_state = 0;
   return -1;
}

int64_t rmp4_video_stream_seek_frame(rmp4_video_stream_t *s, int frame)
{
   int tidx, kf, n;
   rmp4_packet pkt;

   if (!s || s->ts_count <= 0)
      return -1;
   tidx = frame < 0 ? 0 : frame;
   if (tidx >= s->ts_count)
      tidx = s->ts_count - 1;

   /* Pass 1: the last key frame at or before the target, by sample
    * ordinal.  Decode order stands in for the display slot here; with
    * B-frame reordering that is off by at most the reorder depth
    * around the cut, and the key frame itself always displays before
    * everything decoded after it. */
   rmp4_video_stream_rewind(s);
   kf = 0;
   n  = 0;
   while (n <= tidx && rmp4_read_packet(s->demux, &pkt) == 1)
   {
      if (pkt.track != s->track)
         continue;
      if (pkt.keyframe)
         kf = n;
      n++;
   }

   /* Pass 2: skip undecoded up to the key frame - its slot count is
    * exactly the display slots consumed for H.264 and VP9 - then
    * decode forward, discarding pictures, until the target slot has
    * been presented. */
   rmp4_video_stream_rewind(s);
   n = 0;
   while (n < kf && rmp4_read_packet(s->demux, &pkt) == 1)
   {
      if (pkt.track != s->track)
         continue;
      n++;
   }
   s->disp_idx = kf;
   s->h265_decode_sample = (uint32_t)kf;
   while (s->disp_idx < tidx)
      if (rmp4_video_stream_discard(s, NULL) != 1)
         break;
   /* The target slot itself is left for the caller's next
    * rmp4_video_stream_next call, so the frame at the position is the
    * one presented; the catch-up pictures above were never colour
    * converted, and none of them is renderable now. */
   s->rndr_kind = 0;
   return s->disp_idx < s->ts_count ? s->ts[s->disp_idx] / 1000000 : 0;
}

int64_t rmp4_video_stream_seek_movie_ms(rmp4_video_stream_t *s, int64_t ms)
{
   const int64_t maximum = (int64_t)((~(uint64_t)0) >> 1);
   int64_t target, time, last;
   int lo = 0, hi;
   if (!s || s->ts_count <= 0)
      return -1;
   if (ms < 0)
      ms = 0;
   target = ms > (maximum - 999999) / 1000000
      ? maximum : ms * 1000000 + 999999;
   hi = s->ts_count;
   while (lo < hi)
   {
      int mid = lo + (hi - lo) / 2;
      time = rmp4_video_stream_movie_time_ns(s, mid);
      if (time < 0)
         return -1;
      if (time <= target)
         lo = mid + 1;
      else
         hi = mid;
   }
   if (rmp4_video_stream_seek_frame(s, lo ? lo - 1 : 0) < 0)
      return -1;
   time = rmp4_video_stream_movie_time_ns(s, s->disp_idx);
   last = rmp4_video_stream_movie_time_ns(s, s->ts_count - 1);
   if (time < 0 || last < 0)
      return -1;
   if (target < time || target > last)
      time = target;
   return time / 1000000;
}

int64_t rmp4_video_stream_seek_ms(rmp4_video_stream_t *s, int64_t ms)
{
   int64_t target_ns;
   int tidx = 0;
   if (!s || s->ts_count <= 0)
      return -1;
   if (ms < 0)
      ms = 0;
   /* Include a timestamp's fractional millisecond at a frame boundary. */
   target_ns = ms > (INT64_MAX - 999999) / 1000000
      ? INT64_MAX : ms * 1000000 + 999999;
   while (tidx + 1 < s->ts_count && s->ts[tidx + 1] <= target_ns)
      tidx++;
   return rmp4_video_stream_seek_frame(s, tidx);
}

int rmp4_video_stream_frame_index(const rmp4_video_stream_t *s)
{
   return s ? s->disp_idx : -1;
}

/* ------------------------------------------------------------------ */
/* Still image (first displayed frame)                                 */
/* ------------------------------------------------------------------ */
rmp4_video_t *rmp4_video_alloc(void)
{
   return (rmp4_video_t*)calloc(1, sizeof(rmp4_video_t));
}

void rmp4_video_free(rmp4_video_t *mp4)
{
   if (!mp4)
      return;
   if (mp4->stream)
      rmp4_video_stream_close(mp4->stream);
   free(mp4->still_fp16);
   free(mp4);
}

void rmp4_video_set_want_fp16(rmp4_video_t *mp4, int want)
{
   if (mp4)
      mp4->want_fp16 = want ? 1 : 0;
}

bool rmp4_video_is_fp16(const rmp4_video_t *mp4)
{
   return mp4 && mp4->last_fp16;
}

rmp4_video_stream_t *rmp4_video_detach_stream(rmp4_video_t *mp4)
{
   rmp4_video_stream_t *s;
   if (!mp4 || !mp4->stream)
      return NULL;
   /* A stream mid-build in the sliced still decode is not complete
    * (pre-scan or decoder setup may be pending); never hand it out. */
   if (mp4->still_stage != RMP4_VIDEO_STILL_IDLE)
      return NULL;
   s           = mp4->stream;
   mp4->stream = NULL;
   /* The animation consumers upload plain 8-bit frames; the still may
    * have been decoded 10-bit, so drop the request before handing the
    * stream over (each frame re-blits, no stale pixels survive).  The
    * channel order likewise resets to the documented default; adopters
    * re-select per frame via rmp4_video_stream_set_argb. */
   s->want10    = 0;
   s->is10      = 0;
   s->emit_argb = 0;
   return s;
}

bool rmp4_video_set_buf_ptr(rmp4_video_t *mp4, void *data, size_t len)
{
   if (!mp4)
      return false;
   mp4->buf = (const uint8_t*)data;
   mp4->len = len;
   return true;
}

/* Ask the thumbnail decoder to emit packed XRGB2101010 for 10-bit HDR
 * sources (it keeps 8-bit output for 8-bit sources). */
void rmp4_video_set_want_10bit(rmp4_video_t *mp4, int want)
{
   if (mp4)
      mp4->want10 = want ? 1 : 0;
}



void rmp4_video_set_avail(rmp4_video_t *mp4, size_t avail)
{
   if (!mp4)
      return;
   mp4->partial = 1;
   if (avail > mp4->len)
      avail = mp4->len;
   /* An exact store: see rmp4_set_avail.  The bound is "readable
    * right now"; a windowed feeder lowers it after a loop's rewind,
    * and a raise-only mirror here would keep handing the stream its
    * stale high-water mark - reads of decommitted pages one lap in. */
   mp4->avail = avail;
   if (mp4->stream)
      rmp4_video_stream_set_avail(mp4->stream, mp4->avail);
}

/* True if the last rmp4_video_process_image() wrote packed XRGB2101010. */
bool rmp4_video_is_10bit(const rmp4_video_t *mp4)
{
   return mp4 && mp4->last_10bit;
}

/* Sliced still-image decode, mirroring the WebM glue: each call
 * performs one bounded unit of work and returns IMAGE_PROCESS_NEXT
 * until the first displayed frame is ready - stream open, pre-scan in
 * RMP4_VIDEO_SCAN_SLICE-packet chunks, decoder setup, then one coded
 * packet per call (an H.264 picture held for display reordering takes
 * its own slice) - so the still decode no longer monopolises the
 * cooperative task queue in a single process call. */
int rmp4_video_process_image(rmp4_video_t *mp4, void **buf,
      size_t len, unsigned *width, unsigned *height, bool supports_rgba)
{
   rmp4_video_stream_t *s;
   const uint32_t *frame;
   uint32_t *out;
   int r;
   int duration_ms = 0;

   (void)len;

   if (!mp4 || !mp4->buf || !buf)
      return IMAGE_PROCESS_ERROR;

   /* A partial reader raises mp4->avail between calls; push it down
    * so blocked stages can make progress this call. */
   if (mp4->stream && mp4->partial)
      rmp4_video_stream_set_avail(mp4->stream, mp4->avail);

   switch (mp4->still_stage)
   {
      case RMP4_VIDEO_STILL_IDLE:
      {
         int    need_more = 0;
         size_t avail     = mp4->partial ? mp4->avail : mp4->len;
         /* Defensive: a repeated process call re-opens from scratch. */
         if (mp4->stream)
         {
            rmp4_video_stream_close(mp4->stream);
            mp4->stream = NULL;
         }
         if (!(mp4->stream = rmp4_video_stream_open_begin(
               mp4->buf, mp4->len, avail, &need_more, NULL, NULL, 0)))
            /* The moov is still arriving (or, for a trailing moov or a
             * fragmented movie, most of the file is): wait for more
             * bytes rather than failing. */
            return need_more ? IMAGE_PROCESS_WAIT : IMAGE_PROCESS_ERROR;
         mp4->still_stage = RMP4_VIDEO_STILL_SCAN;
         return IMAGE_PROCESS_NEXT;
      }

      case RMP4_VIDEO_STILL_SCAN:
         if (!rmp4_video_stream_scan_step(mp4->stream,
               RMP4_VIDEO_SCAN_SLICE))
            return IMAGE_PROCESS_NEXT;
         if (rmp4_video_stream_open_finish(mp4->stream) != 0)
            goto fail;
         /* Request 10-bit output; the stream honours it only for
          * 10-bit sources.  For 8-bit output, have the blit emit the
          * caller's channel order directly (supports_rgba is sampled
          * once per transfer by task_image, so the value seen here
          * holds for the END slice's copy below). */
         mp4->stream->want10    = mp4->want10;
         mp4->stream->emit_argb = supports_rgba ? 0 : 1;
         /* An HDR source for a caller that takes half floats: the
          * still renders straight into the frame handed out, at 8
          * bytes a pixel. Without the memory it is an ordinary still. */
         free(mp4->still_fp16);
         mp4->still_fp16 = NULL;
         if (     mp4->want_fp16
               && mp4->stream->width <= SIZE_MAX / 8 / mp4->stream->height
               && rmp4_video_stream_is_hdr(mp4->stream)
               && (mp4->still_fp16 = (uint16_t*)malloc(
                     (size_t)mp4->stream->width
                     * mp4->stream->height * 8)))
         {
            mp4->stream->out       = (uint32_t*)mp4->still_fp16;
            mp4->stream->want_fp16 = 1;
         }
         mp4->still_stage       = RMP4_VIDEO_STILL_DECODE;
         return IMAGE_PROCESS_NEXT;

      case RMP4_VIDEO_STILL_DECODE:
         break;

      default:
         return IMAGE_PROCESS_ERROR;
   }

   s = mp4->stream;
   if ((r = rmp4_video_stream_step(s, &duration_ms, 0)) == 0)
      return IMAGE_PROCESS_NEXT;   /* non-shown frame decoded */
   if (r == 2)
      /* The next sample's bytes have not been read yet; nothing was
       * consumed - resume here once more of the file has arrived. */
      return IMAGE_PROCESS_WAIT;
   if (r < 0)
      goto fail;
   if (!(frame = rmp4_video_stream_render(s)))
      goto fail;

   mp4->last_10bit = s->is10;
   mp4->last_fp16  = s->is_fp16;

   if (mp4->still_fp16)
   {
      /* Rendered where it is handed out: half floats from a 10-bit HDR
       * frame, or the 32-bit words of any other, either way in place.
       * The stream lets go of it before it plays on as an animation. */
      out             = (uint32_t*)mp4->still_fp16;
      mp4->still_fp16 = NULL;
      s->out          = NULL;
      s->want_fp16    = 0;
   }
   else
   {
      /* Hand the renderer's canvas to the image owner. Playback either
       * renders into a caller's slot or allocates a new canvas; it must
       * never overwrite or free the still after this transfer. */
      if (!frame || frame != s->frame)
         goto fail;
      out = s->frame;
      s->frame = NULL;
   }

   if (width)
      *width  = s->width;
   if (height)
      *height = s->height;
   *buf = out;

   /* Keep the stream (positioned just past the first displayed frame)
    * so the caller can detach it and continue the video as an
    * animation without re-opening the file.  If nobody detaches it,
    * rmp4_video_free closes it. */
   mp4->still_stage = RMP4_VIDEO_STILL_IDLE;
   return IMAGE_PROCESS_END;

fail:
   rmp4_video_stream_close(mp4->stream);
   mp4->stream      = NULL;
   mp4->still_stage = RMP4_VIDEO_STILL_IDLE;
   free(mp4->still_fp16);
   mp4->still_fp16  = NULL;
   return IMAGE_PROCESS_ERROR;
}
