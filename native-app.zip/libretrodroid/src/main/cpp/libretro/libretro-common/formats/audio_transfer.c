/* Copyright  (C) 2010-2024 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (audio_transfer.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* audio_transfer -- one pull interface over every audio codec in the
 * tree.  A caller that wants interleaved PCM out of a file it holds in
 * memory allocates a state for the type (audio_transfer_new), points
 * it at the bytes (audio_transfer_set_buffer_ptr), starts it, and
 * pulls with audio_transfer_read_s16 or _read_f32 until
 * AUDIO_PROCESS_END; audio_transfer_info reports the channel count and
 * sample rate once decoding has begun.  <formats/audio.h> declares the
 * API and per-call contracts.
 *
 * Each codec sits behind its own arm, compiled in by its HAVE_ flag:
 * WAV (rwav), FLAC (rflac), Ogg Vorbis (rvorbis), MP3 (rmp3's stream
 * interface), Opus (ropus), AAC-LC (raac) and tracker modules
 * (rmodtracker).  The arms own whatever adaptation their codec needs -
 * walking Ogg pages into packets, feeding rflac and rmp3 their spans,
 * batching ropus packets, stepping raac access units - so that the
 * caller sees the same four calls whichever format it was handed.
 *
 * Two ways in.  A buffer is the whole file as it sits on disk, and the
 * type helpers say which arm reads it: audio_transfer_ogg_audio_type
 * looks inside an Ogg container (Vorbis, Opus or FLAC), and
 * audio_transfer_webm_audio_type inside a WebM/Matroska one, whose
 * arms then own an rwebm demuxer internally.  Demuxed input
 * (audio_transfer_set_demuxed_ptr) is for a caller that already runs a
 * container demuxer - rmp4 hands the codec setup data and the
 * elementary-stream packets straight through, so the same Vorbis, FLAC,
 * Opus and AAC arms serve MP4 audio without a container of their own.
 *
 * The remaining calls serve streaming and gapless playback:
 * audio_transfer_set_avail tells a WebM-backed arm how much of a still
 * -downloading buffer is valid so it stops at the frontier instead of
 * misreading truncation as corruption; audio_transfer_set_end_granule
 * and audio_transfer_set_start_trim carry edge trims (Opus pre-skip
 * and end granule, MP3 LAME delay/padding) so the decoded stream
 * starts and ends on the encoded material rather than the codec
 * priming; audio_transfer_buffer_tell reports consumption for callers
 * that window their reads; and audio_transfer_seek moves to an
 * absolute PCM frame, which is how a looping voice returns to the top
 * without tearing the state down.  A demuxed packet set may also be
 * re-pointed and grown mid-stream for progressive sources - the
 * contract for that lives with set_demuxed_ptr in the header. */

#include <stdlib.h>
#include <features/features_cpu.h>
#include <string.h>

#include <file/file_path.h>
#include <formats/audio.h>
#include <compat/strcasestr.h>
#include <string/stdstring.h>
#ifdef HAVE_RWMA
#include <formats/rwma_stream.h>
#endif

#ifdef HAVE_RFLAC
#include <formats/rflac.h>
#endif
#ifdef HAVE_RVORBIS
#include <formats/rvorbis.h>
#endif
#ifdef HAVE_RMP3
#include <formats/rmp3.h>
#endif
#ifdef HAVE_RWAV
#include <formats/rwav.h>
#endif
#ifdef HAVE_RMODTRACKER
#include <formats/rmodtracker.h>
#endif
#if defined(HAVE_ROPUS) || defined(HAVE_RFLAC) || defined(HAVE_RVORBIS)
/* Validate the Ogg page at off and return its total size (header plus
 * body), or 0 if there is no valid page there.  On success the body
 * offset and segment count are stored. */
static size_t audio_transfer_ogg_page(const uint8_t *buf, size_t size,
      size_t off, size_t *body, unsigned *nsegs)
{
   size_t hdr, total;
   unsigned i, n;
   if (off + 27 > size)
      return 0;
   if (memcmp(buf + off, "OggS", 4) != 0 || buf[off + 4] != 0)
      return 0;
   n   = buf[off + 26];
   hdr = 27 + n;
   if (off + hdr > size)
      return 0;
   total = hdr;
   for (i = 0; i < n; i++)
      total += buf[off + 27 + i];
   if (off + total > size)
      return 0;
   if (body)
      *body = off + hdr;
   if (nsegs)
      *nsegs = n;
   return total;
}
#endif

#ifdef HAVE_ROPUS
#include <formats/ropus.h>
#endif
#ifdef HAVE_RAC3
#include <formats/rac3.h>
#endif
#ifdef HAVE_RLPCM
#include <formats/rlpcm.h>
#endif
#ifdef HAVE_RATRAC3
#include <formats/ratrac3.h>
#endif
#ifdef HAVE_RATRAC3P
#include <formats/ratrac3p.h>
#endif
#ifdef HAVE_RAAC
#include <formats/raac.h>
#endif
#ifdef HAVE_RMP4
#include <formats/rmp4.h>
#endif
#if defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) \
 || defined(HAVE_RVORBIS) || defined(HAVE_RAAC) || defined(HAVE_RFLAC))
#include <formats/rwebm.h>
#endif

/* ---- What each codec arm implements, and what it does not ------------
 *
 * The dispatch below is uniform but the arms are not: each decoder
 * supports a different subset of the audio.h contract, and the gaps are
 * deliberate rather than pending.  Nothing degrades silently - an
 * unsupported operation fails at its entry point (start() and seek()
 * return false, info() reports what it knows and 0 for a length it does
 * not, buffer_tell() returns 0 for an arm with no windowable cursor).
 *
 * "buffer" below means set_buffer_ptr, i.e. a whole self-framed file;
 * "demuxed" means set_demuxed_ptr, i.e. a container's setup blob plus
 * its delimited packets.  Each codec is separately compile-gated; an arm
 * whose HAVE_ is off makes new() return NULL for that type.
 *
 * WAV (rwav)
 *   Does: buffer input; s16 and f32 reads; exact length; seek to any
 *     frame; buffer_tell, hence windowing.  Every format rwav reads:
 *     8-bit unsigned PCM, 16- and 24-bit signed, 32-bit IEEE float,
 *     G.711 a-law and mu-law at eight bits carrying a logarithmic
 *     sixteen, and the MS and IMA/DVI ADPCM layouts at four bits in
 *     blocks that each restate their predictor.  A
 *     WAVE_FORMAT_EXTENSIBLE header naming any of them resolves to it,
 *     and rwav walks the chunk list, so LIST, fact, cue and the rest
 *     before the samples are no obstacle.
 *
 *     start() parses the header alone and frames are converted out of
 *     the caller's buffer as they are asked for, so the arm holds no
 *     decoded copy and buffer_tell reports the read frontier: WAV
 *     windows like the compressed arms, its residency a window rather
 *     than the file.  The uncompressed formats are read a sample at a
 *     time from the buffer; the companded and coded ones go through
 *     rwav_decode_s16, which the first pair need for their curve and
 *     the second because their payload is not addressable a frame at
 *     a time.  A block being self-contained, a read starting anywhere
 *     decodes only the block it lands in, so seeking costs no more
 *     than on PCM.
 *
 *     Multichannel parses here and plays: the mixer folds anything up
 *     to eight channels to stereo, so a 5.1 WAV is heard rather than
 *     refused, as a 5.1 FLAC is.
 *   Does not: take demuxed input.  Nor the rarer codecs a WAV can
 *     nominally carry - GSM and the like - which rwav refuses at the
 *     header rather than decoding as though their bytes were PCM.
 *
 * FLAC (rflac)
 *   Does: buffer input; s16 and f32, freely mixed; channels, rate and
 *     length from STREAMINFO; seek to any frame; buffer_tell, hence
 *     windowing (the raw cursor leads the decode position by the
 *     bitstream cache, which is the safe side for a feeder).
 *     A_FLAC in Matroska (.mka/.mkv, HAVE_RWEBM) plays too, and needs
 *     no synthesis to do it: the CodecPrivate is a whole fLaC header,
 *     magic and metadata blocks, and every block is one raw frame, so
 *     the native stream rflac takes is those laid end to end.  What
 *     that produces is a real FLAC stream rather than a stand-in, so
 *     the STREAMINFO length, seeking and buffer_tell all work on it as
 *     they do on a .flac file - none of what made the Vorbis arm's old
 *     Ogg synthesis wrong applies, that having had to invent framing
 *     and granules this does not.  Nor is the stream reassembled: it
 *     is handed to the decoder a block at a time where the demuxer
 *     finds it, so nothing is copied.
 *     Ogg FLAC (RFC 5334) as well, and by the same means: an Ogg page
 *     body is packet bytes with no framing of its own, so the bodies
 *     end to end past the nine-byte mapping header on the first
 *     packet are the native stream, handed over the same way.
 *     And demuxed input: the fLaC header as setup and the frames as
 *     delimited packets, which is what the containers above are
 *     reduced to anyway, so it is the same feed again.  The
 *     packet set may be grown mid-stream - the bases are read fresh
 *     at every read rather than kept, so a realloc between reads is
 *     no obstacle.
 *     Running dry is not the end of the stream on any of them: a
 *     demuxed packet set that grows, or a windowed WebM whose wall is
 *     raised, resumes at the next read, a frame split across the
 *     boundary being held by the decoder until the rest arrives.  A
 *     windowed WebM stalls at its wall (NEXT, nothing produced); the
 *     demuxed arm, which cannot tell a pause from the end, returns END
 *     unlatched, as the other demuxed arms do.
 *   Does not: report a length where the STREAMINFO does not state one:
 *     Ogg FLAC never states one, and neither does a native file piped
 *     rather than seeked.  Seeking still works on those - it is only
 *     the total that is missing, and info() answers 0.
 *
 *     Seeking on the Matroska path costs more than on a .flac: rflac
 *     seeks by byte offset while a demuxer only walks forwards, so a
 *     backwards seek restarts the block walk and reads forward to the
 *     target.  The file is resident, so that is a pass over block
 *     headers rather than any I/O, and only a caller's own seek
 *     reaches it.
 *
 * Vorbis (rvorbis)
 *   Does: three inputs - Ogg buffer, WebM buffer (.weba, HAVE_RWEBM,
 *     packets pulled from rwebm on demand), and demuxed (CodecPrivate +
 *     packets); s16 and f32, freely mixed; channels and rate.  The two
 *     packet-fed inputs decode raw packets where the container holds
 *     them (rvorbis_open_packets), so no Ogg is synthesised, nothing is
 *     copied, and the packets are read as they are played rather than
 *     held for the decoder's lifetime.  From an Ogg buffer: length from
 *     the last page granule, seek to any frame, rewind, buffer_tell,
 *     hence windowing.
 *
 *     From WebM: end trimming.  Vorbis codes in overlapping blocks, so
 *     the last packet decodes past the end of the audio, and two
 *     things say where that end is.  The container's DiscardPadding,
 *     which arrives on the block it applies to, is exact - a resident
 *     buffer has already totalled it in the start() walk, so the bound
 *     holds before a frame is decoded, and a windowed one applies it
 *     when that block arrives.  A stated Duration is not exact, being
 *     the muxer's figure rather than the stream's, but it is there
 *     when a padding is not: a file remuxed from Ogg carries a
 *     padding, one encoded straight to WebM often does not.  The
 *     tighter of the two bounds emission, so a padded file is trimmed
 *     to the sample and an unpadded one to whatever the Duration
 *     claims, which still overshoots.
 *
 *     buffer_tell, hence windowing: the packets are decoded where the
 *     demuxer points at them, so its walk position is the compressed
 *     frontier, and start() reads no further than the header material
 *     unless it is walking for the length above.  A windowed caller
 *     must say so with set_avail, and keep saying so as its window
 *     slides: rwebm's header parse walks the segment's top-level
 *     children as far as its wall, which without one is the end of the
 *     file - and the length walk is skipped there for the same reason.
 *
 *     Seeks to any frame, exactly, from a resident WebM buffer: a
 *     Vorbis packet's frame count can be read off its header
 *     (rvorbis_packet_frames), so the walk to a target decodes
 *     nothing, and priming on the packet before it resumes output
 *     identical to the playthrough's rather than converging on it.
 *     Demuxed packets get the same treatment as a resident WebM,
 *     being resident by definition: the header walk at start gives
 *     the exact length, a seek counts packets to the target and lands
 *     on the sample, and buffer_tell reports how far into the blob
 *     the decoder has read.  That last is a byte offset into the
 *     caller's packets rather than into a buffer set by
 *     set_buffer_ptr, there being none - the same quantity for the
 *     same purpose, and what a feeder growing the set wants.  The
 *     Opus and AAC demuxed arms still report nothing there.
 *     A windowed context seeks too, within what has arrived.  What
 *     set_avail bounds is a prefix that only grows, not a window that
 *     slides, so every byte below it stays readable and the walk
 *     reaches any target inside it exactly.  A target past the wall
 *     is refused rather than approximated, and succeeds once the
 *     feeder has raised the bound past it, so a caller may simply
 *     retry.  A refused seek leaves the stream rewound.
 *
 *     No end trim on the demuxed path, its packet set being the
 *     caller's: with no padding stated, the last packet's overlap-add
 *     overhang is handed out with the rest, and the length reported
 *     is that total rather than a trimmed one.  It is what comes out,
 *     which is the property the length is meant to have.
 *
 *     Chained and multiplexed Ogg both play.  A survey of the page
 *     headers at open says how many logical bitstreams the file
 *     carries, which of them is Vorbis, and where each ends; a file
 *     with one goes to rvorbis whole, as every .ogg always has.
 *
 *     A multiplexed file cannot: rvorbis has no notion of a serial
 *     number and would take the other stream's pages for its own, so
 *     those go to the packet path, where the page walk filters by
 *     serial and assembles packets across page boundaries.  That
 *     brings the exact length and sample-accurate seek with it.
 *
 *     A chained file rvorbis does decode through, link after link,
 *     but it reports the first link's length for the whole file and
 *     hands out the lead of each next link's first block - audio no
 *     granule accounts for.  The length is the summed final granules
 *     of the Vorbis bitstreams, and reads are bounded by it, so what
 *     info() says and what comes out are the same figure again.
 *     Links that disagree on rate or channels are noticed: the survey
 *     reads each one's identification header, and where they differ
 *     the stream is bounded to the first link.  A voice is built
 *     around the values read at open, so the alternative is playing
 *     the later links at the wrong speed.  What info() reports is
 *     again what comes out - the first link's length.
 *   Does not: play the later links of such a file at all.  Following
 *     them would mean rebuilding the voice mid-stream, which is the
 *     mixer's business rather than this arm's.
 *
 *     On channels this arm is not the limit: rvorbis decodes one
 *     through sixteen, verified against libvorbis, and reports what
 *     the stream holds.  A 5.1 file therefore parses here and plays:
 *     the mixer folds up to eight channels to stereo, and refuses
 *     only what is wider than that.
 *
 * MP3 (rmp3)
 *   Does: buffer input, decoded through rmp3_stream - the buffer is
 *     consumed incrementally rather than borrowed whole, so
 *     buffer_tell reports a real frontier, the bytes behind it
 *     releasable rather than merely read (it leads the decode position
 *     by at most the stream's reassembly hold, the safe side for a
 *     feeder); s16 (quantised by the synthesis filter, no float round
 *     trip) and f32, freely mixed - the stream converts its filter
 *     state at the switch as the pull API did; channels and rate from
 *     the first frame's header, read at open by a parse-only walk that
 *     decodes nothing; seek to any PCM frame, recorded at seek() and
 *     performed at the following read as a decode forward from the
 *     head in that read's own pipeline, so the audio after a seek is
 *     byte-identical to a linear decode's - MP3 frames depend on the
 *     bit reservoir of their predecessors, so the top is the only
 *     sample-accurate way in, which is also what the resident decoder
 *     did, minus its habit of carrying stale synthesis state through
 *     the rewind. Windowed input supports refill during priming and
 *     rewind; nonzero seeks require fully available input.
 *     Length and gapless trim from the Xing/Info or VBRI header in the
 *     first frame: that frame carries no audio but is decoded like any
 *     other, so the priming dropped is its own length plus the encoder
 *     delay a LAME tag states, and the padding bounds the end.  What
 *     info() reports is what comes out.  set_start_trim overrides the
 *     tag's delay, for a caller whose container knows better.
 *     A file carrying no such header is measured by walking its frame
 *     headers instead - each states its own bitrate and so its own
 *     size, which works on a variable-bitrate stream as well as a
 *     constant one.  It is a step per frame over four bytes, not a
 *     decode: 1.1 ms for a ten-minute file, measured, which is why
 *     the length is worth having rather than reporting nothing.  What
 *     it counts is what the decoder emits, priming included, there
 *     being no tag to say which of that was padding - so info() and
 *     the output agree here as they do everywhere else.
 *   Does not: take demuxed input.
 *
 * MOD (rmodtracker)
 *   Does: buffer input, MOD/S3M/XM autodetected; s16 and f32; the
 *     duration of one pass through the sequence; rewind; mixing at a
 *     rate the caller asks for through set_output_rate, a replayer
 *     synthesising at whatever rate it is given, so a caller that says
 *     what its output rate is gets audio it need not resample.
 *     Seeks anywhere, including mid-song: a module has no seek table,
 *     so the replayer restarts and walks the sequence forward with the
 *     mixing skipped, which costs time proportional to the distance and
 *     spends it on the calling thread.
 *   Does not: report the module's own channel count through info(),
 *     which says 2 because the replayer mixes to interleaved stereo
 *     and that is what the count in this API means - a module's four
 *     or thirty-two are voices being mixed, not channels being
 *     emitted.  The module's figure is not lost, only elsewhere:
 *     rmodtracker_voices returns it, for a caller wanting to say
 *     something about the file rather than about its output.
 *     No buffer cursor, and no windowing to use one for: the module is
 *     parsed into the replayer's own structures at open, after which
 *     the caller's bytes are not read again, and sample data is
 *     revisited at random for as long as the song plays - neither the
 *     monotonic read nor the bounded head that windowing needs.  No
 *     demuxed input.
 *
 * Opus (ropus)
 *   Does: mono through eight channels, mapping families 0 and 1, the
 *     channels emitted in the stream's own order rather than any
 *     player's layout; three inputs - Ogg Opus buffer (.opus, pages walked in place
 *     per RFC 3533/7845, a packet copied only where it spans pages),
 *     WebM buffer (.weba, HAVE_RWEBM, packets pulled from rwebm on
 *     demand), and demuxed (OpusHead + delimited packets); s16 and f32;
 *     RFC 7845 pre-skip; end trimming, from the last page granule for
 *     Ogg and from the TOC total less DiscardPadding for WebM; windowed
 *     operation, via set_end_granule plus buffer_tell for Ogg, and
 *     via set_avail plus buffer_tell for WebM, whose packets are read
 *     where the demuxer points at them;
 *     rewind, and seek: a packet carries its duration in its first
 *     byte, so the packets before the target are stepped over without
 *     being decoded and only a pre-roll before it is decoded and
 *     dropped.  A seek made before the first read is carried out at
 *     that read, the decoding it does being what fixes the output
 *     format for the context.
 *   Does not: mix output formats on one instance - the first read
 *     latches fmt and the other entry point then errors for the life of
 *     the context, because ropus decodes s16 and f32 through separate
 *     pipelines and forbids the mix.  AAC, whose decoder is one float
 *     pipeline with two output edges, has no such restriction.  No
 *     length from the demuxed path, whose packet set is the caller's;
 *     the buffer modes do report one, being
 *     the bound they already hold emission to.  A resident WebM walks
 *     the packets' TOC bytes at open for that bound; a windowed one
 *     cannot - the walk would run at the wall - and totals them as it
 *     plays instead, taking the padding off when the block carrying it
 *     arrives, so its length is a stated Duration until then - or
 *     nothing at all until then, where the file states no Duration
 *     either, which a live-muxed one does not.  Chained or multiplexed
 *     Ogg is not handled - pages are walked in order, the serial is
 *     ignored and the page CRC is not verified.  A page-spanning packet
 *     larger
 *     than asm_buf is an error, not a reallocation.  Channel mapping
 *     family 1 - a surround stream is several substreams scattered to
 *     the output channels by the head's mapping table - and refuses
 *     families 2, 3 and 255.  As with Vorbis the arm is not where a
 *     multichannel file stops; the mixer folds up to eight channels
 *     to stereo and refuses only what is wider.
 *     The rate is always the 48 kHz Opus decodes at, never the
 *     original input rate.
 *
 * AAC (raac)
 *   Does: three inputs - ADTS buffer (.aac, the AudioSpecificConfig
 *     synthesised from the first header), MP4/M4A buffer (HAVE_RMP4,
 *     packets from rmp4, start trim from the track's edit list),
 *     Matroska buffer (.mka/.mkv, HAVE_RWEBM, the ASC being the
 *     track's CodecPrivate and the access units its blocks, with the
 *     priming from CodecDelay), and demuxed (ASC + delimited access
 *     units, trim via set_start_trim); s16 and f32, freely mixed at any point (the
 *     pending frames stay inside raac, planar, and each read
 *     interleaves and converts its slice of them straight into the
 *     caller's buffer, so the samples are raac_decode_s16's or
 *     raac_decode_f32's whichever is asked for); the
 *     encoder-delay trim, and, from an MP4, the end trim too - the
 *     declared duration bounds emission, so the tail padding coded into
 *     the last access unit is not handed out and the length info()
 *     reports is the length that comes out; rewind; buffer_tell in ADTS
 *     mode, hence windowing there.
 *     Seeks: every access unit this decoder takes yields a fixed
 *     raac_frame_len() frames, so
 *     the units before the target are counted rather than decoded and
 *     only a pre-roll before it is decoded and dropped.
 *   Does not: reproduce a playthrough exactly across a seek where the
 *     encoder used noise substitution - the reset a seek needs reseeds
 *     the noise generator, and substituted noise is noise rather than
 *     coded samples.  Measured, because how far off it lands matters
 *     and the size of it depends entirely on the material: encoded
 *     with substitution off, a seek reproduces the playthrough
 *     bit for bit, on a tone and on noise alike; with it on, a tone
 *     comes back within a third of an LSB and pink noise about 700
 *     against a signal of 2270, which is ten dB down and plainly
 *     audible.  The bands the encoder chose
 *     to substitute are the ones that differ, so tonal material
 *     barely moves and noise-like material moves a lot.
 *
 *     Reports a length only from an MP4 or a Matroska, which declare
 *     one - though a Matroska's
 *     Duration spans what the stream codes, priming included, where an
 *     MP4's edit list is already net of it, so the trim comes off the
 *     one and not the other.  An ADTS stream would have to be walked
 *     to be measured, and the demuxed path's packets are the
 *     caller's.  ADTS carries no delay signalling, so
 *     that path forces the trim to 0 and is not gapless.  A lost ADTS
 *     sync is reported as end of stream rather than resynchronised.
 *     Beyond that the scope is raac's: the AAC-LC core (no
 *     Main/SSR/LTP) with raac's SBR upsampling path, whose doubled
 *     frame length and output rate this arm follows via
 *     raac_frame_len()/raac_sample_rate(); parametric stereo payloads
 *     are skipped (HE-AAC v2 decodes as v1).  The ADTS header parse
 *     refuses anything outside raac's scope before the decoder is
 *     opened.
 *
 * Across all arms: no file I/O and no ownership of the encoded bytes -
 * buffers are borrowed and must outlive the decoder (rmodtracker copies
 * the module at start(), so MOD alone is exempt afterwards).  No
 * resampling and no channel conversion; PCM comes out at the stream's
 * own rate and channel count and the mixer deals with it.  A short read
 * is not end of stream: only a zero-frame read returns
 * AUDIO_PROCESS_END, and END is not latched, which is what lets a grown
 * demuxed packet set resume after starvation.  AUDIO_PROCESS_ERROR_END
 * is never returned from here.  A context is single-threaded; nothing
 * below locks.  audio_decode_get_type maps extensions for WAV, FLAC,
 * Ogg Vorbis, MP3 and MOD only - .opus, .aac, .m4a and .weba have no
 * extension mapping, their types coming from the caller or from the
 * content sniffers (audio_transfer_ogg_audio_type,
 * audio_transfer_webm_audio_type), .ogg being ambiguous between Vorbis
 * and Opus in any case. */

#if defined(HAVE_RWAV) || defined(HAVE_RAC3) || defined(HAVE_RATRAC3) \
 || defined(HAVE_RATRAC3P)
/* Unit-scale float (full scale +-1.0) to s16, the conversion raac
 * applies at its own edge, for the arms whose float arrives at unit
 * scale already (float WAV, AC-3).  A float source can carry anything, including
 * non-finite values, and casting one of those to int is undefined, so
 * pin and saturate before the cast. */
static int16_t audio_transfer_unit_to_s16(float unit)
{
   float v = unit * 32768.0f;
   if (!(v > -1e9f && v < 1e9f))
      v = 0.0f;
   v += (v >= 0.0f) ? 0.5f : -0.5f;
   if (v >  32767.0f)
      v =  32767.0f;
   if (v < -32768.0f)
      v = -32768.0f;
   return (int16_t)(int)v;
}
#endif

static uint32_t audio_transfer_le32(const uint8_t *p)
{
   return (uint32_t)p[0] | ((uint32_t)p[1] << 8)
        | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

/* One transfer context per codec. Each backend keeps only what it needs;
 * the enum 'type' handed to every entry point selects which arm runs, the
 * same switch-dispatch pattern formats/image_transfer.c uses. */

/* WAV holds no decoded copy: start() parses the header alone and the
 * reads convert frames straight out of the caller's buffer, so the arm
 * costs the header and a cursor however long the file is, and exposes a
 * read frontier the way the compressed arms do. */
#ifdef HAVE_RWAV
struct audio_transfer_wav
{
   const uint8_t *data; /* encoded bytes from set_buffer_ptr (caller-owned) */
   size_t      size;
   rwav_t      wav;     /* format + payload location; samples stays NULL    */
   int         opened;  /* rwav_parse succeeded                             */
   size_t      cursor;  /* next frame to hand out                           */
   /* bytes per frame: channels * bits/8, and 0 for a block-coded
    * payload, which has no per-frame size.  Every reader tests the
    * format and takes the decoder before reaching it. */
   size_t      framesz;
   /* s16 staging for the f32 read of a companded or block-coded
    * payload, which rwav decodes to s16 natively.  Owned here rather
    * than shared, and grown to the request; NULL until one is made,
    * so a PCM or float file never allocates it. */
   int16_t    *scratch;
   size_t      scratch_cap;  /* samples, not frames                     */
};
#endif

#if defined(HAVE_RAAC) || defined(HAVE_ROPUS) || defined(HAVE_RVORBIS) || defined(HAVE_RFLAC)
/* Container movie time is separate from the decoder's post-trim source
 * count. Only internally demuxed inputs enable this state: callers of
 * set_demuxed_ptr already own their presentation mapping. The state is
 * constant-sized and retains no packet or encoded-buffer addresses. */
struct audio_transfer_time
{
   int enabled, first_ready, ready, continued, eof, producing_anchor;
   unsigned rate;
   int64_t first, pts, anchor, bias, end, pending, position, total, delay_ns;
};

static int audio_transfer_time_add(int64_t a, int64_t b, int64_t *out)
{
   const int64_t maximum = (int64_t)((~(uint64_t)0) >> 1);
   if ((b > 0 && a > maximum - b) || (b < 0 && a < -maximum - b))
      return 0;
   *out = a + b;
   return 1;
}

#if defined(HAVE_RWEBM) || (defined(HAVE_RAAC) && defined(HAVE_RMP4))
static int audio_transfer_time_frames(int64_t ns, unsigned rate, int64_t *out)
{
   const int64_t maximum = (int64_t)((~(uint64_t)0) >> 1);
   int64_t seconds = ns / 1000000000;
   int64_t fraction = (ns % 1000000000) * (int64_t)rate;
   if (!rate || seconds > maximum / rate || seconds < -maximum / rate)
      return 0;
   fraction = (fraction + (fraction >= 0 ? 500000000 : -500000000)) / 1000000000;
   return audio_transfer_time_add(seconds * rate, fraction, out);
}

static int audio_transfer_time_packet(struct audio_transfer_time *t,
      int64_t ns, int continued)
{
   if (!t->enabled) return 1;
   if (!audio_transfer_time_add(ns, -t->delay_ns, &ns)) return 0;
   if (!audio_transfer_time_frames(ns, t->rate, &t->pts)) return 0;
   if (!t->first_ready) { t->first = t->pts; t->first_ready = 1; }
   t->continued = continued;
   return 1;
}
#endif

#if defined(HAVE_RAAC) || defined(HAVE_ROPUS) || defined(HAVE_RVORBIS) || defined(HAVE_RWEBM)
static int audio_transfer_time_map(struct audio_transfer_time *t,
      size_t skip, size_t frames)
{
   int64_t start, anchor, end;
   int64_t jitter = (int64_t)t->rate / 1000 + 1;
   const int64_t maximum = (int64_t)((~(uint64_t)0) >> 1);
   if (!t->enabled || !frames) return 1;
   if ((uint64_t)skip > (uint64_t)maximum || (uint64_t)frames > (uint64_t)maximum
         || !audio_transfer_time_add(t->pts, (int64_t)skip, &start)) return 0;
   if (!t->ready)
   {
      if (t->producing_anchor) anchor = start;
      else if (!audio_transfer_time_add(t->first, t->anchor, &anchor)) return 0;
      if (anchor >= -jitter && anchor <= jitter) anchor = 0;
      /* Negation is safe: checked timestamp conversion excludes INT64_MIN. */
      if (!audio_transfer_time_add(anchor, -start, &t->bias)) return 0;
      t->ready = 1;
   }
   if (!audio_transfer_time_add(start, t->bias, &start)) return 0;
   if (t->continued || (start >= t->end - jitter
            && (start <= t->end || start - t->end <= jitter))) start = t->end;
   if (!audio_transfer_time_add(start, (int64_t)frames, &end)) return 0;
   t->pending = start;
   if (end > t->end) t->end = end;
   return 1;
}

#endif

/* Drop overlap without dropping decoder history. The caller owns the
 * existing pending PCM buffer and advances it by the returned count. */
static size_t audio_transfer_time_overlap(struct audio_transfer_time *t,
      size_t frames)
{
   uint64_t count;
   if (!t->enabled || t->pending >= t->position) return 0;
   count = (uint64_t)t->position - (uint64_t)t->pending;
   if (count > frames) count = frames;
   t->pending += (int64_t)count;
   return (size_t)count;
}

static size_t audio_transfer_time_silence(struct audio_transfer_time *t,
      size_t want, int eof)
{
   int64_t end;
   uint64_t count;
   if (!t->enabled) return 0;
   end = eof ? t->total : t->pending;
   if (t->total >= 0 && end > t->total) end = t->total;
   if (end <= t->position) return 0;
   count = (uint64_t)(end - t->position);
   if (count > want) count = want;
   t->position += (int64_t)count;
   return (size_t)count;
}

#endif

#ifdef HAVE_RFLAC
struct audio_transfer_flac
{
   const void *data;    /* encoded bytes from set_buffer_ptr (caller-owned) */
   size_t      size;
   rflac_t    *handle;  /* opened decoder, NULL until start() succeeds      */
   unsigned requested_track; /* zero: automatic; otherwise container index + 1 */
   int         fed_hdr; /* setup bytes handed over                          */
   size_t      cursor;  /* bytes of the logical stream handed to the decoder*/
   /* FLAC inside a container.  rflac wants a native fLaC stream; a
    * container holds one taken apart, so it is handed to the decoder a
    * span at a time where it lies rather than reassembled into a
    * buffer.  Nothing is copied.
    *
    * Two containers, one shape.  Matroska keeps the header in
    * CodecPrivate and a frame per block.  Ogg (RFC 5334) needs even
    * less: a page body is packet bytes with no framing of its own, so
    * the bodies laid end to end are the native stream already, once
    * the nine-byte mapping header on the first packet is stepped
    * over.
    *
    * pos is the byte offset within that notional stream, which is
    * what rflac seeks against; cur is the chunk being served. */
   int            ogg;      /* buffer is Ogg FLAC                       */
   size_t         pg_off;   /* next Ogg page                            */
   /* Demuxed input (set_demuxed_ptr): the fLaC header as setup, then
    * the frames as delimited packets.  The base pointers are read
    * fresh at every use rather than cached, because the growth
    * contract lets a caller realloc them mid-stream; position is
    * carried as an index and a byte offset, which survive that. */
   const void      *setup;
   size_t           setup_size;
   const uint8_t   *packets;
   size_t           packets_size;
   const uint32_t  *pkt_sizes;
   size_t           num_packets;
   size_t           pkt_index;
   size_t           blob_off;  /* byte offset of the current packet     */
#ifdef HAVE_RWEBM
   rwebm_t       *demux;
   int            track_idx;
   /* A windowed caller's resident prefix, given before start() so the
    * demuxer opens behind it rather than walking the whole buffer; 0
    * is the whole buffer, as for the other WebM arms. */
   size_t         avail;
#endif
   const uint8_t *hdr;
   size_t         hdr_size;
   size_t         pos;
   const uint8_t *cur;
   size_t         cur_len;
   size_t         cur_off;
   /* The last empty pull stopped at the resident wall, not the end of
    * the stream.  Set at the pull that met the wall, cleared when a
    * packet flows again; audio_transfer_read_* consults it so a stall
    * surfaces as AUDIO_PROCESS_NEXT with zero frames instead of being
    * mistaken for end of stream - which a looping mixer voice answers
    * with a mid-file rewind, and a second stall with releasing the
    * voice entirely. */
   struct audio_transfer_time time;
   int64_t        duration_ns;
   size_t         time_pending, time_skip;
   uint8_t        yielded;
   uint8_t        wall;
   uint8_t        seek_pending;
   uint64_t       seek_remaining;
};
#endif

#ifdef HAVE_RVORBIS
struct audio_transfer_vorbis
{
   const void *data;
   size_t      size;
   rvorbis    *handle;
   unsigned requested_track; /* zero: automatic; otherwise container index + 1 */
   int         channels; /* cached from rvorbis_get_info at start           */
   /* Demuxed-input path (set_demuxed_ptr): the container's CodecPrivate
    * (the 3 xiph-laced Vorbis headers) and the concatenated audio packets.
    * NULL setup means the plain self-framed path. */
   const void *setup;
   size_t      setup_size;
   const void *packets;
   size_t      packets_size;
   const uint32_t *pkt_sizes;
   size_t      num_packets;
   /* Packet-fed operation (demuxed input, and WebM buffer input): the
    * decoder is opened on the setup headers alone and then handed one
    * bare packet at a time out of wherever it lives, which is the
    * caller's blob or the demuxer's own view of the caller's buffer.
    * Nothing is copied and nothing is reframed. */
   /* Plain self-framed .ogg: demuxed incrementally by rvorbis's own
    * Ogg layer, so what a decode holds is a packet rather than the
    * file.  handle is borrowed from it - the stream owns the decoder -
    * and is kept so the queries below need no special case. */
   rvorbis_stream_t *stream;
   size_t      stream_off;  /* bytes of the buffer consumed             */
   int         packet;      /* opened with rvorbis_open_packets         */
   size_t      pkt_index;   /* next packet in the caller's blob         */
   size_t      pkt_offset;
   /* Ogg pages feeding the packet path, for a file that carries more
    * than one logical bitstream.  A plain .ogg does not come this
    * way - rvorbis reads those itself - but a multiplexed one must,
    * because rvorbis has no notion of a serial number and would take
    * the other stream's pages for its own. */
   int         ogg_pkt;
   uint32_t    ogg_serial;
   size_t      pg_off;
   unsigned    seg_idx;
   size_t      body_off;
   uint8_t    *asm_buf;     /* only for packets spanning pages          */
   size_t      asm_cap;
#ifdef HAVE_RWEBM
   rwebm_t    *demux;       /* buffer is WebM audio (.weba)             */
   int         track_idx;
#endif
   /* Resident prefix of the caller's buffer, 0 when all of it is.  A
    * windowed feeder sets this before start() so the header parse
    * stays inside the head, and raises it as the window slides.
    * Unconditional, like the set_avail case that stores it: gating it
    * on HAVE_RWEBM made that store - and the wall flag the read tail
    * consults - a compile error on every RWEBM-less build. */
   size_t      avail;
   uint8_t     wall;        /* see audio_transfer_flac::wall            */
   /* Emission bound, in frames, from a duration the container states;
    * -1 where none does.  Vorbis codes in overlapping blocks, so the
    * last packet decodes past the end of the audio, and only the
    * container knows where that is.  'discard' is the tail the
    * container asks to be dropped (Matroska DiscardPadding), which is
    * exact where a stated duration is only close: it is applied once
    * the final packet has been decoded and the true end is known. */
   int64_t     limit;
   int64_t     discard;
   uint64_t    seek_target, seek_position;
   size_t      seek_count, seek_prime, seek_index;
   int         seek_phase, seek_s16;
   int64_t     emitted;
   struct audio_transfer_time time;
   size_t time_pending;
   int yielded;
};
#endif

#ifdef HAVE_RMP3
struct audio_transfer_mp3
{
   const void *data;
   size_t      size, avail;
   int         wall;
   rmp3_stream_t *stream; /* opened decoder, NULL until start() succeeds    */
   size_t      off;      /* consumption cursor: the compressed frontier      */
   unsigned    channels; /* from the first frame's header, read at start()   */
   unsigned    rate;
   int         eof_sent; /* the stream has been told the tail is all there is */
   /* Recorded rather than done: an MP3 seek is a decode forward from
    * the head, and which pipeline it decodes in belongs to the read
    * that follows, so the output after a seek is byte-identical to a
    * linear decode in that read's own format.  Same shape as the Opus
    * arm's seek_to. */
   int64_t     seek_to;
   /* Gapless, from the Xing/Info or VBRI header in the first frame.
    * That frame carries no audio but dr_mp3 decodes it like any
    * other, so the priming to drop is its own length plus the
    * encoder delay the LAME tag states; the padding comes off the
    * end.  All zero where the file has no such header, which is the
    * old behaviour. */
   uint64_t    start_trim;
   uint64_t    trim_left;
   int64_t     limit;    /* frames to emit after the trim, -1 unbounded      */
   int64_t     emitted;
};
#endif

#ifdef HAVE_RMODTRACKER
struct audio_transfer_mod
{
   const void  *data;   /* module bytes from set_buffer_ptr (caller-owned)  */
   size_t       size;
   rmodtracker *handle; /* replayer, NULL until start() succeeds            */
   unsigned     rate;   /* requested mix rate, 0 for the replayer's default */
};
#endif

/* Vorbis and MP3 expose native s16 reads (rvorbis quantises once during
 * its interleave copy; rmp3's synthesis filter emits s16 directly), so
 * the s16 pipeline below never touches float. */

#ifdef HAVE_RLPCM
/* Raw PCM advances by bytes; DVD packing also retains a partial block. */
struct audio_transfer_lpcm
{
   const uint8_t  *buf;
   size_t          buf_size;
   size_t          avail;        /* resident prefix, 0 = all */
   size_t          pos;          /* the next frame's byte offset */
   rlpcm_format_t  fmt;
   size_t          total_frames;
   float           pending[32];
   unsigned        pending_n;
   unsigned        pending_off;
   unsigned        skip;
   bool            ready;
};

static size_t audio_transfer_lpcm_end(const struct audio_transfer_lpcm *l)
{
   return (l->avail && l->avail < l->buf_size) ? l->avail : l->buf_size;
}

/* Frames between a byte offset and the end of what is resident. At 20
 * bits the pair of samples is the unit, so this counts through the
 * frame size in bits rather than in bytes. */
static size_t audio_transfer_lpcm_frames_left(const struct audio_transfer_lpcm *l,
      size_t at)
{
   size_t end = audio_transfer_lpcm_end(l);
   if (at >= end)
      return 0;
   return (size_t)(((uint64_t)(end - at) * 8) / rlpcm_frame_bits(&l->fmt));
}
static int audio_transfer_dvd_lpcm_read(struct audio_transfer_lpcm *l,
      float *f32, int16_t *s16, size_t frames, size_t *frames_out)
{
   size_t block, end, done = 0;
   unsigned count;
   if (frames_out) *frames_out = 0;
   if ((!f32 && !s16) || !rlpcm_dvd_block_shape(&l->fmt, &block, &count))
      return AUDIO_PROCESS_ERROR;
   end = audio_transfer_lpcm_end(l);
   while (done < frames)
   {
      size_t take, i, samples;
      if (l->pending_off < l->pending_n)
      {
         take = l->pending_n - l->pending_off;
         if (take > frames - done) take = frames - done;
         samples = take * l->fmt.channels;
         for (i = 0; i < samples; i++)
         {
            float value = l->pending[l->pending_off * l->fmt.channels + i];
            if (f32) f32[done * l->fmt.channels + i] = value;
            else
            {
               int32_t v = (int32_t)((double)value * 32768.0 + 32768.5) - 32768;
               if (v > 32767) v = 32767;
               if (v < -32768) v = -32768;
               s16[done * l->fmt.channels + i] = (int16_t)v;
            }
         }
         l->pending_off += (unsigned)take;
         done += take;
         continue;
      }
      l->pending_n = l->pending_off = 0;
      if (l->pos > end || end - l->pos < block) break;
      take = (end - l->pos) / block;
      if (take > (frames - done) / count) take = (frames - done) / count;
      if (take && !l->skip)
      {
         size_t decoded = f32 ? rlpcm_decode_f32(&l->fmt, l->buf + l->pos,
               end - l->pos, f32 + done * l->fmt.channels, take * count)
            : rlpcm_decode_s16(&l->fmt, l->buf + l->pos,
               end - l->pos, s16 + done * l->fmt.channels, take * count);
         if (decoded != take * count) return AUDIO_PROCESS_ERROR;
         l->pos += take * block;
         done += decoded;
         continue;
      }
      if (rlpcm_decode_f32(&l->fmt, l->buf + l->pos, block,
               l->pending, count) != count)
         return AUDIO_PROCESS_ERROR;
      l->pos += block;
      l->pending_n = count;
      l->pending_off = l->skip;
      l->skip = 0;
   }
   if (frames_out) *frames_out = done;
   return done || !frames ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
}

#endif

void *audio_transfer_lpcm_format(void *data)
{
#ifdef HAVE_RLPCM
   struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
   return l ? (void*)&l->fmt : NULL;
#else
   (void)data;
   return NULL;
#endif
}

enum audio_type_enum audio_decode_get_type(const char *path)
{
   /* The extension, not a substring of the path.
    *
    * This searched the whole path for ".flac" and the rest, so a track
    * living under a directory called ".flac_backups" was decoded as
    * FLAC whatever it actually was, and "song.ogg.bak" was decoded as
    * Vorbis.  Both are the sort of path that turns up in a music
    * folder rather than a contrived one.
    *
    * Comparing the extension also removes the ordering dependency the
    * substring form had, where a path matching two of these took
    * whichever was tested first rather than whichever it ends with. */
   const char *ext = path_get_extension(path);

   if (string_is_empty(ext))
      return AUDIO_TYPE_NONE;
#ifdef HAVE_RWMA
   if (string_is_equal_noncase(ext, "wma") || string_is_equal_noncase(ext, "xwma") || string_is_equal_noncase(ext, "xma"))
      return AUDIO_TYPE_WMA;
#endif
   if (string_is_equal_noncase(ext, "flac"))
      return AUDIO_TYPE_FLAC;
   if (string_is_equal_noncase(ext, "ogg"))
      return AUDIO_TYPE_VORBIS;
   if (string_is_equal_noncase(ext, "mp3"))
      return AUDIO_TYPE_MP3;
   if (string_is_equal_noncase(ext, "wav"))
      return AUDIO_TYPE_WAV;
#ifdef HAVE_RAC3
   if (     string_is_equal_noncase(ext, "ac3")
         || string_is_equal_noncase(ext, "eac3")
         || string_is_equal_noncase(ext, "ec3"))
      return AUDIO_TYPE_AC3;
#endif
#ifdef HAVE_RLPCM
   /* Raw samples, so the name is all there is to go on; what shape
    * they are has to come from the caller or from a disc header the
    * buffer opens with. */
   if (     string_is_equal_noncase(ext, "lpcm")
         || string_is_equal_noncase(ext, "pcm"))
      return AUDIO_TYPE_LPCM;
#endif
#ifdef HAVE_RMODTRACKER
   if (     string_is_equal_noncase(ext, "mod")
         || string_is_equal_noncase(ext, "s3m")
         || string_is_equal_noncase(ext, "xm"))
      return AUDIO_TYPE_MOD;
#endif
   return AUDIO_TYPE_NONE;
}

#ifdef HAVE_ROPUS
/* The largest an Opus packet can be: a code 3 packet carries at most
 * 48 frames of at most 1275 bytes (RFC 6716 s3.2.5), plus the TOC and
 * the frame count byte.  Rounded up, and the bound the reassembly
 * buffer below is held to. */
#define AUDIO_OPUS_MAX_PACKET 61500

struct audio_transfer_opus
{
   /* Demuxed input (set_demuxed_ptr): OpusHead as setup, concatenated
    * packets, and the per-packet byte lengths (required -- Opus packets
    * are delimited by the container). */
   const void *setup;
   size_t      setup_size;
   const uint8_t *packets;
   size_t      packets_size;
   const uint32_t *pkt_sizes;
   size_t      num_packets;
   /* Buffer input (set_buffer_ptr): a whole Ogg Opus (.opus) file,
    * paged per RFC 3533/7845; packets are read from the pages in
    * place, assembled only when one spans pages, and the final page's
    * granule position bounds emission the way the reference decoder's
    * does. */
   const uint8_t *buf;
   size_t      buf_size;
   unsigned requested_track; /* zero: automatic; otherwise container index + 1 */
   int         ogg;          /* buffer is an Ogg Opus stream             */
#ifdef HAVE_RWEBM
   rwebm_t    *demux;        /* buffer is WebM audio (.weba)             */
   int         track_idx;
#endif
   /* Unconditional: see the Vorbis arm's note on these two. */
   size_t      avail;        /* resident prefix, 0 = all of it           */
   uint8_t     wall;         /* see audio_transfer_flac::wall            */
   /* A windowed WebM cannot pre-walk the packets for the stream's
    * length, so it accumulates their TOC durations as they play and
    * takes the container's padding off when the block carrying it
    * arrives.  toc_total counts raw decoded frames, before pre-skip;
    * both stay 0 on every other input, where the length is known by
    * other means. */
   int64_t     toc_total;
   size_t      pg_off;       /* byte offset of the current page          */
   size_t      body_off;     /* byte offset of the current segment       */
   unsigned    seg_idx;      /* next segment in the current page         */
   unsigned    seg_count;
   size_t      audio_off;    /* first audio page (for rewind)            */
   int64_t     limit;        /* emission bound from the end granule      */
   int64_t     end_granule;  /* injected last-page granule (windowed
                              * mode): >= 0 means use it as the emission
                              * bound instead of scanning to EOF at open;
                              * -1 means do the full forward scan. */
   int64_t     emitted;      /* frames handed out so far                 */
   /* Reassembly for a packet that spans Ogg pages, which is the only
    * thing that needs a copy - an ordinary packet is read from the
    * page in place.  Allocated on the first one that does, the way
    * the Vorbis arm's asm_buf is, rather than carried inline: page
    * spanning is rare, AUDIO_OPUS_MAX_PACKET is large, and every
    * context paid for it whether or not it ever spanned.  It also sat
    * between the two halves of the hot state, so the fields the read
    * path touches were 60 KiB apart and in different pages. */
   uint8_t    *asm_buf;      /* only for packets spanning pages          */
   size_t      asm_cap;
   ropus_t    *handle;
   unsigned    channels;
   size_t      pkt_index;   /* next packet to decode                     */
   size_t      pkt_offset;  /* byte offset of that packet                */
   unsigned    preskip_left;
   int         fmt;         /* 0 none, 1 s16, 2 f32 (pending buf type)   */
   /* A seek asked for but not yet carried out.  Repositioning decodes
    * a pre-roll, and decoding picks the output pipeline for good, so a
    * seek made before the first read waits here until the read says
    * which pipeline that should be.  -1 when there is none pending. */
   int64_t     seek_to;
   uint64_t    seek_target, seek_position;
   int         seek_pending, seek_fmt, seek_walk;
   uint64_t    seek_prime;
   struct audio_transfer_time time;
   int yielded;

   /* Decoded-but-unconsumed frames from the last packet.
    *
    * One buffer, not two, and sized for the stream rather than for a
    * guess.  ropus_decode_s16/f32 take no output length and require
    * room for ROPUS_MAX_FRAME * channels samples; the two arrays
    * that used to sit here were sized 5760 * 2 apiece, which is that
    * room only for a stream of at most two channels.  ropus_open takes
    * mapping family 1 up to eight, so a six- or eight-channel file -
    * anything opusenc emits from a surround source - decoded straight
    * past the end of the buffer, and for the f32 arm past the end of
    * the allocation.  Sizing this from op->channels at the point the
    * format is latched closes that, and drops the two-channel case
    * from 69120 bytes to 23040 (s16) or 46080 (f32), the other arm's
    * buffer having never been live: fmt is latched by the first read
    * and the opposite entry point errors for the life of the context.
    *
    * pend_elem is what it was allocated for, 2 or 4 bytes.  Rewinding
    * to frame 0 clears fmt, so a context can be asked for the other
    * format afterwards; that reallocates rather than reinterpreting. */
   size_t      pend_frames;
   size_t      pend_pos;
   void       *pend;        /* int16_t* when fmt 1, float* when fmt 2  */
   size_t      pend_elem;   /* sizeof the element pend holds, 0 if none */
   size_t      pend_samples;/* room at pend, in interleaved samples     */
};

/* Opus packet duration in 48 kHz frames from the TOC (RFC 6716 s3). */
static int64_t audio_transfer_opus_pkt_frames(const uint8_t *d, size_t n)
{
   static const int16_t fs[32] = {
      480, 960, 1920, 2880, 480, 960, 1920, 2880,   /* SILK NB/MB      */
      480, 960, 1920, 2880,                         /* SILK WB         */
      480, 960, 480, 960,                           /* hybrid          */
      120, 240, 480, 960, 120, 240, 480, 960,       /* CELT NB/WB      */
      120, 240, 480, 960, 120, 240, 480, 960        /* CELT SWB/FB     */
   };
   int count;
   if (!n)
      return 0;
   switch (d[0] & 3)
   {
      case 0: count = 1; break;
      case 3: count = n >= 2 ? (d[1] & 0x3F) : 0; break;
      default: count = 2; break;
   }
   return (int64_t)fs[d[0] >> 3] * count;
}

#endif


#ifdef HAVE_RAC3
/* AC-3 or E-AC-3: a buffer of syncframes, walked with rac3_parse_frame_info and
 * decoded a frame at a time into a pending block of 1536 frames the
 * reads drain. The stream's channel count and rate are the first
 * frame's; a frame that disagrees ends the stream. The decoder's
 * overlap window means a seek decodes the frame before the target
 * and discards it, so the target frame comes out as it would in a
 * playthrough. s16 is the f32 output saturated. */
struct audio_transfer_ac3
{
#ifdef HAVE_RMP4
   rmp4_t *demux;
   int track_idx;
   unsigned requested_track;
   size_t packet_end;
#endif
   const uint8_t  *buf;
   size_t          buf_size;
   size_t          avail;       /* resident prefix, 0 = all */
   size_t          pos;         /* next frame's byte offset */
   rac3_decoder_t *dec;
   unsigned        channels;    /* handed over, in the mixer's order */
   unsigned        dec_channels;/* the stream's, in mask order */
   uint32_t        layout;
   /* The mixer folds by channel count in the WAV order, and A/52 has
    * configurations the count does not tell apart - 3/1, 2/2, 3/0
    * with LFE and 2/1 with LFE are all four channels. So the frame is
    * put into the WAV shape for its count here: LFE kept only where
    * WAV's count puts one (5.1), a lone back centre split into a
    * phantom pair at -3 dB each, the surround pair in the pair's
    * place. Each output channel is up to two decoded ones at a gain. */
   int             map_a[6], map_b[6];
   float           map_g[6];
   float          *raw;         /* 1536 * dec_channels, the decoder's */
   unsigned        rate;
   uint64_t        total_frames;
   uint64_t        frame_pos;   /* PCM frame at the head of pend, absolute */
   float          *pend;        /* 1536 * channels floats */
   size_t          pend_n;      /* frames in pend */
   size_t          pend_off;    /* frames of pend already handed out */
   bool            ended;
   /* The map is the identity (mono, 2.0, 3.0, 5.1: the decoder's slot
    * order is already WAV's): frames decode straight to where they go */
   bool            identity;
   bool seek_pending;
   uint64_t seek_target, seek_at;
   size_t seek_previous;
};

static size_t audio_transfer_ac3_end(const struct audio_transfer_ac3 *a);

static int audio_transfer_ac3_span(struct audio_transfer_ac3 *a)
{
#ifdef HAVE_RMP4
   if (a->demux && a->pos >= a->packet_end)
   {
      rmp4_packet packet;
      int result;
      for (;;)
      {
         size_t lo = 0, hi = 0;
         rmp4_read_span(a->demux, &lo, &hi);
         if (a->avail && hi > a->avail)
         { a->pos = lo; return 0; }
         result = rmp4_read_packet(a->demux, &packet);
         if (result != 1) break;
         if (packet.track == a->track_idx)
         {
            a->pos = (size_t)(packet.data - a->buf);
            a->packet_end = a->pos + packet.size;
            return 1;
         }
      }
      if (!result) a->pos = a->buf_size;
      return result == RMP4_READ_AGAIN ? 0 : result;
   }
#endif
   return a->pos < audio_transfer_ac3_end(a) ? 1 : 0;
}

static size_t audio_transfer_ac3_end(const struct audio_transfer_ac3 *a)
{
   return (a->avail && a->avail < a->buf_size) ? a->avail : a->buf_size;
}

/* Decodes the frame at pos into pend, advances pos. Returns 1 on a
 * frame, 0 at the end of the buffer (or the frontier), -1 on a bad
 * frame. */
/* Decodes the frame at pos, in the mixer's channel shape, into @fdst
 * as floats or else @sdst as s16, and advances pos.  Returns 1 with
 * the frame count in @frames, 0 at the end of the buffer (or the
 * frontier), -1 on a bad frame.  An identity map decodes straight
 * into @fdst; any other map, and the s16 form, go through the
 * decoder's own buffer once, with the map, gain and conversion in
 * one pass on the way out. */
static int audio_transfer_ac3_next_into(struct audio_transfer_ac3 *a,
      float *fdst, int16_t *sdst, size_t *frames)
{
   rac3_frame_info_t info;
   size_t end;
   int span = audio_transfer_ac3_span(a);
   size_t got;
   float *dec;
   enum rac3_status st;
   if (span != 1) return span;
   end = audio_transfer_ac3_end(a);
#ifdef HAVE_RMP4
   if (a->demux && end > a->packet_end) end = a->packet_end;
#endif
   if (a->pos >= end)
      return 0;
   st = rac3_parse_frame_info(a->buf + a->pos, end - a->pos, &info);
   if (st == RAC3_NEED_MORE)
      return 0;
   if (st != RAC3_OK)
      return -1;
   if (a->pos + info.frame_bytes > end)
      return 0;
   if (info.channels != a->dec_channels || info.sample_rate != a->rate)
      return -1;
   dec = (a->identity && fdst) ? fdst : a->raw;
   got = rac3_decode_frame(a->dec, a->buf + a->pos, info.frame_bytes, dec, &info);
   if (!got)
      return -1;
   if (dec != fdst)
   {
      size_t f, i; unsigned c;
      if (a->identity)
         /* s16 of an identity map: the conversion alone */
         for (i = 0; i < got * a->channels; i++)
            sdst[i] = audio_transfer_unit_to_s16(a->raw[i]);
      else
         for (f = 0; f < got; f++)
         {
            const float *in = a->raw + f * a->dec_channels;
            for (c = 0; c < a->channels; c++)
            {
               float v = in[a->map_a[c]];
               if (a->map_b[c] >= 0)
                  v += in[a->map_b[c]];
               v *= a->map_g[c];
               if (fdst)
                  fdst[f * a->channels + c] = v;
               else
                  sdst[f * a->channels + c] = audio_transfer_unit_to_s16(v);
            }
         }
   }
   a->pos += info.frame_bytes;
   *frames = got;
   return 1;
}

/* Decodes the frame at pos into pend.  Same returns. */
static int audio_transfer_ac3_next(struct audio_transfer_ac3 *a)
{
   size_t got = 0;
   int    r   = audio_transfer_ac3_next_into(a, a->pend, NULL, &got);
   if (r == 1)
   {
      a->pend_n   = got;
      a->pend_off = 0;
   }
   return r;
}

/* The WAV-shaped channel set for an A/52 layout: the count the mixer
 * folds by, and where each channel comes from. Mask bits: FL 1, FR 2,
 * FC 4, LFE 8, BC 0x100, SL 0x200, SR 0x400, in ascending order in
 * the decoder's output. */
static void audio_transfer_ac3_map(struct audio_transfer_ac3 *a)
{
   unsigned slot[16], n = 0, i, out = 0;
   bool fc  = (a->layout & 0x004u) != 0;
   bool bc  = (a->layout & 0x100u) != 0;
   bool sp  = (a->layout & 0x200u) != 0;   /* the surround pair */
   bool lfe = (a->layout & 0x008u) != 0;
   for (i = 0; i < 16; i++)
      slot[i] = (a->layout & (1u << i)) ? n++ : 0;
#define AC3_OUT(A, B, G) do { a->map_a[out] = (A); a->map_b[out] = (B); a->map_g[out] = (G); out++; } while (0)
   if (!(a->layout & 0x001u))
   {
      /* mono: the centre alone */
      AC3_OUT((int)slot[2], -1, 1.0f);
   }
   else
   {
      AC3_OUT((int)slot[0], -1, 1.0f);
      AC3_OUT((int)slot[1], -1, 1.0f);
      if (fc)
         AC3_OUT((int)slot[2], -1, 1.0f);
      if (fc && lfe && sp)
         AC3_OUT((int)slot[3], -1, 1.0f);     /* 5.1: WAV's LFE slot */
      if (sp)
      {
         AC3_OUT((int)slot[9], -1, 1.0f);
         AC3_OUT((int)slot[10], -1, 1.0f);
      }
      else if (bc)
      {
         AC3_OUT((int)slot[8], -1, 0.70710678f);
         AC3_OUT((int)slot[8], -1, 0.70710678f);
      }
   }
#undef AC3_OUT
   a->channels = out;
   a->identity = (out == a->dec_channels);
   for (i = 0; i < out; i++)
      if (     a->map_a[i] != (int)i || a->map_b[i] >= 0
            || a->map_g[i] != 1.0f)
         a->identity = false;
   (void)lfe;
}

/* The stream's frames, by walking the headers. */
static uint64_t audio_transfer_ac3_count(struct audio_transfer_ac3 *a)
{
   size_t   pos   = 0, end = a->buf_size;
   uint64_t total = 0;
#ifdef HAVE_RMP4
   if (a->demux)
   {
      uint32_t count = 0;
      rmp4_track_pts(a->demux, a->track_idx, &count);
      rmp4_rewind(a->demux);
      a->pos = a->packet_end = 0;
      /* A prefix is not the duration of the complete recording. */
      return rmp4_index_complete(a->demux) ? (uint64_t)count * 1536 : 0;
   }
#endif
   while (pos < end)
   {
      rac3_frame_info_t info;
      if (rac3_parse_frame_info(a->buf + pos, end - pos, &info) != RAC3_OK)
         break;
      if (pos + info.frame_bytes > end)
         break;
      total += info.samples;
      pos   += info.frame_bytes;
   }
   return total;
}

/* Fresh decoder state: at the head, or the frame before the target
 * decoded and discarded so the overlap window is what a playthrough
 * would have left. */
static bool audio_transfer_ac3_seek_to(struct audio_transfer_ac3 *a, uint64_t frame)
{
   size_t   pos = 0;
   uint64_t at  = 0;
   size_t   prev_pos = (size_t)-1;
#ifdef HAVE_RMP4
   if (a->demux)
   {
      rmp4_rewind(a->demux);
      a->pos = a->packet_end = 0;
      while (audio_transfer_ac3_span(a) == 1)
      {
         rac3_frame_info_t info;
         if (rac3_parse_frame_info(a->buf + a->pos,
                  a->packet_end - a->pos, &info) != RAC3_OK) return false;
         if (at + info.samples > frame) break;
         prev_pos = a->pos;
         at += info.samples;
         a->pos += info.frame_bytes;
      }
      pos = a->pos;
   }
   else
#endif
   while (pos < a->buf_size)
   {
      rac3_frame_info_t info;
      if (rac3_parse_frame_info(a->buf + pos, a->buf_size - pos, &info) != RAC3_OK)
         return false;
      if (pos + info.frame_bytes > a->buf_size)
         return false;
      if (at + info.samples > frame)
         break;
      prev_pos = pos;
      at      += info.samples;
      pos     += info.frame_bytes;
   }
   if (pos >= a->buf_size)
      return false;
   rac3_decoder_reset(a->dec);
   if (prev_pos != (size_t)-1)
   {
      rac3_frame_info_t info;
      if (rac3_parse_frame_info(a->buf + prev_pos, a->buf_size - prev_pos, &info) != RAC3_OK)
         return false;
      rac3_decode_frame(a->dec, a->buf + prev_pos, info.frame_bytes, a->raw, &info);
   }
   a->pos       = pos;
   a->pend_n    = 0;
   a->pend_off  = 0;
   a->frame_pos = at;
   a->ended     = false;
   /* the frames of the target's block before the target */
   if (audio_transfer_ac3_next(a) == 1)
      a->pend_off = (size_t)(frame - at);
   return true;
}

static int audio_transfer_ac3_read(struct audio_transfer_ac3 *a,
      float *out_f32, int16_t *out_s16, size_t frames, size_t *frames_out)
{
   size_t produced = 0;
   if (!a || !a->dec)
      return AUDIO_PROCESS_ERROR;
   while (produced < frames)
   {
      size_t take, i, n;
      const float *src;
      if (a->pend_off >= a->pend_n)
      {
         int r;
         if (a->ended)
            break;
         /* Room for a whole frame (an A/52 frame is at most 1536):
          * decode it straight into the caller's buffer */
         if (frames - produced >= 1536)
         {
            size_t got = 0;
            r = audio_transfer_ac3_next_into(a,
                  out_f32 ? out_f32 + produced * a->channels : NULL,
                  out_f32 ? NULL    : out_s16 + produced * a->channels,
                  &got);
            if (r == 1)
            {
               a->frame_pos += got;
               produced     += got;
               continue;
            }
         }
         else
            r = audio_transfer_ac3_next(a);
         if (r < 0)
         {
            if (frames_out) *frames_out = produced;
            return AUDIO_PROCESS_ERROR;
         }
         if (r == 0)
         {
            /* the frontier, or the end: the end when the whole buffer
             * has been walked */
            if (audio_transfer_ac3_end(a) >= a->buf_size)
               a->ended = true;
            break;
         }
      }
      take = a->pend_n - a->pend_off;
      if (take > frames - produced)
         take = frames - produced;
      src = a->pend + a->pend_off * a->channels;
      n   = take * a->channels;
      if (out_f32)
         memcpy(out_f32 + produced * a->channels, src, n * sizeof(float));
      else
         for (i = 0; i < n; i++)
            out_s16[produced * a->channels + i] = audio_transfer_unit_to_s16(src[i]);
      a->pend_off  += take;
      a->frame_pos += take;
      produced     += take;
   }
   if (frames_out)
      *frames_out = produced;
   if (produced == 0 && a->ended)
      return AUDIO_PROCESS_END;
   return AUDIO_PROCESS_NEXT;
}
#endif

#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
/* ATRAC3 and ATRAC3plus: OpenMG files (.oma, .aa3: an optional "ea3"
 * tag, then the 96-byte EA3 header naming the codec and its frame
 * size) and WAVE files (.at3: format tag 270h, or FFFEh with the
 * ATRAC3plus sub-format). Frames are block_align bytes, 1024 samples a
 * channel for ATRAC3 and 2048 for ATRAC3plus, decoded one at a time
 * into a pending block the reads drain. Encrypted OpenMG is refused.
 *
 * ATRAC3plus decodes in Sony's order - FL FR FC, then the back pair,
 * the back centre or the side pair, and LFE last - which is put into
 * the WAV shape for the count, as the AC-3 arm does: 5.1, 6.1 and 7.1
 * reordered, 6.1's back pair in WAV 7's side slots (the fold treats
 * them alike), and 4.0's lone back centre split into a phantom pair at
 * -3 dB each, five channels out. A frame that does not parse comes out
 * as silence, the decoders keeping their history. */
struct audio_transfer_atrac
{
   const uint8_t *buf;
   size_t         buf_size;
   size_t         avail;        /* resident prefix, 0 = all */
   size_t         data, data_end;
   size_t         pos;          /* the next frame's offset */
   unsigned       block_align;
   unsigned       spf;          /* samples a channel a frame */
   unsigned       dec_channels; /* the stream's */
   unsigned       channels;     /* handed over, in the WAV shape */
   unsigned       rate;
   bool           plus;
   bool           joint;
   bool           identity;
   bool           ended;
   signed char    map[8];       /* output channel: the decoded one */
   float          gain[8];
#ifdef HAVE_RATRAC3
   ratrac3_t     *d3;
#endif
#ifdef HAVE_RATRAC3P
   ratrac3p_t    *d3p;
#endif
   float         *raw;          /* spf * dec_channels */
   float         *pend;         /* spf * channels */
   size_t         pend_n, pend_off;
   uint64_t       total_frames;
   uint64_t       frame_pos;
};

static unsigned audio_transfer_be16(const uint8_t *p)
{
   return ((unsigned)p[0] << 8) | p[1];
}

/* The container: codec, frame size, rate and where the frames are */
static bool audio_transfer_atrac_parse(struct audio_transfer_atrac *a)
{
   static const unsigned rates[8] = { 32000, 44100, 48000, 88200, 96000, 0, 0, 0 };
   static const unsigned plus_ch[8] = { 0, 1, 2, 3, 4, 6, 7, 8 };
   const uint8_t *b = a->buf;
   size_t         n = a->buf_size, off = 0;

   if (n >= 12 && !memcmp(b, "RIFF", 4) && !memcmp(b + 8, "WAVE", 4))
   {
      size_t c = 12;
      bool   fmt = false;
      while (c + 8 <= n)
      {
         size_t len = audio_transfer_le32(b + c + 4);
         if (len > n - c - 8)
            len = n - c - 8;
         if (!memcmp(b + c, "fmt ", 4))
         {
#ifdef HAVE_RATRAC3P
            ratrac3p_info_t pi;
            if (ratrac3p_parse_wave_fmt(b + c + 8, len, &pi))
            {
               a->plus = true;  a->dec_channels = pi.channels;
               a->rate = pi.sample_rate; a->block_align = pi.block_align;
               fmt = true;
            }
#endif
#ifdef HAVE_RATRAC3
            if (!fmt)
            {
               ratrac3_info_t ti;
               if (ratrac3_parse_wave_fmt(b + c + 8, len, &ti))
               {
                  a->plus = false; a->dec_channels = ti.channels;
                  a->rate = ti.sample_rate; a->block_align = ti.block_align;
                  a->joint = ti.joint_stereo;
                  fmt = true;
               }
            }
#endif
            if (!fmt)
               return false;
         }
         else if (!memcmp(b + c, "data", 4) && fmt)
         {
            a->data     = c + 8;
            a->data_end = c + 8 + len;
            return true;
         }
         c += 8 + len + (len & 1);
      }
      return false;
   }

   /* OpenMG: "ea3" tag (an ID3v2.3 tag by another name), then "EA3" */
   if (n >= 10 && !memcmp(b, "ea3", 3))
      off = 10 + (((size_t)(b[6] & 0x7f) << 21) | ((size_t)(b[7] & 0x7f) << 14)
            | ((size_t)(b[8] & 0x7f) << 7) | (b[9] & 0x7f));
   if (off > n || n - off < 96 || memcmp(b + off, "EA3", 3))
      return false;
   {
      const uint8_t *h      = b + off;
      unsigned       hsize  = audio_transfer_be16(h + 4);
      unsigned       eid    = audio_transfer_be16(h + 6);
      unsigned       codec  = h[32];
      uint32_t       params = ((uint32_t)h[33] << 16) | ((uint32_t)h[34] << 8) | h[35];
      if (eid != 0xFFFF && eid != 0xFF80)
         return false;   /* encrypted */
      if (hsize < 96 || hsize > n - off)
         return false;
      a->rate = rates[(params >> 13) & 7];
      switch (codec)
      {
#ifdef HAVE_RATRAC3
         case 0:
            a->plus         = false;
            a->dec_channels = 2;
            a->joint        = ((params >> 17) & 1) != 0;
            a->block_align  = (unsigned)(params & 0x3FF) * 8;
            break;
#endif
#ifdef HAVE_RATRAC3P
         case 1:
            a->plus         = true;
            a->dec_channels = plus_ch[(params >> 10) & 7];
            a->block_align  = (unsigned)(params & 0x3FF) * 8 + 8;
            break;
#endif
         default:
            return false;
      }
      a->data     = off + hsize;
      a->data_end = n;
   }
   (void)plus_ch;
   return a->rate && a->dec_channels && a->block_align;
}

/* the WAV shape for ATRAC3plus's channel count (see above) */
static bool audio_transfer_atrac_map(struct audio_transfer_atrac *a)
{
   static const signed char maps[9][8] = {
      { 0 }, { 0 }, { 0, 1 }, { 0, 1, 2 },
      { 0, 1, 2, 3, 3 },                 /* FL FR FC BC: BC split */
      { 0 },
      { 0, 1, 2, 5, 3, 4 },              /* FL FR FC BL BR LFE    */
      { 0, 1, 2, 6, 5, 3, 4 },           /* FL FR FC BL BR BC LFE */
      { 0, 1, 2, 7, 3, 4, 5, 6 }         /* FL FR FC BL BR SL SR LFE */
   };
   unsigned i, n = a->dec_channels;
   unsigned channels = n == 4 ? 5 : n;
   if (!n || n >= sizeof(maps) / sizeof(maps[0])
         || channels > sizeof(a->map) / sizeof(a->map[0]))
      return false;
   a->channels = channels;
   for (i = 0; i < sizeof(a->map) / sizeof(a->map[0]) && i < channels; i++)
   {
      a->map[i]  = a->plus ? maps[n][i] : (signed char)i;
      a->gain[i] = (a->plus && n == 4 && i >= 3) ? 0.70710678f : 1.0f;
   }
   a->identity = true;
   for (i = 0; i < sizeof(a->map) / sizeof(a->map[0]) && i < channels; i++)
      if (a->map[i] != (signed char)i || a->gain[i] != 1.0f)
         a->identity = false;
   if (a->channels != n)
      a->identity = false;
   return true;
}

static size_t audio_transfer_atrac_end(const struct audio_transfer_atrac *a)
{
   size_t end = a->data_end;
   if (a->avail && a->avail < end)
      end = a->avail;
   return end;
}

/* Decodes the frame at pos into @fdst (floats) or @sdst (s16) in the
 * WAV shape and advances pos: 1 with @frames, 0 at the end of the
 * frames or the frontier */
static int audio_transfer_atrac_next_into(struct audio_transfer_atrac *a,
      float *fdst, int16_t *sdst, size_t *frames)
{
   size_t   end = audio_transfer_atrac_end(a), i;
   float   *dec;
   unsigned c;
   int      r = -1;
   if (a->pos >= end || a->block_align > end - a->pos)
      return 0;
   dec = (a->identity && fdst) ? fdst : a->raw;
#ifdef HAVE_RATRAC3P
   if (a->plus)
      r = ratrac3p_decode_float(a->d3p, a->buf + a->pos, a->block_align, dec);
#endif
#ifdef HAVE_RATRAC3
   if (!a->plus)
      r = ratrac3_decode_float(a->d3, a->buf + a->pos, a->block_align, dec);
#endif
   (void)r;   /* a frame that does not parse is silence */
   if (dec != fdst)
   {
      if (a->identity)
         for (i = 0; i < (size_t)a->spf * a->channels; i++)
            sdst[i] = audio_transfer_unit_to_s16(a->raw[i]);
      else
         for (i = 0; i < a->spf; i++)
         {
            const float *in = a->raw + i * a->dec_channels;
            for (c = 0; c < a->channels; c++)
            {
               float v = in[a->map[c]] * a->gain[c];
               if (fdst)
                  fdst[i * a->channels + c] = v;
               else
                  sdst[i * a->channels + c] = audio_transfer_unit_to_s16(v);
            }
         }
   }
   a->pos += a->block_align;
   *frames = a->spf;
   return 1;
}

static int audio_transfer_atrac_read(struct audio_transfer_atrac *a,
      float *out_f32, int16_t *out_s16, size_t frames, size_t *frames_out)
{
   size_t produced = 0;
   if (!a || !a->raw)
      return AUDIO_PROCESS_ERROR;
   while (produced < frames)
   {
      size_t take, i, n;
      const float *src;
      if (a->pend_off >= a->pend_n)
      {
         size_t got = 0;
         int    r;
         if (a->ended)
            break;
         /* room for a whole frame: straight into the caller's buffer */
         if (frames - produced >= a->spf)
         {
            r = audio_transfer_atrac_next_into(a,
                  out_f32 ? out_f32 + produced * a->channels : NULL,
                  out_f32 ? NULL : out_s16 + produced * a->channels, &got);
            if (r == 1)
            {
               a->frame_pos += got;
               produced     += got;
               continue;
            }
         }
         else
         {
            r = audio_transfer_atrac_next_into(a, a->pend, NULL, &got);
            if (r == 1)
            {
               a->pend_n   = got;
               a->pend_off = 0;
            }
         }
         if (r == 0)
         {
            if (audio_transfer_atrac_end(a) >= a->data_end)
               a->ended = true;
            break;
         }
      }
      take = a->pend_n - a->pend_off;
      if (take > frames - produced)
         take = frames - produced;
      src = a->pend + a->pend_off * a->channels;
      n   = take * a->channels;
      if (out_f32)
         memcpy(out_f32 + produced * a->channels, src, n * sizeof(float));
      else
         for (i = 0; i < n; i++)
            out_s16[produced * a->channels + i] = audio_transfer_unit_to_s16(src[i]);
      a->pend_off  += take;
      a->frame_pos += take;
      produced     += take;
   }
   if (frames_out)
      *frames_out = produced;
   if (produced == 0 && a->ended)
      return AUDIO_PROCESS_END;
   return AUDIO_PROCESS_NEXT;
}

/* Fresh history: the frame before the target decoded and dropped, so
 * the overlap is what a playthrough would have left */
static bool audio_transfer_atrac_seek_to(struct audio_transfer_atrac *a, uint64_t frame)
{
   uint64_t index = frame / a->spf;
   size_t   got;
   if (frame >= a->total_frames)
      return false;
#ifdef HAVE_RATRAC3P
   if (a->plus)
      ratrac3p_reset(a->d3p);
#endif
#ifdef HAVE_RATRAC3
   if (!a->plus)
      ratrac3_reset(a->d3);
#endif
   a->ended    = false;
   a->pend_n   = a->pend_off = 0;
   if (index)
   {
      a->pos = a->data + (size_t)(index - 1) * a->block_align;
      audio_transfer_atrac_next_into(a, a->pend, NULL, &got);
   }
   a->pos       = a->data + (size_t)index * a->block_align;
   a->frame_pos = index * a->spf;
   if (audio_transfer_atrac_next_into(a, a->pend, NULL, &got) == 1)
   {
      a->pend_n    = got;
      a->pend_off  = (size_t)(frame - a->frame_pos);
      a->frame_pos = frame;
   }
   return true;
}
#endif

#ifdef HAVE_RAAC
struct audio_transfer_aac
{
   /* Demuxed input (set_demuxed_ptr): the AudioSpecificConfig as
    * setup, concatenated raw access units, and the per-packet byte
    * lengths (required -- AAC access units are delimited by the
    * container). */
   const void *setup;
   size_t      setup_size;
   const uint8_t *packets;
   size_t      packets_size;
   const uint32_t *pkt_sizes;
   size_t      num_packets;
   raac_t     *handle;
   unsigned requested_track; /* zero: automatic; otherwise container index + 1 */
   unsigned    channels;
   size_t      pkt_index;   /* next packet to decode                     */
   size_t      pkt_offset;  /* byte offset of that packet                */
   /* Buffer input (set_buffer_ptr): a whole file.  An ADTS stream
    * (.aac) is walked here directly; an MP4/M4A is demuxed with rmp4
    * when it is built in, packets streaming from the demuxer on
    * demand with the edit list's start trim picked up from the
    * track. */
   const uint8_t *buf;
   size_t      buf_size;
   /* Resident prefix of 'buf' for a windowed caller; 0 means all of
    * it.  Raised through audio_transfer_set_avail as the window
    * slides, exactly as the Vorbis and Opus arms take it. */
   size_t      avail;
   uint8_t     wall;        /* see audio_transfer_flac::wall             */
   int         adts;        /* buffer is an ADTS stream                  */
   size_t      adts_pos;    /* byte cursor of the next ADTS frame        */
#ifdef HAVE_RMP4
   rmp4_t     *demux;
   int         track_idx;
#endif
#ifdef HAVE_RWEBM
   /* Matroska (.mka/.mkv) carrying A_AAC: the AudioSpecificConfig is
    * the track's CodecPrivate and the access units are its blocks,
    * pulled on demand like every other packet-fed path here. */
   rwebm_t    *wdemux;
   int         wtrack_idx;
#endif
   /* Frames the container's edit list trims from the stream start (the
    * encoder delay); set with audio_transfer_set_start_trim before
    * audio_transfer_start. */
   uint64_t    start_trim;
   uint64_t    trim_left;
   /* Emission bound from the container's declared duration, which is
    * net of the edit list: the encoder's tail padding is coded and
    * would otherwise be handed out.  -1 where nothing declares one. */
   int64_t     limit;
   int64_t     emitted;
   /* Decoded-but-unconsumed frames of the last packet, which stay
    * inside raac as its synthesis left them: each read interleaves
    * its slice straight into the caller's buffer in the format asked
    * for (raac_copy_s16/raac_copy_f32), so the two may be mixed at
    * any point, mid-packet included, and no copy of the packet is
    * kept here.  Opus cannot do this: ropus's s16 and f32 are
    * separate pipelines rather than one pipeline with two edges, so
    * that arm keeps its format latch. */
   size_t      pend_frames;
   size_t      pend_pos;
   uint64_t    seek_target, seek_position;
   bool        seek_pending; /* exclusive owner, bounded MP4 preparation */
   struct audio_transfer_time time;
   struct audio_transfer_time seek_times[4];
   uint32_t seek_scan;
   int seek_phase;
   uint64_t seek_count, seek_prime, seek_index;
   int64_t packet_pad;
   int yielded;
};
#endif

#ifdef HAVE_RWMA
struct audio_transfer_wma
{
   const uint8_t *buf;
   rwma_stream *stream;
   rwma_frame pending;
   size_t size, avail, offset;
   unsigned channels, rate;
};

static int16_t audio_transfer_wma_s16(float unit)
{
   float value = unit * 32768.0f, fraction;
   int integer;
   if (value >= 32767.0f) return 32767;
   if (value <= -32768.0f) return -32768;
   if (!(value > -32769.0f && value < 32768.0f)) return 0;
   integer = (int)value;
   fraction = value - integer;
   if (fraction > 0.5f || (fraction == 0.5f && integer % 2)) integer++;
   if (fraction < -0.5f || (fraction == -0.5f && integer % 2)) integer--;
   return (int16_t)integer;
}

static int audio_transfer_wma_read(struct audio_transfer_wma *a,
      float *out, int16_t *out16, size_t frames, size_t *frames_out)
{
   size_t done = 0;
   int status = RWMA_OK;
   if (frames_out) *frames_out = 0;
   if (!a || !a->stream || !a->channels ||
         frames > (size_t)-1 / a->channels || (frames && !out && !out16))
      return AUDIO_PROCESS_ERROR;
   while (done < frames)
   {
      size_t take, i;
      unsigned c;
      if (a->offset == a->pending.samples)
      {
         status = rwma_stream_next(a->stream, &a->pending);
         a->offset = 0;
         if (status) break;
         if (!a->pending.samples || a->pending.channels != a->channels ||
               a->pending.sample_rate != a->rate)
            return AUDIO_PROCESS_ERROR;
      }
      take = a->pending.samples - a->offset;
      if (take > frames - done) take = frames - done;
      for (i = 0; i < take; i++)
         for (c = 0; c < a->channels; c++)
         {
            float value = a->pending.planes[c][a->offset + i];
            if (out) out[(done + i) * a->channels + c] = value;
            else out16[(done + i) * a->channels + c] = audio_transfer_wma_s16(value);
         }
      a->offset += take;
      done += take;
   }
   if (frames_out) *frames_out = done;
   if (status < 0) return AUDIO_PROCESS_ERROR;
   return !done && status == RWMA_STREAM_END ? AUDIO_PROCESS_END : AUDIO_PROCESS_NEXT;
}
#endif

void *audio_transfer_new(enum audio_type_enum type)
{
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         return calloc(1, sizeof(struct audio_transfer_wma));
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
         return calloc(1, sizeof(struct audio_transfer_flac));
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
         return calloc(1, sizeof(struct audio_transfer_vorbis));
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
         return calloc(1, sizeof(struct audio_transfer_mp3));
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
         return calloc(1, sizeof(struct audio_transfer_mod));
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
         return calloc(1, sizeof(struct audio_transfer_opus));
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
         return calloc(1, sizeof(struct audio_transfer_aac));
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
         return calloc(1, sizeof(struct audio_transfer_atrac));
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
         return calloc(1, sizeof(struct audio_transfer_ac3));
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
         return calloc(1, sizeof(struct audio_transfer_lpcm));
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
         return calloc(1, sizeof(struct audio_transfer_wav));
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   return NULL;
}

void audio_transfer_set_buffer_ptr(void *data, enum audio_type_enum type,
      void *ptr, size_t len)
{
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
      {
         struct audio_transfer_wma *a = (struct audio_transfer_wma*)data;
         if (a && !a->stream) { a->buf = (const uint8_t*)ptr; a->size = len; }
         break;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (fl)
         {
            fl->data = ptr;
            fl->size = len;
         }
         break;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (op)
         {
            op->buf         = (const uint8_t*)ptr;
            op->buf_size    = len;
            op->end_granule = -1;   /* full scan unless injected */
         }
         break;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (ac)
         {
            ac->buf      = (const uint8_t*)ptr;
            ac->buf_size = len;
         }
         break;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         if (v)
         {
            v->data = ptr;
            v->size = len;
         }
         break;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (m)
         {
            m->data = ptr;
            m->size = len;
         }
         break;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (md)
         {
            md->data = ptr;
            md->size = len;
         }
         break;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         if (a)
         {
            a->buf      = (const uint8_t*)ptr;
            a->buf_size = len;
         }
         break;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         if (a)
         {
            a->buf      = (const uint8_t*)ptr;
            a->buf_size = len;
         }
         break;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         if (l)
         {
            l->buf      = (const uint8_t*)ptr;
            l->buf_size = len;
         }
         break;
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         if (w)
         {
            w->data = (const uint8_t*)ptr;
            w->size = len;
         }
         break;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
}

#ifdef HAVE_RVORBIS
/* --- Packet-fed Vorbis -------------------------------------------------
 *
 * WebM (and Matroska generally) carries Vorbis as raw packets: the three
 * setup headers live in CodecPrivate, xiph-laced, and the audio frames
 * are bare packets.  rvorbis decodes those where they lie
 * (rvorbis_open_packets, rvorbis_packet_decode), so no Ogg is
 * synthesised for them and nothing is copied: the decoder is pointed at
 * the demuxer's view of the caller's buffer, or at the caller's own
 * packet blob, one packet at a time.
 *
 * Overlap-add makes a packet worth zero or more frames rather than a
 * fixed count - the first one only primes the window - so the drain
 * below decodes another packet whenever the pending frames run out,
 * instead of assuming one call per buffer.
 */

/* Split the xiph-laced CodecPrivate into its 3 header pointers/lengths.
 * Returns 1 on success. */
static int audio_vorbis_split_setup(const uint8_t *priv, size_t size,
      const uint8_t *hdr[3], uint32_t hlen[3])
{
   size_t p, sum;
   int    i;
   if (!priv || size < 3 || priv[0] != 2) /* nheaders-1 == 2 */
      return 0;
   p = 1;
   for (i = 0; i < 2; i++)
   {
      uint32_t l = 0;
      while (p < size && priv[p] == 255) { l += 255; p++; }
      if (p >= size) return 0;
      l += priv[p++];
      hlen[i] = l;
   }
   sum = (size_t)hlen[0] + hlen[1];
   if (p + sum > size)
      return 0;
   hlen[2]  = (uint32_t)(size - p - sum);
   hdr[0]   = priv + p;
   hdr[1]   = priv + p + hlen[0];
   hdr[2]   = priv + p + hlen[0] + hlen[1];
   return 1;
}

/* The next coded packet, wherever this context's packets come from.
 * Returns 1 with the bytes, 0 at end of stream, < 0 on a blob whose
 * sizes do not agree with its length. */
static int audio_transfer_vorbis_ogg_pkt(struct audio_transfer_vorbis *v,
      const uint8_t **pdata, uint32_t *plen);

static int audio_transfer_vorbis_pull(struct audio_transfer_vorbis *v,
      const uint8_t **pdata, uint32_t *plen, int64_t *ppad)
{
   *ppad = 0;
   if (v->ogg_pkt)
      return audio_transfer_vorbis_ogg_pkt(v, pdata, plen) == 1 ? 1 : 0;
#ifdef HAVE_RWEBM
   if (v->demux)
   {
      /* .weba: pull the next packet from the demuxer, which hands back
       * a pointer into the caller's buffer. */
      rwebm_packet pkt;
      unsigned walked = 0;
      for (;;)
      {
         int r;
         if ((v->seek_phase || v->time.enabled) && walked++ == 256) return -3;
         r = rwebm_read_packet_track(v->demux, v->track_idx, &pkt);
         if (r == RWEBM_READ_YIELD) return -3;
         /* The walk reached the resident wall rather than the end of
          * the stream: the feeder has not got here yet.  Report it
          * apart from end of stream, so the drain returns short and
          * the next call resumes instead of the sound ending. */
         if (r == RWEBM_READ_AGAIN)
         {
            v->wall = 1;
            return -2;
         }
         if (r != 1)
            return 0;
         if (pkt.track == v->track_idx)
         {
            v->wall = 0;
            break;
         }
      }
      *pdata = pkt.data;
      *plen  = (uint32_t)pkt.size;
      /* DiscardPadding is attached to the block it applies to, so it
       * arrives with the packet rather than having to be found by
       * walking to the end first.  It is handed back with the packet
       * rather than left in the context: a caller that only reads
       * headers - a seek walk, a length walk - would otherwise have to
       * remember to clear it, and one that forgot would have it come
       * off whichever packet the next decode touched. */
      if (pkt.discard_padding > 0)
      {
         unsigned rate = rvorbis_get_info(v->handle).sample_rate;
         if (!audio_transfer_time_frames(pkt.discard_padding, rate, ppad)) return -1;
      }
      if (!audio_transfer_time_packet(&v->time, pkt.timestamp,
               pkt.timestamp_continuation)) return -1;
      return 1;
   }
#endif
   if (v->pkt_index >= v->num_packets)
      return 0;
   /* An unsplit blob is one packet: the whole of it. */
   *plen = v->pkt_sizes ? v->pkt_sizes[v->pkt_index]
                        : (uint32_t)v->packets_size;
   if (v->pkt_offset + *plen > v->packets_size)
      return -1;
   *pdata = (const uint8_t*)v->packets + v->pkt_offset;
   v->pkt_offset += *plen;
   v->pkt_index++;
   return 1;
}

/* Drain 'frames' frames out of the packet stream in one of the two
 * pipelines (s16 selects it; out16 or outf is the buffer that matches).
 * Decoded frames left over from the last packet go out first, and a
 * fresh packet is decoded whenever they run out.  Returns the frames
 * written, short of the ask at end of stream or at the container's
 * stated end. */
/* Plain-Ogg read: hand rvorbis's demuxer the unconsumed tail of the
 * buffer and take what it produces.  The compressed cursor is kept here
 * rather than in the decoder because a windowed feeder reads it, and
 * because a seek re-points it. */

/* Seek a plain-Ogg stream.  Ogg locates a sample by bisecting on page
 * granule positions - there is no index - and the decoder cannot read,
 * so the bisection is driven from here over the buffer.  Each probe
 * resynchronises at the next page and reports where it landed; the
 * decode forward from the page before the target is what makes the
 * landing exact, since a page boundary is the finest position the
 * container states.
 *
 * The frames before the target are decoded and dropped rather than
 * skipped: a Vorbis packet's output depends on its predecessor's
 * overlap, so arriving with no history would resume converging on the
 * playthrough rather than matching it. */
static bool audio_transfer_vorbis_stream_seek(
      struct audio_transfer_vorbis *v, uint64_t frame)
{
   int16_t  scratch[64 * 8];
   size_t   lo  = 0;
   size_t   hi  = v->size;
   unsigned ch  = (unsigned)((v->channels > 0 && v->channels <= 8)
         ? v->channels : 8);
   size_t   cap = 2048 / ch;
   size_t   start;
   int      guard;

   if (!v->stream)
      return false;

   if (!frame)
   {
      rvorbis_stream_rewind(v->stream);
      v->stream_off = 0;
      v->emitted    = 0;
      return true;
   }

   for (guard = 0; lo < hi && guard < 64; guard++)
   {
      size_t mid = lo + (hi - lo) / 2;
      size_t off = mid;
      int    landed = 0;

      rvorbis_stream_reset(v->stream);
      while (off < v->size)
      {
         size_t rd = 0, wr = 0;
         int    r;
         rvorbis_stream_set_out_s16(v->stream, scratch, cap);
         rvorbis_stream_set_in(v->stream, (const uint8_t*)v->data + off,
               v->size - off);
         r = rvorbis_stream_process(v->stream, &rd, &wr);
         off += rd;
         if (rvorbis_stream_pos_known(v->stream))
         {
            landed = 1;
            break;
         }
         if (r == RVORBIS_STREAM_ERROR || r == RVORBIS_STREAM_EOS)
            break;
         if (r == RVORBIS_STREAM_NEED_IN && !rd)
            break;
      }
      if (landed && rvorbis_stream_tell(v->stream) <= frame)
         lo = mid + 1;
      else
         hi = mid;
   }

   /* One page back from the boundary, so the target is reached by
    * decoding forward rather than jumped over. */
   start = (lo > 65307) ? lo - 65307 : 0;

   for (guard = 0; guard < 2; guard++)
   {
      size_t off = start;
      if (start)
         rvorbis_stream_reset(v->stream);
      else
         rvorbis_stream_rewind(v->stream);
      while (off < v->size)
      {
         size_t rd = 0, wr = 0, want = cap;
         int    r;
         /* Once the position is known, ask for exactly the distance
          * left.  Asking for a full scratch instead would step past
          * the target and land wherever the packet happened to end. */
         if (rvorbis_stream_pos_known(v->stream))
         {
            uint64_t at = rvorbis_stream_tell(v->stream);
            if (at == frame)
            {
               v->stream_off = off;
               v->emitted    = (int64_t)frame;
               return true;
            }
            if (at > frame)
               break;           /* landed late: restart from the head */
            if (frame - at < (uint64_t)want)
               want = (size_t)(frame - at);
         }
         rvorbis_stream_set_out_s16(v->stream, scratch, want);
         rvorbis_stream_set_in(v->stream, (const uint8_t*)v->data + off,
               v->size - off);
         r = rvorbis_stream_process(v->stream, &rd, &wr);
         off += rd;
         if (r == RVORBIS_STREAM_ERROR)
            return false;
         if (r == RVORBIS_STREAM_EOS)
            break;
         if (r == RVORBIS_STREAM_NEED_IN && !rd && !wr)
            break;
      }
      if (!start)
         break;
      start = 0;               /* the bisection landed late; take the
                                * whole stream, which always works */
   }
   return false;
}

static size_t audio_transfer_vorbis_stream_pull(
      struct audio_transfer_vorbis *v, int s16, int16_t *out16,
      float *outf, size_t frames)
{
   size_t done = 0;
   if (!v->stream || !frames)
      return 0;
   while (done < frames)
   {
      size_t rd = 0, wr = 0;
      int    r;
      if (s16)
         rvorbis_stream_set_out_s16(v->stream, out16 + done * (size_t)v->channels,
               frames - done);
      else
         rvorbis_stream_set_out_f32(v->stream, outf + done * (size_t)v->channels,
               frames - done);
      rvorbis_stream_set_in(v->stream,
            (const uint8_t*)v->data + v->stream_off,
            v->size - v->stream_off);
      r = rvorbis_stream_process(v->stream, &rd, &wr);
      v->stream_off += rd;
      done          += wr;
      if (r == RVORBIS_STREAM_ERROR || r == RVORBIS_STREAM_EOS)
         break;
      if (r == RVORBIS_STREAM_NEED_IN && !rd && !wr)
         break;   /* the buffer is spent: a feeder must extend it */
   }
   return done;
}

static size_t audio_transfer_vorbis_drain(struct audio_transfer_vorbis *v,
      int s16, int16_t *out16, float *outf, size_t frames)
{
   size_t done = 0;
   int    ch   = v->channels;
   if (ch <= 0)
      return 0;
   for (;;)
   {
      const uint8_t *pd  = NULL;
      uint32_t       pl  = 0;
      int64_t        pad = 0;
      int            want, got;
      /* Vorbis codes in overlapping blocks, so the last packet decodes
       * past the end of the audio.  Where the container says where that
       * is, stop there rather than handing out the overhang.  Checked
       * every pass, not once: the bound tightens to its exact value
       * partway through the buffer that reaches the end. */
      if (v->limit >= 0)
      {
         int64_t left = v->limit - (v->emitted + (int64_t)done);
         if (left <= 0)
            break;
         if ((int64_t)(frames - done) > left)
            frames = done + (size_t)left;
      }
      if (done >= frames)
         break;
      if (rvorbis_packet_pending(v->handle) > 0)
      {
         want = (int)(frames - done);
         got  = s16
            ? rvorbis_packet_read_s16(v->handle, ch,
                  out16 + done * (size_t)ch, want * ch)
            : rvorbis_packet_read_float(v->handle, ch,
                  outf + done * (size_t)ch, want * ch);
         if (got <= 0)
            break;
         done += (size_t)got;
         continue;
      }
      /* Nothing pending: decode another packet.  It may yield nothing
       * (the first one primes the window, and a packet can carry no
       * audio at all), which is not the end of anything - pull again. */
      if (audio_transfer_vorbis_pull(v, &pd, &pl, &pad) != 1)
         break;
      if (rvorbis_packet_decode(v->handle, pd, pl, s16) < 0)
         break;
      /* This packet carried a padding, so the frames it just yielded
       * run past the end of the audio by that much.  Its yield is
       * countable now, which is what makes the exact end knowable; a
       * stated duration only rounds up past the overhang, so this
       * supersedes it. */
      if (pad > 0)
      {
         int64_t out   = v->emitted + (int64_t)done;
         int64_t total = out + rvorbis_packet_pending(v->handle)
                             - pad;
         /* A padding longer than the packet's yield would ask for
          * frames already handed out; the bound stops at what has
          * gone rather than going backwards. */
         if (total < out)
            total = out;
         if (v->limit < 0 || total < v->limit)
            v->limit = total;
      }
   }
   v->emitted += (int64_t)done;
   return done;
}

static int audio_transfer_vorbis_movie_fill(struct audio_transfer_vorbis *v, int s16)
{
   unsigned walked = 0;
   while (!v->time_pending)
   {
      const uint8_t *pd;
      uint32_t pl;
      int64_t pad = 0, count;
      int r;
      if (v->time.eof) return 0;
      if ((v->seek_phase && walked) || walked >= 16)
      { v->yielded = 1; return 2; }
      walked++;
      if (v->limit >= 0 && v->emitted >= v->limit)
      { v->time.eof = 1; return 0; }
      r = audio_transfer_vorbis_pull(v, &pd, &pl, &pad);
      if (r == -2 || r == -3) { v->yielded = r == -3; return 2; }
      if (r < 0) return -1;
      if (!r) { v->time.eof = 1; v->wall = 0; return 0; }
      r = rvorbis_packet_decode(v->handle, pd, pl, s16);
      if (r < 0) return -1;
      count = r;
      if (pad > 0) count = pad < count ? count - pad : 0;
      if (v->limit >= 0 && count > v->limit - v->emitted)
         count = v->limit - v->emitted;
      if (!audio_transfer_time_add(v->emitted, count, &v->emitted)
            || !audio_transfer_time_map(&v->time, 0, (size_t)count)) return -1;
      v->time_pending = (size_t)count;
   }
   return 1;
}

#ifdef HAVE_RWEBM
/* Header-only contribution in the original decoder sequence. A seek's
 * priming packet still occupies that sequence even though decoding it
 * after reset produces no PCM. */
static int audio_transfer_vorbis_movie_header(struct audio_transfer_vorbis *v,
      const uint8_t *packet, uint32_t size, int64_t pad, size_t index)
{
   int frames = rvorbis_packet_frames(v->handle, packet, size);
   if (frames < 0) return -1;
   if (!index) frames = 0;
   if (pad > 0) frames = pad < frames ? frames - (int)pad : 0;
   if (v->limit >= 0 && frames > v->limit - v->emitted)
      frames = (int)(v->limit - v->emitted);
   if (frames < 0 || !audio_transfer_time_map(&v->time, 0, (size_t)frames)
         || !audio_transfer_time_add(v->emitted, frames, &v->emitted)) return -1;
   return frames;
}
#endif

static int audio_transfer_vorbis_movie_read(struct audio_transfer_vorbis *v,
      int s16, int16_t *out16, float *outf, size_t frames, size_t *got)
{
   size_t done = 0;
   unsigned walked = 0;
   v->yielded = 0;
   while (done < frames)
   {
      size_t take, skip;
      int r, count;
      if (++walked > 32) { v->yielded = 1; break; }
      if (v->time.total >= 0 && v->time.position >= v->time.total) break;
      r = audio_transfer_vorbis_movie_fill(v, s16);
      if (r < 0) return AUDIO_PROCESS_ERROR;
      if (r == 2) break;
      take = audio_transfer_time_silence(&v->time, frames - done, !r);
      if (take)
      {
         if (s16) memset(out16 + done * v->channels, 0, take * v->channels * sizeof(*out16));
         else memset(outf + done * v->channels, 0, take * v->channels * sizeof(*outf));
         done += take;
         continue;
      }
      if (!r) break;
      skip = audio_transfer_time_overlap(&v->time, v->time_pending);
      /* Use the caller's still-unwritten output as discard scratch;
       * no extra PCM allocation or large stack buffer is needed. */
      take = skip ? skip : v->time_pending;
      if (take > frames - done) take = frames - done;
      if (take > 256) take = 256;
      if (!skip && v->time.total >= 0 && (uint64_t)(v->time.total - v->time.position) < take)
         take = (size_t)(v->time.total - v->time.position);
      count = s16 ? rvorbis_packet_read_s16(v->handle, v->channels,
            out16 + done * v->channels, (int)take * v->channels)
         : rvorbis_packet_read_float(v->handle, v->channels,
               outf + done * v->channels, (int)take * v->channels);
      if (count <= 0 || count != (int)take) return AUDIO_PROCESS_ERROR;
      v->time_pending -= take;
      if (skip)
      {
         /* overlap() advanced by the entire pending overlap; only
          * this bounded portion has actually left the decoder. */
         v->time.pending -= (int64_t)(skip - take);
      }
      else
      {
         v->time.pending += (int64_t)take;
         v->time.position += (int64_t)take;
         done += take;
      }
   }
   if (got) *got = done;
   return done || v->wall || v->yielded ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
}
#endif

int audio_transfer_demuxed_packet_frames(void *data, enum audio_type_enum type,
      const void *packet, size_t size, size_t index)
{
   if (!data || !packet || !size) return -1;
   switch (type)
   {
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         int frames;
         if (!v->handle || !v->setup) return -1;
         frames = rvorbis_packet_frames(v->handle, packet, size);
         return frames < 0 ? -1 : index ? frames : 0;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *o = (struct audio_transfer_opus*)data;
         int64_t frames;
         if (!o->setup || !o->handle) return -1;
         frames = audio_transfer_opus_pkt_frames((const uint8_t*)packet, size);
         return frames > 0 && frames <= 5760 ? (int)frames : -1;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *a = (struct audio_transfer_aac*)data;
         if (!a->setup || !a->handle) return -1;
         return 1024;
      }
#endif
      default: break;
   }
   (void)index;
   return -1;
}

bool audio_transfer_set_demuxed_ptr(void *data, enum audio_type_enum type,
      const void *setup, size_t setup_size,
      const void *packets, size_t packets_size,
      const uint32_t *sizes, size_t num_packets)
{
   switch (type)
   {
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         if (!v)
            return false;
         v->setup        = setup;
         v->setup_size   = setup_size;
         v->packets      = packets;
         v->packets_size = packets_size;
         v->pkt_sizes    = sizes;
         v->num_packets  = num_packets;
         return true;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl)
            return false;
         /* setup is the fLaC header - magic and metadata blocks, as a
          * container stores it - and the packets are the frames. */
         fl->setup        = setup;
         fl->setup_size   = setup_size;
         fl->packets      = (const uint8_t*)packets;
         fl->packets_size = packets_size;
         fl->pkt_sizes    = sizes;
         fl->num_packets  = num_packets;
         return true;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (!op)
            return false;
         op->setup        = setup;
         op->setup_size   = setup_size;
         op->packets      = (const uint8_t*)packets;
         op->packets_size = packets_size;
         op->pkt_sizes    = sizes;
         op->num_packets  = num_packets;
         return true;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (!ac)
            return false;
         ac->setup        = setup;
         ac->setup_size   = setup_size;
         ac->packets      = (const uint8_t*)packets;
         ac->packets_size = packets_size;
         ac->pkt_sizes    = sizes;
         ac->num_packets  = num_packets;
         return true;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   (void)data; (void)setup; (void)setup_size;
   (void)packets; (void)packets_size; (void)sizes; (void)num_packets;
   return false;
}

void audio_transfer_set_output_rate(void *data, enum audio_type_enum type,
      unsigned rate)
{
#ifdef HAVE_RMODTRACKER
   /* A tracker synthesises, so it can be asked to synthesise at the
    * rate the caller wants and spare everyone a resampler.  The decoders
    * reproduce a recording made at a rate the stream itself states,
    * which is not a thing a caller gets to choose. */
   if (data && type == AUDIO_TYPE_MOD)
      ((struct audio_transfer_mod*)data)->rate = rate;
#else
   (void)data;
   (void)type;
   (void)rate;
#endif
}

/* Raise the resident prefix of the caller's buffer.  A windowed feeder
 * calls this before start(), so the container header parse is bounded
 * by the head, and again as the window slides.  The value is a prefix
 * even though a window is not one: the demuxer only ever reads forward
 * at its own cursor, which the feeder keeps inside the window, so the
 * wall is what stops a parse running off to the end of the file rather
 * than a claim about every byte below it.  Monotonic - the demuxer
 * clamps a value below the one it already has.  No-op for a type with
 * no windowed container path. */
void audio_transfer_set_avail(void *data, enum audio_type_enum type,
      size_t avail)
{
/* Any arm that honours a resident bound needs this compiled, not just
 * the WebM-backed ones: requiring HAVE_RWEBM here no-opped the whole
 * function on an RWEBM-less build, so an M4A stream's every bound -
 * the one at open that keeps rmp4's box walk off unpopulated pages,
 * and every feeder raise after - was accepted by the caller's guard
 * (audio_mixer_play_stream admits RAAC+RMP4 alone, and says why) and
 * silently dropped here.  The demuxer then believed the whole file
 * readable and handed the decoder packets on pages the window never
 * committed. */
#if defined(HAVE_RWEBM) || defined(HAVE_RVORBIS) || defined(HAVE_ROPUS) \
 || defined(HAVE_RAAC) || defined(HAVE_RFLAC) || defined(HAVE_RAC3) || defined(HAVE_RWMA) || defined(HAVE_RMP3)
   switch (type)
   {
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (m) m->avail = avail;
         return;
      }
#endif

#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
      {
         struct audio_transfer_wma *a = (struct audio_transfer_wma*)data;
         if (a) { a->avail = avail; rwma_stream_set_avail(a->stream, avail); }
         return;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         if (!v)
            return;
         v->avail = avail;
#ifdef HAVE_RWEBM
         if (v->demux)
            rwebm_set_avail(v->demux, avail);
#endif
         return;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (!op)
            return;
         op->avail = avail;
#ifdef HAVE_RWEBM
         if (op->demux)
            rwebm_set_avail(op->demux, avail);
#endif
         return;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         if (a)
            a->avail = avail;
         break;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         if (a)
         {
            a->avail = avail;
#ifdef HAVE_RMP4
            if (a->demux) rmp4_set_avail(a->demux, avail);
#endif
         }
         break;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         if (l)
            l->avail = avail;
         break;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (!ac)
            return;
         ac->avail = avail;
#ifdef HAVE_RMP4
         /* MP4: the sample tables address the whole file, so the
          * demuxer must be told which of those bytes have actually
          * arrived - it withholds a packet whose extent is past the
          * bound rather than reading reserved pages. */
         if (ac->demux)
            rmp4_set_avail(ac->demux, avail);
#endif
#ifdef HAVE_RWEBM
         if (ac->wdemux)
            rwebm_set_avail(ac->wdemux, avail);
#endif
         return;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl)
            return;
#ifdef HAVE_RWEBM
         fl->avail = avail;
         if (fl->demux)
            rwebm_set_avail(fl->demux, avail);
#endif
         return;
      }
#endif
      default:
         break;
   }
#endif
   (void)data; (void)type; (void)avail;
}

#ifdef HAVE_ROPUS
/* Windowed Opus: inject the last Ogg page's granule so buffer setup
 * skips the full-file end-granule scan (see audio_transfer_opus's
 * end_granule).  No-op for any other type.  Must be called after
 * set_buffer_ptr and before audio_transfer_start. */
void audio_transfer_set_end_granule(void *data, enum audio_type_enum type,
      int64_t end_granule)
{
   if (data && type == AUDIO_TYPE_OPUS)
      ((struct audio_transfer_opus*)data)->end_granule = end_granule;
}
#endif

enum audio_type_enum audio_transfer_ogg_audio_type(const void *buf,
      size_t len)
{
   const uint8_t *b = (const uint8_t*)buf;
   unsigned nsegs, i;
   size_t first, plen = 0;
   if (!b || len < 28
         || b[0] != 'O' || b[1] != 'g' || b[2] != 'g' || b[3] != 'S'
         || b[4] != 0)
      return AUDIO_TYPE_NONE;
   /* first page: the identification header sits alone in it; its
    * opening bytes name the codec */
   nsegs = b[26];
   first = 27 + nsegs;
   if (len < first + 8)
      return AUDIO_TYPE_NONE;
   for (i = 0; i < nsegs; i++)
      plen += b[27 + i];
   if (plen < 7 || len < first + plen)
      return AUDIO_TYPE_NONE;
#ifdef HAVE_ROPUS
   if (plen >= 8 && !memcmp(b + first, "OpusHead", 8))
      return AUDIO_TYPE_OPUS;
#endif
#ifdef HAVE_RVORBIS
   if (!memcmp(b + first, "\x01vorbis", 7))
      return AUDIO_TYPE_VORBIS;
#endif
#ifdef HAVE_RFLAC
   /* RFC 5334: 0x7F, "FLAC", then the mapping version. */
   if (b[first] == 0x7F && !memcmp(b + first + 1, "FLAC", 4))
      return AUDIO_TYPE_FLAC;
#endif
   return AUDIO_TYPE_NONE;
}

#if defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) \
 || defined(HAVE_RVORBIS) || defined(HAVE_RAAC) || defined(HAVE_RFLAC))
/* Open a WebM container with the header parse bounded by the bytes the
 * caller says are actually there.
 *
 * rwebm_open_memory walks the segment's top-level children as far as
 * its wall, which at avail == size is segment_end: an element header
 * read at every cluster boundary in the file.  Whole-file callers can
 * afford that; a windowed one holds a head and a sliding window with
 * reserved, unpopulated pages between, and the walk would read them.
 * 'avail' is that caller's resident prefix, and 0 means the whole
 * buffer is there.
 *
 * A windowed caller's wall then stays where it put it, to be raised by
 * audio_transfer_set_avail as the window slides.  A whole-file caller's
 * goes straight to the end, which is the old behaviour exactly. */
static rwebm_t *audio_transfer_webm_open(const uint8_t *data, size_t size,
      size_t avail)
{
   rwebm_t *m = rwebm_open_memory_avail(data, size,
         (avail && avail < size) ? avail : size, NULL);
   if (m && !avail)
      rwebm_set_avail(m, size);
   return m;
}
#endif

enum audio_type_enum audio_transfer_webm_audio_track_type(const void *buf,
      size_t len, int track)
{
#if defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) \
 || defined(HAVE_RVORBIS) || defined(HAVE_RAAC) || defined(HAVE_RFLAC))
   rwebm_t *wm;
   int i;
   enum audio_type_enum found = AUDIO_TYPE_NONE;
   const uint8_t *b = (const uint8_t*)buf;
   if (track < -1 || !b || len < 4
         || b[0] != 0x1A || b[1] != 0x45 || b[2] != 0xDF || b[3] != 0xA3)
      return AUDIO_TYPE_NONE;
   if (!(wm = audio_transfer_webm_open(b, len, 0)))
      return AUDIO_TYPE_NONE;
   for (i = 0; i < rwebm_num_tracks(wm) && found == AUDIO_TYPE_NONE; i++)
   {
      const rwebm_track *t = rwebm_get_track(wm, i);
      if ((track >= 0 && i != track) || !t || t->type != RWEBM_TRACK_AUDIO || !t->codec_private_size)
         continue;
#ifdef HAVE_ROPUS
      if (t->codec == RWEBM_CODEC_OPUS)
         found = AUDIO_TYPE_OPUS;
#endif
#ifdef HAVE_RVORBIS
      if (t->codec == RWEBM_CODEC_VORBIS)
         found = AUDIO_TYPE_VORBIS;
#endif
#ifdef HAVE_RFLAC
      if (t->codec == RWEBM_CODEC_FLAC)
         found = AUDIO_TYPE_FLAC;
#endif
#ifdef HAVE_RAAC
      if (t->codec == RWEBM_CODEC_AAC)
         found = AUDIO_TYPE_AAC;
#endif
   }
   rwebm_close(wm);
   return found;
#else
   (void)buf;
   (void)len;
   (void)track;
   return AUDIO_TYPE_NONE;
#endif
}

enum audio_type_enum audio_transfer_webm_audio_type(const void *buf, size_t len)
{
   return audio_transfer_webm_audio_track_type(buf, len, -1);
}

/* Explicit choices use the demuxer's index, including non-audio entries.
 * A different codec or missing track must fail instead of falling back. */
#if (defined(HAVE_RWEBM) && (defined(HAVE_RFLAC) || defined(HAVE_RVORBIS) \
      || defined(HAVE_ROPUS) || defined(HAVE_RAAC))) \
      || (defined(HAVE_RMP4) && defined(HAVE_RAAC))
static bool audio_transfer_track_container(const void *data, size_t size,
      size_t avail, bool mp4)
{
   const uint8_t *bytes = (const uint8_t*)data;
   if (!bytes || size < 4 || (avail && avail < 4))
      return false;
#ifdef HAVE_RWEBM
   if (bytes[0] == 0x1a && bytes[1] == 0x45
         && bytes[2] == 0xdf && bytes[3] == 0xa3)
      return true;
#endif
#ifdef HAVE_RMP4
   if (mp4 && size >= 8 && (!avail || avail >= 8))
   {
      uint32_t box = (uint32_t)bytes[0] << 24 | (uint32_t)bytes[1] << 16
         | (uint32_t)bytes[2] << 8 | bytes[3];
      return !box || box == 1 || (box >= 8 && box <= size);
   }
#else
   (void)mp4;
#endif
   return false;
}
#endif

bool audio_transfer_set_container_track(void *data, enum audio_type_enum type,
      int track)
{
   if (!data || track < -1)
      return false;
   switch (type)
   {
#if defined(HAVE_RAC3) && defined(HAVE_RMP4)
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         if (a->dec || a->demux) return false;
         a->requested_track = (unsigned)track + 1;
         return true;
      }
#endif
#if defined(HAVE_RFLAC) && defined(HAVE_RWEBM)
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (fl->handle || fl->demux || (track >= 0
               && !audio_transfer_track_container(fl->data, fl->size, fl->avail, false)))
            return false;
         fl->requested_track = (unsigned)track + 1;
         return true;
      }
#endif
#if defined(HAVE_RVORBIS) && defined(HAVE_RWEBM)
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         if (v->handle || v->demux || (track >= 0
               && !audio_transfer_track_container(v->data, v->size, v->avail, false)))
            return false;
         v->requested_track = (unsigned)track + 1;
         return true;
      }
#endif
#if defined(HAVE_ROPUS) && defined(HAVE_RWEBM)
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (op->handle || op->demux || (track >= 0
               && !audio_transfer_track_container(op->buf, op->buf_size, op->avail, false)))
            return false;
         op->requested_track = (unsigned)track + 1;
         return true;
      }
#endif
#if defined(HAVE_RAAC) && (defined(HAVE_RWEBM) || defined(HAVE_RMP4))
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (ac->handle
#ifdef HAVE_RWEBM
               || ac->wdemux
#endif
#ifdef HAVE_RMP4
               || ac->demux
#endif
               || (track >= 0 && !audio_transfer_track_container(ac->buf,
                     ac->buf_size, ac->avail, true)))
            return false;
         ac->requested_track = (unsigned)track + 1;
         return true;
      }
#endif
      default:
         break;
   }
   return false;
}

int audio_transfer_container_track(const void *data, enum audio_type_enum type)
{
   if (!data)
      return -1;
   switch (type)
   {
#if defined(HAVE_RAC3) && defined(HAVE_RMP4)
      case AUDIO_TYPE_AC3:
      {
         const struct audio_transfer_ac3 *a = (const struct audio_transfer_ac3*)data;
         return a->dec && a->demux ? a->track_idx : -1;
      }
#endif
#if defined(HAVE_RFLAC) && defined(HAVE_RWEBM)
      case AUDIO_TYPE_FLAC:
      {
         const struct audio_transfer_flac *fl = (const struct audio_transfer_flac*)data;
         return fl->handle && fl->demux ? fl->track_idx : -1;
      }
#endif
#if defined(HAVE_RVORBIS) && defined(HAVE_RWEBM)
      case AUDIO_TYPE_VORBIS:
      {
         const struct audio_transfer_vorbis *v = (const struct audio_transfer_vorbis*)data;
         return v->handle && v->demux ? v->track_idx : -1;
      }
#endif
#if defined(HAVE_ROPUS) && defined(HAVE_RWEBM)
      case AUDIO_TYPE_OPUS:
      {
         const struct audio_transfer_opus *op = (const struct audio_transfer_opus*)data;
         return op->handle && op->demux ? op->track_idx : -1;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         const struct audio_transfer_aac *ac = (const struct audio_transfer_aac*)data;
         if (!ac->handle)
            return -1;
#ifdef HAVE_RWEBM
         if (ac->wdemux)
            return ac->wtrack_idx;
#endif
#ifdef HAVE_RMP4
         if (ac->demux)
            return ac->track_idx;
#endif
         break;
      }
#endif
      default:
         break;
   }
   return -1;
}

/* ---- a file's arm from its bytes ------------------------------------ */

#ifdef HAVE_RMP3
/* An MPEG audio frame header's frame length (layers I to III, MPEG-1,
 * 2 and 2.5), 0 when @h is not one; free format is not taken */
static size_t audio_transfer_mpa_len(const uint8_t *h)
{
   static const uint16_t kbps[2][3][15] = {
      { { 0,32,64,96,128,160,192,224,256,288,320,352,384,416,448 },
        { 0,32,48,56,64,80,96,112,128,160,192,224,256,320,384 },
        { 0,32,40,48,56,64,80,96,112,128,160,192,224,256,320 } },
      { { 0,32,48,56,64,80,96,112,128,144,160,176,192,224,256 },
        { 0,8,16,24,32,40,48,56,64,80,96,112,128,144,160 },
        { 0,8,16,24,32,40,48,56,64,80,96,112,128,144,160 } }
   };
   static const uint16_t rates[3] = { 44100, 48000, 32000 };
   unsigned ver, layer, bi, si, pad, rate, lsf;
   uint32_t br;
   if (h[0] != 0xFF || (h[1] & 0xE0) != 0xE0)
      return 0;
   ver   = (h[1] >> 3) & 3;   /* 0 MPEG-2.5, 1 reserved, 2 MPEG-2, 3 MPEG-1 */
   layer = 4 - ((h[1] >> 1) & 3);
   bi    = h[2] >> 4;
   si    = (h[2] >> 2) & 3;
   pad   = (h[2] >> 1) & 1;
   if (ver == 1 || layer == 4 || bi == 0 || bi == 15 || si == 3)
      return 0;
   lsf  = ver != 3;
   rate = rates[si] >> (ver == 3 ? 0 : ver == 2 ? 1 : 2);
   br   = (uint32_t)kbps[lsf][layer - 1][bi] * 1000;
   if (layer == 1)
      return (size_t)((12 * br / rate + pad) * 4);
   if (layer == 3 && lsf)
      return (size_t)(72 * br / rate + pad);
   return (size_t)(144 * br / rate + pad);
}
#endif

/* The length of the raw-stream frame at @p of @type's syntax, 0 when
 * there is none there */
static size_t audio_transfer_raw_frame(const uint8_t *p, size_t n,
      enum audio_type_enum type)
{
   switch (type)
   {
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
         return n >= 4 ? audio_transfer_mpa_len(p) : 0;
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         raac_adts_t h;
         return raac_adts_parse(p, n, &h) == 0 ? h.frame_size : 0;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         rac3_frame_info_t info;
         return rac3_parse_frame_info(p, n, &info) == RAC3_OK
            ? info.frame_bytes : 0;
      }
#endif
      default:
         break;
   }
   (void)p; (void)n;
   return 0;
}

enum audio_type_enum audio_transfer_sniff_type(const void *buf, size_t len,
      size_t *skip)
{
   const uint8_t *b = (const uint8_t*)buf;
   size_t         at = 0, i;
   if (skip)
      *skip = 0;
   if (!b)
      return AUDIO_TYPE_NONE;

#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
   /* OpenMG: its "ea3" tag, or the EA3 header itself; the arm reads
    * both */
   if (len >= 10 && (!memcmp(b, "ea3", 3) || !memcmp(b, "EA3", 3)))
      return AUDIO_TYPE_ATRAC;
#endif

   /* ID3v2 tags in front of a stream, each 10 bytes, a syncsafe size
    * and 10 more for a footer */
   while (len - at >= 10 && !memcmp(b + at, "ID3", 3) && b[at + 3] != 0xFF
         && !((b[at + 6] | b[at + 7] | b[at + 8] | b[at + 9]) & 0x80))
   {
      size_t tag = 10 + (((size_t)b[at + 6] << 21) | ((size_t)b[at + 7] << 14)
            | ((size_t)b[at + 8] << 7) | b[at + 9]) + ((b[at + 5] & 0x10) ? 10 : 0);
      if (tag > len - at)
         return AUDIO_TYPE_NONE;
      at += tag;
   }
   b   += at;
   len -= at;
   if (skip)
      *skip = at;

#ifdef HAVE_RFLAC
   if (len >= 4 && !memcmp(b, "fLaC", 4))
      return AUDIO_TYPE_FLAC;
#endif
   if (len >= 4 && !memcmp(b, "OggS", 4))
      return audio_transfer_ogg_audio_type(b, len);
   if (len >= 4 && b[0] == 0x1A && b[1] == 0x45 && b[2] == 0xDF && b[3] == 0xA3)
      return audio_transfer_webm_audio_type(b, len);

   if (len >= 12 && !memcmp(b, "RIFF", 4))
   {
      size_t c = 12;
#ifdef HAVE_RWMA
      if (!memcmp(b + 8, "XWMA", 4))
         return AUDIO_TYPE_WMA;
#endif
      if (memcmp(b + 8, "WAVE", 4))
         return AUDIO_TYPE_NONE;
      /* the format tag says which arm */
      while (c + 8 <= len)
      {
         uint32_t clen = audio_transfer_le32(b + c + 4);
         if (!memcmp(b + c, "fmt ", 4) && clen >= 2 && len - c - 8 >= 2)
         {
            unsigned tag = b[c + 8] | ((unsigned)b[c + 9] << 8);
            if (tag == 0xFFFE && clen >= 26 && len - c - 8 >= 26)
               tag = b[c + 32] | ((unsigned)b[c + 33] << 8);
#ifdef HAVE_RWAV
            if (tag == 1 || tag == 3)
               return AUDIO_TYPE_WAV;
#endif
#ifdef HAVE_RWMA
            if (tag == 0x0161 || tag == 0x0162 || tag == 0x0163)
               return AUDIO_TYPE_WMA;
#endif
#ifdef HAVE_RATRAC3
            if (tag == 0x0270)
               return AUDIO_TYPE_ATRAC;
#endif
#ifdef HAVE_RATRAC3P
            {
               /* the ATRAC3plus sub-format GUID */
               static const uint8_t g[16] = { 0xBF,0xAA,0x23,0xE9,0x58,0xCB,0x71,0x44,
                                              0xA1,0x19,0xFF,0xFA,0x01,0xE4,0xCE,0x62 };
               if (     b[c + 8] == 0xFE && b[c + 9] == 0xFF && clen >= 40
                     && len - c - 8 >= 40 && !memcmp(b + c + 32, g, 16))
                  return AUDIO_TYPE_ATRAC;
            }
#endif
            return AUDIO_TYPE_NONE;
         }
         if (clen > len - c - 8)
            break;
         c += 8 + clen + (clen & 1);
      }
      return AUDIO_TYPE_NONE;
   }

#ifdef HAVE_RWMA
   {
      static const uint8_t asf[16] = { 0x30,0x26,0xB2,0x75,0x8E,0x66,0xCF,0x11,
                                       0xA6,0xD9,0x00,0xAA,0x00,0x62,0xCE,0x6C };
      if (len >= 16 && !memcmp(b, asf, 16))
         return AUDIO_TYPE_WMA;
   }
#endif
#if defined(HAVE_RAAC) && defined(HAVE_RMP4)
   if (len >= 8 && (!memcmp(b + 4, "ftyp", 4) || !memcmp(b + 4, "moov", 4)))
      return AUDIO_TYPE_AAC;
#endif
#ifdef HAVE_RMODTRACKER
   if (     (len >= 17 && !memcmp(b, "Extended Module: ", 17))
         || (len >= 4  && !memcmp(b, "IMPM", 4))
         || (len >= 48 && !memcmp(b + 44, "SCRM", 4)))
      return AUDIO_TYPE_MOD;
   if (len >= 1084)
   {
      static const char tags[][5] = { "M.K.", "M!K!", "FLT4", "FLT8", "EXO4",
            "EXO8", "OKTA", "OCTA", "CD81", "FA08" };
      const uint8_t *t = b + 1080;
      for (i = 0; i < sizeof(tags) / sizeof(tags[0]); i++)
         if (!memcmp(t, tags[i], 4))
            return AUDIO_TYPE_MOD;
      if (     (t[0] >= '1' && t[0] <= '9' && !memcmp(t + 1, "CHN", 3))
            || (t[0] >= '1' && t[0] <= '9' && t[1] >= '0' && t[1] <= '9'
               && !memcmp(t + 2, "CH", 2)))
         return AUDIO_TYPE_MOD;
   }
#endif

   /* Raw streams: a frame header, and another where it says the next
    * one is (or the end of the file), at the start or after a little
    * junk. */
   {
      static const enum audio_type_enum raw[3] = {
         AUDIO_TYPE_AC3, AUDIO_TYPE_AAC, AUDIO_TYPE_MP3 };
      size_t limit = len < 65536 ? len : 65536;
      for (i = 0; i + 4 <= limit; i++)
      {
         unsigned k;
         for (k = 0; k < 3; k++)
         {
            size_t f = audio_transfer_raw_frame(b + i, len - i, raw[k]);
            if (     f && f <= len - i
                  && (f == len - i
                     || audio_transfer_raw_frame(b + i + f, len - i - f, raw[k])))
            {
               if (skip)
                  *skip = at + i;
               return raw[k];
            }
         }
      }
   }
   (void)i;
   return AUDIO_TYPE_NONE;
}

bool audio_transfer_set_start_trim(void *data, enum audio_type_enum type,
      uint64_t frames)
{
   switch (type)
   {
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (!ac)
            return false;
         ac->start_trim = frames;
         ac->trim_left  = frames;
         return true;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (!m)
            return false;
         /* Overrides the LAME tag's delay, and is taken as covering
          * the header frame too - a caller stating this knows what
          * the stream plays, which is what the arm needs. */
         m->start_trim = frames;
         m->trim_left  = frames;
         return true;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   /* every arm that reads these is compiled out in this build, the
    * way set_demuxed_ptr's already are */
   (void)data;
   (void)frames;
   return false;
}

#ifdef HAVE_RMP3
/* The frame count and gapless figures an MP3 carries in its first
 * frame, which is otherwise silent filler.
 *
 * A Xing or Info tag states how many frames the stream holds; a LAME
 * tag after it states the encoder delay and the padding.  VBRI, which
 * Fraunhofer writes instead, states the count and nothing else.  All
 * three sit inside the first frame at an offset that depends on the
 * MPEG version and whether the stream is mono, because that is how
 * much side information the frame has.
 *
 * Returns 1 when a count was found.  *out_frames is the audio the
 * stream is meant to play, *out_delay the priming to drop from the
 * front - the filler frame included, since the decoder emits it. */
static int audio_transfer_mp3_gapless(const uint8_t *b, size_t len,
      uint64_t *out_frames, uint64_t *out_delay)
{
   size_t   off = 0, xo;
   unsigned ver, sfi, chmode, spf;
   const uint8_t *h;
   uint32_t flags, frames = 0;

   if (!b || len < 4)
      return 0;
   /* An ID3v2 tag sits before the audio; its size is seven bits a
    * byte, the high bit of each being reserved. */
   if (len > 10 && b[0] == 'I' && b[1] == 'D' && b[2] == '3')
   {
      size_t tag = ((size_t)(b[6] & 0x7f) << 21)
                 | ((size_t)(b[7] & 0x7f) << 14)
                 | ((size_t)(b[8] & 0x7f) << 7)
                 |  (size_t)(b[9] & 0x7f);
      off = 10 + tag + ((b[5] & 0x10) ? 10 : 0);
   }
   while (off + 4 <= len && !(b[off] == 0xFF && (b[off + 1] & 0xE0) == 0xE0))
      off++;
   if (off + 4 > len)
      return 0;
   h      = b + off;
   ver    = (h[1] >> 3) & 3;      /* 3 MPEG1, 2 MPEG2, 0 MPEG2.5       */
   sfi    = (h[2] >> 2) & 3;
   chmode = (h[3] >> 6) & 3;      /* 3 = mono                          */
   if (ver == 1 || sfi == 3)      /* reserved version / sample rate    */
      return 0;
   spf    = (ver == 3) ? 1152 : 576;
   if (ver == 3)
      xo = (chmode == 3) ? 4 + 17 : 4 + 32;
   else
      xo = (chmode == 3) ? 4 +  9 : 4 + 17;

   if (   off + xo + 8 <= len
       && (   !memcmp(b + off + xo, "Xing", 4)
           || !memcmp(b + off + xo, "Info", 4)))
   {
      const uint8_t *p = b + off + xo + 8;
      uint64_t delay = 0, pad = 0;
      flags = ((uint32_t)b[off + xo + 4] << 24)
            | ((uint32_t)b[off + xo + 5] << 16)
            | ((uint32_t)b[off + xo + 6] <<  8)
            |  (uint32_t)b[off + xo + 7];
      if (flags & 1)
      {
         if ((size_t)(p - b) + 4 > len)
            return 0;
         frames = ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16)
                | ((uint32_t)p[2] <<  8) |  (uint32_t)p[3];
         p += 4;
      }
      if (flags & 2)
         p += 4;
      if (flags & 4)
         p += 100;
      if (flags & 8)
         p += 4;
      if (!frames)
         return 0;
      /* The LAME tag starts here; its delay and padding are twelve
       * bits each, packed into three bytes at offset 21.  Its delay is
       * the encoder's; the decoder's own, 529 samples, comes on top,
       * as rmp3's pull API (RMP3_DECODER_DELAY) and FFmpeg take it -
       * without it the audio started 529 samples late and its last
       * 529 were cut.  The padding is net of it already. */
      if ((size_t)(p - b) + 24 <= len)
      {
         delay = ((uint64_t)p[21] << 4) | (p[22] >> 4);
         pad   = ((uint64_t)(p[22] & 0xf) << 8) | p[23];
         *out_delay = (uint64_t)spf + delay + RMP3_DECODER_DELAY;
      }
      else
         *out_delay = (uint64_t)spf;
      /* The filler frame is decoded like any other, so it is priming
       * too.  What is left to play is the stated audio less both
       * ends. */
      *out_frames = (uint64_t)frames * spf;
      *out_frames = (*out_frames > delay + pad)
                  ? *out_frames - delay - pad : 0;
      return 1;
   }
   if (   off + 4 + 32 + 18 <= len
       && !memcmp(b + off + 4 + 32, "VBRI", 4))
   {
      const uint8_t *v = b + off + 4 + 32;
      frames = ((uint32_t)v[14] << 24) | ((uint32_t)v[15] << 16)
             | ((uint32_t)v[16] <<  8) |  (uint32_t)v[17];
      if (!frames)
         return 0;
      /* VBRI states no delay, so only the filler frame is dropped. */
      *out_delay  = (uint64_t)spf;
      *out_frames = (uint64_t)frames * spf;
      return 1;
   }
   return 0;
}
#endif

#ifdef HAVE_RMP3
/* Drain 'frames' frames out of the stream in one of the two pipelines,
 * feeding it the unconsumed tail of the buffer as it asks.  The
 * compressed cursor is kept here rather than in the decoder because a
 * windowed feeder reads it, and because a seek re-points it.  Returns
 * the frames written, short of the ask at end of stream. */
static size_t audio_transfer_mp3_pull(struct audio_transfer_mp3 *m,
      int s16, int16_t *o16, float *of, size_t frames)
{
   size_t done = 0;
   size_t avail = m->avail && m->avail < m->size ? m->avail : m->size;
   m->wall = 0;
   if (!m->stream || !frames)
      return 0;
   while (done < frames)
   {
      size_t rd = 0, wr = 0;
      int    r;
      if (s16)
         rmp3_stream_set_out_s16(m->stream,
               o16 + done * (size_t)m->channels, frames - done);
      else
         rmp3_stream_set_out_f32(m->stream,
               of + done * (size_t)m->channels, frames - done);
      rmp3_stream_set_in(m->stream,
            (const uint8_t*)m->data + m->off, avail - m->off);
      r = rmp3_stream_process(m->stream, &rd, &wr);
      m->off += rd;
      done   += wr;
      if (r == RMP3_STREAM_ERROR || r == RMP3_STREAM_END)
         break;
      if (r == RMP3_STREAM_NEED_IN && avail < m->size)
      {
         m->wall = 1;
         break;
      }
      if (r == RMP3_STREAM_NEED_IN && m->off >= m->size)
      {
         /* A frame must be presented whole, so the tail of the stream
          * sits in the hold waiting for a window that will never fill;
          * this is what says the short tail is all there is.  Latched
          * until a seek resets the stream, and once declared the
          * stream answers END when it is spent - it no longer asks
          * for input past EOF, so this branch runs at most once. */
         rmp3_stream_set_eof(m->stream);
         m->eof_sent = 1;
      }
   }
   return done;
}

/* Restart the stream and decode forward to @frame, discarding, in the
 * pipeline of the read that asked - which is what makes the output
 * after the seek byte-identical to a linear decode's.  MP3 frames
 * depend on the bit reservoir of their predecessors, so decoding from
 * the top is the only sample-accurate way in.  Frame numbers here are
 * of the played audio; the priming sits before frame 0 and is part of
 * the distance.  Returns the frame reached, or < 0 if the stream ends
 * first. */
static int64_t audio_transfer_mp3_seek_to(struct audio_transfer_mp3 *m,
      int64_t frame, int s16)
{
   /* Somewhere to throw the frames walked past.  On the stack, and one
    * union rather than two arrays: these were a pair of function-local
    * statics, 24 KiB of BSS of which only ever half was in use, and
    * shared by every context.  audio_mixer runs up to
    * AUDIO_MIXER_MAX_VOICES at once, so two MP3 streams priming in the
    * same callback wrote over each other's sink.  Small because it is
    * only a sink - the loop below iterates until the distance is gone. */
   union { int16_t s16[256]; float f32[256]; } skip;
   uint64_t left = (uint64_t)frame + m->start_trim;
   unsigned ch   = m->channels ? m->channels : 1;

   rmp3_stream_reset(m->stream);
   m->off      = 0;
   m->eof_sent = 0;
   while (left)
   {
      size_t cap  = (sizeof(skip.s16) / sizeof(skip.s16[0])) / ch;
      size_t want = (left < (uint64_t)cap) ? (size_t)left : cap;
      size_t n    = audio_transfer_mp3_pull(m, s16,
            skip.s16, skip.f32, want);
      if (!n)
         return -1;                /* the stream ends before the target */
      left -= n;
   }
   m->trim_left = 0;
   m->emitted   = frame;
   return frame;
}

/* Read past the priming and stop at the padding.  The trim is dropped
 * by decoding it and throwing it away - there is nowhere else for it
 * to go, the frames being coded - and the bound is what the tag says
 * is left after both ends come off. */
static size_t audio_transfer_mp3_read(struct audio_transfer_mp3 *m,
      int s16, int16_t *o16, float *of, size_t frames)
{
   size_t   got;
   union { int16_t s16[256]; float f32[256]; } skip;
   unsigned ch = m->channels ? m->channels : 1;
   while (m->trim_left)
   {
      size_t cap  = (sizeof(skip.s16) / sizeof(skip.s16[0])) / ch;
      size_t want = (m->trim_left < cap) ? (size_t)m->trim_left : cap;
      size_t n    = audio_transfer_mp3_pull(m, s16,
            skip.s16, skip.f32, want);
      if (!n)
      {
         if (!m->wall) m->trim_left = 0; /* true end inside priming */
         return 0;
      }
      m->trim_left -= n;
   }
   if (m->limit >= 0)
   {
      int64_t left = m->limit - m->emitted;
      if (left <= 0)
         return 0;
      if ((int64_t)frames > left)
         frames = (size_t)left;
   }
   got = audio_transfer_mp3_pull(m, s16, o16, of, frames);
   m->emitted += (int64_t)got;
   return got;
}
#endif

#ifdef HAVE_RFLAC
/* The next chunk of the stream, from whichever container holds it. */
static int audio_transfer_flac_next(struct audio_transfer_flac *fl)
{
   if (fl->ogg)
   {
      const uint8_t *b = (const uint8_t*)fl->data;
      size_t   body = 0, total;
      unsigned nsegs = 0;
      total = audio_transfer_ogg_page(b, fl->size, fl->pg_off, &body,
            &nsegs);
      if (!total)
         return 0;
      fl->cur     = b + body;
      fl->cur_len = total - (body - fl->pg_off);
      /* The first packet opens with the mapping header - 0x7F, "FLAC",
       * a version and a packet count - and the native stream starts
       * after it. */
      fl->cur_off = (fl->pg_off == 0) ? 9 : 0;
      fl->pg_off += total;
      return fl->cur_len > fl->cur_off;
   }
#ifdef HAVE_RWEBM
   if (fl->demux)
   {
      rwebm_packet pkt;
      fl->cur = NULL;
      fl->cur_len = 0;
      fl->wall = 0;
      for (;;)
      {
         int r = rwebm_read_packet_track(fl->demux, fl->track_idx, &pkt);
         /* The resident wall is not the end of the stream.  The pull
          * still reports "no chunk" - nothing here consumed anything,
          * so the retry is exact - but the wall flag lets the read
          * surface the difference instead of ending the sound. */
         if (r == RWEBM_READ_AGAIN || r == RWEBM_READ_YIELD)
         {
            fl->wall = 1;
            return 0;
         }
         if (r != 1)
            return r < 0 ? -1 : 0;
         if (pkt.track == fl->track_idx)
         {
            fl->wall = 0;
            break;
         }
      }
      if (fl->time.enabled)
      {
         int frames = rflac_packet_frames(pkt.data, pkt.size);
         int64_t padding;
         size_t skip = 0;
         if (frames < 0 || !audio_transfer_time_packet(&fl->time,
                  pkt.timestamp, pkt.timestamp_continuation)
               || !audio_transfer_time_frames(pkt.discard_padding,
                  fl->time.rate, &padding)) return -1;
         if (padding > 0)
            frames -= padding < frames ? (int)padding : frames;
         else if (padding < 0)
         {
            skip = -padding < frames ? (size_t)-padding : (size_t)frames;
            frames -= (int)skip;
         }
         if (!audio_transfer_time_map(&fl->time, skip, (size_t)frames)) return -1;
         fl->time_skip = skip;
         fl->time_pending = (size_t)frames;
      }
      fl->cur     = pkt.data;
      fl->cur_len = pkt.size;
      fl->cur_off = 0;
      return 1;
   }
#endif
   if (fl->packets)
   {
      /* No pointer kept: the caller may have moved the blob since the
       * last read, so only the index and the offset carry over. */
      uint32_t len;
      if (fl->pkt_index >= fl->num_packets)
         return 0;
      len = fl->pkt_sizes ? fl->pkt_sizes[fl->pkt_index]
                          : (uint32_t)fl->packets_size;
      if (fl->blob_off + len > fl->packets_size)
         return 0;
      fl->cur     = NULL;
      fl->cur_len = len;
      fl->cur_off = 0;
      fl->pkt_index++;
      return len > 0;
   }
   return 0;
}

/* Hands the decoder its next span.  The decoder owns no reader of its
 * own, so this is the only thing that moves the stream forward: the
 * setup bytes first, then whatever the container yields, and for a
 * resident buffer the whole thing at once.
 *
 * Nothing is reassembled and nothing is copied.  The Matroska arm used
 * to lay every block end to end into one buffer and keep that second
 * copy of the audio for the life of the decoder; a block is now handed
 * over where it already sits.
 *
 * Returns 0 when there is nothing further to give. */
static int audio_transfer_flac_feed(struct audio_transfer_flac *fl)
{
   int next;
   if (!fl->fed_hdr && fl->hdr && fl->hdr_size)
   {
      rflac_set_in(fl->handle, fl->hdr, fl->hdr_size);
      fl->fed_hdr = 1;
      return 1;
   }

   if (!fl->ogg && !fl->packets
#ifdef HAVE_RWEBM
         && !fl->demux
#endif
      )
   {
      /* Buffer mode: one span, handed over once, and it is the whole
       * stream - which lets the decoder skip its rewind points. */
      if (fl->fed_hdr)
         return 0;
      rflac_set_in(fl->handle, (const uint8_t*)fl->data, fl->size);
      rflac_set_eof(fl->handle);
      fl->fed_hdr = 1;
      return 1;
   }

   next = audio_transfer_flac_next(fl);
   if (next <= 0) return next;

   /* The delimited-packet arm keeps no pointer, because the caller may
    * move the blob between reads; it is resolved here instead. */
   if (fl->packets && !fl->cur)
   {
      fl->cur      = fl->packets + fl->blob_off;
      fl->blob_off += fl->cur_len;
   }

   rflac_set_in(fl->handle, fl->cur + fl->cur_off, fl->cur_len - fl->cur_off);
   return 1;
}

/* Runs the decoder until the output is full or the input is exhausted. */
static size_t audio_transfer_flac_pull(struct audio_transfer_flac *fl,
      void *out, size_t frames, int as_float)
{
   size_t produced = 0;

   if (!out)
      rflac_set_out_discard(fl->handle, frames);
   else if (as_float)
      rflac_set_out_f32(fl->handle, (float*)out, frames);
   else
      rflac_set_out_s16(fl->handle, (int16_t*)out, frames);

   while (produced < frames)
   {
      size_t rd = 0, wr = 0;
      int    e  = rflac_process(fl->handle, &rd, &wr);

      fl->cursor += rd;
      produced   += wr;

      if (e == RFLAC_PROCESS_ERROR || e == RFLAC_PROCESS_END)
         break;
      /* Nothing to give is not the end of the stream: a demuxed
       * packet set may grow and a windowed WebM may raise its wall, and
       * the next read picks up there. Every source answers this again
       * cheaply, so nothing is latched. */
      if (wr == 0 && audio_transfer_flac_feed(fl) <= 0)
         break;
   }

   return produced;
}

/* Bound a decode-forward step to @samples across all channels. FLAC goes
 * up to eight channels.  Before the header is read the count is not
 * known, so the step assumes the most. */
static size_t audio_transfer_flac_step_frames(
      const struct audio_transfer_flac *fl, size_t samples)
{
   const rflac_format_t *ff = rflac_format(fl->handle);
   unsigned ch = (ff && ff->channels && ff->channels <= 8)
      ? ff->channels : 8;
   return samples / ch;
}

/* Restarts the stream and decodes forward to @frame.  Returns 1 when
 * positioned. */
static uint32_t audio_transfer_flac_seek_to(struct audio_transfer_flac *fl,
      uint64_t frame)
{
   uint64_t at;

   if (!fl || !fl->handle)
      return 0;

   /* A byte-addressable source can take the shortcut: the stream's own
    * seek table names a frame boundary at or before the target, and
    * decoding resumes from there instead of from zero.  Only buffer
    * mode qualifies -- a container hands over packets and cannot be
    * pointed at an arbitrary byte -- and only a stream that carries a
    * table, which one inside a container never does. */
   if (!fl->ogg && !fl->packets
#ifdef HAVE_RWEBM
         && !fl->demux
#endif
         && fl->data)
   {
      uint64_t at    = 0;
      uint64_t point = 0;
      if (rflac_seek_point(fl->handle, frame, &at, &point)
               == RFLAC_PROCESS_NEXT
            && at < fl->size)
      {
         uint64_t landed;
         /* Resumed at the seek point's own frame.  Told 0 instead, the
          * decoder took the point for the start, and the remainder below
          * was decoded on from the point as if from frame 0: the seek
          * landed point frames past its target. */
         rflac_seek_resumed(fl->handle, point);
         rflac_set_in(fl->handle, (const uint8_t*)fl->data + at,
               fl->size - (size_t)at);
         rflac_set_eof(fl->handle);
         fl->fed_hdr = 1;
         fl->cursor  = (size_t)at;
         /* The table names the boundary, not the frame; close the
          * remainder by decoding. */
         landed = rflac_tell(fl->handle);
         for (; landed < frame; )
         {
            size_t  want = (size_t)(frame - landed);
            size_t  most = audio_transfer_flac_step_frames(fl,
                  2048);
            size_t  got;
            if (want > most)
               want = most;
            got = audio_transfer_flac_pull(fl, NULL, want, 0);
            if (!got)
               break;
            landed += got;
         }
         if (landed >= frame)
            return 1;
      }
   }

   /* Rewind every source this arm can have. */
   rflac_reset(fl->handle);
   fl->fed_hdr = 0;
   fl->cursor  = 0;
   fl->pg_off  = 0;
   fl->cur     = NULL;
   fl->cur_len = 0;
   fl->cur_off = 0;
   fl->pkt_index = 0;
   fl->blob_off  = 0;
#ifdef HAVE_RWEBM
   if (fl->demux)
      rwebm_rewind(fl->demux);
#endif

   for (at = 0; at < frame; )
   {
      size_t want = (size_t)(frame - at);
      size_t most = audio_transfer_flac_step_frames(fl,
            2048);
      size_t got;
      if (want > most)
         want = most;
      got = audio_transfer_flac_pull(fl, NULL, want, 0);
      if (!got)
         return 0;
      at += got;
   }

   return 1;
}


static void audio_transfer_flac_movie_head(struct audio_transfer_flac *fl)
{
   rflac_seek_resumed(fl->handle, 0);
   fl->fed_hdr = 1;
   fl->cur = NULL;
   fl->cur_len = fl->cur_off = fl->cursor = 0;
   fl->time.first_ready = fl->time.ready = fl->time.eof = 0;
   fl->time.end = fl->time.pending = fl->time.position = 0;
   fl->time_pending = fl->time_skip = 0;
   fl->wall = fl->yielded = 0;
#ifdef HAVE_RWEBM
   rwebm_rewind(fl->demux);
   if (fl->avail) { fl->avail = 1; rwebm_set_avail(fl->demux, 1); }
#endif
}

static int audio_transfer_flac_movie_fill(struct audio_transfer_flac *fl)
{
   int result;
   if (fl->time_pending) return 1;
   if (fl->time.eof) return 0;
   result = audio_transfer_flac_next(fl);
   if (result < 0) return -1;
   if (!result)
   {
      if (fl->wall) return 2;
      fl->time.eof = 1;
      return 0;
   }
   if (!fl->time_pending) { fl->yielded = 1; return 2; }
   /* Complete independent frames need neither carry nor a rollback copy. */
   rflac_seek_resumed(fl->handle, 0);
   rflac_set_in(fl->handle, fl->cur, fl->cur_len);
   rflac_set_eof(fl->handle);
   return 1;
}

static int audio_transfer_flac_movie_take(struct audio_transfer_flac *fl,
      void *out, size_t frames, int s16)
{
   size_t read = 0, wrote = 0;
   int result;
   if (!out) rflac_set_out_discard(fl->handle, frames);
   else if (s16) rflac_set_out_s16(fl->handle, (int16_t*)out, frames);
   else rflac_set_out_f32(fl->handle, (float*)out, frames);
   result = rflac_process(fl->handle, &read, &wrote);
   fl->cursor += read;
   return result != RFLAC_PROCESS_ERROR && wrote == frames;
}

static int audio_transfer_flac_movie_read(struct audio_transfer_flac *fl,
      int s16, int16_t *out16, float *outf, size_t frames, size_t *got)
{
   size_t done = 0;
   unsigned walked = 0;
   const rflac_format_t *format;
   if (!audio_transfer_info(fl, AUDIO_TYPE_FLAC, NULL, NULL, NULL))
      return AUDIO_PROCESS_ERROR;
   format = rflac_format(fl->handle);
   fl->yielded = 0;
   while (done < frames)
   {
      size_t take, skip, wanted = frames - done;
      int result;
      void *out;
      if (++walked > 32) { fl->yielded = 1; break; }
      if (fl->time.total >= 0 && fl->time.position >= fl->time.total) break;
      result = audio_transfer_flac_movie_fill(fl);
      if (result < 0) return AUDIO_PROCESS_ERROR;
      if (result == 2) break;
      if (wanted > 256) wanted = 256;
      take = audio_transfer_time_silence(&fl->time, wanted, !result);
      if (take)
      {
         if (s16) memset(out16 + done * format->channels, 0,
               take * format->channels * sizeof(*out16));
         else memset(outf + done * format->channels, 0,
               take * format->channels * sizeof(*outf));
         done += take;
         continue;
      }
      if (!result) break;
      if (fl->time_skip)
      {
         take = fl->time_skip > 256 ? 256 : fl->time_skip;
         if (!audio_transfer_flac_movie_take(fl, NULL, take, s16)) return AUDIO_PROCESS_ERROR;
         fl->time_skip -= take;
         continue;
      }
      skip = audio_transfer_time_overlap(&fl->time, fl->time_pending);
      take = skip ? skip : fl->time_pending;
      if (take > frames - done) take = frames - done;
      if (take > 256) take = 256;
      if (!skip && fl->time.total >= 0 && (uint64_t)(fl->time.total - fl->time.position) < take)
         take = (size_t)(fl->time.total - fl->time.position);
      out = s16 ? (void*)(out16 + done * format->channels)
         : (void*)(outf + done * format->channels);
      if (!audio_transfer_flac_movie_take(fl, skip ? NULL : out, take, s16))
         return AUDIO_PROCESS_ERROR;
      fl->time_pending -= take;
      if (skip) fl->time.pending -= (int64_t)(skip - take);
      else
      {
         fl->time.pending += (int64_t)take;
         fl->time.position += (int64_t)take;
         done += take;
      }
   }
   if (got) *got = done;
   return done || fl->wall || fl->yielded ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
}

static int audio_transfer_flac_movie_seek_step(struct audio_transfer_flac *fl)
{
   int result;
   int64_t end;
   size_t skip;
   result = audio_transfer_flac_movie_fill(fl);
   if (result < 0) goto failed;
   if (result == 2) return 0;
   if (!result)
   {
      if (fl->time.total < 0 && fl->seek_remaining > (uint64_t)fl->time.end)
         goto failed;
   }
   else
   {
      if (!audio_transfer_time_add(fl->time.pending,
               (int64_t)fl->time_pending, &end)) goto failed;
      if (end <= 0 || (uint64_t)end <= fl->seek_remaining)
      {
         fl->time_pending = fl->time_skip = 0;
         return 0;
      }
      fl->time.position = (int64_t)fl->seek_remaining;
      skip = audio_transfer_time_overlap(&fl->time, fl->time_pending);
      if ((skip || fl->time_skip) && !audio_transfer_flac_movie_take(fl,
               NULL, skip + fl->time_skip, 0)) goto failed;
      fl->time_skip = 0;
      fl->time_pending -= skip;
   }
   fl->time.position = (int64_t)fl->seek_remaining;
   fl->seek_pending = 0;
   return 1;
failed:
   fl->seek_pending = 0;
   return -1;
}


#endif

#ifdef HAVE_RVORBIS
/* The serial of the first logical bitstream whose first packet is a
 * Vorbis identification header, and how many distinct serials the
 * file carries.  A single-serial file is an ordinary .ogg and goes to
 * rvorbis whole; anything else has to be filtered. */
static int audio_transfer_ogg_survey(const uint8_t *b, size_t size,
      uint32_t *serial, int *nstreams, int *chained, int64_t *total,
      int *mismatch, int64_t *first_total)
{
   uint32_t seen[16];
   uint32_t vser[16];
   int64_t  vgran[16];
   int      n = 0, nv = 0, found = 0, bos_after_data = 0, data_seen = 0;
   int      first_ch = 0, differs = 0;
   uint32_t first_rate = 0;
   size_t   off = 0;
   for (;;)
   {
      size_t   body = 0, psz;
      unsigned nsegs = 0;
      uint32_t ser;
      int      i, known = 0;
      psz = audio_transfer_ogg_page(b, size, off, &body, &nsegs);
      if (!psz)
         break;
      ser = (uint32_t)b[off + 14]        | ((uint32_t)b[off + 15] << 8)
          | ((uint32_t)b[off + 16] << 16) | ((uint32_t)b[off + 17] << 24);
      for (i = 0; i < n; i++)
         if (seen[i] == ser)
            known = 1;
      if (!known && n < (int)(sizeof(seen) / sizeof(seen[0])))
         seen[n++] = ser;
      if (b[off + 5] & 0x02)            /* beginning of a stream       */
      {
         if (data_seen)
            bos_after_data = 1;
         if (body + 7 <= size
               && b[body] == 1 && !memcmp(b + body + 1, "vorbis", 6))
         {
            if (!found)
            {
               *serial = ser;
               found   = 1;
            }
            if (nv < (int)(sizeof(vser) / sizeof(vser[0])))
            {
               vser[nv]    = ser;
               vgran[nv++] = 0;
            }
            /* An identification header states the channels at byte 11
             * and the rate at 12.  Links that disagree cannot all be
             * played by one voice, so note it here rather than let
             * the later ones come out at the first one's rate. */
            if (body + 16 <= size)
            {
               int      lch = b[body + 11];
               uint32_t lr  = (uint32_t)b[body + 12]
                            | ((uint32_t)b[body + 13] << 8)
                            | ((uint32_t)b[body + 14] << 16)
                            | ((uint32_t)b[body + 15] << 24);
               if (!first_ch)
               {
                  first_ch   = lch;
                  first_rate = lr;
               }
               else if (lch != first_ch || lr != first_rate)
                  differs = 1;
            }
         }
      }
      else
         data_seen = 1;
      /* A page's granule position is where its last finished packet
       * leaves the stream, so the last one a bitstream carries is its
       * length.  Summed over the Vorbis bitstreams, that is what the
       * file plays - one for a multiplexed file, one per link for a
       * chained one. */
      {
         int i;
         for (i = 0; i < nv; i++)
            if (vser[i] == ser)
            {
               int64_t g = 0;
               int     k;
               for (k = 7; k >= 0; k--)
                  g = (g << 8) | b[off + 6 + k];
               if (g >= 0)
                  vgran[i] = g;
            }
      }
      off += psz;
   }
   *nstreams = n;
   *chained  = bos_after_data;
   if (mismatch)
      *mismatch = differs;
   if (total)
   {
      int i;
      *total = 0;
      for (i = 0; i < nv; i++)
         *total += vgran[i];
   }
   /* The first link's length on its own, which is what plays when the
    * links disagree and only it can be played. */
   if (first_total)
      *first_total = nv ? vgran[0] : 0;
   return found;
}

/* Assemble the next packet of the chosen bitstream, skipping pages
 * belonging to any other.  Shaped like the Opus arm's assembler, with
 * the serial test added; a packet spanning pages is gathered into
 * asm_buf, otherwise it aliases the buffer. */
static int audio_transfer_vorbis_ogg_pkt(struct audio_transfer_vorbis *v,
      const uint8_t **pdata, uint32_t *plen)
{
   const uint8_t *b = (const uint8_t*)v->data;
   size_t asm_len = 0;
   int    spans   = 0;
   for (;;)
   {
      size_t   body = 0, start, run = 0;
      unsigned nsegs = 0;
      size_t   psz = audio_transfer_ogg_page(b, v->size, v->pg_off,
            &body, &nsegs);
      uint32_t ser;
      int      done = 0;
      if (!psz)
         return asm_len ? -1 : 0;
      ser = (uint32_t)b[v->pg_off + 14]
          | ((uint32_t)b[v->pg_off + 15] << 8)
          | ((uint32_t)b[v->pg_off + 16] << 16)
          | ((uint32_t)b[v->pg_off + 17] << 24);
      if (ser != v->ogg_serial)
      {
         v->pg_off += psz;            /* another stream's page         */
         v->seg_idx = 0;
         continue;
      }
      if (v->seg_idx == 0)
         v->body_off = body;
      if (asm_len && v->seg_idx == 0 && !(b[v->pg_off + 5] & 0x01))
         return -1;
      start = v->body_off;
      while (v->seg_idx < nsegs)
      {
         unsigned lace = b[v->pg_off + 27 + v->seg_idx];
         run += lace;
         v->seg_idx++;
         if (lace < 255)
         {
            done = 1;
            break;
         }
      }
      v->body_off = start + run;
      if (v->seg_idx >= nsegs && !done)
      {
         if (run)
         {
            if (asm_len + run > v->asm_cap)
               return -1;
            memcpy(v->asm_buf + asm_len, b + start, run);
            asm_len += run;
         }
         spans      = 1;
         v->pg_off += psz;
         v->seg_idx = 0;
         continue;
      }
      if (v->seg_idx >= nsegs)
      {
         v->pg_off += psz;
         v->seg_idx = 0;
      }
      if (!spans)
      {
         *pdata = b + start;
         *plen  = (uint32_t)run;
      }
      else
      {
         if (asm_len + run > v->asm_cap)
            return -1;
         memcpy(v->asm_buf + asm_len, b + start, run);
         asm_len += run;
         *pdata   = v->asm_buf;
         *plen    = (uint32_t)asm_len;
      }
      return 1;
   }
}
#endif

#ifdef HAVE_RVORBIS
/* Cap a whole-file read at the length the Ogg granules state.
 *
 * rvorbis decodes a chained file through every link, but reports only
 * the first link's length, and at each boundary it hands out the lead
 * of the next link's first block - audio the granules do not account
 * for.  Bounding by the summed granules makes the length reported and
 * the audio emitted the same figure, which is the property the length
 * is meant to have.  For a file with one link the bound is what comes
 * out anyway, so nothing changes there. */
static size_t audio_transfer_vorbis_cap(struct audio_transfer_vorbis *v,
      size_t frames)
{
   if (v->limit >= 0)
   {
      int64_t left = v->limit - v->emitted;
      if (left <= 0)
         return 0;
      if ((int64_t)frames > left)
         frames = (size_t)left;
   }
   return frames;
}
#endif

#ifdef HAVE_RMP3
/* Count what every frame in the file contributes.
 *
 * The fallback for a stream carrying no Xing, Info or VBRI header,
 * which states nothing about its own length.  Each frame header gives
 * its own bitrate and so its own size, which makes this work on a
 * variable-bitrate stream as well as a constant one - the file size
 * and a nominal rate would not.
 *
 * It is a step per frame over four header bytes, not a decode: 1.1 ms
 * for a ten-minute file, measured, which is why the length is worth
 * having rather than reporting nothing.  What it counts is what the
 * decoder emits, priming and all, there being no tag to say which of
 * that was padding. */
static uint64_t audio_transfer_mp3_walk(const uint8_t *b, size_t len)
{
   static const unsigned rates[4] = { 44100, 48000, 32000, 0 };
   static const unsigned br1[16]  = { 0,32,40,48,56,64,80,96,112,128,
                                      160,192,224,256,320,0 };
   static const unsigned br2[16]  = { 0,8,16,24,32,40,48,56,64,80,96,
                                      112,128,144,160,0 };
   size_t   off   = 0;
   uint64_t total = 0;
   if (!b || len < 4)
      return 0;
   if (len > 10 && b[0] == 'I' && b[1] == 'D' && b[2] == '3')
      off = 10 + (((size_t)(b[6] & 0x7f) << 21)
                | ((size_t)(b[7] & 0x7f) << 14)
                | ((size_t)(b[8] & 0x7f) <<  7)
                |  (size_t)(b[9] & 0x7f));
   for (;;)
   {
      unsigned ver, sfi, br, pad, rate, spf, blen;
      while (off + 4 <= len
            && !(b[off] == 0xFF && (b[off + 1] & 0xE0) == 0xE0))
         off++;
      if (off + 4 > len)
         break;
      ver = (b[off + 1] >> 3) & 3;
      sfi = (b[off + 2] >> 2) & 3;
      br  = (b[off + 2] >> 4) & 15;
      pad = (b[off + 2] >> 1) & 1;
      if (ver == 1 || sfi == 3 || br == 0 || br == 15)
      {
         off++;                      /* not a frame header after all   */
         continue;
      }
      rate = rates[sfi];
      if (ver == 2)
         rate /= 2;
      else if (ver == 0)
         rate /= 4;
      if (!rate)
         break;
      spf  = (ver == 3) ? 1152 : 576;
      blen = (ver == 3) ? (144000 * br1[br]) / rate + pad
                        : ( 72000 * br2[br]) / rate + pad;
      if (!blen || off + blen > len)
         break;
      total += spf;
      off   += blen;
   }
   return total;
}
#endif

bool audio_transfer_start(void *data, enum audio_type_enum type)
{
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
      {
         struct audio_transfer_wma *a = (struct audio_transfer_wma*)data;
         if (!a || a->stream || rwma_stream_open(&a->stream, a->buf, a->size, a->avail))
            return false;
         rwma_stream_info(a->stream, &a->channels, &a->rate);
         return true;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl || (fl->requested_track && fl->setup))
            return false;
         memset(&fl->time, 0, sizeof(fl->time));
         fl->time.total = -1;
         /* A demuxed caller supplies no buffer, so the bytes have to
          * come from one source or the other. */
         if (!fl->data && !(fl->setup && fl->packets))
            return false;
         /* Demuxed: the caller holds the header and the frames apart,
          * which is the shape the containers above are reduced to, so
          * it is served the same way. */
         if (fl->setup && fl->packets)
         {
            fl->hdr       = (const uint8_t*)fl->setup;
            fl->hdr_size  = fl->setup_size;
            fl->pos       = 0;
            fl->pkt_index = 0;
            fl->blob_off  = 0;
            fl->cur       = NULL;
            fl->cur_len   = 0;
            fl->cur_off   = 0;
            fl->handle    = rflac_new();
            return fl->handle != NULL;
         }
         /* Ogg FLAC (RFC 5334).  The first packet opens with the
          * mapping header - 0x7F, "FLAC", a version and a packet
          * count - and the native stream follows it, so the page
          * bodies laid end to end past those nine bytes are what
          * rflac reads.  Fed the same way as the Matroska path, and
          * nothing is reassembled. */
         if (fl->data && fl->size >= 28
               && !memcmp(fl->data, "OggS", 4))
         {
            const uint8_t *b = (const uint8_t*)fl->data;
            size_t   body = 0;
            unsigned nsegs = 0;
            if (   audio_transfer_ogg_page(b, fl->size, 0, &body, &nsegs)
                && body + 5 <= fl->size
                && b[body] == 0x7F
                && !memcmp(b + body + 1, "FLAC", 4))
            {
               fl->ogg      = 1;
               fl->pg_off   = 0;
               fl->hdr      = NULL;
               fl->hdr_size = 0;
               fl->pos      = 0;
               fl->cur      = NULL;
               fl->cur_len  = 0;
               fl->cur_off  = 0;
               fl->handle   = rflac_new();
               return fl->handle != NULL;
            }
         }
#ifdef HAVE_RWEBM
         /* Matroska lends CodecPrivate as the native header, then one
          * borrowed FLAC frame per block. */
         if (fl->data && fl->size >= 4
               && ((const uint8_t*)fl->data)[0] == 0x1A
               && ((const uint8_t*)fl->data)[1] == 0x45
               && ((const uint8_t*)fl->data)[2] == 0xDF
               && ((const uint8_t*)fl->data)[3] == 0xA3)
         {
            const rwebm_track *at = NULL;
            int                i;
            if (!(fl->demux = audio_transfer_webm_open(
                        (const uint8_t*)fl->data, fl->size, fl->avail)))
               return false;
            fl->track_idx = -1;
            for (i = 0; i < rwebm_num_tracks(fl->demux); i++)
            {
               const rwebm_track *t = rwebm_get_track(fl->demux, i);
               if ((!fl->requested_track || fl->requested_track - 1 == (unsigned)i)
                     && t && t->type == RWEBM_TRACK_AUDIO
                     && t->codec == RWEBM_CODEC_FLAC
                     && t->codec_private_size >= 4)
               {
                  at            = t;
                  fl->track_idx = i;
                  break;
               }
            }
            if (!at)
               return false;
            fl->hdr      = at->codec_private;
            fl->hdr_size = at->codec_private_size;
            fl->pos      = 0;
            fl->cur      = NULL;
            fl->cur_len  = 0;
            fl->cur_off  = 0;
            if (at->codec_delay_ns > ((~(uint64_t)0) >> 1)) return false;
            fl->time.enabled = fl->time.producing_anchor = 1;
            fl->time.delay_ns = (int64_t)at->codec_delay_ns;
            /* Audio-only Duration can be rounded beyond the lossless PCM. */
            for (i = 0; i < rwebm_num_tracks(fl->demux); i++)
            {
               const rwebm_track *track = rwebm_get_track(fl->demux, i);
               if (track && track->type == RWEBM_TRACK_VIDEO)
               {
                  fl->duration_ns = rwebm_duration_ns(fl->demux);
                  break;
               }
            }
            fl->handle   = rflac_new();
            return fl->handle != NULL;
         }
#endif
         fl->handle = rflac_new();
         return fl->handle != NULL;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
#ifdef HAVE_RWEBM
         int64_t duration_ns = 0;
#endif
         int     err         = 0;
         if (!v || (v->requested_track && v->setup))
            return false;
         v->limit   = -1;
         v->emitted = 0;
         memset(&v->time, 0, sizeof(v->time));
         v->time.total = -1;
#ifdef HAVE_RWEBM
         /* Buffer mode, WebM audio (.weba): the setup headers are the
          * Vorbis track's CodecPrivate and the audio packets stay in
          * the container, read out one at a time as they are decoded.
          * The demuxer is held open for that, and it aliases the
          * caller's buffer rather than copying out of it. */
         if (!v->setup && v->data && v->size >= 4
               && ((const uint8_t*)v->data)[0] == 0x1A
               && ((const uint8_t*)v->data)[1] == 0x45
               && ((const uint8_t*)v->data)[2] == 0xDF
               && ((const uint8_t*)v->data)[3] == 0xA3)
         {
            const rwebm_track *at = NULL;
            int i;
            if (!(v->demux = audio_transfer_webm_open(
                        (const uint8_t*)v->data, v->size, v->avail)))
               return false;
            v->track_idx = -1;
            for (i = 0; i < rwebm_num_tracks(v->demux); i++)
            {
               const rwebm_track *t = rwebm_get_track(v->demux, i);
               if ((!v->requested_track || v->requested_track - 1 == (unsigned)i)
                     && t && t->type == RWEBM_TRACK_AUDIO
                     && t->codec == RWEBM_CODEC_VORBIS
                     && t->codec_private_size)
               {
                  at           = t;
                  v->track_idx = i;
                  break;
               }
            }
            if (!at)
               return false;
            v->setup      = at->codec_private;
            v->setup_size = at->codec_private_size;
            duration_ns   = rwebm_duration_ns(v->demux);
         }
#endif
         if (v->setup)
         {
            /* Packet-fed: the identification and setup headers come out
             * of the xiph-laced CodecPrivate and are parsed where they
             * lie.  The comment header carries no decode state and is
             * not wanted. */
            const uint8_t *hdr[3];
            uint32_t       hlen[3];
            if (!audio_vorbis_split_setup((const uint8_t*)v->setup,
                     v->setup_size, hdr, hlen))
               return false;
            v->handle = rvorbis_open_packets(hdr[0], (int)hlen[0],
                  hdr[2], (int)hlen[2], &err, NULL);
            if (!v->handle)
               return false;
            v->packet     = 1;
            v->pkt_index  = 0;
            v->pkt_offset = 0;
         }
         else
         {
            uint32_t ser = 0;
            int      nstreams = 0, chained = 0;
            int64_t  gtotal = 0;
            int      isvorbis, mismatch = 0;
            int64_t  gfirst = 0;
            if (!v->data)
               return false;
            isvorbis = audio_transfer_ogg_survey((const uint8_t*)v->data,
                  v->size, &ser, &nstreams, &chained, &gtotal,
                  &mismatch, &gfirst);
            /* One logical bitstream is an ordinary .ogg and goes to
             * rvorbis whole, which is the path every such file has
             * always taken.  More than one and it cannot: rvorbis has
             * no notion of a serial number, so a multiplexed file
             * would feed it the other stream's pages.  Those go
             * through the packet path instead, where the pages can be
             * filtered. */
            if (isvorbis && nstreams > 1 && !chained)
            {
               const uint8_t *hdr[3];
               uint32_t       hlen[3];
               int            i, ok = 1;
               v->asm_cap = 65536;
               if (!(v->asm_buf = (uint8_t*)malloc(v->asm_cap)))
                  return false;
               v->ogg_pkt    = 1;
               v->ogg_serial = ser;
               v->pg_off     = 0;
               v->seg_idx    = 0;
               v->body_off   = 0;
               for (i = 0; i < 3; i++)
                  if (audio_transfer_vorbis_ogg_pkt(v, &hdr[i], &hlen[i])
                        != 1)
                  {
                     ok = 0;
                     break;
                  }
               if (!ok)
                  return false;
               /* Identification and setup; the comment packet in
                * between is not needed to decode. */
               v->handle = rvorbis_open_packets(hdr[0], (int)hlen[0],
                     hdr[2], (int)hlen[2], &err, NULL);
               if (!v->handle)
                  return false;
               v->packet = 1;
            }
            else
            {
               /* Feed until the setup headers are in.  That is all the
                * residency an open needs; the rest of the file is read
                * as it plays. */
               size_t rd, wr;
               if (!(v->stream = rvorbis_stream_new()))
                  return false;
               for (;;)
               {
                  int r;
                  rvorbis_stream_set_out_s16(v->stream, NULL, 0);
                  rvorbis_stream_set_in(v->stream,
                        (const uint8_t*)v->data + v->stream_off,
                        v->size - v->stream_off);
                  r = rvorbis_stream_process(v->stream, &rd, &wr);
                  v->stream_off += rd;
                  if (rvorbis_stream_info(v->stream, NULL))
                     break;
                  if (r != RVORBIS_STREAM_NEED_IN || !rd
                        || v->stream_off >= v->size)
                  {
                     rvorbis_stream_free(v->stream);
                     v->stream = NULL;
                     return false;
                  }
               }
               v->handle = rvorbis_stream_decoder(v->stream);
               if (!v->handle)
                  return false;
               (void)err;
            }
            /* The granules say what the file plays.  For a chained
             * file that is the sum over its links, which rvorbis
             * decodes through but reports only the first of; for a
             * multiplexed one it is the chosen bitstream's, which
             * also trims the last packet's overhang. */
            if (gtotal > 0)
               v->limit = gtotal;
            /* Links that disagree on rate or channels: the voice is
             * built around the first one's, so play that link and
             * stop rather than run the rest at the wrong speed.  The
             * length becomes the first link's granule, which is what
             * comes out. */
            /* From the survey, not from rvorbis: the handle here is
             * packet-fed and has no buffer of Ogg pages to walk, so
             * asking it for a length answered zero and left the bound
             * at the sum over every link - a length no chained file
             * with disagreeing links ever reached. */
            if (mismatch && gfirst > 0)
               v->limit = gfirst;
         }
         v->channels = rvorbis_get_info(v->handle).channels;
#ifdef HAVE_RWEBM
         if (v->demux)
         {
            const rwebm_track *at = rwebm_get_track(v->demux, v->track_idx);
            v->time.enabled = 1;
            v->time.producing_anchor = 1;
            v->time.rate = rvorbis_get_info(v->handle).sample_rate;
            if (at->codec_delay_ns > ((~(uint64_t)0) >> 1)) return false;
            v->time.delay_ns = (int64_t)at->codec_delay_ns;
            if (duration_ns > 0 && !audio_transfer_time_frames(duration_ns,
                     v->time.rate, &v->time.total)) return false;
         }
#endif
         /* A caller's packet blob is resident by definition, so the
          * same header walk gives its exact length.  No padding is
          * stated for it - the set is the caller's - so the last
          * packet's overlap-add overhang is part of what plays, and
          * the total is what comes out. */
         if (v->packets && v->channels > 0)
         {
            const uint8_t *pd = NULL;
            uint32_t       pl = 0;
            int64_t        total = 0, pad = 0;
            int            n = 0, ok = 1;
            while (audio_transfer_vorbis_pull(v, &pd, &pl, &pad) == 1)
            {
               int fr = rvorbis_packet_frames(v->handle, pd, pl);
               if (fr < 0)
               {
                  ok = 0;
                  break;
               }
               if (++n > 1)
                  total += fr;
            }
            v->pkt_index  = 0;
            v->pkt_offset = 0;
            v->emitted    = 0;
            if (ok && total > 0)
               v->limit = total;
            return true;
         }
         /* Movie duration is not a raw decoder sample count. Tail
          * padding arrives with its packet; avoid a whole-file header
          * walk at open, including for fully resident WebM buffers. */
         v->time.first_ready = v->time.ready = v->time.eof = 0;
         v->time.end = v->time.pending = v->time.position = 0;
         return true;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         size_t avail;
         if (!m || !m->data)
            return false;
         avail = m->avail && m->avail < m->size ? m->avail : m->size;
         if (!(m->stream = rmp3_stream_new()))
            return false;
         /* Walk parse-only until the first frame is located, which is
          * where the channel count and rate come from - MPEG audio has
          * no header ahead of the stream to read them from.  Locating
          * decodes nothing, so the walk costs a scan; a buffer with no
          * frame in it fails here, as the resident open did.  Then back
          * to the head, so the first read decodes from frame one. */
         m->off      = 0;
         m->eof_sent = 0;
         for (;;)
         {
            size_t rd = 0, wr = 0;
            int    r;
            rmp3_stream_set_out_s16(m->stream, NULL, 0);
            rmp3_stream_set_in(m->stream,
                  (const uint8_t*)m->data + m->off, avail - m->off);
            r = rmp3_stream_process(m->stream, &rd, &wr);
            m->off += rd;
            if (rmp3_stream_info(m->stream, &m->channels, &m->rate))
               break;
            if (r == RMP3_STREAM_NEED_IN && avail < m->size)
            {
               rmp3_stream_free(m->stream);
               m->stream = NULL;
               return false;
            }
            if (r == RMP3_STREAM_NEED_IN && m->off >= m->size
                  && !m->eof_sent)
            {
               /* A file shorter than the reassembly hold never fills
                * it; say the short tail is all there is, so its frame
                * is still found.  Past this the stream never asks for
                * input again - a spent stream answers END - so failing
                * to locate a frame surfaces below, not as a second
                * NEED_IN. */
               rmp3_stream_set_eof(m->stream);
               m->eof_sent = 1;
               continue;
            }
            if (r == RMP3_STREAM_ERROR || r == RMP3_STREAM_END)
            {
               rmp3_stream_free(m->stream);
               m->stream = NULL;
               return false;
            }
         }
         rmp3_stream_reset(m->stream);
         m->off      = 0;
         m->eof_sent = 0;
         m->seek_to  = -1;
         m->limit    = -1;
         {
            uint64_t fr = 0, delay = 0;
            if (!audio_transfer_mp3_gapless((const uint8_t*)m->data,
                     avail, &fr, &delay))
            {
               /* No header to state a length; count the frames. */
               uint64_t walked = avail == m->size ? audio_transfer_mp3_walk(
                     (const uint8_t*)m->data, m->size) : 0;
               if (walked)
                  m->limit = (int64_t)walked;
            }
            else
            {
               /* set_start_trim, if the caller used it, wins - it is
                * a statement from a container that knows better than
                * the stream's own tag. */
               if (!m->start_trim)
                  m->start_trim = delay;
               m->limit = (int64_t)fr;
            }
         }
         m->trim_left = m->start_trim;
         m->emitted   = 0;
         return true;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (!md || !md->data)
            return false;
         if (md->rate)
         {
            md->handle = rmodtracker_open_memory_rate(md->data, md->size,
                  (int)md->rate);
            /* a rate the replayer will not take is not worth failing
             * the load over: mix at the default and let the caller
             * resample, which is what it did before asking */
            if (md->handle)
               return true;
         }
         md->handle = rmodtracker_open_memory(md->data, md->size);
         return md->handle != NULL;
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         if (!w || !w->data)
            return false;
         /* header only: no allocation, and the payload is not read
          * here, so a caller streaming the file needs just the head
          * resident at open */
         if (rwav_parse(&w->wav, w->data, w->size) != RWAV_ITERATE_DONE)
            return false;
         /* rwav admits 8-, 16- and 24-bit integer PCM, 32-bit IEEE
          * float, the two companded eight-bit formats and the two
          * four-bit ADPCM layouts; all of them convert on the way out
          * below, the last four through rwav's own decoder. */
         if (     w->wav.bitspersample != 16
               && w->wav.bitspersample != 8
               && w->wav.bitspersample != 24
               && w->wav.bitspersample != 32
               && w->wav.bitspersample != 4)
            return false;
         /* Meaningless for a block-coded payload, which is not
          * addressable a frame at a time; the decoder is given the
          * frame index instead. */
         w->framesz = (w->wav.bitspersample >= 8)
                    ? (size_t)w->wav.numchannels
                      * (size_t)(w->wav.bitspersample / 8)
                    : 0;
         w->opened  = 1;
         w->cursor  = 0;
         return true;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (!op || (op->requested_track && op->setup))
            return false;
         /* Unbounded unless a container says otherwise.  The two buffer
          * modes below work a bound out and overwrite this; the demuxed
          * path has none, and must not be left holding the zero calloc
          * gave it - a bound of zero reads as a stream with no frames
          * in it, which is what refused every seek on that path. */
         op->limit = -1;
         memset(&op->time, 0, sizeof(op->time));
         op->time.total = -1;
#ifdef HAVE_RWEBM
         /* buffer mode, WebM audio (.weba): demux with rwebm; packets
          * stream from the demuxer on demand.  The exact decodable
          * length comes from the packets' TOC durations less pre-skip
          * and the container's end trimming (DiscardPadding). */
         if (!op->setup && op->buf && op->buf_size >= 4
               && op->buf[0] == 0x1A && op->buf[1] == 0x45
               && op->buf[2] == 0xDF && op->buf[3] == 0xA3)
         {
            const rwebm_track *at = NULL;
            int i;
            if (!(op->demux = audio_transfer_webm_open(op->buf,
                     op->buf_size, op->avail)))
               return false;
            op->track_idx = -1;
            for (i = 0; i < rwebm_num_tracks(op->demux); i++)
            {
               const rwebm_track *t = rwebm_get_track(op->demux, i);
               if ((!op->requested_track || op->requested_track - 1 == (unsigned)i)
                     && t && t->type == RWEBM_TRACK_AUDIO
                     && t->codec == RWEBM_CODEC_OPUS
                     && t->codec_private_size)
               {
                  at            = t;
                  op->track_idx = i;
                  break;
               }
            }
            if (!at)
               return false;
            op->handle = ropus_open(at->codec_private,
                  at->codec_private_size);
            if (!op->handle)
               return false;
            /* Source length is learned incrementally from packet padding. */
            op->emitted   = 0;
            op->toc_total = 0;
            op->time.enabled = 1;
            op->time.rate = 48000;
            op->time.anchor = (int64_t)ropus_preskip(op->handle);
            if (at->codec_delay_ns > ((~(uint64_t)0) >> 1)) return false;
            op->time.delay_ns = (int64_t)at->codec_delay_ns;
            {
               int64_t duration = rwebm_duration_ns(op->demux);
               if (duration > 0 && !audio_transfer_time_frames(duration,
                        48000, &op->time.total)) return false;
            }
            if (op->avail) op->limit = -1;
         }
         else
#endif
         /* buffer mode: a whole Ogg Opus file.  The ID header sits
          * alone on the first page (RFC 7845), the comment header
          * finishes on its own page(s), and audio pages follow; the
          * final page's granule position, less the pre-skip, is the
          * stream's exact decodable length. */
         if (!op->setup && op->buf)
         {
            size_t body = 0, off, total;
            unsigned nsegs = 0;
            int64_t  last_granule = -1;
            total = audio_transfer_ogg_page(op->buf, op->buf_size, 0,
                  &body, &nsegs);
            if (!total || !(op->buf[5] & 0x02))   /* first page: BOS  */
               return false;
            op->handle = ropus_open(op->buf + body, total - (body - 0));
            if (!op->handle)
               return false;
            /* skip the comment header: pages until a lacing value
             * below 255 completes the packet */
            off = total;
            for (;;)
            {
               unsigned i;
               int done = 0;
               size_t psz = audio_transfer_ogg_page(op->buf, op->buf_size,
                     off, &body, &nsegs);
               if (!psz)
                  return false;
               for (i = 0; i < nsegs; i++)
                  if (op->buf[off + 27 + i] < 255)
                     done = 1;
               off += psz;
               if (done)
                  break;
            }
            op->ogg       = 1;
            op->audio_off = off;
            op->pg_off    = off;
            op->seg_idx   = 0;
            op->body_off  = 0;
            /* End granule: normally walk the remaining page headers
             * once to the last granule.  In windowed mode the tail is
             * not resident, so the feeder injected the last-page
             * granule (found from a bounded tail peek) - use it and
             * skip the walk, which would read past the head window. */
            if (op->end_granule >= 0)
               last_granule = op->end_granule;
            else while (off < op->buf_size)
            {
               size_t psz = audio_transfer_ogg_page(op->buf, op->buf_size,
                     off, NULL, NULL);
               uint64_t g;
               unsigned k;
               if (!psz)
                  break;
               g = 0;
               for (k = 0; k < 8; k++)
                  g |= (uint64_t)op->buf[off + 6 + k] << (8 * k);
               if (g != (uint64_t)-1)
                  last_granule = (int64_t)g;
               off += psz;
            }
            op->limit = -1;
            if (last_granule >= 0)
            {
               op->limit = last_granule - (int64_t)ropus_preskip(op->handle);
               if (op->limit < 0)
                  op->limit = 0;
            }
            op->emitted = 0;
         }
         else
         {
            if (!op->setup || (op->num_packets
                  && (!op->packets || !op->pkt_sizes)))
               return false;      /* no input set                        */
            op->handle = ropus_open(op->setup, op->setup_size);
            if (!op->handle)
               return false;
         }
         op->channels     = ropus_channels(op->handle);
         op->seek_to      = -1;
         op->preskip_left = ropus_preskip(op->handle);
         op->pkt_index    = 0;
         op->pkt_offset   = 0;
         op->pend_frames  = 0;
         op->pend_pos     = 0;
         op->fmt          = 0;
         return true;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         if (!a || !a->buf || !audio_transfer_atrac_parse(a))
            return false;
         a->spf = a->plus ? 2048 : 1024;
         if (!audio_transfer_atrac_map(a))
            return false;
#ifdef HAVE_RATRAC3P
         if (a->plus && !(a->d3p = ratrac3p_new(a->dec_channels, a->block_align)))
            return false;
#endif
#ifdef HAVE_RATRAC3
         if (!a->plus && !(a->d3 = ratrac3_new(a->dec_channels, a->block_align, a->joint)))
            return false;
#endif
         a->raw  = (float*)malloc((size_t)a->spf * a->dec_channels * sizeof(float));
         a->pend = (float*)malloc((size_t)a->spf * a->channels * sizeof(float));
         if (!a->raw || !a->pend)
         {
            free(a->raw);
            free(a->pend);
            a->raw = a->pend = NULL;
            return false;
         }
         a->total_frames = (uint64_t)((a->data_end - a->data) / a->block_align) * a->spf;
         a->pos          = a->data;
         a->pend_n       = a->pend_off = 0;
         a->frame_pos    = 0;
         a->ended        = false;
         return true;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         rac3_frame_info_t info;
         if (!a || !a->buf || !a->buf_size)
            return false;
#ifdef HAVE_RMP4
         if (a->buf_size >= 8 && !memcmp(a->buf + 4, "ftyp", 4))
         {
            int i;
            a->demux = rmp4_open_memory_avail(a->buf, a->buf_size,
                  a->avail ? a->avail : a->buf_size, NULL, NULL, NULL);
            if (!a->demux) return false;
            a->track_idx = -1;
            for (i = 0; i < rmp4_num_tracks(a->demux); i++)
            {
               const rmp4_track *t = rmp4_get_track(a->demux, i);
               if (t && t->codec == RMP4_CODEC_AC3
                     && (!a->requested_track || a->requested_track - 1 == (unsigned)i))
               { a->track_idx = i; break; }
            }
            if (a->track_idx < 0) return false;
            {
               static const uint32_t masks[8] = {3, 4, 3, 7, 0x103, 0x107, 0x603, 0x607};
               static const unsigned rates[3] = {48000, 44100, 32000};
               static const unsigned channels[8] = {2, 1, 2, 3, 3, 4, 4, 5};
               const rmp4_track *t = rmp4_get_track(a->demux, a->track_idx);
               const uint8_t *d = t->codec_private;
               unsigned fscod;
               if (!d || t->codec_private_size < 3) return false;
               memset(&info, 0, sizeof(info));
               fscod = d[0] >> 6;
               info.bsid = (d[0] >> 1) & 31;
               if (fscod > 2 || info.bsid > 10) return false;
               info.kind = RAC3_KIND_AC3;
               info.acmod = (d[1] >> 3) & 7;
               info.lfe = ((d[1] >> 2) & 1) != 0;
               info.channels = channels[info.acmod] + (info.lfe ? 1 : 0);
               info.layout = masks[info.acmod] | (info.lfe ? 8 : 0);
               info.sample_rate = rates[fscod] >> (info.bsid > 8 ? info.bsid - 8 : 0);
            }
         }
         else
#endif
         if (rac3_parse_frame_info(a->buf + a->pos,
                  audio_transfer_ac3_end(a) - a->pos, &info) != RAC3_OK)
            return false;
         /* E-AC-3 too, a frame of one to six blocks; a dependent
          * substream is not a programme on its own */
         if (info.kind == RAC3_KIND_EAC3 && info.stream_type != RAC3_STREAM_INDEPENDENT
               && info.stream_type != RAC3_STREAM_AC3_CONVERT)
            return false;
         a->dec_channels = info.channels;
         a->layout       = info.layout;
         a->rate         = info.sample_rate;
         audio_transfer_ac3_map(a);
         a->total_frames = audio_transfer_ac3_count(a);
         a->raw          = (float*)malloc(1536 * a->dec_channels * sizeof(float));
         a->pend         = (float*)malloc(1536 * a->channels * sizeof(float));
         a->dec          = rac3_decoder_new();
         if (!a->raw || !a->pend || !a->dec)
         {
            free(a->raw);
            free(a->pend);
            a->raw  = NULL;
            a->pend = NULL;
            rac3_decoder_free(a->dec);
            a->dec  = NULL;
            return false;
         }
         a->pos = 0;
         a->pend_n = a->pend_off = 0;
         a->frame_pos = 0;
         a->ended = false;
         return true;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         size_t end, block;
         unsigned count;
         if (!l || !l->buf || !l->buf_size)
            return false;
         l->ready = false;
         l->pending_n = l->pending_off = l->skip = 0;
         /* A caller that filled in a shape before starting keeps it -
          * that is the raw case, where nothing in the bytes says what
          * they are. Otherwise the disc headers are tried, Blu-ray's
          * first: its four bytes carry a payload length that has to
          * agree with the buffer, which a DVD header does not, so it
          * is the one that can be told apart. */
         if (l->fmt.bits && l->fmt.channels && l->fmt.sample_rate
               && !l->fmt.header_bytes)
         {
            enum rlpcm_kind kind = l->fmt.kind;
            if (rlpcm_parse_format(RLPCM_KIND_RAW, NULL, 0, &l->fmt) != RLPCM_OK)
               return false;
            if (kind == RLPCM_KIND_DVD)
            {
               l->fmt.kind = kind;
               if (!rlpcm_dvd_block_shape(&l->fmt, &block, &count)) return false;
            }
         }
         else if (l->fmt.kind == RLPCM_KIND_DVD)
         {
            if (rlpcm_parse_format(RLPCM_KIND_DVD, l->buf, l->buf_size,
                     &l->fmt) != RLPCM_OK) return false;
         }
         else if (rlpcm_parse_format(RLPCM_KIND_BLURAY, l->buf, l->buf_size,
                  &l->fmt) == RLPCM_OK
               && l->fmt.payload_bytes
               && l->fmt.payload_bytes + l->fmt.header_bytes <= l->buf_size)
         {
            /* the header named a payload the buffer holds */
         }
         else if (rlpcm_parse_format(RLPCM_KIND_DVD, l->buf, l->buf_size,
                  &l->fmt) != RLPCM_OK)
            return false;

         if (!rlpcm_frame_bits(&l->fmt))
            return false;
         l->pos = l->fmt.header_bytes;
         end    = l->buf_size;
         if (l->fmt.payload_bytes
               && l->fmt.header_bytes + l->fmt.payload_bytes < end)
            end = l->fmt.header_bytes + l->fmt.payload_bytes;
         if (end < l->fmt.header_bytes) return false;
         if (l->fmt.kind == RLPCM_KIND_DVD)
         {
            if (!rlpcm_dvd_block_shape(&l->fmt, &block, &count)) return false;
            l->total_frames = ((end - l->fmt.header_bytes) / block) * count;
         }
         else
            l->total_frames = (size_t)(((uint64_t)(end - l->fmt.header_bytes) * 8)
                  / rlpcm_frame_bits(&l->fmt));
         l->ready        = true;
         return true;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         raac_adts_t                adts;
         if (!ac || (ac->requested_track && ac->setup))
            return false;
         ac->limit = -1;   /* unbounded unless a container says otherwise */
         memset(&ac->time, 0, sizeof(ac->time));
         ac->time.total = -1;
         /* buffer mode, ADTS stream: the header carries the setup,
          * so synthesise the AudioSpecificConfig from it (LC only,
          * matching the decoder's scope) and walk frames in place */
         if (!ac->setup && ac->buf
               && raac_adts_parse(ac->buf, ac->buf_size, &adts) == 0)
         {
            unsigned chcfg = (adts.asc[1] >> 3) & 15;
            if (ac->requested_track)
               return false;
            if ((adts.asc[0] >> 3) != 2 || chcfg < 1 || chcfg > 2)
               return false;
            ac->handle = raac_open(adts.asc, sizeof(adts.asc));
            if (!ac->handle)
               return false;
            ac->adts       = 1;
            ac->adts_pos   = 0;
            ac->start_trim = 0;   /* ADTS carries no delay signalling  */
         }
         else
#ifdef HAVE_RWEBM
         /* buffer mode, Matroska (.mka/.mkv) carrying A_AAC.  Same
          * shape as the MP4 path below: the AudioSpecificConfig is the
          * track's CodecPrivate and the access units are its blocks.
          * The encoder delay comes from CodecDelay rather than an edit
          * list, and the length from the container's Duration, which
          * is net of that delay. */
         if (!ac->setup && ac->buf && ac->buf_size >= 4
               && ac->buf[0] == 0x1A && ac->buf[1] == 0x45
               && ac->buf[2] == 0xDF && ac->buf[3] == 0xA3)
         {
            const rwebm_track *at = NULL;
            int      i;
            int64_t  dur;
            if (!(ac->wdemux = audio_transfer_webm_open(ac->buf,
                        ac->buf_size, ac->avail)))
               return false;
            ac->wtrack_idx = -1;
            for (i = 0; i < rwebm_num_tracks(ac->wdemux); i++)
            {
               const rwebm_track *t = rwebm_get_track(ac->wdemux, i);
               if ((!ac->requested_track || ac->requested_track - 1 == (unsigned)i)
                     && t && t->type == RWEBM_TRACK_AUDIO
                     && t->codec == RWEBM_CODEC_AAC
                     && t->codec_private_size)
               {
                  at             = t;
                  ac->wtrack_idx = i;
                  break;
               }
            }
            if (!at)
               return false;
            ac->handle = raac_open(at->codec_private,
                  at->codec_private_size);
            if (!ac->handle)
               return false;
            dur = rwebm_duration_ns(ac->wdemux);
            ac->time.enabled = 1;
            ac->time.rate = raac_sample_rate(ac->handle);
            if (at->codec_delay_ns > ((~(uint64_t)0) >> 1)) return false;
            ac->time.delay_ns = (int64_t)at->codec_delay_ns;
            /* CodecDelay shifts Matroska frame timestamps. AAC has no
             * Opus-style mandatory pre-skip: crop negative presentation
             * samples through the mapper, without deleting a positive
             * track's priming packet a second time. */
            ac->start_trim = 0;
            ac->time.anchor = 0;
            if (dur > 0 && !audio_transfer_time_frames(dur,
                     ac->time.rate, &ac->time.total)) return false;
            /* WebM tail padding belongs to its final packet; movie
             * duration is a presentation bound, not a source count. */
            ac->limit = -1;
         }
         else
#endif
#ifdef HAVE_RMP4
         /* buffer mode: a whole MP4/M4A; demux it here */
         if (!ac->setup && ac->buf)
         {
            const rmp4_track *at = NULL;
            int i;
            /* Bounded open: a windowed caller has only a prefix
             * resident, and the unbounded open walks the box tree to
             * the end of the file - which for a leading-moov movie is
             * a reserved-page read past the head.  avail == 0 is the
             * whole-file caller and behaves exactly as before. */
            if (!(ac->demux = rmp4_open_memory_avail(ac->buf,
                        ac->buf_size,
                        (ac->avail && ac->avail < ac->buf_size)
                           ? ac->avail : ac->buf_size,
                        NULL, NULL, NULL)))
               return false;
            ac->track_idx = -1;
            for (i = 0; i < rmp4_num_tracks(ac->demux); i++)
            {
               const rmp4_track *t = rmp4_get_track(ac->demux, i);
               if ((!ac->requested_track || ac->requested_track - 1 == (unsigned)i)
                     && t && t->type == RMP4_TRACK_AUDIO
                     && t->codec == RMP4_CODEC_AAC
                     && t->codec_private_size)
               {
                  at            = t;
                  ac->track_idx = i;
                  break;
               }
            }
            if (!at)
               return false;
            ac->handle = raac_open(at->codec_private,
                  at->codec_private_size);
            if (!ac->handle)
               return false;
            {
               int64_t ns = rmp4_duration_ns(ac->demux);
               unsigned sr = raac_sample_rate(ac->handle);
               /* the track's edit list carries the encoder delay in
                * media-timescale units, i.e. core-rate samples; the
                * trim is consumed in output frames, which double under
                * SBR, so convert by the rate ratio */
               ac->start_trim = at->media_skip;
               if (at->sample_rate && sr && sr != at->sample_rate)
               {
                  if (at->media_skip > ((~(uint64_t)0)
                           - at->sample_rate / 2) / sr) return false;
                  ac->start_trim = (at->media_skip * sr
                        + at->sample_rate / 2) / at->sample_rate;
               }
               if (ac->start_trim > ((~(uint64_t)0) >> 1)) return false;
               ac->time.enabled = 1;
               ac->time.rate = sr;
               if (!audio_transfer_time_frames(at->presentation_delay_ns,
                        sr, &ac->time.anchor) || ac->time.anchor < 0)
                  return false;
               if (ns > 0 && !audio_transfer_time_frames(ns, sr,
                        &ac->time.total)) return false;
               ac->limit = -1;
               if (at->presentation_duration_ns >= 0
                     && !audio_transfer_time_frames(at->presentation_duration_ns,
                        sr, &ac->limit)) return false;
            }
         }
         else
#endif
         {
            if (!ac->setup || (ac->num_packets
                  && (!ac->packets || !ac->pkt_sizes)))
               return false;      /* no input set                        */
            ac->handle = raac_open(ac->setup, ac->setup_size);
            if (!ac->handle)
               return false;
         }
         ac->channels    = raac_channels(ac->handle);
         /* the WAVE order every arm but Vorbis and Opus hands over, and
          * audio_transfer_fold_q15 folds by; a layout raac has no WAVE
          * map for stays in stream order */
         raac_set_channel_order(ac->handle, RAAC_ORDER_WAVE);
         ac->trim_left   = ac->start_trim;
         ac->emitted     = 0;
         ac->pkt_index   = 0;
         ac->pkt_offset  = 0;
         ac->pend_frames = 0;
         ac->pend_pos    = 0;
         return true;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   return false;
}

bool audio_transfer_is_valid(void *data, enum audio_type_enum type)
{
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         return data && ((struct audio_transfer_wma*)data)->stream;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         return (fl && fl->handle);
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         return (v && v->handle);
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         return (m && m->stream);
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         return (md && md->handle);
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         return w && w->opened;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         return op && op->handle;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         return a && a->raw;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         return a && a->dec;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         return l && l->ready;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         return ac && ac->handle;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   return false;
}

/* ---- folding to stereo ----------------------------------------------
 *
 * The arms do no channel conversion: wider than stereo comes out as the
 * codec orders it, and the consumer folds. Vorbis and Opus (mapping
 * family 1) order the channels one way (Vorbis I 4.3.9), everything
 * else - WAV, FLAC, AAC (put into this order at start), AC-3 (shaped
 * into it), MP3 - the WAVEFORMATEXTENSIBLE way:
 *
 *   Vorbis  3 L C R        4 L R RL RR      5 L C R RL RR
 *           6 L C R RL RR LFE              7 L C R RL RR BC LFE
 *           8 L C R RL RR SL SR LFE
 *   WAV     3 FL FR FC     4 FL FR BL BR    5 FL FR FC BL BR
 *           6 FL FR FC LFE BL BR           7 FL FR FC LFE BC SL SR
 *           8 FL FR FC LFE BL BR SL SR
 *
 * Folding one with the other's table is not a subtle error: on 5.1 it
 * sends front-right to both sides, front-centre to the right alone,
 * LFE into the mix and back-right nowhere.
 *
 * Coefficients are the usual ITU-R BS.775 ones: centre and surrounds
 * enter both sides at -3 dB, a lone back centre at -6 dB into each, LFE
 * is dropped. Not normalised: scaling by the coefficient sum would put
 * 5.1 content 7.7 dB below the same material in a stereo file, which is
 * a surprising thing for a file's channel count to do to its volume;
 * the sum only reaches full scale when the channels are correlated.
 * Q15 in int32: unity is 32768, which an int16 would wrap. */
#define AT_FOLD_UNITY 32768
#define AT_FOLD_M3DB  23170
#define AT_FOLD_M6DB  16384

static const int32_t audio_transfer_fold_vorbis[9][8][2] = {
   { {0,0} },
   { {AT_FOLD_UNITY,AT_FOLD_UNITY} },
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY} },
   /* 3: L C R */
   { {AT_FOLD_UNITY,0}, {AT_FOLD_M3DB,AT_FOLD_M3DB}, {0,AT_FOLD_UNITY} },
   /* 4: L R RL RR */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB} },
   /* 5: L C R RL RR */
   { {AT_FOLD_UNITY,0}, {AT_FOLD_M3DB,AT_FOLD_M3DB}, {0,AT_FOLD_UNITY},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB} },
   /* 6: L C R RL RR LFE */
   { {AT_FOLD_UNITY,0}, {AT_FOLD_M3DB,AT_FOLD_M3DB}, {0,AT_FOLD_UNITY},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB}, {0,0} },
   /* 7: L C R RL RR BC LFE */
   { {AT_FOLD_UNITY,0}, {AT_FOLD_M3DB,AT_FOLD_M3DB}, {0,AT_FOLD_UNITY},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB},
     {AT_FOLD_M6DB,AT_FOLD_M6DB}, {0,0} },
   /* 8: L C R RL RR SL SR LFE */
   { {AT_FOLD_UNITY,0}, {AT_FOLD_M3DB,AT_FOLD_M3DB}, {0,AT_FOLD_UNITY},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB}, {0,0} }
};

static const int32_t audio_transfer_fold_wav[9][8][2] = {
   { {0,0} },
   { {AT_FOLD_UNITY,AT_FOLD_UNITY} },
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY} },
   /* 3: FL FR FC */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY}, {AT_FOLD_M3DB,AT_FOLD_M3DB} },
   /* 4: FL FR BL BR */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB} },
   /* 5: FL FR FC BL BR */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY}, {AT_FOLD_M3DB,AT_FOLD_M3DB},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB} },
   /* 6: FL FR FC LFE BL BR */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY}, {AT_FOLD_M3DB,AT_FOLD_M3DB},
     {0,0}, {AT_FOLD_M3DB,0}, {0,AT_FOLD_M3DB} },
   /* 7: FL FR FC LFE BC SL SR */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY}, {AT_FOLD_M3DB,AT_FOLD_M3DB},
     {0,0}, {AT_FOLD_M6DB,AT_FOLD_M6DB},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB} },
   /* 8: FL FR FC LFE BL BR SL SR */
   { {AT_FOLD_UNITY,0}, {0,AT_FOLD_UNITY}, {AT_FOLD_M3DB,AT_FOLD_M3DB},
     {0,0}, {AT_FOLD_M3DB,0}, {0,AT_FOLD_M3DB},
     {AT_FOLD_M3DB,0},  {0,AT_FOLD_M3DB} }
};

const int32_t (*audio_transfer_fold_q15(enum audio_type_enum type,
      unsigned channels))[2]
{
   if (channels < 1 || channels > 8)
      return NULL;
   if (type == AUDIO_TYPE_VORBIS || type == AUDIO_TYPE_OPUS)
      return audio_transfer_fold_vorbis[channels];
   return audio_transfer_fold_wav[channels];
}

bool audio_transfer_stereo_matrix(void *data, enum audio_type_enum type,
      int32_t matrix[8][2])
{
   const int32_t (*fold)[2];
   unsigned ch = 0;
   if (!data || !matrix)
      return false;
#ifdef HAVE_RWMA
   /* by the stream's speaker mask */
   if (type == AUDIO_TYPE_WMA)
   {
      static const uint32_t defaults[9] = {0,4,3,7,51,55,63,1807,1599};
      struct audio_transfer_wma *a = (struct audio_transfer_wma*)data;
      uint32_t mask;
      unsigned lane = 0, bit;
      if (!a->stream || !a->channels || a->channels > 8)
         return false;
      mask = rwma_stream_channel_mask(a->stream);
      if (!mask) mask = defaults[a->channels];
      if ((a->channels <= 2 && mask != defaults[a->channels]) || (mask & ~0x7ffu))
         return false;
      memset(matrix, 0, 8 * 2 * sizeof(int32_t));
      for (bit = 0; bit < 11; bit++)
         if (mask & (1u << bit))
         {
            int left = 0, right = 0;
            if (lane >= a->channels) return false;
            switch (bit)
            {
               case 0: left = 32768; break;
               case 1: right = 32768; break;
               case 2: left = right = 23170; break;
               case 3: break;
               case 4: case 6: case 9: left = 23170; break;
               case 5: case 7: case 10: right = 23170; break;
               case 8: left = right = 16384; break;
            }
            matrix[lane][0] = left;
            matrix[lane++][1] = right;
         }
      return lane == a->channels;
   }
#endif
   /* by the channel count, in the order the arm hands them over */
   if (     !audio_transfer_info(data, type, &ch, NULL, NULL)
         || !(fold = audio_transfer_fold_q15(type, ch)))
      return false;
   memset(matrix, 0, 8 * 2 * sizeof(int32_t));
   memcpy(matrix, fold, ch * 2 * sizeof(int32_t));
   return true;
}

bool audio_transfer_stereo_matrix_f32(void *data, enum audio_type_enum type,
      float matrix[8][2])
{
   int32_t fixed[8][2];
   unsigned i, c;
   if (!matrix || !audio_transfer_stereo_matrix(data,type,fixed)) return false;
   for (i=0;i<8;i++) for(c=0;c<2;c++)
      matrix[i][c] = fixed[i][c] == 23170 ? 0.7071067811865475244f
            : fixed[i][c] / 32768.0f;
   return true;
}

bool audio_transfer_info(void *data, enum audio_type_enum type,
      unsigned *channels, unsigned *rate, uint64_t *total_frames)
{
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
      {
         struct audio_transfer_wma *a = (struct audio_transfer_wma*)data;
         if (!a || !a->stream) return false;
         if (channels) *channels = a->channels;
         if (rate) *rate = a->rate;
         /* what the container states: the decode runs on past it by
          * the codec's priming */
         if (total_frames) *total_frames = rwma_stream_frames(a->stream);
         return true;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl || !fl->handle)
            return false;
         {
            const rflac_format_t *ff = rflac_format(fl->handle);
            if (!ff)
            {
               /* The header has not been seen yet.  Hand over the
                * setup bytes and let the decoder read it, which costs
                * one span and no audio. */
               if (audio_transfer_flac_feed(fl) <= 0)
                  return false;
               rflac_process(fl->handle, NULL, NULL);
               if (!(ff = rflac_format(fl->handle)))
                  return false;
            }
            if (fl->time.enabled && !fl->time.rate)
            {
               fl->time.rate = ff->sample_rate;
#ifdef HAVE_RWEBM
               if (fl->duration_ns > 0 && !audio_transfer_time_frames(
                        fl->duration_ns, fl->time.rate, &fl->time.total))
                  return false;
#endif
            }
            if (channels)
               *channels     = (unsigned)ff->channels;
            if (rate)
               *rate         = (unsigned)ff->sample_rate;
            if (total_frames)
               *total_frames = fl->time.enabled
                  ? (fl->time.total >= 0 ? (uint64_t)fl->time.total : 0)
                  : rflac_total_frames(fl->handle);
         }
         return true;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         rvorbis_info info;
         if (!v || !v->handle)
            return false;
         info = rvorbis_get_info(v->handle);
         if (channels)
            *channels     = (unsigned)info.channels;
         if (rate)
            *rate         = (unsigned)info.sample_rate;
         if (total_frames)
         {
            if (v->time.enabled)
            {
               *total_frames = v->time.total >= 0 ? (uint64_t)v->time.total : 0;
               return true;
            }
            /* stream_length_in_samples walks the Ogg pages to the last
             * granule, which a packet-fed context has none of: its
             * length is whatever bound the container stated, and 0
             * where it stated none. */
            /* Whatever bound was established, on either path: the
             * container's for a packet-fed context, the summed Ogg
             * granules for a buffer.  Only where nothing stated one
             * does this fall back to asking rvorbis, which walks to
             * the last granule of the first link and so answers for
             * a chained file with its first link alone. */
            if (v->limit >= 0)
               *total_frames = (uint64_t)v->limit;
            else if (v->packet)
               *total_frames = 0;
            else
               *total_frames =
                  (uint64_t)rvorbis_stream_length_in_samples(v->handle);
         }
         return true;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (!m || !m->stream)
            return false;
         if (channels)
            *channels     = m->channels;
         if (rate)
            *rate         = m->rate;
         /* From the Xing/Info or VBRI count, less the gapless trim
          * where a LAME tag states one; 0 for a file carrying no
          * such header, which cannot be measured without a walk. */
         if (total_frames)
            *total_frames = (m->limit >= 0) ? (uint64_t)m->limit : 0;
         return true;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (!md || !md->handle)
            return false;
         if (channels)  /* the replayer always mixes interleaved stereo */
            *channels     = 2;
         if (rate)
            *rate         = (unsigned)rmodtracker_sample_rate(md->handle);
         if (total_frames) /* one pass through the sequence */
            *total_frames = (uint64_t)rmodtracker_duration_frames(md->handle);
         return true;
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         if (!w || !w->opened)
            return false;
         if (channels)
            *channels     = w->wav.numchannels;
         if (rate)
            *rate         = w->wav.samplerate;
         if (total_frames) /* WAV is fully decoded, so length is known */
            *total_frames = (uint64_t)w->wav.numsamples;
         return true;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         int bounded;
         if (!op || !op->handle)
            return false;
         if (channels)
            *channels = op->channels;
         if (rate)
            *rate = 48000;
         bounded = op->ogg;
#ifdef HAVE_RWEBM
         if (op->demux)
            bounded = 1;
#endif
         /* WebM reports its declared movie period, including silence.
          * Ogg reports its source granule bound. Zero means unknown;
          * caller-demuxed packets may still be growing. */
         if (total_frames)
            *total_frames = op->time.enabled
               ? (op->time.total >= 0 ? (uint64_t)op->time.total : 0)
               : (bounded && op->limit >= 0 ? (uint64_t)op->limit : 0);
         return true;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         if (!a || !a->raw)
            return false;
         if (channels)     *channels     = a->channels;
         if (rate)         *rate         = a->rate;
         if (total_frames) *total_frames = a->total_frames;
         return true;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         if (!a || !a->dec)
            return false;
         if (channels)     *channels     = a->channels;
         if (rate)         *rate         = a->rate;
         if (total_frames) *total_frames = a->total_frames;
         return true;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         if (!l || !l->ready)
            return false;
         if (channels)     *channels     = l->fmt.channels;
         if (rate)         *rate         = l->fmt.sample_rate;
         if (total_frames) *total_frames = l->total_frames;
         return true;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         unsigned srate;
         if (!ac || !ac->handle)
            return false;
         srate = raac_sample_rate(ac->handle);
         if (channels)
            *channels = ac->channels;
         if (rate)
            *rate = srate;
         if (total_frames)
         {
            /* Containers report the movie period, separate from the
             * edit's source play length. ADTS and caller-demuxed input
             * do not acquire a length through a whole-file scan. */
            *total_frames = ac->time.enabled
               ? (ac->time.total >= 0 ? (uint64_t)ac->time.total : 0)
               : (ac->limit >= 0 ? (uint64_t)ac->limit : 0);
         }
         return true;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   return false;
}

#ifdef HAVE_ROPUS
/* Room for the reassembly buffer, allocated on the first packet that
 * needs it and never grown after: AUDIO_OPUS_MAX_PACKET is the whole
 * of what one can be, so a request past it is a malformed stream and
 * not a reason to reallocate - which is what the fixed array this
 * replaces already enforced. */
static int audio_transfer_opus_asm(struct audio_transfer_opus *op,
      size_t need)
{
   if (need > AUDIO_OPUS_MAX_PACKET)
      return 0;
   if (!op->asm_buf)
   {
      if (!(op->asm_buf = (uint8_t*)malloc(AUDIO_OPUS_MAX_PACKET)))
         return 0;
      op->asm_cap = AUDIO_OPUS_MAX_PACKET;
   }
   return 1;
}

/* Assemble the next Opus packet from the Ogg pages.  Returns 1 with
 * the packet bytes (aliasing the buffer unless it spans pages, in
 * which case it is copied into asm_buf), 0 at end of stream, < 0 on a
 * malformed stream. */
static int audio_transfer_opus_next_pkt(struct audio_transfer_opus *op,
      const uint8_t **pdata, uint32_t *plen)
{
   size_t asm_len = 0;
   int    spans   = 0;
   for (;;)
   {
      size_t body = 0;
      unsigned nsegs = 0;
      size_t psz = audio_transfer_ogg_page(op->buf, op->buf_size,
            op->pg_off, &body, &nsegs);
      size_t start;
      size_t run = 0;
      int    done = 0;
      if (!psz)
         return asm_len ? -1 : 0;   /* out of pages                   */
      if (op->seg_idx == 0)
         op->body_off = body;
      if (asm_len && op->seg_idx == 0 && !(op->buf[op->pg_off + 5] & 0x01))
         return -1;                 /* continuation page not flagged  */
      start = op->body_off;
      while (op->seg_idx < nsegs)
      {
         unsigned lace = op->buf[op->pg_off + 27 + op->seg_idx];
         run += lace;
         op->seg_idx++;
         if (lace < 255)
         {
            done = 1;
            break;
         }
      }
      op->body_off = start + run;
      if (op->seg_idx >= nsegs && !done)
      {
         /* packet continues on the next page: stash what we have */
         if (run)
         {
            if (!audio_transfer_opus_asm(op, asm_len + run))
               return -1;
            memcpy(op->asm_buf + asm_len, op->buf + start, run);
            asm_len += run;
         }
         spans       = 1;
         op->pg_off += psz;
         op->seg_idx = 0;
         continue;
      }
      if (op->seg_idx >= nsegs)
      {
         op->pg_off += psz;
         op->seg_idx = 0;
      }
      if (!spans)
      {
         *pdata = op->buf + start;
         *plen  = (uint32_t)run;
      }
      else
      {
         if (!audio_transfer_opus_asm(op, asm_len + run))
            return -1;
         memcpy(op->asm_buf + asm_len, op->buf + start, run);
         asm_len += run;
         *pdata  = op->asm_buf;
         *plen   = (uint32_t)asm_len;
      }
      return 1;
   }
}

/* Decode the next Opus packet into the pending buffer in the requested
 * format (1 = s16, 2 = f32), honouring pre-skip.  Returns frames now
 * pending, 0 at end of stream, < 0 on error. */
/* The next coded packet, wherever this context's packets come from.
 * Returns 1 with the bytes, 0 at end of stream, < 0 on a malformed
 * stream. */
static int audio_transfer_opus_pull(struct audio_transfer_opus *op,
      const uint8_t **pdata, uint32_t *plen, int64_t *ppad)
{
   *ppad = 0;
#ifdef HAVE_RWEBM
   if (op->demux)
   {
      /* .weba: pull the next packet from the demuxer */
      rwebm_packet pkt;
      unsigned walked = 0;
      for (;;)
      {
         int r;
         if ((op->seek_pending || op->time.enabled) && walked++ == 256) return -3;
         r = rwebm_read_packet_track(op->demux, op->track_idx, &pkt);
         if (r == RWEBM_READ_YIELD) return -3;
         /* Resident wall, not end of stream: see the Vorbis pull. */
         if (r == RWEBM_READ_AGAIN)
         {
            op->wall = 1;
            return -2;
         }
         if (r != 1)
            return 0;
         if (pkt.track == op->track_idx)
         {
            op->wall = 0;
            /* Handed back with the packet rather than left in the
             * context: see the Vorbis pull. */
            if (pkt.discard_padding > 0
                  && !audio_transfer_time_frames(pkt.discard_padding,
                     48000, ppad)) return -1;
            if (!audio_transfer_time_packet(&op->time, pkt.timestamp,
                     pkt.timestamp_continuation)) return -1;
            break;
         }
      }
      *pdata = pkt.data;
      *plen  = (uint32_t)pkt.size;
      return 1;
   }
#endif
   if (op->ogg)
      return audio_transfer_opus_next_pkt(op, pdata, plen);
   if (op->pkt_index >= op->num_packets)
      return 0;
   *plen = op->pkt_sizes[op->pkt_index];
   if (op->pkt_offset + *plen > op->packets_size)
      return -1;
   *pdata = op->packets + op->pkt_offset;
   op->pkt_offset += *plen;
   op->pkt_index++;
   return 1;
}

static int audio_transfer_opus_fill(struct audio_transfer_opus *op, int fmt);

/* Frames decoded before the target and thrown away, so the decoder has
 * converged by the time the caller sees anything.  RFC 7845 s4.2 asks
 * for 80 ms of that; the rest is headroom for the walk below, which
 * stops on a packet boundary and so can overshoot where it meant to
 * stop by as much as one packet - 120 ms, the longest Opus codes.
 * Together they guarantee the walk lands before the target with at
 * least the 80 ms still to decode. */
#define AUDIO_OPUS_PREROLL (3840 + 5760)

/* Rewind and walk forward to 'frame'.  The walk itself decodes nothing:
 * a packet's duration is in its TOC byte, so the packets before the
 * target can be stepped over by reading one byte of each.  Only the
 * pre-roll is decoded, and thrown away.  Returns the frame reached,
 * or < 0 if the stream ends first. */
static void audio_transfer_opus_to_head(struct audio_transfer_opus *op)
{
   op->time.first_ready = op->time.ready = op->time.eof = 0;
   op->time.end = op->time.pending = op->time.position = 0;
   op->yielded = 0;
   ropus_reset(op->handle);
#ifdef HAVE_RWEBM
   if (op->demux)
   {
      rwebm_rewind(op->demux);
      if (op->avail) { op->avail = 1; rwebm_set_avail(op->demux, 1); }
   }
#endif
   op->pkt_index    = 0;
   op->pkt_offset   = 0;
   op->pg_off       = op->audio_off;
   op->seg_idx      = 0;
   op->body_off     = 0;
   op->emitted      = 0;
   op->pend_frames  = 0;
   op->pend_pos     = 0;
   op->toc_total    = 0;
   op->preskip_left = ropus_preskip(op->handle);
}

static int64_t audio_transfer_opus_seek_to(struct audio_transfer_opus *op,
      int64_t frame, int fmt)
{
   int64_t  pos  = 0;      /* frames emitted, i.e. after the pre-skip  */
   unsigned skip;
   int64_t  stop = frame - AUDIO_OPUS_PREROLL;

   audio_transfer_opus_to_head(op);
   skip = ropus_preskip(op->handle);
   if (stop < 0)
      stop = 0;
   while (pos < stop)
   {
      const uint8_t *pdata;
      uint32_t plen;
      int64_t d;
      int64_t pad = 0;
      int r = audio_transfer_opus_pull(op, &pdata, &plen, &pad);
      if (r < 0)
         return -1;
      if (r == 0)
         return -1;        /* asked past the end of the stream         */
      d = audio_transfer_opus_pkt_frames(pdata, plen);
      if (d <= 0)
         return -1;
      /* End trimming uses the raw duration of the entire stream,
       * including packets skipped without decoding during preroll. */
      op->toc_total += d;
      /* the head of the stream is pre-skip, which is discarded rather
       * than emitted, so it does not count towards the position */
      if (skip)
      {
         unsigned taken = (d < (int64_t)skip) ? (unsigned)d : skip;
         skip -= taken;
         d    -= (int64_t)taken;
      }
      /* The packet has been consumed, so it counts whether or not it
       * takes the walk past where it meant to stop; the pre-roll is
       * sized so that overshooting by one packet still leaves the
       * target ahead. */
      pos += d;
   }
   /* Whatever pre-skip is left belongs to the frames the decode below
    * is about to produce. */
   op->preskip_left = skip;
   op->emitted      = pos;
   op->pend_frames  = 0;
   op->pend_pos     = 0;
   /* Decode from here, discarding, so the decoder is converged and the
    * position is exact rather than packet-aligned. */
   while (pos < frame)
   {
      int64_t take;
      int r = audio_transfer_opus_fill(op, fmt);
      if (r < 0)
         return -1;
      if (r == 0)
         return -1;
      take = frame - pos;
      if (take > (int64_t)op->pend_frames)
         take = (int64_t)op->pend_frames;
      op->pend_pos    += (size_t)take;
      op->pend_frames -= (size_t)take;
      pos             += take;
   }
   return pos;
}

/* Next packet's frames, made pending in op->pend - or, given a dst
 * with room for the whole packet, decoded straight into it and
 * reported in *direct instead (pending stays empty).  Only a packet
 * whose frames all go out as decoded is taken that way: none of the
 * pre-skip left to drop off its front, and no movie timeline to map
 * it through.  The end bound still applies, by count alone. */
static int audio_transfer_opus_fill_into(struct audio_transfer_opus *op,
      int fmt, void *dst, size_t room, size_t *direct)
{
   unsigned decoded = 0;
   int      into    = 0;
   size_t elem = (fmt == 1) ? sizeof(int16_t) : sizeof(float);

   /* The decoder writes ROPUS_MAX_FRAME * channels samples into
    * this and is given no bound, so the buffer is made to fit before
    * the first packet of a format goes through it.  A format change
    * can only follow a rewind, which leaves nothing pending. */
   if (!op->pend || op->pend_elem != elem)
   {
      if (!op->channels)
         return -1;
      free(op->pend);
      op->pend_elem    = 0;
      op->pend_samples = 0;
      if (!(op->pend = calloc((size_t)ROPUS_MAX_FRAME
                  * (size_t)op->channels, elem)))
         return -1;
      op->pend_elem    = elem;
      op->pend_samples = (size_t)ROPUS_MAX_FRAME * (size_t)op->channels;
      op->pend_frames = 0;
      op->pend_pos    = 0;
   }

   while (op->pend_frames == 0)
   {
      const uint8_t *pdata;
      uint32_t plen;
      int64_t  pad = 0;
      int r;
      unsigned skip;
      if (op->time.enabled && op->time.eof) return 0;
      if ((op->seek_pending && decoded) || (op->time.enabled && decoded >= 16))
      { op->yielded = 1; return -3; }
      decoded++;
      r = audio_transfer_opus_pull(op, &pdata, &plen, &pad);
      /* The resident wall is not the end of the stream and not an
       * error: report no frames for now, so the read comes up short
       * and the next call resumes once the feeder has caught up.
       * (The pull raised op->wall; read_* turns the resulting empty
       * read into AUDIO_PROCESS_NEXT rather than END.) */
      if (r == -2)
         return 0;
      if (r <= 0)
      {
         if (!r && op->time.enabled) { op->time.eof = 1; op->wall = 0; }
         return r;
      }
      into = dst && !op->preskip_left && !op->time.enabled
            && audio_transfer_opus_pkt_frames(pdata, plen) <= (int64_t)room;
      r    = ROPUS_ERR_ROOM;
      if (into)
      {
         if (fmt == 1)
            r = ropus_decode_s16(op->handle, pdata, plen,
                  (int16_t*)dst, room * op->channels);
         else
            r = ropus_decode_f32(op->handle, pdata, plen,
                  (float*)dst, room * op->channels);
      }
      /* Refused for room before anything was decoded: the TOC
       * undercounted a malformed packet, which pending can still take
       * and the decoder then judges as it always has. */
      if (r == ROPUS_ERR_ROOM)
      {
         into = 0;
         if (fmt == 1)
            r = ropus_decode_s16(op->handle, pdata, plen,
                  (int16_t*)op->pend, op->pend_samples);
         else
            r = ropus_decode_f32(op->handle, pdata, plen,
                  (float*)op->pend, op->pend_samples);
      }
      if (r < 0)
         return -1;
      op->pend_frames = (size_t)r;
      op->pend_pos    = 0;
      if (!audio_transfer_time_add(op->toc_total, r, &op->toc_total)) return -1;
      /* That block carried the container's end trimming, so the
       * stream's true length is known now: everything its packets
       * decode to, less the pre-skip dropped at the front and the
       * padding dropped at the back.  A pre-walk at open works this
       * out in advance and arrives at the same number; where one
       * could not run, this is where it comes from. */
      if (pad > 0)
      {
         int64_t exact = op->toc_total
                       - (int64_t)ropus_preskip(op->handle)
                       - pad;
         if (exact < 0)
            exact = 0;
         if (op->limit < 0 || exact < op->limit)
            op->limit = exact;
      }
      skip = op->preskip_left;
      if (skip)
      {
         if (skip >= op->pend_frames)
         {
            op->preskip_left -= (unsigned)op->pend_frames;
            op->pend_frames = 0;   /* whole packet skipped; loop        */
         }
         else
         {
            op->pend_pos      = skip;
            op->pend_frames  -= skip;
            op->preskip_left  = 0;
         }
      }
      /* Buffer modes: the end granule (Ogg) or the TOC total less end
       * trimming (WebM) bounds emission; frames now pending will all
       * be consumed, so credit them here.
       *
       * Counted whether or not a bound is known yet, which matters
       * because one need not be known at open.  A windowed WebM that
       * states no Duration has none until the block carrying the
       * padding arrives and says where the end is - and a count that
       * had not been running until then would be compared against
       * zero, letting the whole stream through untrimmed. */
      if (op->ogg
#ifdef HAVE_RWEBM
            || op->demux
#endif
         )
      {
         if (op->limit >= 0 && op->pend_frames)
         {
            int64_t left = op->limit - op->emitted;
            if (left <= 0)
            {
               op->pend_frames = 0;
               if (op->time.enabled) op->time.eof = 1;
               return 0;
            }
            if ((int64_t)op->pend_frames > left)
               op->pend_frames = (size_t)left;
         }
         op->emitted += (int64_t)op->pend_frames;
      }
      if (!audio_transfer_time_map(&op->time, op->pend_pos,
               op->pend_frames)) return -1;
   }
   op->fmt = fmt;
   if (into)
   {
      *direct         = op->pend_frames;
      op->pend_frames = 0;
      return (int)*direct;
   }
   return (int)op->pend_frames;
}

static int audio_transfer_opus_fill(struct audio_transfer_opus *op, int fmt)
{
   return audio_transfer_opus_fill_into(op, fmt, NULL, 0, NULL);
}

static int audio_transfer_opus_movie_read(struct audio_transfer_opus *op,
      void *out, size_t frames, size_t *got, int fmt)
{
   size_t produced = 0;
   size_t elem = fmt == 1 ? sizeof(int16_t) : sizeof(float);
   unsigned walked = 0;
   if (got) *got = 0;
   if (op->seek_to >= 0)
   {
      uint64_t target = (uint64_t)op->seek_to;
      op->seek_to = -1;
      if (!audio_transfer_seek_begin_format(op, AUDIO_TYPE_OPUS, target, fmt == 1))
         return AUDIO_PROCESS_ERROR;
   }
   if (op->seek_pending)
   {
      int r = audio_transfer_seek_step(op, AUDIO_TYPE_OPUS);
      if (r < 0) return AUDIO_PROCESS_ERROR;
      if (!r) return AUDIO_PROCESS_NEXT;
   }
   op->yielded = 0;
   while (produced < frames)
   {
      size_t take, skip;
      int r;
      if (++walked > 32) { op->yielded = 1; break; }
      if (op->time.total >= 0 && op->time.position >= op->time.total) break;
      r = audio_transfer_opus_fill(op, fmt);
      if (r == -3) { op->yielded = 1; break; }
      if (r < 0) return AUDIO_PROCESS_ERROR;
      if (!r && op->wall) break;
      take = audio_transfer_time_silence(&op->time, frames - produced, !r);
      if (take)
      {
         memset((uint8_t*)out + produced * op->channels * elem, 0,
               take * op->channels * elem);
         produced += take;
         continue;
      }
      if (!r) break;
      skip = audio_transfer_time_overlap(&op->time, op->pend_frames);
      op->pend_pos += skip;
      op->pend_frames -= skip;
      take = frames - produced;
      if (take > op->pend_frames) take = op->pend_frames;
      if (op->time.total >= 0 && (uint64_t)(op->time.total - op->time.position) < take)
         take = (size_t)(op->time.total - op->time.position);
      memcpy((uint8_t*)out + produced * op->channels * elem,
            (const uint8_t*)op->pend + op->pend_pos * op->channels * elem,
            take * op->channels * elem);
      op->pend_pos += take;
      op->pend_frames -= take;
      op->time.position += (int64_t)take;
      op->time.pending += (int64_t)take;
      produced += take;
   }
   if (got) *got = produced;
   return produced || op->wall || op->yielded ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
}

#ifdef HAVE_RWEBM
static int audio_transfer_opus_movie_header(struct audio_transfer_opus *op,
      const uint8_t *packet, uint32_t size, int64_t pad)
{
   int64_t raw = audio_transfer_opus_pkt_frames(packet, size);
   int64_t frames, exact;
   unsigned skip;
   if (raw <= 0 || !audio_transfer_time_add(op->toc_total, raw, &op->toc_total)) return -1;
   skip = op->preskip_left;
   if ((int64_t)skip > raw) skip = (unsigned)raw;
   op->preskip_left -= skip;
   frames = raw - skip;
   if (pad > 0)
   {
      exact = op->toc_total - (int64_t)ropus_preskip(op->handle);
      exact = exact > pad ? exact - pad : 0;
      if (op->limit < 0 || exact < op->limit) op->limit = exact;
   }
   if (op->limit >= 0 && frames > op->limit - op->emitted)
      frames = op->limit - op->emitted;
   if (frames < 0 || !audio_transfer_time_map(&op->time, skip, (size_t)frames)
         || !audio_transfer_time_add(op->emitted, frames, &op->emitted)) return -1;
   return (int)frames;
}
#endif
#endif

#ifdef HAVE_RAAC
/* The next access unit, wherever this context's come from.  Returns 1
 * with the bytes, 0 at end of stream, < 0 on a malformed one. */
static int audio_transfer_aac_pull(struct audio_transfer_aac *ac,
      const uint8_t **pdata, uint32_t *plen)
{
#if defined(HAVE_RWEBM) || defined(HAVE_RMP4)
   unsigned walked = 0;
#endif
   {
      /* Windowed ADTS: stop at the resident prefix rather than the
       * buffer end, and say "again" instead of "end of stream". */
      if (ac->adts && ac->avail && ac->adts_pos + 7 > ac->avail)
         return 2;
      if (ac->adts)
      {
         /* walk the next ADTS frame: 12-bit sync, CRC flag choosing a
          * 7- or 9-byte header, 13-bit total frame length */
         size_t      pos = ac->adts_pos;
         raac_adts_t adts;
         unsigned    hdr, flen;
         if (raac_adts_parse(ac->buf + pos, ac->buf_size - pos, &adts) < 0)
            return 0;             /* lost sync: treat as end of stream */
         hdr  = adts.header_size;
         flen = adts.frame_size;
         if (pos + flen > ac->buf_size)
            return 0;
         *pdata       = ac->buf + pos + hdr;
         *plen        = flen - hdr;
         ac->adts_pos = pos + flen;
         return 1;
      }
#ifdef HAVE_RWEBM
      if (ac->wdemux)
      {
         /* buffer mode, Matroska: the next block of the AAC track */
         rwebm_packet wpkt;
         for (;;)
         {
            int r;
            if (walked++ == 256) return 3; /* metadata yield, not a byte wall */
            r = rwebm_read_packet_track(ac->wdemux, ac->wtrack_idx, &wpkt);
            if (r == RWEBM_READ_YIELD) return 3;
            /* Resident wall, not end of stream - the same distinction
             * the rmp4 branch below has always drawn; conflating them
             * here had a Matroska AAC voice end (and a looping one
             * rewind mid-file) whenever the feeder fell one tick
             * behind.  2 also makes the seek walk refuse rather than
             * treat the wall as the stream ending under it. */
            if (r == RWEBM_READ_AGAIN)
               return 2;
            if (r != 1)
               return 0;
            if (wpkt.track == ac->wtrack_idx)
               break;
         }
         *pdata = wpkt.data;
         *plen  = (uint32_t)wpkt.size;
         if (!audio_transfer_time_packet(&ac->time, wpkt.timestamp,
                  wpkt.timestamp_continuation)
               || !audio_transfer_time_frames(wpkt.discard_padding,
                  ac->time.rate, &ac->packet_pad)) return -1;
         return 1;
      }
#endif
#ifdef HAVE_RMP4
      if (ac->demux)
      {
         /* buffer mode: pull the next access unit from the demuxer */
         rmp4_packet pkt;
         for (;;)
         {
            int r;
            if (walked++ == 256) return 3;
            r = rmp4_read_packet(ac->demux, &pkt);
            /* The sample's bytes are not resident yet.  This is NOT
             * end of stream: reporting 0 here would have the mixer
             * loop or stop the voice mid-file the moment the feeder
             * fell a window behind. */
            if (r == RMP4_READ_AGAIN)
               return 2;
            if (r != 1)
               return 0;
            if (pkt.track == ac->track_idx)
               break;
         }
         *pdata = pkt.data;
         *plen  = (uint32_t)pkt.size;
         if (!audio_transfer_time_packet(&ac->time, pkt.timestamp, 0)) return -1;
         ac->packet_pad = 0;
         return 1;
      }
#endif
      {
         if (ac->pkt_index >= ac->num_packets)
            return 0;
         *plen = ac->pkt_sizes[ac->pkt_index];
         if (ac->pkt_offset + *plen > ac->packets_size)
            return -1;
         *pdata = ac->packets + ac->pkt_offset;
         ac->pkt_offset += *plen;
         ac->pkt_index++;
         return 1;
      }
   }
}

/* Frames decoded before the target and dropped so the decoder has its
 * overlap-add history back.  One access unit is the overlap itself and
 * the walk stops on a unit boundary, so three covers both. */
#define AUDIO_AAC_PREROLL 3   /* access units decoded before target */

/* Every access unit this decoder takes yields a fixed frame count -
 * raac_frame_len(), the core 1024 doubled under SBR - so the walk to a
 * target needs no decoding at all; only the pre-roll does.  Returns
 * the frame reached, or < 0 if the stream ends first.
 *
 * Streams using PNS reconstruct their noise bands from a generator
 * whose state advances with every draw; a seek skips the draws of the
 * walked-over access units, so noise samples after a seek differ from
 * a straight decode (by an LSB or so at s16).  Deterministic loops on
 * PNS content need seek(0), which raac_reset makes exact. */
/* Out of a sliding window, nothing behind the old position is
 * resident any more: the feeder let the head go as the lap went on,
 * and only it can bring the head back, on its next tick. Until it
 * publishes a new bound the reads stand at the wall rather than touch
 * pages that are gone. A whole-file buffer has no window and no
 * bound, and is untouched. Every rewind of an AAC stream goes through
 * here - the seek's own and the loop's. */
static void audio_transfer_aac_withdraw_bound(struct audio_transfer_aac *ac)
{
   if (!ac->avail)
      return;
   ac->avail = 1;
#ifdef HAVE_RMP4
   if (ac->demux)
      rmp4_set_avail(ac->demux, 1);
#endif
#ifdef HAVE_RWEBM
   if (ac->wdemux)
      rwebm_set_avail(ac->wdemux, 1);
#endif
}

static void audio_transfer_aac_to_head(struct audio_transfer_aac *ac)
{
   raac_reset(ac->handle);
#ifdef HAVE_RMP4
   if (ac->demux) rmp4_rewind(ac->demux);
#endif
#ifdef HAVE_RWEBM
   if (ac->wdemux) rwebm_rewind(ac->wdemux);
#endif
   ac->adts_pos = ac->pkt_index = ac->pkt_offset = 0;
   ac->pend_frames = ac->pend_pos = 0;
   ac->trim_left = ac->start_trim;
   ac->emitted = 0;
   ac->packet_pad = 0;
   ac->time.first_ready = ac->time.ready = ac->time.eof = 0;
   ac->time.end = ac->time.pending = ac->time.position = 0;
   ac->yielded = ac->wall = 0;
   audio_transfer_aac_withdraw_bound(ac);
}

#ifdef HAVE_RWEBM
static int audio_transfer_aac_movie_header(struct audio_transfer_aac *ac)
{
   size_t frames = raac_frame_len(ac->handle);
   size_t skip = ac->trim_left < frames ? (size_t)ac->trim_left : frames;
   ac->trim_left -= skip;
   frames -= skip;
   if (ac->packet_pad > 0)
      frames = (uint64_t)ac->packet_pad < frames ? frames - (size_t)ac->packet_pad : 0;
   if (ac->limit >= 0)
   {
      int64_t left = ac->limit > ac->emitted ? ac->limit - ac->emitted : 0;
      if ((uint64_t)left < frames) frames = (size_t)left;
   }
   if (!audio_transfer_time_map(&ac->time, skip, frames)
         || !audio_transfer_time_add(ac->emitted, (int64_t)frames, &ac->emitted)) return -1;
   return (int)frames;
}
#endif

static int audio_transfer_aac_fill(struct audio_transfer_aac *ac);

static int64_t audio_transfer_aac_seek_to(struct audio_transfer_aac *ac,
      int64_t frame)
{
   int64_t  pos  = 0;
   uint64_t skip = ac->start_trim;
   int64_t  flen = (int64_t)raac_frame_len(ac->handle);
   int64_t  stop = frame - AUDIO_AAC_PREROLL * flen;

   raac_reset(ac->handle);
   ac->adts_pos = 0;
#ifdef HAVE_RMP4
   if (ac->demux)
      rmp4_rewind(ac->demux);
#endif
   ac->pkt_index   = 0;
   ac->pkt_offset  = 0;
   ac->pend_frames = 0;
   ac->pend_pos    = 0;
   audio_transfer_aac_withdraw_bound(ac);
   if (stop < 0)
      stop = 0;
   while (pos < stop)
   {
      const uint8_t *pdata;
      uint32_t plen;
      int64_t d = flen;
      int r = audio_transfer_aac_pull(ac, &pdata, &plen);
      /* r == 2 left pdata/plen unset: a target past the resident wall
       * is refused rather than approximated, per the windowing
       * contract, and the caller retries once the feeder has raised
       * the bound past it. */
      if (r != 1)
         return -1;              /* asked past the end of the stream   */
      /* the encoder delay is dropped rather than emitted, so it does
       * not count towards the position */
      if (skip)
      {
         uint64_t taken = ((uint64_t)d < skip) ? (uint64_t)d : skip;
         skip -= taken;
         d    -= (int64_t)taken;
      }
      pos += d;
   }
   ac->trim_left = skip;
   ac->emitted   = pos;
   while (pos < frame)
   {
      int64_t take;
      int r = audio_transfer_aac_fill(ac);
      if (r < 0)
         return -1;
      if (r == 0 || r == 2)   /* 2: refused, see the walk above */
         return -1;
      take = frame - pos;
      if (take > (int64_t)ac->pend_frames)
         take = (int64_t)ac->pend_frames;
      ac->pend_pos    += (size_t)take;
      ac->pend_frames -= (size_t)take;
      pos             += take;
   }
   return pos;
}

/* Refill readiness is 1 for pending samples, 2 for the resident wall,
 * 0 at end of stream, or negative on error. Sample counts are held in
 * pend_frames, so a short tail cannot alias a status code. */
static int audio_transfer_aac_fill(struct audio_transfer_aac *ac)
{
   unsigned walked = 0;
   while (ac->pend_frames == 0)
   {
      const uint8_t *pdata = NULL;
      uint32_t plen        = 0;
      int r;
      uint64_t skip;
      if (ac->time.enabled && ac->time.eof) return 0;
      if ((ac->seek_pending && walked) || walked >= 16)
      { ac->yielded = 1; return 2; }
      walked++;
      r = audio_transfer_aac_pull(ac, &pdata, &plen);
      if (r == 3) { ac->yielded = 1; return 2; }
      if (r == 2)
      {
         ac->wall = 1;
         return 2;               /* not yet resident; no frames, no EOF */
      }
      if (r <= 0)
      {
         if (!r && ac->time.enabled) { ac->time.eof = 1; ac->wall = 0; }
         return r;
      }
      ac->wall = 0;
      r = raac_decode(ac->handle, pdata, plen);
      if (r < 0)
         return -1;
      ac->pend_frames = (size_t)r;
      ac->pend_pos    = 0;
      skip = ac->trim_left;
      if (skip)
      {
         if (skip >= ac->pend_frames)
         {
            ac->trim_left  -= ac->pend_frames;
            ac->pend_frames = 0;   /* whole packet trimmed; loop        */
         }
         else
         {
            ac->pend_pos     = (size_t)skip;
            ac->pend_frames -= (size_t)skip;
            ac->trim_left    = 0;
         }
      }
      if (ac->packet_pad > 0 && ac->pend_frames)
      {
         size_t pad = (uint64_t)ac->packet_pad < ac->pend_frames
            ? (size_t)ac->packet_pad : ac->pend_frames;
         ac->pend_frames -= pad;
      }
      /* Stop at the duration the container declares: the last access
       * unit is a whole 1024 frames of which only part is the
       * recording, and handing the rest out is both wrong and longer
       * than the length info() reports. */
      if (ac->limit >= 0 && ac->pend_frames)
      {
         int64_t left = ac->limit - ac->emitted;
         if (left <= 0)
         {
            ac->pend_frames = 0;
            if (ac->time.enabled) ac->time.eof = 1;
            return 0;
         }
         if ((int64_t)ac->pend_frames > left)
            ac->pend_frames = (size_t)left;
      }
      if (!audio_transfer_time_add(ac->emitted, (int64_t)ac->pend_frames,
               &ac->emitted)) return -1;
      if (!audio_transfer_time_map(&ac->time, ac->pend_pos,
               ac->pend_frames)) return -1;
   }
   /* Readiness is distinct from the pending-frame count: two real
    * frames must not alias the resident-wall status (2). */
   return ac->pend_frames ? 1 : 0;
}

/* Both output formats use the same movie/sample schedule. Silence never
 * consumes a coded packet twice, and overlap only advances pending PCM. */
static int audio_transfer_aac_read(struct audio_transfer_aac *ac,
      float *f32, int16_t *s16, size_t frames, size_t *got)
{
   size_t produced = 0;
   unsigned walked = 0;
   ac->yielded = 0;
   while (produced < frames)
   {
      size_t take, skip;
      int r;
      if (++walked > 32) { ac->yielded = 1; break; }
      if (ac->time.enabled && ac->time.total >= 0
            && ac->time.position >= ac->time.total) break;
      r = audio_transfer_aac_fill(ac);
      if (r < 0) return AUDIO_PROCESS_ERROR;
      if (r == 2) break;
      take = audio_transfer_time_silence(&ac->time, frames - produced, !r);
      if (take)
      {
         if (f32) memset(f32 + produced * ac->channels, 0,
               take * ac->channels * sizeof(*f32));
         else memset(s16 + produced * ac->channels, 0,
               take * ac->channels * sizeof(*s16));
         produced += take;
         continue;
      }
      if (!r) break;
      skip = audio_transfer_time_overlap(&ac->time, ac->pend_frames);
      ac->pend_pos += skip;
      ac->pend_frames -= skip;
      take = frames - produced;
      if (take > ac->pend_frames) take = ac->pend_frames;
      if (ac->time.enabled && ac->time.total >= 0
            && (uint64_t)(ac->time.total - ac->time.position) < take)
         take = (size_t)(ac->time.total - ac->time.position);
      if (f32) raac_copy_f32(ac->handle, ac->pend_pos, take,
            f32 + produced * ac->channels);
      else raac_copy_s16(ac->handle, ac->pend_pos, take,
            s16 + produced * ac->channels);
      ac->pend_pos += take;
      ac->pend_frames -= take;
      if (ac->time.enabled)
      {
         ac->time.position += (int64_t)take;
         ac->time.pending += (int64_t)take;
      }
      produced += take;
   }
   if (got) *got = produced;
   return produced || ac->wall || ac->yielded ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
}
#endif


/* The indexed MP4 arm does not walk media bytes to find the target.
 * Its owner feeds the selected byte frontier before retrying step. */
#if defined(HAVE_RVORBIS) && defined(HAVE_RWEBM)
static void audio_transfer_vorbis_to_head(struct audio_transfer_vorbis *v);
#endif

bool audio_transfer_seek_begin_format(void *data, enum audio_type_enum type,
      uint64_t frame, bool s16)
{
#ifdef HAVE_RAC3
   if (type == AUDIO_TYPE_AC3)
   {
      struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
      if (!a || !a->dec || (a->total_frames && frame > a->total_frames)) return false;
      rac3_decoder_reset(a->dec);
#ifdef HAVE_RMP4
      if (a->demux) { rmp4_rewind(a->demux); a->packet_end = 0; }
#endif
      a->pos = 0;
      a->pend_n = a->pend_off = 0;
      a->frame_pos = 0;
      a->ended = false;
      a->seek_target = frame;
      a->seek_at = 0;
      a->seek_previous = (size_t)-1;
      a->seek_pending = true;
      return true;
   }
#endif
#ifdef HAVE_RFLAC
   if (type == AUDIO_TYPE_FLAC)
   {
      struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
      uint64_t total;
      if (!fl || !fl->handle || frame > ((~(uint64_t)0) >> 1))
         return false;
      if (fl->time.enabled)
      {
         if (!audio_transfer_info(fl, type, NULL, NULL, NULL)
               || (fl->time.total >= 0 && frame > (uint64_t)fl->time.total))
            return false;
         audio_transfer_flac_movie_head(fl);
         fl->seek_remaining = frame;
         fl->seek_pending = 1;
         return true;
      }
      total = rflac_total_frames(fl->handle);
      if ((total && frame > total) || !audio_transfer_flac_seek_to(fl, 0))
         return false;
#ifdef HAVE_RWEBM
      if (fl->demux && fl->avail)
      {
         fl->avail = 1;
         rwebm_set_avail(fl->demux, 1);
      }
#endif
      fl->wall = 0;
      fl->seek_remaining = frame;
      fl->seek_pending = 1;
      return true;
   }
#endif
#if defined(HAVE_RVORBIS) && defined(HAVE_RWEBM)
   if (type == AUDIO_TYPE_VORBIS)
   {
      struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
      if (!v || !v->handle || !v->packet || !v->demux
            || frame > (uint64_t)((~(uint64_t)0) >> 1)
            || (v->time.total >= 0 && frame > (uint64_t)v->time.total)) return false;
      audio_transfer_vorbis_to_head(v);
      rvorbis_packet_reset(v->handle);
      v->emitted = 0;
      v->seek_target = frame;
      v->seek_position = 0;
      v->seek_count = v->seek_index = 0;
      v->seek_prime = 1;
      v->seek_phase = 1;
      v->seek_s16 = s16 ? 1 : 0;
      v->wall = 0;
      return true;
   }
#endif
#if defined(HAVE_ROPUS) && defined(HAVE_RWEBM)
   if (type == AUDIO_TYPE_OPUS)
   {
      struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
      if (!op || !op->handle || !op->demux
            || frame > (uint64_t)((~(uint64_t)0) >> 1)
            || (op->time.total >= 0 && frame > (uint64_t)op->time.total)) return false;
      audio_transfer_opus_to_head(op);
      op->fmt = 0;
      op->seek_to = -1;
      op->seek_target = frame;
      op->seek_position = 0;
      op->seek_fmt = s16 ? 1 : 2;
      op->seek_pending = 1;
      op->seek_walk = 1;
      op->wall = 0;
      return true;
   }
#else
   (void)s16;
#endif
#if defined(HAVE_RAAC) && (defined(HAVE_RMP4) || defined(HAVE_RWEBM))
   if (type == AUDIO_TYPE_AAC)
   {
      struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
      int container = 0;
      if (!ac || !ac->handle
            || frame > ((~(uint64_t)0) >> 1)
            || (ac->time.total >= 0 && frame > (uint64_t)ac->time.total))
         return false;
#ifdef HAVE_RMP4
      if (ac->demux) container = 1;
#endif
#ifdef HAVE_RWEBM
      if (ac->wdemux) container = 3;
#endif
      if (!container) return false;
      /* Map metadata in slices before touching coded bytes. Four small
       * snapshots retain the decoder's three-packet preroll without a
       * whole-file timing allocation or a second metadata walk. */
      audio_transfer_aac_to_head(ac);
      ac->seek_target = frame;
      ac->seek_scan = 0;
      ac->seek_phase = container;
      ac->seek_count = ac->seek_index = ac->seek_prime = 0;
      ac->seek_pending = true;
      ac->wall = 0;
      ac->yielded = 0;
      audio_transfer_aac_withdraw_bound(ac);
      return true;
   }
#else
   (void)data; (void)type; (void)frame;
#endif
   return false;
}

bool audio_transfer_seek_begin(void *data, enum audio_type_enum type,
      uint64_t frame)
{
   return audio_transfer_seek_begin_format(data, type, frame, false);
}

int audio_transfer_seek_step(void *data, enum audio_type_enum type)
{
#ifdef HAVE_RAC3
   if (type == AUDIO_TYPE_AC3)
   {
      struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
      unsigned walked;
      if (!a || !a->dec || !a->seek_pending) return -1;
      for (walked = 0; walked < 64; walked++)
      {
         rac3_frame_info_t info;
         size_t end;
         int span = audio_transfer_ac3_span(a);
         if (span != 1)
         {
            if (!span && a->pos >= a->buf_size && a->seek_at == a->seek_target)
            { a->ended = true; a->frame_pos = a->seek_at; a->seek_pending = false; return 1; }
            return span < 0 || a->pos >= a->buf_size ? -1 : 0;
         }
         end = audio_transfer_ac3_end(a);
#ifdef HAVE_RMP4
         if (a->demux && end > a->packet_end) end = a->packet_end;
#endif
         if (rac3_parse_frame_info(a->buf + a->pos, end - a->pos, &info) != RAC3_OK)
            return -1;
         if (a->seek_at + info.samples > a->seek_target)
         {
            if (a->seek_previous != (size_t)-1)
            {
               rac3_frame_info_t previous;
               if (rac3_parse_frame_info(a->buf + a->seek_previous,
                        audio_transfer_ac3_end(a) - a->seek_previous, &previous) != RAC3_OK
                     || !rac3_decode_frame(a->dec, a->buf + a->seek_previous,
                        previous.frame_bytes, a->raw, &previous)) return -1;
            }
            a->frame_pos = a->seek_at;
            if (audio_transfer_ac3_next(a) != 1) return -1;
            a->pend_off = (size_t)(a->seek_target - a->seek_at);
            a->seek_pending = false;
            return 1;
         }
         a->seek_previous = a->pos;
         a->seek_at += info.samples;
         a->pos += info.frame_bytes;
      }
      return 0;
   }
#endif
#ifdef HAVE_RFLAC
   if (type == AUDIO_TYPE_FLAC)
   {
      struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
      size_t read = 0, wrote = 0, want;
      int result;
      if (!fl || !fl->seek_pending) return -1;
      if (fl->time.enabled) return audio_transfer_flac_movie_seek_step(fl);
      if (!fl->seek_remaining)
      {
         fl->seek_pending = 0;
         return 1;
      }
      want = fl->seek_remaining > (size_t)-1
         ? (size_t)-1 : (size_t)fl->seek_remaining;
      rflac_set_out_discard(fl->handle, want);
      result = rflac_process(fl->handle, &read, &wrote);
      fl->cursor += read;
      fl->seek_remaining -= wrote;
      if (!fl->seek_remaining)
      {
         fl->seek_pending = 0;
         return 1;
      }
      if (result == RFLAC_PROCESS_ERROR || result == RFLAC_PROCESS_END)
         goto flac_failed;
      if (!wrote)
      {
         fl->wall = 0;
         if (!audio_transfer_flac_feed(fl) && !fl->wall)
            goto flac_failed;
      }
      return 0;
flac_failed:
      fl->seek_pending = 0;
      return -1;
   }
#endif
#if defined(HAVE_RVORBIS) && defined(HAVE_RWEBM)
   if (type == AUDIO_TYPE_VORBIS)
   {
      struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
      const uint8_t *bytes = NULL;
      uint32_t size = 0;
      int64_t pad = 0;
      int ret, frames;
      if (!v || !v->seek_phase) return -1;
      if (v->seek_phase == 1)
      {
         ret = audio_transfer_vorbis_pull(v, &bytes, &size, &pad);
         if (ret == -2 || ret == -3) return 0;
         if (ret < 0) goto vorbis_failed;
         if (ret)
         {
            frames = audio_transfer_vorbis_movie_header(v, bytes, size, pad, v->seek_count++);
            if (frames < 0) goto vorbis_failed;
            if (v->seek_target && (!frames || v->time.pending + frames <= (int64_t)v->seek_target))
               return 0;
         }
         else if (v->time.total < 0 && (int64_t)v->seek_target > v->time.end)
            goto vorbis_failed;
         v->seek_prime = v->seek_count > 1 ? v->seek_count - 2 : 0;
         audio_transfer_vorbis_to_head(v);
         rvorbis_packet_reset(v->handle);
         v->emitted = 0;
         v->seek_phase = 2;
         return 0;
      }
      if (v->seek_phase == 2)
      {
         ret = audio_transfer_vorbis_pull(v, &bytes, &size, &pad);
         if (ret == -2 || ret == -3) return 0;
         if (!ret && !v->seek_count && (v->time.total >= 0 || !v->seek_target))
         {
            v->time.position = (int64_t)v->seek_target;
            v->time.eof = 1;
            v->wall = 0;
            v->seek_phase = 0;
            return 1;
         }
         if (ret != 1) goto vorbis_failed;
         frames = audio_transfer_vorbis_movie_header(v, bytes, size, pad, v->seek_index);
         if (frames < 0) goto vorbis_failed;
         if (v->seek_index++ < v->seek_prime) return 0;
         if (rvorbis_packet_decode(v->handle, bytes, size, v->seek_s16) < 0)
            goto vorbis_failed;
         v->time.position = (int64_t)v->seek_target;
         v->time_pending = 0;
         v->seek_phase = 3;
         return 0;
      }
      v->yielded = 0;
      ret = audio_transfer_vorbis_movie_fill(v, v->seek_s16);
      if (ret == 2) return 0;
      if (ret < 0) goto vorbis_failed;
      if (ret)
      {
         union { int16_t s16[256]; float f32[256]; } scratch;
         size_t skip = audio_transfer_time_overlap(&v->time, v->time_pending);
         if (skip)
         {
            size_t take = skip;
            if (v->channels <= 0 || v->channels > 8) goto vorbis_failed;
            if (take > 256 / (unsigned)v->channels) take = 256 / (unsigned)v->channels;
            ret = v->seek_s16
               ? rvorbis_packet_read_s16(v->handle, v->channels, scratch.s16, (int)take * v->channels)
               : rvorbis_packet_read_float(v->handle, v->channels, scratch.f32, (int)take * v->channels);
            if (ret != (int)take) goto vorbis_failed;
            v->time.pending -= (int64_t)(skip - take);
            v->time_pending -= take;
            if (skip > take || !v->time_pending) return 0;
         }
      }
      v->seek_phase = 0;
      return 1;
vorbis_failed:
      v->seek_phase = 0;
      return -1;
   }
#endif
#if defined(HAVE_ROPUS) && defined(HAVE_RWEBM)
   if (type == AUDIO_TYPE_OPUS)
   {
      struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
      int r;
      if (!op || !op->seek_pending) return -1;
      if (op->seek_walk == 1)
      {
         const uint8_t *bytes;
         uint32_t size;
         int64_t pad = 0, before = op->emitted;
         r = audio_transfer_opus_pull(op, &bytes, &size, &pad);
         if (r == -2 || r == -3) return 0;
         if (r < 0) goto opus_failed;
         if (r)
         {
            int frames = audio_transfer_opus_movie_header(op, bytes, size, pad);
            if (frames < 0) goto opus_failed;
            if (op->seek_target && (!frames || op->time.pending + frames <= (int64_t)op->seek_target))
               return 0;
         }
         else if (op->time.total < 0 && (int64_t)op->seek_target > op->time.end)
            goto opus_failed;
         op->seek_prime = before > AUDIO_OPUS_PREROLL
            ? (uint64_t)(before - AUDIO_OPUS_PREROLL) : 0;
         audio_transfer_opus_to_head(op);
         op->seek_walk = 2;
         return 0;
      }
      if (op->seek_walk == 2)
      {
         const uint8_t *bytes;
         uint32_t size;
         int64_t pad = 0;
         if ((uint64_t)op->emitted < op->seek_prime)
         {
            r = audio_transfer_opus_pull(op, &bytes, &size, &pad);
            if (r == -2 || r == -3) return 0;
            if (r != 1 || audio_transfer_opus_movie_header(op, bytes, size, pad) < 0)
               goto opus_failed;
            return 0;
         }
         op->time.position = (int64_t)op->seek_target;
         op->seek_walk = 3;
         return 0;
      }
      op->yielded = 0;
      r = audio_transfer_opus_fill(op, op->seek_fmt);
      if (r == -3 || (!r && op->wall)) return 0;
      if (r < 0) goto opus_failed;
      if (r)
      {
         size_t skip = audio_transfer_time_overlap(&op->time, op->pend_frames);
         op->pend_pos += skip;
         op->pend_frames -= skip;
         if (!op->pend_frames) return 0;
      }
      op->seek_pending = 0;
      op->seek_walk = 0;
      return 1;
opus_failed:
      op->seek_pending = 0;
      op->seek_walk = 0;
      return -1;
   }
#endif
#if defined(HAVE_RAAC) && (defined(HAVE_RMP4) || defined(HAVE_RWEBM))
   if (type == AUDIO_TYPE_AAC)
   {
      struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
      size_t skip;
      int r;
      if (!ac || !ac->seek_pending) return -1;
#ifdef HAVE_RWEBM
      if (ac->seek_phase == 3)
      {
         const uint8_t *bytes;
         uint32_t size;
         r = audio_transfer_aac_pull(ac, &bytes, &size);
         if (r == 2) { ac->wall = 1; return 0; }
         if (r == 3) return 0;
         if (r < 0) goto failed;
         if (r)
         {
            int frames = audio_transfer_aac_movie_header(ac);
            if (frames < 0 || ac->seek_count == ~(uint64_t)0) goto failed;
            ac->seek_count++;
            if (ac->seek_target && (!frames
                     || ac->time.pending + frames <= (int64_t)ac->seek_target)) return 0;
         }
         else if (ac->time.total < 0 && (int64_t)ac->seek_target > ac->time.end) goto failed;
         ac->seek_prime = ac->seek_count > AUDIO_AAC_PREROLL + 1
            ? ac->seek_count - AUDIO_AAC_PREROLL - 1 : 0;
         audio_transfer_aac_to_head(ac);
         ac->seek_phase = 4;
         return 0;
      }
      if (ac->seek_phase == 4)
      {
         const uint8_t *bytes;
         uint32_t size;
         if (ac->seek_index < ac->seek_prime)
         {
            r = audio_transfer_aac_pull(ac, &bytes, &size);
            if (r == 2) { ac->wall = 1; return 0; }
            if (r == 3) return 0;
            if (r != 1 || audio_transfer_aac_movie_header(ac) < 0) goto failed;
            ac->seek_index++;
            return 0;
         }
         ac->time.position = (int64_t)ac->seek_target;
         ac->seek_phase = 2;
         return 0;
      }
#endif
#ifdef HAVE_RMP4
      if (ac->seek_phase == 1)
      {
         uint32_t count = 0, prime;
         uint64_t raw, flen = raac_frame_len(ac->handle);
         const int64_t *pts = rmp4_track_pts(ac->demux, ac->track_idx, &count);
         unsigned walked;
         int found = 0;
         int64_t started = cpu_features_get_time_usec();
         if (!flen || !pts || !count) goto failed;
         /* These steps inspect resident timing tables, not coded audio.
          * Yield by elapsed work rather than once per 256 packets: a
          * long movie otherwise pays a worker wakeup for every batch. */
         for (walked = 0; ac->seek_scan < count && walked < 65536; walked++)
         {
            size_t frames = (size_t)flen, trimmed;
            int64_t source;
            raw = (uint64_t)ac->seek_scan * flen;
            ac->seek_times[ac->seek_scan % 4] = ac->time;
            trimmed = raw < ac->start_trim
               ? (size_t)(ac->start_trim - raw < flen ? ac->start_trim - raw : flen) : 0;
            frames -= trimmed;
            source = raw > ac->start_trim ? (int64_t)(raw - ac->start_trim) : 0;
            if (ac->limit >= 0)
            {
               int64_t left = ac->limit > source ? ac->limit - source : 0;
               if ((uint64_t)left < frames) frames = (size_t)left;
            }
            if (!audio_transfer_time_packet(&ac->time, pts[ac->seek_scan], 0)
                  || !audio_transfer_time_map(&ac->time, trimmed, frames)) goto failed;
            if (!ac->seek_target || (frames
                     && ac->time.pending + (int64_t)frames > (int64_t)ac->seek_target))
            { found = 1; break; }
            ac->seek_scan++;
            if (!(walked & 255)
                  && cpu_features_get_time_usec() - started >= 4000)
               break;
         }
         if (!found && ac->seek_scan < count) return 0;
         prime = ac->seek_scan > AUDIO_AAC_PREROLL
            ? ac->seek_scan - AUDIO_AAC_PREROLL : 0;
         if (prime >= count || !rmp4_select_track_sample(ac->demux,
                  ac->track_idx, prime)) goto failed;
         ac->time = ac->seek_times[prime % 4];
         ac->time.position = (int64_t)ac->seek_target;
         raw = (uint64_t)prime * flen;
         ac->trim_left = raw < ac->start_trim ? ac->start_trim - raw : 0;
         ac->emitted = raw > ac->start_trim ? (int64_t)(raw - ac->start_trim) : 0;
         raac_reset(ac->handle);
         ac->seek_phase = 2;
         audio_transfer_aac_withdraw_bound(ac);
         return 0;
      }
#endif
      ac->yielded = 0;
      r = audio_transfer_aac_fill(ac);
      if (r == 2) return 0;
      if (r < 0) goto failed;
      if (!r)
      {
         /* A target in the movie's audio-free tail is still valid. */
         if (ac->time.total < 0 && ac->time.position > ac->time.end) goto failed;
         ac->seek_phase = 0;
         ac->seek_pending = false;
         return 1;
      }
      skip = audio_transfer_time_overlap(&ac->time, ac->pend_frames);
      ac->pend_pos += skip;
      ac->pend_frames -= skip;
      if (ac->pend_frames)
      {
         ac->seek_phase = 0;
         ac->seek_pending = false;
         return 1;
      }
      return 0;
failed:
      ac->seek_phase = 0;
      ac->seek_pending = false;
      return -1;
   }
#else
   (void)data; (void)type;
#endif
   return -1;
}


/* Did the last empty read stop at the resident wall rather than the
 * end of the stream?  Consulted by the read tails below: an empty
 * read at the wall returns AUDIO_PROCESS_NEXT - no frames yet, call
 * again once the feeder has raised the bound - while an empty read at
 * the true end keeps returning AUDIO_PROCESS_END, which is what lets
 * a looping mixer voice rewind at the loop point and only there.
 * Conflating the two is what turned a feeder one tick behind into a
 * mid-file rewind, and two ticks behind into the voice releasing. */
static int audio_transfer_wall_stalled(void *data,
      enum audio_type_enum type)
{
   switch (type)
   {
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
         return ((struct audio_transfer_mp3*)data)->wall;
#endif

#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
         return ((struct audio_transfer_vorbis*)data)->wall;
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
         return ((struct audio_transfer_opus*)data)->wall;
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
         return ((struct audio_transfer_aac*)data)->wall;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
         return ((struct audio_transfer_flac*)data)->wall;
#endif
      default:
         break;
   }
   return 0;
}

int audio_transfer_read_s16(void *data, enum audio_type_enum type,
      int16_t *out, size_t frames, size_t *frames_out)
{
   size_t produced = 0;

   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         return audio_transfer_wma_read((struct audio_transfer_wma*)data,
               NULL, out, frames, frames_out);
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl || !fl->handle)
            return AUDIO_PROCESS_ERROR;
         if (fl->time.enabled)
            return audio_transfer_flac_movie_read(fl, 1, out, NULL, frames, frames_out);
         produced = audio_transfer_flac_pull(fl, out, frames, 0);
         break;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         if (!v || !v->handle)
            return AUDIO_PROCESS_ERROR;
         if (v->time.enabled)
            return audio_transfer_vorbis_movie_read(v, 1, out, NULL, frames, frames_out);
         if (v->packet)
            produced = audio_transfer_vorbis_drain(v, 1, out, NULL, frames);
         else
         {
            frames   = audio_transfer_vorbis_cap(v, frames);
            produced = audio_transfer_vorbis_stream_pull(v, 1, out, NULL,
                  frames);
            v->emitted += (int64_t)produced;
         }
         break;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (!m || !m->stream)
            return AUDIO_PROCESS_ERROR;
         if (m->seek_to >= 0)
         {
            int64_t at = audio_transfer_mp3_seek_to(m, m->seek_to, 1);
            m->seek_to = -1;
            if (at < 0)
               return AUDIO_PROCESS_ERROR;
         }
         produced = audio_transfer_mp3_read(m, 1, out, NULL, frames);
         break;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (!md || !md->handle)
            return AUDIO_PROCESS_ERROR;
         produced = rmodtracker_get_samples_s16_interleaved(
               md->handle, out, frames);
         break;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (!op || !op->handle || op->fmt == 2)
            return AUDIO_PROCESS_ERROR;
         if (op->time.enabled)
            return audio_transfer_opus_movie_read(op, out, frames, frames_out, 1);
         if (op->seek_to >= 0)
         {
            int64_t at = audio_transfer_opus_seek_to(op, op->seek_to, 1);
            op->seek_to = -1;
            if (at < 0)
               return AUDIO_PROCESS_ERROR;
         }
         while (produced < frames)
         {
            size_t take, direct = 0;
            /* With nothing pending, the next packet decodes straight
             * into the caller's buffer when it fits there whole. */
            int r = op->pend_frames ? (int)op->pend_frames
               : audio_transfer_opus_fill_into(op, 1,
                     out + produced * op->channels, frames - produced,
                     &direct);
            if (r < 0)
               return AUDIO_PROCESS_ERROR;
            if (r == 0)
               break;
            if (direct)
            {
               produced += direct;
               continue;
            }
            take = frames - produced;
            if (take > op->pend_frames)
               take = op->pend_frames;
            memcpy(out + produced * op->channels,
                  (const int16_t*)op->pend + op->pend_pos * op->channels,
                  take * op->channels * sizeof(int16_t));
            op->pend_pos    += take;
            op->pend_frames -= take;
            produced        += take;
         }
         break;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
         return audio_transfer_atrac_read((struct audio_transfer_atrac*)data,
               NULL, out, frames, frames_out);
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
         return audio_transfer_ac3_read((struct audio_transfer_ac3*)data,
               NULL, out, frames, frames_out);
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         size_t take;
         if (!l || !l->ready)
            return AUDIO_PROCESS_ERROR;
         if (l->fmt.kind == RLPCM_KIND_DVD)
            return audio_transfer_dvd_lpcm_read(l, NULL, out, frames, frames_out);
         take = audio_transfer_lpcm_frames_left(l, l->pos);
         if (take > frames)
            take = frames;
         if (take)
         {
            take = rlpcm_decode_s16(&l->fmt, l->buf + l->pos,
                  audio_transfer_lpcm_end(l) - l->pos, out, take);
            l->pos += (size_t)(((uint64_t)take * rlpcm_frame_bits(&l->fmt)) / 8);
         }
         if (frames_out)
            *frames_out = take;
         return take ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (!ac || !ac->handle)
            return AUDIO_PROCESS_ERROR;
         return audio_transfer_aac_read(ac, NULL, out, frames, frames_out);
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         const uint8_t *src;
         size_t avail, want, ch, i, n;
         if (!w || !w->opened)
            return AUDIO_PROCESS_ERROR;
         ch    = (size_t)w->wav.numchannels;
         avail = w->wav.numsamples - w->cursor;
         want  = (frames < avail) ? frames : avail;
         n     = want * ch;
         /* The companded and block-coded payloads are not readable a
          * sample at a time from the buffer - a-law is a curve and
          * ADPCM continues predictor state a block establishes - so
          * those go through rwav's decoder, which yields s16 natively
          * and steps into whichever block holds the cursor. */
         if (w->wav.format != RWAV_FORMAT_PCM
               && w->wav.format != RWAV_FORMAT_FLOAT)
         {
            want       = rwav_decode_s16(&w->wav, w->data, w->cursor,
                  want, out);
            w->cursor += want;
            produced   = want;
            break;
         }
         src   = w->data + w->wav.dataoffset + w->cursor * w->framesz;
         if (w->wav.bitspersample == 16)
         {
#ifndef MSB_FIRST
            /* Interleaved PCM16 on a little-endian host is already in
             * output order, and the loop below is a memcpy spelled
             * slowly - about thirteen instructions a sample to
             * reassemble what is already sitting there.  Measured at
             * 5x on a 69k-frame clip.  rwav_decode_s16 takes the same
             * shortcut under the same condition; this arm indexes by
             * framesz, which is the packed frame width, so the stride
             * condition rwav has to test is structural here. */
            memcpy(out, src, n * sizeof(int16_t));
#else
            /* rwav.h's accessors read the file's little-endian words a
             * byte at a time: right on either endianness, and safe
             * where an unaligned load would fault.  Big-endian keeps
             * the loop, whose byte assembly is the swab it needs. */
            for (i = 0; i < n; i++)
               out[i] = rwav_s16(src + i * 2);
#endif
         }
         else if (w->wav.bitspersample == 24)
         {
            /* packed three-byte samples, quantised by the shared
             * accessor so every reader of a 24-bit file rounds it
             * the same way */
            for (i = 0; i < n; i++)
               out[i] = rwav_s24_to_s16(src + i * 3);
         }
         else if (w->wav.bitspersample == 32) /* IEEE float -> s16 */
         {
            for (i = 0; i < n; i++)
               out[i] = audio_transfer_unit_to_s16(
                     rwav_f32(src + i * 4));
         }
         else /* 8-bit unsigned PCM -> signed 16-bit */
         {
            /* Biased before the shift, not after: (v - 128) is
             * negative for the lower half of the range and shifting a
             * negative value left is undefined.  src[i] << 8 is at
             * most 65280 and fits an int on every target this builds
             * for, so the same numbers come out of a defined
             * expression. */
            for (i = 0; i < n; i++)
               out[i] = (int16_t)(((int)src[i] << 8) - 32768);
         }
         w->cursor += want;
         produced   = want;
         break;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         return AUDIO_PROCESS_ERROR;
   }

   if (frames_out)
      *frames_out = produced;
   if (produced == 0 && audio_transfer_wall_stalled(data, type))
      return AUDIO_PROCESS_NEXT;   /* starved, not finished: retry     */
   return (produced == 0) ? AUDIO_PROCESS_END : AUDIO_PROCESS_NEXT;
}

int audio_transfer_read_f32(void *data, enum audio_type_enum type,
      float *out, size_t frames, size_t *frames_out)
{
   size_t produced = 0;

   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         return audio_transfer_wma_read((struct audio_transfer_wma*)data,
               out, NULL, frames, frames_out);
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl || !fl->handle)
            return AUDIO_PROCESS_ERROR;
         if (fl->time.enabled)
            return audio_transfer_flac_movie_read(fl, 0, NULL, out, frames, frames_out);
         produced = audio_transfer_flac_pull(fl, out, frames, 1);
         break;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         int got;
         if (!v || !v->handle)
            return AUDIO_PROCESS_ERROR;
         if (v->time.enabled)
            return audio_transfer_vorbis_movie_read(v, 0, NULL, out, frames, frames_out);
         if (v->packet)
         {
            produced = audio_transfer_vorbis_drain(v, 0, NULL, out, frames);
            break;
         }
         frames = audio_transfer_vorbis_cap(v, frames);
         (void)got;
         produced = audio_transfer_vorbis_stream_pull(v, 0, NULL, out, frames);
         v->emitted += (int64_t)produced;
         break;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (!m || !m->stream)
            return AUDIO_PROCESS_ERROR;
         if (m->seek_to >= 0)
         {
            int64_t at = audio_transfer_mp3_seek_to(m, m->seek_to, 0);
            m->seek_to = -1;
            if (at < 0)
               return AUDIO_PROCESS_ERROR;
         }
         produced = audio_transfer_mp3_read(m, 0, NULL, out, frames);
         break;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (!md || !md->handle)
            return AUDIO_PROCESS_ERROR;
         produced = rmodtracker_get_samples_float_interleaved(
               md->handle, out, frames);
         break;
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         const uint8_t *src;
         size_t avail, want, ch, i, n;
         if (!w || !w->opened)
            return AUDIO_PROCESS_ERROR;
         ch    = (size_t)w->wav.numchannels;
         avail = w->wav.numsamples - w->cursor;
         want  = (frames < avail) ? frames : avail;
         n     = want * ch;
         /* See the s16 path: these decode through rwav.  Their native
          * result is s16, so scaling it here loses nothing. */
         if (w->wav.format != RWAV_FORMAT_PCM
               && w->wav.format != RWAV_FORMAT_FLOAT)
         {
            /* Staged through a buffer this context owns rather than a
             * 64 KiB function-local static.  The static was shared by
             * every context - two block-coded voices in one mixer
             * callback wrote over each other - and larger than L1D, so
             * the scale below evicted the cache on every call.
             *
             * Per context and grown to the request, not blocked
             * through a small stack buffer: rwav_decode_s16 starts at
             * the block containing the frame it is given, so a chunk
             * smaller than a block re-decodes that block every call.
             * Measured at 88.2 -> 12.9 Mframe/s on MS ADPCM with a
             * 128-frame chunk.  One pass keeps the old access
             * pattern exactly. */
            size_t need = want * ch;
            if (w->scratch_cap < need)
            {
               int16_t *p = (int16_t*)realloc(w->scratch,
                     need * sizeof(int16_t));
               if (!p)
                  return AUDIO_PROCESS_ERROR;
               w->scratch     = p;
               w->scratch_cap = need;
            }
            want = rwav_decode_s16(&w->wav, w->data, w->cursor, want,
                  w->scratch);
            for (i = 0; i < want * ch; i++)
               out[i] = (float)w->scratch[i] * (1.0f / 32768.0f);
            w->cursor += want;
            produced   = want;
            break;
         }
         src   = w->data + w->wav.dataoffset + w->cursor * w->framesz;
         if (w->wav.bitspersample == 16)
         {
            for (i = 0; i < n; i++)
               out[i] = (float)rwav_s16(src + i * 2) * (1.0f / 32768.0f);
         }
         else if (w->wav.bitspersample == 24)
         {
            for (i = 0; i < n; i++)
               out[i] = rwav_s24_to_float(src + i * 3);
         }
         else if (w->wav.bitspersample == 32)
         {
            /* already unit-scale float: hand the file's samples
             * through unaltered, unclamped as the f32 paths are */
#ifndef MSB_FIRST
            memcpy(out, src, n * sizeof(float));
#else
            for (i = 0; i < n; i++)
               out[i] = rwav_f32(src + i * 4);
#endif
         }
         else /* 8-bit unsigned PCM */
         {
            for (i = 0; i < n; i++)
               out[i] = ((float)src[i] - 128.0f) * (1.0f / 128.0f);
         }
         w->cursor += want;
         produced   = want;
         break;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (!op || !op->handle || op->fmt == 1)
            return AUDIO_PROCESS_ERROR;
         if (op->time.enabled)
            return audio_transfer_opus_movie_read(op, out, frames, frames_out, 2);
         if (op->seek_to >= 0)
         {
            int64_t at = audio_transfer_opus_seek_to(op, op->seek_to, 2);
            op->seek_to = -1;
            if (at < 0)
               return AUDIO_PROCESS_ERROR;
         }
         while (produced < frames)
         {
            size_t take, direct = 0;
            /* With nothing pending, the next packet decodes straight
             * into the caller's buffer when it fits there whole. */
            int r = op->pend_frames ? (int)op->pend_frames
               : audio_transfer_opus_fill_into(op, 2,
                     out + produced * op->channels, frames - produced,
                     &direct);
            if (r < 0)
               return AUDIO_PROCESS_ERROR;
            if (r == 0)
               break;
            if (direct)
            {
               produced += direct;
               continue;
            }
            take = frames - produced;
            if (take > op->pend_frames)
               take = op->pend_frames;
            memcpy(out + produced * op->channels,
                  (const float*)op->pend + op->pend_pos * op->channels,
                  take * op->channels * sizeof(float));
            op->pend_pos    += take;
            op->pend_frames -= take;
            produced        += take;
         }
         break;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
         return audio_transfer_atrac_read((struct audio_transfer_atrac*)data,
               out, NULL, frames, frames_out);
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
         return audio_transfer_ac3_read((struct audio_transfer_ac3*)data,
               out, NULL, frames, frames_out);
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         size_t take;
         if (!l || !l->ready)
            return AUDIO_PROCESS_ERROR;
         if (l->fmt.kind == RLPCM_KIND_DVD)
            return audio_transfer_dvd_lpcm_read(l, out, NULL, frames, frames_out);
         take = audio_transfer_lpcm_frames_left(l, l->pos);
         if (take > frames)
            take = frames;
         if (take)
         {
            take = rlpcm_decode_f32(&l->fmt, l->buf + l->pos,
                  audio_transfer_lpcm_end(l) - l->pos, out, take);
            l->pos += (size_t)(((uint64_t)take * rlpcm_frame_bits(&l->fmt)) / 8);
         }
         if (frames_out)
            *frames_out = take;
         return take ? AUDIO_PROCESS_NEXT : AUDIO_PROCESS_END;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (!ac || !ac->handle)
            return AUDIO_PROCESS_ERROR;
         return audio_transfer_aac_read(ac, out, NULL, frames, frames_out);
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         return AUDIO_PROCESS_ERROR;
   }

   if (frames_out)
      *frames_out = produced;
   if (produced == 0 && audio_transfer_wall_stalled(data, type))
      return AUDIO_PROCESS_NEXT;   /* starved, not finished: retry     */
   return (produced == 0) ? AUDIO_PROCESS_END : AUDIO_PROCESS_NEXT;
}

size_t audio_transfer_buffer_read_end(void *data, enum audio_type_enum type)
{
   size_t lo = 0, hi = 0;
   if (!data) return 0;
   switch (type)
   {
#if defined(HAVE_RMP4) && defined(HAVE_RAC3)
      case AUDIO_TYPE_AC3:
         rmp4_read_span(((struct audio_transfer_ac3*)data)->demux, &lo, &hi);
         break;
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (m->wall && m->avail && m->avail < m->size)
            return m->size - m->avail < 16384 ? m->size : m->avail + 16384;
         return 0;
      }
#endif

#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         return rwma_stream_read_end(((struct audio_transfer_wma*)data)->stream);
#endif
#if defined(HAVE_RWEBM) && defined(HAVE_RFLAC)
      case AUDIO_TYPE_FLAC:
         rwebm_read_span(((struct audio_transfer_flac*)data)->demux, &lo, &hi);
         break;
#endif
#if defined(HAVE_RWEBM) && defined(HAVE_ROPUS)
      case AUDIO_TYPE_OPUS:
         rwebm_read_span(((struct audio_transfer_opus*)data)->demux, &lo, &hi);
         break;
#endif
#if defined(HAVE_RWEBM) && defined(HAVE_RVORBIS)
      case AUDIO_TYPE_VORBIS:
         rwebm_read_span(((struct audio_transfer_vorbis*)data)->demux, &lo, &hi);
         break;
#endif
#if defined(HAVE_RWEBM) && defined(HAVE_RAAC)
      case AUDIO_TYPE_AAC:
         rwebm_read_span(((struct audio_transfer_aac*)data)->wdemux, &lo, &hi);
         break;
#endif
      default: break;
   }
   (void)lo;
   return hi;
}

size_t audio_transfer_buffer_tell(void *data, enum audio_type_enum type)
{
   if (!data)
      return 0;
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         return data ? rwma_stream_tell(((struct audio_transfer_wma*)data)->stream) : 0;
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v =
               (struct audio_transfer_vorbis*)data;
         if (v->handle)
         {
#ifdef HAVE_RWEBM
            /* WebM: the packets are decoded where the demuxer points
             * at them in the caller's buffer, so its walk position is
             * the compressed frontier a feeder needs.  Monotonic
             * through playback, and back to the first cluster on a
             * rewind - never below the header material the demuxer
             * keeps borrowed pointers into. */
            if (v->demux)
               return rwebm_tell(v->demux);
#endif
            /* Demuxed: the frontier is a byte offset into the
             * caller's packet blob rather than into a buffer set by
             * set_buffer_ptr, there being none.  It is the same
             * quantity for the same purpose - how far the decoder has
             * read - and a feeder growing the set is the caller that
             * wants it.  The Opus and AAC demuxed arms still report
             * nothing here; this one has a packet cursor to report. */
            if (v->packets)
               return v->pkt_offset;
            /* Self-framed Ogg buffer: the demuxer consumes the buffer
             * as it plays, so the cursor kept alongside it is the
             * compressed frontier - and now a real one, the bytes
             * behind it being releasable rather than merely read. */
            if (v->stream)
               return v->stream_off;
            if (!v->packet)
               return (size_t)rvorbis_buffer_tell(v->handle);
         }
         return 0;
      }
#endif
#ifdef HAVE_RWAV
      case AUDIO_TYPE_WAV:
      {
         struct audio_transfer_wav *w =
               (struct audio_transfer_wav*)data;
         /* the payload is read in place, so the frame cursor is a byte
          * offset into the caller's buffer like any other arm's */
         if (!w->opened)
            return 0;
         /* A block-coded payload has no per-frame byte position; the
          * frontier is the block the cursor sits in. */
         if (w->wav.format == RWAV_FORMAT_MS_ADPCM
               || w->wav.format == RWAV_FORMAT_IMA_ADPCM)
            return w->wav.dataoffset
                 + (w->cursor / w->wav.samplesperblock + 1)
                 * (size_t)w->wav.blockalign;
         return w->wav.dataoffset + w->cursor * w->framesz;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl =
               (struct audio_transfer_flac*)data;
         if (!fl->handle)
            return 0;
#ifdef HAVE_RWEBM
         if (fl->demux)
         {
            /* The decoder borrows the current packet until its next feed. */
            if (fl->cur)
               return (size_t)(fl->cur - (const uint8_t*)fl->data);
            return rwebm_tell(fl->demux);
         }
#endif
         return fl->cursor;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m =
               (struct audio_transfer_mp3*)data;
         /* The stream consumes the buffer as it plays, so the cursor
          * kept alongside it is the compressed frontier - a real one,
          * the bytes behind it being releasable rather than merely
          * read.  It leads the decode position by at most the stream's
          * reassembly hold, which is the safe side for a feeder. */
         if (m->stream)
            return m->off;
         return 0;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op =
               (struct audio_transfer_opus*)data;
         /* Ogg buffer mode walks pages forward from the caller's
          * buffer; pg_off is the current page's byte offset, the
          * compressed frontier the feeder needs. */
         if (op->handle && op->ogg)
            return op->pg_off;
#ifdef HAVE_RWEBM
         /* WebM likewise: the packets are decoded where the demuxer
          * points at them in the caller's buffer, so its walk position
          * is that frontier. */
         if (op->handle && op->demux)
            return rwebm_tell(op->demux);
#endif
         /* Demuxed: a byte offset into the caller's packet blob,
          * there being no set_buffer_ptr buffer to hold one.  The
          * same quantity for the same purpose as the two above - how
          * far the decoder has read - and what a feeder growing the
          * set wants.  The Vorbis arm reports it for its blob; this
          * one was left behind when that was added. */
         if (op->handle && op->packets)
            return op->pkt_offset;
         return 0;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         return a ? a->pos : 0;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         return a ? a->pos : 0;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         return l ? l->pos : 0;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac =
               (struct audio_transfer_aac*)data;
         /* The ADTS buffer path walks the caller's buffer linearly;
          * adts_pos is the next frame's byte offset, the compressed
          * frontier a feeder needs. */
         if (ac->handle && ac->adts)
            return ac->adts_pos;
         /* Demuxed: see the Opus arm - a byte offset into the
          * caller's packets rather than into a buffer it did not
          * set. */
         if (ac->handle && ac->packets)
            return ac->pkt_offset;
#ifdef HAVE_RMP4
         /* MP4: the packets are decoded where the demuxer points at
          * them in the caller's buffer, so its consumed offset is the
          * compressed frontier a feeder needs - the same quantity
          * rwebm_tell reports for the WebM arms.  Without this a
          * windowed M4A stream could be given a bound but the feeder
          * could never learn where to move it. */
         if (ac->handle && ac->demux)
            return rmp4_consumed(ac->demux);
#endif
#ifdef HAVE_RWEBM
         if (ac->handle && ac->wdemux)
            return rwebm_tell(ac->wdemux);
#endif
         return 0;
      }
#endif
      default:
         break;
   }
   return 0;
}

#ifdef HAVE_RVORBIS
/* Sample-accurate seek on a packet-fed stream.
 *
 * A Vorbis packet says how many frames it contributes
 * (rvorbis_packet_frames) without being decoded, so the walk to a
 * target costs two bytes a packet and no decoding at all.  The count
 * cannot come from the container: Matroska timestamps a block to the
 * millisecond, which at 44.1 kHz is 44 frames of slack, and it carries
 * no granule position to ask instead.  Counting the packets is the
 * only way to land on the right sample.
 *
 * Priming with packet m - resetting, then decoding m first - makes m
 * yield nothing and the audio resume at the position a linear decode
 * would have reached after m.  So the walk looks for the last m whose
 * position is still at or before the target, and the frames between
 * that and the target are decoded and dropped.  One packet of priming
 * is all Vorbis needs: it carries no prediction across frames, only
 * the overlap window, so the output after it is not converging on the
 * playthrough's, it is identical to it.
 *
 * Two passes rather than one, so that no packet pointer is held across
 * a read - rwebm documents a packet as valid only until the next call.
 * Both are header walks and the second stops at m. */
/* Put the packet walk back at the first packet, whichever source it
 * comes from. */
static void audio_transfer_vorbis_to_head(struct audio_transfer_vorbis *v)
{
   v->time.first_ready = v->time.ready = v->time.eof = 0;
   v->time.end = v->time.pending = v->time.position = 0;
   v->time_pending = 0;
   v->yielded = 0;
#ifdef HAVE_RWEBM
   if (v->demux)
   {
      rwebm_rewind(v->demux);
      if (v->avail) { v->avail = 1; rwebm_set_avail(v->demux, 1); }
   }
#endif
   if (v->ogg_pkt)
   {
      /* Back to the first page, and past the three headers, which are
       * not audio and are not decoded again. */
      const uint8_t *pd = NULL;
      uint32_t       pl = 0;
      int            i;
      v->pg_off   = 0;
      v->seg_idx  = 0;
      v->body_off = 0;
      for (i = 0; i < 3; i++)
         audio_transfer_vorbis_ogg_pkt(v, &pd, &pl);
   }
   v->pkt_index  = 0;
   v->pkt_offset = 0;
}

static bool audio_transfer_vorbis_seek_walk(struct audio_transfer_vorbis *v,
      int64_t target)
{
   const uint8_t *pd  = NULL;
   uint32_t       pl  = 0;
   int64_t        pad = 0;
   int64_t        pos = 0;
   int            n, m = 1, i, r;
   int            reached = 0;
   /* Sink for the frames walked past.  On the stack: this was a
    * function-local static shared by every context, and a seek on one
    * mixer voice wrote into it while another was seeking too.  Small
    * because the loop below iterates. */
   int16_t        skip[256];

   /* Pass 1: where does each packet leave the stream? */
   audio_transfer_vorbis_to_head(v);
   n = 0;
   for (;;)
   {
      int fr;
      r = audio_transfer_vorbis_pull(v, &pd, &pl, &pad);
      if (r == -2)
      {
         /* The walk met the resident wall before the target.  Not a
          * malformed stream - the bytes have not arrived yet - so the
          * seek fails and can be tried again once they have. */
         audio_transfer_vorbis_to_head(v);
         rvorbis_packet_reset(v->handle);
         v->emitted = 0;
         return false;
      }
      if (r != 1)
         break;
      n++;
      fr = rvorbis_packet_frames(v->handle, pd, pl);
      if (fr < 0)
         return false;
      /* A decode's first packet yields nothing, so the position only
       * starts moving with the second. */
      if (n < 2)
         continue;
      if (pos + fr > target)
      {
         reached = 1;
         break;
      }
      pos += fr;
      m    = n;
   }
   /* Running out of packets short of the target is a seek past the
    * end, not a position. */
   if (!reached && pos < target)
   {
      audio_transfer_vorbis_to_head(v);
      rvorbis_packet_reset(v->handle);
      v->emitted = 0;
      return false;
   }

   /* Pass 2: walk to m without decoding, then prime with it. */
   rvorbis_packet_reset(v->handle);
   audio_transfer_vorbis_to_head(v);
   for (i = 0; i < m; i++)
      if (audio_transfer_vorbis_pull(v, &pd, &pl, &pad) != 1)
         return false;
   if (rvorbis_packet_decode(v->handle, pd, pl, 1) < 0)
      return false;
   v->emitted = pos;

   /* Drop the remainder through the ordinary drain, so the frames
    * counted here are the frames a playthrough emits. */
   while (v->emitted < target)
   {
      size_t cap  = 2048 / (size_t)v->channels;
      size_t want = (size_t)(target - v->emitted);
      if (!cap)
         return false;
      if (want > cap)
         want = cap;
      if (!audio_transfer_vorbis_drain(v, 1, skip, NULL, want))
         return false;   /* the stream ended before the target */
   }
   return true;
}
#endif

bool audio_transfer_seek(void *data, enum audio_type_enum type,
      uint64_t frame)
{
   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
      {
         struct audio_transfer_wma *a = (struct audio_transfer_wma*)data;
         if (!a || !a->stream || frame) return false;
         rwma_stream_rewind(a->stream);
         memset(&a->pending, 0, sizeof(a->pending)); a->offset = 0;
         return true;
      }
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (!fl || !fl->handle)
            return false;
         if (fl->time.enabled)
         {
            int result;
            if (!frame)
            {
               if (!audio_transfer_info(fl, type, NULL, NULL, NULL)) return false;
               audio_transfer_flac_movie_head(fl);
               fl->seek_pending = 0;
               return true;
            }
            if (!audio_transfer_seek_begin(data, type, frame)) return false;
            do
            {
               result = audio_transfer_seek_step(data, type);
               if (!result && fl->wall) return false;
            } while (!result);
            return result == 1;
         }
         /* Seeking restarts the stream and decodes forward.  The
          * decoder cannot fetch anything itself, and only this side
          * knows how to rewind a container, so the walk belongs here.
          * A resident buffer makes it one pass over already-present
          * bytes; a container arm pays a re-walk of its own index,
          * which is what it paid before. */
         return audio_transfer_flac_seek_to(fl,
               (uint64_t)frame) != 0;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         if (!v || !v->handle)
            return false;
         if (v->time.enabled && frame)
         {
            int result;
            if (!audio_transfer_seek_begin_format(data, type, frame, true)) return false;
            do
            {
               result = audio_transfer_seek_step(data, type);
               if (!result && v->wall) return false;
            } while (!result);
            return result == 1;
         }
         if (v->packet)
         {
            /* Count the packets to the target.  A windowed context
             * can be walked too: what set_avail bounds is a prefix
             * that only grows, not a window that slides, so every
             * byte below it stays readable and a target within it is
             * as reachable as on a resident file.  Only a target past
             * the wall is not, and the walk says so by meeting it. */
            if (frame != 0 && v->channels > 0)
               return audio_transfer_vorbis_seek_walk(v, (int64_t)frame);
            if (frame != 0)
               return false;
            /* Every source the packet path can have, and that is more
             * than the blob cursor: an Ogg page feeder has a page,
             * segment and body offset of its own, and leaving those
             * where the last read left them means the rewound stream
             * hands out nothing. */
            audio_transfer_vorbis_to_head(v);
            rvorbis_packet_reset(v->handle);
            v->emitted    = 0;
            v->seek_phase = 0;
            return true;
         }
         /* The emission bound is counted against what has been handed
          * out, so a seek that moves the stream has to move that count
          * with it.  Left alone, a loop back to the start reaches the
          * bound immediately and the stream reads as ended for good. */
         return audio_transfer_vorbis_stream_seek(v, frame);
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (!m || !m->stream)
            return false;
         /* Where the length is known, refuse to be sent past it rather
          * than walk to the end and report failure from there. */
         if (frame > (uint64_t)INT64_MAX ||
             (m->limit >= 0 && (int64_t)frame > m->limit) ||
             (frame && m->avail < m->size))
            return false;
         if (frame == 0)
         {
            /* Priming can resume after a window refill. */
            rmp3_stream_reset(m->stream);
            m->off       = 0;
            m->eof_sent  = 0;
            m->wall      = 0;
            m->seek_to   = -1;
            m->trim_left = m->start_trim;
            m->emitted   = 0;
            return true;
         }
         /* Recorded, not done: see seek_to.  Frame numbers here are of
          * the played audio, so the priming sits before frame 0 and the
          * walk at the read covers both. */
         m->seek_to = (int64_t)frame;
         return true;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (!md || !md->handle)
            return false;
         if (frame == 0) /* loop-to-start: rewind always succeeds */
         {
            rmodtracker_rewind(md->handle);
            return true;
         }
         /* Sequenced, so the replayer restarts and works forward with
          * the mixing skipped.  That is proportional to the distance
          * and runs here, on the calling thread; it lands exactly, and
          * fails only if the song ends before the target does. */
         return rmodtracker_seek(md->handle, (int)frame) == (int)frame;
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
      {
         struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
         if (!w || !w->opened || frame > (uint64_t)w->wav.numsamples)
            return false;
         w->cursor = (size_t)frame;
         return true;
      }
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (!op || !op->handle)
            return false;
         if (frame == 0)
         {
            audio_transfer_opus_to_head(op);
            op->seek_to = -1;
            op->fmt     = 0;
            op->seek_pending = op->seek_walk = 0;
            return true;
         }
         /* Where the length is known, refuse to be sent past it rather
          * than walk to the end and report failure from there. */
         if (frame > ((~(uint64_t)0) >> 1)
               || (op->time.enabled ? (op->time.total >= 0 && frame > (uint64_t)op->time.total)
                  : (op->limit >= 0 && frame > (uint64_t)op->limit)))
            return false;
         /* Recorded, not done: see seek_to. */
         op->seek_to = (int64_t)frame;
         return true;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         if (!a || !a->raw)
            return false;
         return audio_transfer_atrac_seek_to(a, frame);
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         if (!a || !a->dec)
            return false;
         return audio_transfer_ac3_seek_to(a, frame);
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
      {
         struct audio_transfer_lpcm *l = (struct audio_transfer_lpcm*)data;
         size_t at;
         if (!l || !l->ready)
            return false;
         if (frame > l->total_frames)
            return false;
         if (l->fmt.kind == RLPCM_KIND_DVD)
         {
            size_t block;
            unsigned count;
            if (!rlpcm_dvd_block_shape(&l->fmt, &block, &count)) return false;
            at = l->fmt.header_bytes + (size_t)(frame / count) * block;
            if (at > audio_transfer_lpcm_end(l)) return false;
            l->pending_n = l->pending_off = 0;
            l->skip = (unsigned)(frame % count);
         }
         else
            at = l->fmt.header_bytes
               + (size_t)(((uint64_t)frame * rlpcm_frame_bits(&l->fmt)) / 8);
         if (at > audio_transfer_lpcm_end(l))
            return false;
         l->pos = at;
         return true;
      }
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (!ac || !ac->handle)
            return false;
         if (frame == 0)
         {
            audio_transfer_aac_to_head(ac);
            ac->seek_pending = false;
            ac->seek_phase = 0;
            return true;
         }
         if (ac->time.enabled)
         {
            int result;
            if (!audio_transfer_seek_begin(data, type, frame)) return false;
            do
            {
               result = audio_transfer_seek_step(data, type);
               if (!result && ac->wall) return false;
            } while (!result);
            return result == 1;
         }
         /* Where the length is known, refuse to be sent past it rather
          * than walk to the end and report failure from there. */
         if (ac->limit >= 0 && (int64_t)frame > ac->limit)
            return false;
         return audio_transfer_aac_seek_to(ac, (int64_t)frame)
               == (int64_t)frame;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }
   return false;
}

void audio_transfer_free(void *data, enum audio_type_enum type)
{
   if (!data)
      return;

   switch (type)
   {
#ifdef HAVE_RWMA
      case AUDIO_TYPE_WMA:
         if (data) rwma_stream_close(((struct audio_transfer_wma*)data)->stream);
         break;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_TYPE_FLAC:
      {
         struct audio_transfer_flac *fl = (struct audio_transfer_flac*)data;
         if (fl->handle)
            rflac_free(fl->handle);
#ifdef HAVE_RWEBM
         if (fl->demux)
            rwebm_close(fl->demux);
#endif
         break;
      }
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_TYPE_VORBIS:
      {
         struct audio_transfer_vorbis *v = (struct audio_transfer_vorbis*)data;
         /* handle is borrowed from the stream where there is one, so it
          * must not also be closed. */
         if (v->stream)
            rvorbis_stream_free(v->stream);
         else if (v->handle)
            rvorbis_close(v->handle);
#ifdef HAVE_RWEBM
         if (v->demux)
            rwebm_close(v->demux);
#endif
         break;
      }
#endif
#ifdef HAVE_RMP3
      case AUDIO_TYPE_MP3:
      {
         struct audio_transfer_mp3 *m = (struct audio_transfer_mp3*)data;
         if (m->stream)
            rmp3_stream_free(m->stream);
         break;
      }
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_TYPE_MOD:
      {
         struct audio_transfer_mod *md = (struct audio_transfer_mod*)data;
         if (md->handle)
            rmodtracker_close(md->handle);
         break;
      }
#endif
      case AUDIO_TYPE_WAV:
#ifdef HAVE_RWAV
         /* rwav_parse allocates nothing and the samples were read in
          * place; the f32 staging buffer is the one thing this arm
          * ever owns */
         {
            struct audio_transfer_wav *w = (struct audio_transfer_wav*)data;
            if (w)
               free(w->scratch);
         }
         break;
#endif
#ifdef HAVE_ROPUS
      case AUDIO_TYPE_OPUS:
      {
         struct audio_transfer_opus *op = (struct audio_transfer_opus*)data;
         if (op && op->handle)
            ropus_close(op->handle);
#ifdef HAVE_RWEBM
         if (op && op->demux)
            rwebm_close(op->demux);
#endif
         if (op)
         {
            free(op->pend);
            free(op->asm_buf);
         }
         break;
      }
#endif
#if defined(HAVE_RATRAC3) || defined(HAVE_RATRAC3P)
      case AUDIO_TYPE_ATRAC:
      {
         struct audio_transfer_atrac *a = (struct audio_transfer_atrac*)data;
         if (a)
         {
#ifdef HAVE_RATRAC3P
            ratrac3p_free(a->d3p);
#endif
#ifdef HAVE_RATRAC3
            ratrac3_free(a->d3);
#endif
            free(a->raw);
            free(a->pend);
         }
         break;
      }
#endif
#ifdef HAVE_RAC3
      case AUDIO_TYPE_AC3:
      {
         struct audio_transfer_ac3 *a = (struct audio_transfer_ac3*)data;
         if (a)
         {
            free(a->raw);
            free(a->pend);
            rac3_decoder_free(a->dec);
#ifdef HAVE_RMP4
            rmp4_close(a->demux);
#endif
         }
         break;
      }
#endif
#ifdef HAVE_RLPCM
      case AUDIO_TYPE_LPCM:
         /* Nothing of its own: the samples are the caller's buffer and
          * the reader is a position in it. */
         break;
#endif
#ifdef HAVE_RAAC
      case AUDIO_TYPE_AAC:
      {
         struct audio_transfer_aac *ac = (struct audio_transfer_aac*)data;
         if (ac && ac->handle)
            raac_close(ac->handle);
#ifdef HAVE_RMP4
         if (ac && ac->demux)
            rmp4_close(ac->demux);
#endif
#ifdef HAVE_RWEBM
         if (ac && ac->wdemux)
            rwebm_close(ac->wdemux);
#endif
         break;
      }
#endif
      case AUDIO_TYPE_NONE:
      default:
         break;
   }

   free(data);
}

enum audio_type_enum audio_transfer_mp4_audio_track_type(const void *buf,
      size_t len, size_t avail, int track)
{
   enum audio_type_enum type = AUDIO_TYPE_NONE;
#ifdef HAVE_RMP4
   rmp4_t *m;
   int i;
   if (!buf || track < -1) return type;
   m = rmp4_open_memory_avail((const uint8_t*)buf, len, avail ? avail : len,
         NULL, NULL, NULL);
   if (!m) return type;
   for (i = 0; i < rmp4_num_tracks(m); i++)
   {
      const rmp4_track *t = rmp4_get_track(m, i);
      if (!t || t->type != RMP4_TRACK_AUDIO || (track >= 0 && track != i)) continue;
#ifdef HAVE_RAAC
      if (t->codec == RMP4_CODEC_AAC) type = AUDIO_TYPE_AAC;
#endif
#ifdef HAVE_RAC3
      if (t->codec == RMP4_CODEC_AC3) type = AUDIO_TYPE_AC3;
#endif
      if (type != AUDIO_TYPE_NONE) break;
   }
   rmp4_close(m);
#else
   (void)buf; (void)len; (void)avail; (void)track;
#endif
   return type;
}
