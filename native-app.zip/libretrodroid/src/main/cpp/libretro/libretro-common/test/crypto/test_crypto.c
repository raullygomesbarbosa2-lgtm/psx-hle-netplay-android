/* Copyright  (C) 2026 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (test_crypto.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifdef CHECK_SHIM
#include "../check_shim.h"
#else
#include <check.h>
#endif
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


#include <crypto/crypto.h>
#include <crypto/kdf.h>
#include <crypto/pk.h>
#include <crypto/x509.h>
#include <net/net_krb5.h>
#include "../../net/cacert.h"
#include "test_x509_vectors.h"
#include <lrc_hash.h>

#define SUITE_NAME "crypto"

/* Known-answer tests. AES: FIPS 197 appendix C; CMAC: RFC 4493;
 * GCM: the GCM spec test cases 13/14/16/17/18 plus test case 2;
 * ChaCha20 / Poly1305 / AEAD: RFC 8439 sections 2.4.2, 2.5.2, 2.8.2;
 * HMAC: RFC 4231 case 2; HKDF: RFC 5869 case 1; PBKDF2: the
 * commonly published SHA-256 vectors for "password"/"salt". */

static size_t unhex(uint8_t *out, size_t out_len, const char *hex)
{
   size_t n = 0;
   while (hex[0] && hex[1] && n < out_len)
   {
      unsigned v;
      char tmp[3];
      tmp[0] = hex[0]; tmp[1] = hex[1]; tmp[2] = '\0';
      sscanf(tmp, "%x", &v);
      out[n++] = (uint8_t)v;
      hex += 2;
   }
   return n;
}

static void ck_hex(const uint8_t *got, size_t len, const char *hex)
{
   uint8_t want[256];
   size_t wl = unhex(want, sizeof(want), hex);
   ck_assert_uint_eq(wl, len);
   ck_assert(memcmp(got, want, len) == 0);
}

static const char *aes_pt   = "00112233445566778899aabbccddeeff";
static const char *cmac_key = "2b7e151628aed2a6abf7158809cf4f3c";
static const char *cmac_msg =
   "6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e51"
   "30c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710";
static const char *gcm_key  =
   "feffe9928665731c6d6a8f9467308308feffe9928665731c6d6a8f9467308308";
static const char *gcm_pt   =
   "d9313225f88406e5a55909c5aff5269a86a7a9531534f7da2e4c303d8a318a72"
   "1c3c0c95956809532fcf0e2449a6b525b16aedf5aa0de657ba637b39";
static const char *gcm_aad  = "feedfacedeadbeeffeedfacedeadbeefabaddad2";
static const char *chacha_pt =
   "Ladies and Gentlemen of the class of '99: If I could offer you "
   "only one tip for the future, sunscreen would be it.";

START_TEST (test_aes_block)
{
   struct aes_ctx ctx;
   uint8_t key[32], pt[16], ct[16];
   unsigned i;
   for (i = 0; i < 32; i++)
      key[i] = (uint8_t)i;
   unhex(pt, 16, aes_pt);

   ck_assert_int_eq(aes_init(&ctx, key, 16), 0);
   aes_encrypt_block(&ctx, pt, ct);
   ck_hex(ct, 16, "69c4e0d86a7b0430d8cdb78070b4c55a");

   ck_assert_int_eq(aes_init(&ctx, key, 24), 0);
   aes_encrypt_block(&ctx, pt, ct);
   ck_hex(ct, 16, "dda97ca4864cdfe06eaf70a0ec0d7191");

   ck_assert_int_eq(aes_init(&ctx, key, 32), 0);
   aes_encrypt_block(&ctx, pt, ct);
   ck_hex(ct, 16, "8ea2b7ca516745bfeafc49904b496089");

   /* in-place */
   memcpy(ct, pt, 16);
   aes_encrypt_block(&ctx, ct, ct);
   ck_hex(ct, 16, "8ea2b7ca516745bfeafc49904b496089");

   ck_assert_int_eq(aes_init(&ctx, key, 20), -1);
}
END_TEST

START_TEST (test_aes_cmac)
{
   struct aes_ctx ctx;
   uint8_t key[16], msg[64], mac[16];
   unhex(key, 16, cmac_key);
   unhex(msg, 64, cmac_msg);
   ck_assert_int_eq(aes_init(&ctx, key, 16), 0);
   aes_cmac(&ctx, msg,  0, mac); ck_hex(mac, 16, "bb1d6929e95937287fa37d129b756746");
   aes_cmac(&ctx, msg, 16, mac); ck_hex(mac, 16, "070a16b46b4d4144f79bdd9dd04a287c");
   aes_cmac(&ctx, msg, 40, mac); ck_hex(mac, 16, "dfa66747de9ae63030ca32611497c827");
   aes_cmac(&ctx, msg, 64, mac); ck_hex(mac, 16, "51f0bebf7e3b9d92fc49741779363cfe");
}
END_TEST

static void gcm_case(const char *iv_hex, const char *want_hex)
{
   struct aes_gcm_ctx g;
   uint8_t key[32], iv[64], pt[60], aad[20], ct[60], tag[16], dec[60];
   size_t ivl = unhex(iv, sizeof(iv), iv_hex);
   unhex(key, 32, gcm_key);
   unhex(pt, 60, gcm_pt);
   unhex(aad, 20, gcm_aad);
   ck_assert_int_eq(aes_gcm_init(&g, key, 32), 0);
   ck_assert_int_eq(aes_gcm_encrypt(&g, iv, ivl, aad, 20, pt, 60, ct, tag), 0);
   {
      uint8_t both[76];
      memcpy(both, ct, 60);
      memcpy(both + 60, tag, 16);
      ck_hex(both, 76, want_hex);
   }
   ck_assert_int_eq(aes_gcm_decrypt(&g, iv, ivl, aad, 20, ct, 60, tag, dec), 0);
   ck_assert(memcmp(dec, pt, 60) == 0);
   tag[3] ^= 1;
   memset(dec, 0xa5, 60);
   ck_assert_int_eq(aes_gcm_decrypt(&g, iv, ivl, aad, 20, ct, 60, tag, dec), -1);
   ck_assert_uint_eq(dec[0], 0xa5);
}

START_TEST (test_aes_gcm)
{
   struct aes_gcm_ctx g;
   uint8_t key[32], iv[12], zero[16], ct[16], tag[16];
   memset(key, 0, 32); memset(iv, 0, 12); memset(zero, 0, 16);

   ck_assert_int_eq(aes_gcm_init(&g, key, 32), 0);
   ck_assert_int_eq(aes_gcm_encrypt(&g, iv, 12, NULL, 0, NULL, 0, ct, tag), 0);
   ck_hex(tag, 16, "530f8afbc74536b9a963b4f1c4cb738b");
   ck_assert_int_eq(aes_gcm_encrypt(&g, iv, 12, NULL, 0, zero, 16, ct, tag), 0);
   ck_hex(ct,  16, "cea7403d4d606b6e074ec5d3baf39d18");
   ck_hex(tag, 16, "d0d1c8a799996bf0265b98b5d48ab919");

   ck_assert_int_eq(aes_gcm_init(&g, key, 16), 0);
   ck_assert_int_eq(aes_gcm_encrypt(&g, iv, 12, NULL, 0, zero, 16, ct, tag), 0);
   ck_hex(ct,  16, "0388dace60b6a392f328c2b971b2fe78");
   ck_hex(tag, 16, "ab6e47d42cec13bdf53a67b21257bddf");

   gcm_case("cafebabefacedbaddecaf888",
      "522dc1f099567d07f47f37a32a84427d643a8cdcbfe5c0c97598a2bd2555d1aa"
      "8cb08e48590dbb3da7b08b1056828838c5f61e6393ba7a0abcc9f662"
      "76fc6ece0f4e1768cddf8853bb2d551b");
   gcm_case("cafebabefacedbad",
      "c3762df1ca787d32ae47c13bf19844cbaf1ae14d0b976afac52ff7d79bba9de0"
      "feb582d33934a4f0954cc2363bc73f7862ac430e64abe499f47c9b1f"
      "3a337dbf46a792c45e454913fe2ea8f2");
   gcm_case("9313225df88406e555909c5aff5269aa6a7a9538534f7da1e4c303d2a318a728"
            "c3c0c95156809539fcf0e2429a6b525416aedbf5a0de6a57a637b39b",
      "5a8def2f0c9e53f1f75d7853659e2a20eeb2b22aafde6419a058ab4f6f746bf4"
      "0fc0c3b780f244452da3ebf1c5d82cdea2418997200ef82e44ae7e3f"
      "a44a8266ee1c8eb0c8b5d4cf5ae9f19a");
}
END_TEST

START_TEST (test_chacha20)
{
   uint8_t key[32], nonce[12], ct[114], dec[114];
   unsigned i;
   for (i = 0; i < 32; i++)
      key[i] = (uint8_t)i;
   unhex(nonce, 12, "000000000000004a00000000");
   chacha20_xor(key, nonce, 1, (const uint8_t*)chacha_pt, ct, 114);
   ck_hex(ct, 114,
      "6e2e359a2568f98041ba0728dd0d6981e97e7aec1d4360c20a27afccfd9fae0b"
      "f91b65c5524733ab8f593dabcd62b3571639d624e65152ab8f530c359f0861d8"
      "07ca0dbf500d6a6156a38e088a22b65e52bc514d16ccf806818ce91ab7793736"
      "5af90bbf74a35be6b40b8eedf2785e42874d");
   chacha20_xor(key, nonce, 1, ct, dec, 114);
   ck_assert(memcmp(dec, chacha_pt, 114) == 0);
}
END_TEST

START_TEST (test_poly1305)
{
   struct poly1305_ctx p;
   uint8_t key[32], tag[16];
   const char *msg = "Cryptographic Forum Research Group";
   unhex(key, 32, "85d6be7857556d337f4452fe42d506a80103808afb0db2fd4abff6af4149f51b");
   poly1305_auth(tag, (const uint8_t*)msg, 34, key);
   ck_hex(tag, 16, "a8061dc1305136c6c22b8baf0c0127a9");

   /* same thing fed in odd-sized pieces */
   poly1305_init(&p, key);
   poly1305_update(&p, (const uint8_t*)msg, 7);
   poly1305_update(&p, (const uint8_t*)msg + 7, 20);
   poly1305_update(&p, (const uint8_t*)msg + 27, 7);
   poly1305_final(&p, tag);
   ck_hex(tag, 16, "a8061dc1305136c6c22b8baf0c0127a9");
}
END_TEST

START_TEST (test_aead)
{
   uint8_t key[32], nonce[12], aad[12], ct[114], tag[16], dec[114];
   unsigned i;
   for (i = 0; i < 32; i++)
      key[i] = (uint8_t)(0x80 + i);
   unhex(nonce, 12, "070000004041424344454647");
   unhex(aad, 12, "50515253c0c1c2c3c4c5c6c7");

   ck_assert_int_eq(aead_encrypt(AEAD_CHACHA20_POLY1305, key, 32, nonce, 12,
         aad, 12, (const uint8_t*)chacha_pt, 114, ct, tag, 16), 0);
   ck_hex(ct, 114,
      "d31a8d34648e60db7b86afbc53ef7ec2a4aded51296e08fea9e2b5a736ee62d6"
      "3dbea45e8ca9671282fafb69da92728b1a71de0a9e060b2905d6a5b67ecd3b36"
      "92ddbd7f2d778b8c9803aee328091b58fab324e4fad675945585808b4831d7bc"
      "3ff4def08e4b7a9de576d26586cec64b6116");
   ck_hex(tag, 16, "1ae10b594f09e26a7e902ecbd0600691");
   ck_assert_int_eq(aead_decrypt(AEAD_CHACHA20_POLY1305, key, 32, nonce, 12,
         aad, 12, ct, 114, tag, 16, dec), 0);
   ck_assert(memcmp(dec, chacha_pt, 114) == 0);
   aad[0] ^= 1;
   ck_assert_int_eq(aead_decrypt(AEAD_CHACHA20_POLY1305, key, 32, nonce, 12,
         aad, 12, ct, 114, tag, 16, dec), -2);
   aad[0] ^= 1;

   /* AES-256-GCM through the same front, in place, round trip */
   memcpy(ct, chacha_pt, 114);
   ck_assert_int_eq(aead_encrypt(AEAD_AES256_GCM, key, 32, nonce, 12,
         aad, 12, ct, 114, ct, tag, 16), 0);
   ck_assert(memcmp(ct, chacha_pt, 114) != 0);
   ck_assert_int_eq(aead_decrypt(AEAD_AES256_GCM, key, 32, nonce, 12,
         aad, 12, ct, 114, tag, 16, ct), 0);
   ck_assert(memcmp(ct, chacha_pt, 114) == 0);

   /* parameter checks */
   ck_assert_int_eq(aead_encrypt(AEAD_AES256_GCM, key, 16, nonce, 12,
         aad, 12, ct, 114, ct, tag, 16), -1);
   ck_assert_int_eq(aead_encrypt(AEAD_AES256_GCM, key, 32, nonce, 8,
         aad, 12, ct, 114, ct, tag, 16), -1);
   ck_assert_int_eq(aead_encrypt((enum aead_alg)7, key, 32, nonce, 12,
         aad, 12, ct, 114, ct, tag, 16), -1);
}
END_TEST

START_TEST (test_hmac_hkdf_pbkdf2)
{
   uint8_t mac[32], ikm[22], salt[13], info[10], okm[42], prk[32], dk[32];
   struct hmac_sha256_ctx h;
   unsigned i;

   hmac_sha256((const uint8_t*)"Jefe", 4,
         (const uint8_t*)"what do ya want for nothing?", 28, mac);
   ck_hex(mac, 32, "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");

   /* streaming, split mid-message */
   hmac_sha256_init(&h, (const uint8_t*)"Jefe", 4);
   hmac_sha256_update(&h, (const uint8_t*)"what do ya", 10);
   hmac_sha256_update(&h, (const uint8_t*)" want for nothing?", 18);
   hmac_sha256_final(&h, mac);
   ck_hex(mac, 32, "5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843");

   {
      struct hmac_sha384_ctx h3;
      uint8_t m3[48];
      hmac_sha384_init(&h3, (const uint8_t*)"Jefe", 4);
      hmac_sha384_update(&h3, (const uint8_t*)"what do ya want for nothing?", 28);
      hmac_sha384_final(&h3, m3);
      ck_hex(m3, 48, "af45d2e376484031617f78d2b58a6b1b9c7ef464f5a01b47e42ec3736322445e8e2240ca5e69e2c78b3239ecfab21649");
   }

   /* key longer than a block goes through the hash */
   {
      uint8_t longkey[131];
      memset(longkey, 0xaa, sizeof(longkey));
      hmac_sha256(longkey, sizeof(longkey),
            (const uint8_t*)"Test Using Larger Than Block-Size Key - Hash Key First", 54, mac);
      ck_hex(mac, 32, "60e431591ee0b67f0d8a26aacbf5b77f8e0bc6213728c5140546040f0ee37f54");
   }

   memset(ikm, 0x0b, 22);
   for (i = 0; i < 13; i++) salt[i] = (uint8_t)i;
   for (i = 0; i < 10; i++) info[i] = (uint8_t)(0xf0 + i);
   hkdf_sha256_extract(salt, 13, ikm, 22, prk);
   ck_hex(prk, 32, "077709362c2e32df0ddc3f0dc47bba6390b6c73bb50f9c3122ec844ad7c2b3e5");
   ck_assert_int_eq(hkdf_sha256(salt, 13, ikm, 22, info, 10, okm, 42), 0);
   ck_hex(okm, 42, "3cb25f25faacd57a90434f64d0362f2a2d2d0a90cf1a5a4c5db02d56ecc4c5bf34007208d5b887185865");
   ck_assert_int_eq(hkdf_sha256_expand(prk, 32, info, 10, okm, 255 * 32 + 1), -1);

   ck_assert_int_eq(pbkdf2_hmac_sha256((const uint8_t*)"password", 8,
         (const uint8_t*)"salt", 4, 1, dk, 32), 0);
   ck_hex(dk, 32, "120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b");
   ck_assert_int_eq(pbkdf2_hmac_sha256((const uint8_t*)"password", 8,
         (const uint8_t*)"salt", 4, 4096, dk, 32), 0);
   ck_hex(dk, 32, "c5e478d59288c841aa530db6845c4c8d962893a001ce4e11a4963873aa98134a");
   ck_assert_int_eq(pbkdf2_hmac_sha256((const uint8_t*)"password", 8,
         (const uint8_t*)"salt", 4, 0, dk, 32), -1);
   /* HKDF-SHA384 known answer (RFC 5869 has SHA-256 only): the RFC's
    * test case 1 inputs, checked against an independent HMAC/SHA-384
    * implementation */
   {
      static const uint8_t okm384[48] = {0x9b,0x50,0x97,0xa8,0x60,0x38,0xb8,0x05,0x30,0x90,0x76,0xa4,0x4b,0x3a,0x9f,0x38,0x06,0x3e,0x25,0xb5,0x16,0xdc,0xbf,0x36,0x9f,0x39,0x4c,0xfa,0xb4,0x36,0x85,0xf7,0x48,0xb6,0x45,0x77,0x63,0xe4,0xf0,0x20,0x4f,0xc5,0xd9,0x5d,0x1d,0xa3,0xe6,0x25};
      uint8_t ikm[22], salt[13], info[10], prk[48], okm[48];
      unsigned i;
      memset(ikm, 0x0b, 22);
      for (i = 0; i < 13; i++) salt[i] = (uint8_t)i;
      for (i = 0; i < 10; i++) info[i] = (uint8_t)(0xf0 + i);
      hkdf_sha384_extract(salt, 13, ikm, 22, prk);
      ck_assert_int_eq(hkdf_sha384_expand(prk, 48, info, 10, okm, 48), 0);
      ck_assert(memcmp(okm, okm384, 48) == 0);
   }
}
END_TEST

START_TEST (test_drbg)
{
   struct drbg_ctx a, b;
   uint8_t seed[32], o1[200], o2[200], o3[200], zero[200];
   memset(seed, 0x42, 32);
   memset(zero, 0, 200);

   ck_assert_int_eq(drbg_init(&a, seed, 32), 0);
   ck_assert_int_eq(drbg_init(&b, seed, 32), 0);
   ck_assert_int_eq(drbg_generate(&a, o1, 200), 0);
   ck_assert_int_eq(drbg_generate(&b, o2, 200), 0);
   ck_assert(memcmp(o1, o2, 200) == 0);
   ck_assert(memcmp(o1, zero, 200) != 0);
   /* key erasure: the next call does not repeat the last */
   ck_assert_int_eq(drbg_generate(&a, o3, 200), 0);
   ck_assert(memcmp(o1, o3, 200) != 0);
   /* a different seed diverges */
   seed[0] ^= 1;
   ck_assert_int_eq(drbg_init(&b, seed, 32), 0);
   ck_assert_int_eq(drbg_generate(&b, o2, 200), 0);
   ck_assert(memcmp(o1, o2, 200) != 0);
   drbg_free(&a);
   ck_assert_int_eq(drbg_generate(&a, o1, 16), -1);
   drbg_free(&b);

   /* platform entropy is live and not stuck */
   ck_assert_int_eq(crypto_random_bytes(o1, 64), 0);
   ck_assert_int_eq(crypto_random_bytes(o2, 64), 0);
   ck_assert(memcmp(o1, o2, 64) != 0);
   ck_assert(memcmp(o1, zero, 64) != 0);
   ck_assert_int_eq(drbg_init(&a, NULL, 0), 0);
   ck_assert_int_eq(drbg_generate(&a, o1, 64), 0);
   ck_assert(memcmp(o1, zero, 64) != 0);
   drbg_free(&a);
}
END_TEST

START_TEST (test_util)
{
   uint8_t a[8] = {1,2,3,4,5,6,7,8};
   uint8_t b[8] = {1,2,3,4,5,6,7,8};
   ck_assert_int_eq(crypto_memeq_ct(a, b, 8), 1);
   ck_assert_int_eq(crypto_memeq_ct(a, b, 0), 1);
   b[7] = 9;
   ck_assert_int_eq(crypto_memeq_ct(a, b, 8), 0);
   ck_assert_int_eq(crypto_memeq_ct(a, b, 7), 1);
   crypto_memzero(a, 8);
   ck_assert_int_eq(crypto_memeq_ct(a, "\0\0\0\0\0\0\0\0", 8), 1);
}
END_TEST

/* Vectors in test_pk_vectors.h were produced with a reference
 * implementation (python-cryptography / OpenSSL): fresh RSA-2048,
 * RSA-4096 and P-256 keys signing one message, and one P-256 ECDH
 * exchange. Regenerating them is fine; nothing depends on the values. */
#include "test_pk_vectors.h"

static const uint8_t e65537[3] = { 0x01, 0x00, 0x01 };
static const uint8_t e3[1]     = { 0x03 };

static void hex_to_pk(uint8_t *out, const char *hex, size_t n)
{
   size_t i;
   for (i = 0; i < n; i++)
   {
      unsigned v;
      char t[3];
      t[0] = hex[2 * i]; t[1] = hex[2 * i + 1]; t[2] = 0;
      sscanf(t, "%x", &v);
      out[i] = (uint8_t)v;
   }
}

START_TEST (test_sha512)
{
   struct sha512_state s;
   uint8_t d[64], want[64];
   uint8_t *big;
   size_t i;

   sha512_stream_init(&s, 1);
   sha512_stream_update(&s, (const uint8_t*)"abc", 3);
   sha512_stream_final(&s, d);
   hex_to_pk(want, "cb00753f45a35e8bb5a03d699ac65007272c32ab0eded1631a8b605a43ff5bed8086072ba1e7cc2358baeca134c825a7", 48);
   ck_assert(memcmp(d, want, 48) == 0);

   sha512_stream_init(&s, 0);
   sha512_stream_update(&s, (const uint8_t*)"abc", 3);
   sha512_stream_final(&s, d);
   hex_to_pk(want, "ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f", 64);
   ck_assert(memcmp(d, want, 64) == 0);

   /* 112 octets: the length no longer fits in the first block */
   sha512_stream_init(&s, 0);
   for (i = 0; i < 112; i++)
      sha512_stream_update(&s, (const uint8_t*)"a", 1);
   sha512_stream_final(&s, d);
   hex_to_pk(want, "c01d080efd492776a1c43bd23dd99d0a2e626d481e16782e75d54c2503b5dc32bd05f0f1ba33e568b88fd2d970929b719ecbb152f58f130a407c8830604b70ca", 64);
   ck_assert(memcmp(d, want, 64) == 0);

   big = (uint8_t*)malloc(1000000);
   ck_assert_ptr_nonnull(big);
   memset(big, 'a', 1000000);
   sha512_stream_init(&s, 1);
   sha512_stream_update(&s, big, 777);
   sha512_stream_update(&s, big + 777, 1000000 - 777);
   sha512_stream_final(&s, d);
   hex_to_pk(want, "9d0e1809716474cb086e834e310a4a1ced149e9c00f248527972cec5704c2a5b07b8b3dc38ecc4ebae97ddd87f3d8985", 48);
   ck_assert(memcmp(d, want, 48) == 0);
   free(big);
}
END_TEST

START_TEST (test_bn)
{
   /* 128-bit modulus 2^128 - 159 (a prime), so k = 128 / BN_WORD_BITS
    * whichever limb width is compiled in. Expected values come from
    * Python's pow() / arbitrary-precision arithmetic. */
   enum { KW = 128 / BN_WORD_BITS };
   bn_word a[KW], b[KW], m[KW], r2[KW], r[KW], e[KW];
   bn_word tmp[BN_MONT_TMP_WORDS(KW)];
   bn_word work[3 * KW + BN_MONT_TMP_WORDS(KW)];
   uint8_t be[16], want[16];

   hex_to_pk(be, "ffffffffffffffffffffffffffffff61", 16);
   bn_from_be(m, KW, be, 16);
   hex_to_pk(be, "00000010000000000000000000000003", 16);   /* 2^100 + 3 */
   bn_from_be(a, KW, be, 16);
   hex_to_pk(be, "00000000000000400000000000000005", 16);   /* 2^70 + 5 */
   bn_from_be(b, KW, be, 16);

   bn_mont_r2(r2, m, KW);
   bn_mod_mul(r, a, b, m, r2, bn_mont_n0(m), KW, tmp);
   bn_to_be(be, 16, r, KW);
   hex_to_pk(want, "00000050000000c000027c000000000f", 16);
   ck_assert(memcmp(be, want, 16) == 0);

   /* 3^5 mod m */
   bn_zero(a, KW); a[0] = 3;
   bn_zero(e, KW); e[0] = 5;
   bn_mod_exp(r, a, e, KW, m, r2, bn_mont_n0(m), KW, work);
   bn_to_be(be, 16, r, KW);
   hex_to_pk(want, "000000000000000000000000000000f3", 16);
   ck_assert(memcmp(be, want, 16) == 0);

   /* octet conversion round trip, short and long buffers */
   bn_from_be(b, KW, be + 14, 2);
   ck_assert_int_eq(bn_cmp(b, r, KW), 0);
   bn_to_be(be, 3, r, KW);
   ck_assert_uint_eq(be[2], 243u);
   ck_assert_uint_eq(be[0], 0u);

   ck_assert_int_eq(bn_cmp(m, r, KW), 1);
   ck_assert_int_eq(bn_cmp(r, m, KW), -1);
   ck_assert_uint_eq(bn_bit_length(m, KW), 128u);
   ck_assert_uint_eq(bn_bit_length(r, KW), 8u);
   ck_assert_uint_eq(bn_get_bit(r, 7), 1u);
   ck_assert_uint_eq(bn_get_bit(r, 2), 0u);
   bn_zero(a, KW);
   ck_assert(bn_is_zero(a, KW));
   ck_assert_uint_eq(bn_bit_length(a, KW), 0u);
}
END_TEST

START_TEST (test_rsa)
{
   uint8_t bad[512];

   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_sha256_sig, 256), 0);
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha384_n, 256, e65537, 3,
         RSA_HASH_SHA384, rsa2048_sha384_digest, 48, rsa2048_sha384_sig, 256), 0);
   ck_assert_int_eq(rsa_pkcs1_verify(rsa4096_sha512_n, 512, e65537, 3,
         RSA_HASH_SHA512, rsa4096_sha512_digest, 64, rsa4096_sha512_sig, 512), 0);
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_e3_n, 256, e3, 1,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_e3_sig, 256), 0);

   /* wrong hash algorithm for the DigestInfo */
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA384, rsa2048_sha384_digest, 48, rsa2048_sha256_sig, 256), -1);
   /* wrong digest */
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha384_digest, 32, rsa2048_sha256_sig, 256), -1);
   /* wrong key */
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha384_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_sha256_sig, 256), -1);
   /* flipped signature bit */
   memcpy(bad, rsa2048_sha256_sig, 256);
   bad[100] ^= 0x10;
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, bad, 256), -1);
   /* signature >= n */
   memcpy(bad, rsa2048_sha256_n, 256);
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, bad, 256), -1);
   /* length mismatch, even modulus, even exponent, digest length */
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_sha256_sig, 255), -1);
   memcpy(bad, rsa2048_sha256_n, 256);
   bad[255] &= 0xfe;
   ck_assert_int_eq(rsa_pkcs1_verify(bad, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_sha256_sig, 256), -1);
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, (const uint8_t*)"\x02", 1,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_sha256_sig, 256), -1);
   ck_assert_int_eq(rsa_pkcs1_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 31, rsa2048_sha256_sig, 256), -1);
}
END_TEST

START_TEST (test_rsa_pss)
{
   uint8_t bad[256];
   /* OpenSSL PSS signatures, SHA-256 and SHA-384, verify */
   ck_assert_int_eq(rsa_pss_verify(rsa2048_pss_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_pss_sha256_digest, 32, rsa2048_pss_sha256_sig, 256), 0);
   ck_assert_int_eq(rsa_pss_verify(rsa2048_pss_n, 256, e65537, 3,
         RSA_HASH_SHA384, rsa2048_pss_sha384_digest, 48, rsa2048_pss_sha384_sig, 256), 0);
   /* a flipped bit, the wrong hash, a PKCS#1 signature as PSS, the
    * wrong digest: all refused */
   memcpy(bad, rsa2048_pss_sha256_sig, 256);
   bad[100] ^= 0x01;
   ck_assert_int_eq(rsa_pss_verify(rsa2048_pss_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_pss_sha256_digest, 32, bad, 256), -1);
   ck_assert_int_eq(rsa_pss_verify(rsa2048_pss_n, 256, e65537, 3,
         RSA_HASH_SHA384, rsa2048_pss_sha384_digest, 48, rsa2048_pss_sha256_sig, 256), -1);
   ck_assert_int_eq(rsa_pss_verify(rsa2048_sha256_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_sha256_digest, 32, rsa2048_sha256_sig, 256), -1);
   ck_assert_int_eq(rsa_pss_verify(rsa2048_pss_n, 256, e65537, 3,
         RSA_HASH_SHA256, rsa2048_pss_sha384_digest, 32, rsa2048_pss_sha256_sig, 256), -1);
}
END_TEST

START_TEST (test_x25519)
{
   /* RFC 7748 5.2 vector 1, and the 6.1 Diffie-Hellman example */
   static const uint8_t k1[32] = {0xa5,0x46,0xe3,0x6b,0xf0,0x52,0x7c,0x9d,0x3b,0x16,0x15,0x4b,0x82,0x46,0x5e,0xdd,0x62,0x14,0x4c,0x0a,0xc1,0xfc,0x5a,0x18,0x50,0x6a,0x22,0x44,0xba,0x44,0x9a,0xc4};
   static const uint8_t u1[32] = {0xe6,0xdb,0x68,0x67,0x58,0x30,0x30,0xdb,0x35,0x94,0xc1,0xa4,0x24,0xb1,0x5f,0x7c,0x72,0x66,0x24,0xec,0x26,0xb3,0x35,0x3b,0x10,0xa9,0x03,0xa6,0xd0,0xab,0x1c,0x4c};
   static const uint8_t r1[32] = {0xc3,0xda,0x55,0x37,0x9d,0xe9,0xc6,0x90,0x8e,0x94,0xea,0x4d,0xf2,0x8d,0x08,0x4f,0x32,0xec,0xcf,0x03,0x49,0x1c,0x71,0xf7,0x54,0xb4,0x07,0x55,0x77,0xa2,0x85,0x52};
   static const uint8_t a_priv[32] = {0x77,0x07,0x6d,0x0a,0x73,0x18,0xa5,0x7d,0x3c,0x16,0xc1,0x72,0x51,0xb2,0x66,0x45,0xdf,0x4c,0x2f,0x87,0xeb,0xc0,0x99,0x2a,0xb1,0x77,0xfb,0xa5,0x1d,0xb9,0x2c,0x2a};
   static const uint8_t a_pub[32]  = {0x85,0x20,0xf0,0x09,0x89,0x30,0xa7,0x54,0x74,0x8b,0x7d,0xdc,0xb4,0x3e,0xf7,0x5a,0x0d,0xbf,0x3a,0x0d,0x26,0x38,0x1a,0xf4,0xeb,0xa4,0xa9,0x8e,0xaa,0x9b,0x4e,0x6a};
   static const uint8_t b_pub[32]  = {0xde,0x9e,0xdb,0x7d,0x7b,0x7d,0xc1,0xb4,0xd3,0x5b,0x61,0xc2,0xec,0xe4,0x35,0x37,0x3f,0x83,0x43,0xc8,0x5b,0x78,0x67,0x4d,0xad,0xfc,0x7e,0x14,0x6f,0x88,0x2b,0x4f};
   static const uint8_t shared[32] = {0x4a,0x5d,0x9d,0x5b,0xa4,0xce,0x2d,0xe1,0x72,0x8e,0x3b,0xf4,0x80,0x35,0x0f,0x25,0xe0,0x7e,0x21,0xc9,0x47,0xd1,0x9e,0x33,0x76,0xf0,0x9b,0x3c,0x1e,0x16,0x17,0x42};
   static const uint8_t zero[32] = {0};
   uint8_t out[32];
   ck_assert_int_eq(x25519(out, k1, u1), 0);
   ck_assert(memcmp(out, r1, 32) == 0);
   ck_assert_int_eq(x25519_base(out, a_priv), 0);
   ck_assert(memcmp(out, a_pub, 32) == 0);
   ck_assert_int_eq(x25519(out, a_priv, b_pub), 0);
   ck_assert(memcmp(out, shared, 32) == 0);
   /* the all-zero point is refused */
   ck_assert_int_eq(x25519(out, a_priv, zero), -1);
}
END_TEST

START_TEST (test_x509_policy)
{
   /* leaf policy (RFC 5280 4.2, TLS server usage): a fresh CA loaded
    * as the trust store, leaves under it that must pass or fail */
   static const struct { const uint8_t *der; size_t len; int expect; const char *why; } cases[] = {
      { x509_policy_good,        sizeof(x509_policy_good),         0, "serverAuth EKU + digitalSignature" },
      { x509_policy_noncrit,     sizeof(x509_policy_noncrit),      0, "unknown non-critical extension" },
      { x509_policy_critunknown, sizeof(x509_policy_critunknown), -1, "unknown critical extension" },
      { x509_policy_clientonly,  sizeof(x509_policy_clientonly),  -1, "clientAuth-only EKU" },
      { x509_policy_codesign,    sizeof(x509_policy_codesign),    -1, "codeSigning-only EKU" },
      { x509_policy_nosign,      sizeof(x509_policy_nosign),      -1, "keyUsage without digitalSignature" },
   };
   unsigned i;
   char info[128];
   ck_assert(x509_trust_load_pem(x509_policy_ca_pem, sizeof(x509_policy_ca_pem) - 1) == 1);
   for (i = 0; i < sizeof(cases) / sizeof(cases[0]); i++)
   {
      const uint8_t *ders[1] = { cases[i].der };
      size_t lens[1] = { cases[i].len };
      /* the policy certificates run from late 2026 for twenty years */
      int r = x509_verify_chain(ders, lens, 1, "policy.example.com", (time_t)1800000000, info, sizeof(info));
      if (r != cases[i].expect)
         fprintf(stderr, "policy case %s: got %d (%s)\n", cases[i].why, r, info);
      ck_assert_int_eq(r, cases[i].expect);
   }
   x509_trust_free();
}
END_TEST

START_TEST (test_p256)
{
   uint8_t pub[65], shared[32], bad[65], sig[32];

   /* keygen matches the reference public key */
   ck_assert_int_eq(p256_keygen(ecdh_a_priv, pub), 0);
   ck_assert(memcmp(pub, ecdh_a_pub, 65) == 0);

   /* ECDH agrees with the reference */
   ck_assert_int_eq(p256_ecdh(ecdh_a_priv, ecdh_b_pub, shared), 0);
   ck_assert(memcmp(shared, ecdh_shared, 32) == 0);

   /* invalid peer points: off curve, x >= p, wrong prefix */
   memcpy(bad, ecdh_b_pub, 65);
   bad[40] ^= 1;
   ck_assert_int_eq(p256_ecdh(ecdh_a_priv, bad, shared), -1);
   memcpy(bad, ecdh_b_pub, 65);
   memset(bad + 1, 0xff, 32);
   ck_assert_int_eq(p256_ecdh(ecdh_a_priv, bad, shared), -1);
   memcpy(bad, ecdh_b_pub, 65);
   bad[0] = 0x02;
   ck_assert_int_eq(p256_ecdh(ecdh_a_priv, bad, shared), -1);
   /* zero and >= n scalars */
   memset(bad, 0, 32);
   ck_assert_int_eq(p256_keygen(bad, pub), -1);
   memset(bad, 0xff, 32);
   ck_assert_int_eq(p256_keygen(bad, pub), -1);

   /* ECDSA, SHA-256 and a SHA-384 digest (truncated to 32) */
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha256_digest, 32,
         ecdsa_sha256_r, ecdsa_sha256_s), 0);
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha384_digest, 48,
         ecdsa_sha384_r, ecdsa_sha384_s), 0);
   /* wrong digest, wrong key, tampered r and s */
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha384_digest, 48,
         ecdsa_sha256_r, ecdsa_sha256_s), -1);
   ck_assert_int_eq(p256_ecdsa_verify(ecdh_a_pub, ecdsa_sha256_digest, 32,
         ecdsa_sha256_r, ecdsa_sha256_s), -1);
   memcpy(sig, ecdsa_sha256_r, 32);
   sig[31] ^= 1;
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha256_digest, 32,
         sig, ecdsa_sha256_s), -1);
   memcpy(sig, ecdsa_sha256_s, 32);
   sig[0] ^= 0x80;
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha256_digest, 32,
         ecdsa_sha256_r, sig), -1);
   memset(sig, 0, 32);
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha256_digest, 32,
         sig, ecdsa_sha256_s), -1);
}
END_TEST

struct p256_ecdsa_vector
{
   unsigned id;
   uint8_t  key;        /* index into the file's key table */
   uint8_t  valid;
   uint8_t  digest_len;
   uint8_t  digest[64];
   uint8_t  sig[64];    /* r || s */
};

struct p256_ecdsa_der_vector
{
   unsigned id;
   uint8_t  key;
   uint8_t  valid;
   uint8_t  sig_len;
   uint8_t  digest[32];
   uint8_t  sig[80];    /* ECDSA-Sig-Value */
};

#include "test_p256_edge_vectors.h"

static void p256_check_vectors(const char *name, const uint8_t (*keys)[65],
      const struct p256_ecdsa_vector *v, size_t n)
{
   size_t i;
   for (i = 0; i < n; i++, v++)
   {
      int r = p256_ecdsa_verify(keys[v->key], v->digest, v->digest_len,
            v->sig, v->sig + 32);
      if (r != (v->valid ? 0 : -1))
         fprintf(stderr, "%s vector %u: got %d\n", name, v->id, r);
      ck_assert_int_eq(r, v->valid ? 0 : -1);
   }
}

START_TEST (test_p256_vectors)
{
   p256_check_vectors("P-256 edge", p256_edge_keys, p256_edge_vectors,
         sizeof(p256_edge_vectors) / sizeof(p256_edge_vectors[0]));
   p256_check_vectors("P-256 generated", p256_gen_keys, p256_gen_vectors,
         sizeof(p256_gen_vectors) / sizeof(p256_gen_vectors[0]));
}
END_TEST

START_TEST (test_p256_der)
{
   struct x509_cert key;
   size_t i;
   memset(&key, 0, sizeof(key));
   key.key_type = X509_KEY_P256;
   for (i = 0; i < sizeof(p256_gen_der) / sizeof(p256_gen_der[0]); i++)
   {
      const struct p256_ecdsa_der_vector *v = &p256_gen_der[i];
      int r;
      key.ec_point = p256_gen_keys[v->key];
      r = x509_verify_ecdsa_digest(&key, v->digest, 32, v->sig, v->sig_len);
      if (r != (v->valid ? 0 : -1))
         fprintf(stderr, "P-256 DER vector %u: got %d\n", v->id, r);
      ck_assert_int_eq(r, v->valid ? 0 : -1);
   }
}
END_TEST

START_TEST (test_p384)
{
   uint8_t pub[97], shared[48], bad[97], sig[48];

   ck_assert_int_eq(p384_keygen(ecdh384_a_priv, pub), 0);
   ck_assert(memcmp(pub, ecdh384_a_pub, 97) == 0);
   ck_assert_int_eq(p384_ecdh(ecdh384_a_priv, ecdh384_b_pub, shared), 0);
   ck_assert(memcmp(shared, ecdh384_shared, 48) == 0);
   memcpy(bad, ecdh384_b_pub, 97);
   bad[50] ^= 1;
   ck_assert_int_eq(p384_ecdh(ecdh384_a_priv, bad, shared), -1);

   ck_assert_int_eq(p384_ecdsa_verify(ecdsa384_pub, ecdsa384_digest, 48,
         ecdsa384_r, ecdsa384_s), 0);
   memcpy(sig, ecdsa384_s, 48);
   sig[47] ^= 1;
   ck_assert_int_eq(p384_ecdsa_verify(ecdsa384_pub, ecdsa384_digest, 48,
         ecdsa384_r, sig), -1);
   ck_assert_int_eq(p384_ecdsa_verify(ecdsa384_pub, ecdsa_sha256_digest, 32,
         ecdsa384_r, ecdsa384_s), -1);
   /* the P-256 vectors still hold after the curve-generic rewrite */
   ck_assert_int_eq(p256_ecdsa_verify(ecdsa_pub, ecdsa_sha256_digest, 32,
         ecdsa_sha256_r, ecdsa_sha256_s), 0);
}
END_TEST

/* RFC 6979 A.2.14, NIST B-233 with SHA-256 */
static const uint8_t b233_rfc_x[30] = {
   0x00,0x7a,0xdc,0x13,0xdd,0x5b,0xf3,0x4d,0x1d,0xde,0xeb,0x50,0xb2,0xce,0x23,0xb5,
   0xf5,0xe6,0xd1,0x80,0x67,0x30,0x6d,0x60,0xc5,0xf6,0xff,0x11,0xe5,0xd3
};
static const uint8_t b233_rfc_pub[61] = {
   0x04,0x00,0xfb,0x34,0x8b,0x32,0x46,0xb4,0x73,0xaa,0x7f,0xbb,0x2a,0x01,0xb7,0x8d,
   0x61,0xb6,0x2c,0x42,0x21,0xd0,0xf9,0xab,0x55,0xfc,0x72,0xdb,0x3d,0xf4,0x78,0x01,
   0x16,0x2f,0xa1,0xf6,0xc6,0xac,0xf7,0xfd,0x8d,0x19,0xfc,0x7d,0x74,0xbd,0xd9,0x10,
   0x40,0x76,0xe8,0x33,0x89,0x8b,0xc4,0xc0,0x42,0xa6,0xe6,0xbe,0xbf
};
static const uint8_t b233_rfc_sample_r[30] = {
   0x00,0xa7,0x97,0xf3,0xb8,0xae,0xfc,0xe7,0x45,0x62,0x02,0xdf,0x1e,0x46,0xcc,0xc2,
   0x91,0xea,0x5a,0x49,0xda,0x3d,0x4b,0xdd,0xa9,0xa4,0xb6,0x2d,0x5e,0x0d
};
static const uint8_t b233_rfc_sample_s[30] = {
   0x00,0x1f,0x6f,0x81,0xda,0x55,0xc2,0x2d,0xa4,0x15,0x21,0x34,0xc6,0x61,0x58,0x8f,
   0x4b,0xd6,0xf8,0x2f,0xdb,0xaf,0x0c,0x58,0x77,0x09,0x6b,0x07,0x0d,0xc2
};
static const uint8_t b233_rfc_test_r[30] = {
   0x00,0x35,0xc3,0xd6,0xdf,0xee,0xa1,0xcf,0xb2,0x9b,0x93,0xbe,0x3f,0xdb,0x91,0xa7,
   0xb1,0x30,0x95,0x17,0x70,0xc2,0x69,0x0c,0x16,0x83,0x3a,0x15,0x96,0x77
};
static const uint8_t b233_rfc_test_s[30] = {
   0x00,0x60,0x0f,0x73,0x01,0xd1,0x2a,0xb3,0x76,0xb5,0x6d,0x44,0x59,0x77,0x41,0x59,
   0xad,0xb5,0x1f,0x97,0xe2,0x82,0xff,0x38,0x44,0x06,0xaf,0xd5,0x3a,0x02
};
/* ECDH from OpenSSL; the first key is above n. The last point is the
 * second public key plus the point of order 2: on the curve, order 2n. */
static const uint8_t b233_ecdh_a_priv[30] = {
   0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef,0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef,
   0x01,0x23,0x45,0x67,0x89,0xab,0xcd,0xef,0x01,0x23,0x45,0x67,0x89,0xab
};
static const uint8_t b233_ecdh_a_pub[61] = {
   0x04,0x01,0x18,0x67,0x33,0xb7,0x09,0x65,0xf7,0xbb,0x77,0x5c,0xcb,0x68,0x70,0x61,
   0xd7,0x87,0xca,0xd0,0x5e,0x80,0x91,0xea,0xcc,0x7d,0x26,0x16,0xf6,0x53,0x63,0x01,
   0xdc,0xd5,0x7c,0x2e,0x8d,0x9a,0x5b,0x77,0x7e,0x50,0x54,0x25,0x1f,0xea,0x21,0xac,
   0x65,0xc6,0xfc,0xa4,0x27,0x60,0x4a,0x95,0x29,0x6c,0x7e,0xdb,0x20
};
static const uint8_t b233_ecdh_b_priv[30] = {
   0x00,0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,0x10,0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,
   0x10,0xfe,0xdc,0xba,0x98,0x76,0x54,0x32,0x10,0xfe,0xdc,0xba,0x98,0x76
};
static const uint8_t b233_ecdh_b_pub[61] = {
   0x04,0x00,0x26,0x8a,0xc5,0xcb,0xc8,0x24,0xc5,0x3d,0x31,0xca,0xa5,0xc4,0x08,0x33,
   0x10,0xda,0xbd,0x50,0x3e,0xd4,0xbc,0xb5,0xa2,0x83,0x26,0xb3,0x6a,0x54,0x8e,0x01,
   0xba,0xb7,0xb5,0x52,0x89,0xb2,0xbb,0x26,0x18,0x01,0xf8,0x9c,0x6e,0x36,0xd7,0x78,
   0x80,0xd3,0x5d,0x5a,0xcb,0x19,0x7e,0x3c,0x8d,0x2c,0x00,0xe6,0x0f
};
static const uint8_t b233_ecdh_shared[30] = {
   0x00,0xfb,0xee,0x4e,0x8f,0x12,0x5c,0xc6,0x48,0x43,0x36,0xdd,0x0f,0xab,0x5d,0x34,
   0x7c,0x0e,0x93,0x85,0x8f,0x2b,0x75,0xa2,0x52,0x3d,0xeb,0xa3,0x2f,0xed
};
static const uint8_t b233_order_2n[61] = {
   0x04,0x00,0x5c,0xc7,0xcc,0x8e,0xe5,0xa8,0x05,0x92,0x1c,0xc7,0x40,0x2b,0x1e,0x7a,
   0x62,0x29,0x52,0x1e,0x87,0x9a,0x3a,0x6f,0x8b,0xc0,0xe4,0xd4,0x20,0x0c,0xdb,0x01,
   0x94,0xfc,0x26,0xd0,0xda,0xf0,0x2a,0x10,0xed,0x36,0xc4,0x2e,0xa0,0x1a,0x5a,0x39,
   0xe8,0x48,0x00,0xc5,0x32,0x71,0xff,0x19,0x98,0xc1,0x75,0x19,0x48
};

/* RSA-1024 RSAPrivateKey and its PKCS#1 v1.5 signatures of "sample",
 * from OpenSSL. */
static const uint8_t rsa1024_key[607] = {
   0x30,0x82,0x02,0x5b,0x02,0x01,0x00,0x02,0x81,0x81,0x00,0xe8,0x22,0x03,0xe9,0x63,
   0xa2,0xf6,0x88,0xd6,0xa6,0x06,0xa5,0x1c,0x62,0x2b,0xe4,0x02,0x8b,0x6a,0x60,0xb1,
   0x14,0xc8,0x16,0xfe,0xdd,0xc6,0xfd,0xc3,0x4c,0x5e,0x16,0x55,0x2b,0x5c,0x0e,0x2b,
   0xa0,0xef,0xac,0x59,0x02,0xbe,0xec,0xf8,0xe0,0xb7,0x1d,0xb1,0x80,0x82,0x08,0x4e,
   0x12,0xfa,0xc9,0xb9,0xf0,0xc3,0xa4,0x6d,0x85,0x1b,0x09,0x7f,0x2f,0x57,0xae,0x8b,
   0xe4,0x95,0x21,0x1c,0xa3,0x9d,0x7c,0xd5,0x12,0x85,0xb9,0x32,0x22,0x9f,0xf0,0xa3,
   0xc7,0xc2,0x20,0x24,0xe2,0xfe,0xb2,0x46,0x12,0x0a,0x8a,0xce,0x62,0x0d,0x53,0x33,
   0xdd,0x3b,0x2c,0xe6,0x32,0x47,0x8e,0x97,0x90,0x5a,0x9b,0x84,0xc6,0x36,0x48,0x51,
   0xdf,0x86,0x7b,0x30,0x8a,0xa8,0xa6,0xf1,0x93,0x26,0x05,0x02,0x03,0x01,0x00,0x01,
   0x02,0x81,0x80,0x6a,0x74,0x87,0x04,0xb6,0x6b,0xda,0xd1,0xe0,0x56,0x5d,0x7f,0xc4,
   0xe7,0x84,0xa7,0x59,0x3f,0x64,0x76,0x99,0x5f,0x25,0x6f,0xde,0x4c,0x08,0xe1,0x01,
   0x7a,0x79,0x3f,0x96,0xa9,0x7e,0xdb,0x04,0xc9,0x16,0x81,0x1c,0x84,0xf4,0xd8,0x2a,
   0x3e,0xab,0xdb,0x93,0x36,0x92,0xeb,0x8a,0x1a,0x8c,0x26,0x8c,0xfe,0x4c,0x4a,0x90,
   0xeb,0x54,0xfd,0x03,0x50,0xef,0x0b,0xd2,0x95,0x57,0x94,0x53,0x49,0x79,0xb2,0x1a,
   0x01,0x6f,0x2c,0x3e,0xa9,0x09,0x6e,0xc9,0x1d,0xa8,0x0d,0x77,0x69,0x32,0x4f,0xdc,
   0x23,0xe2,0x0c,0x37,0xe1,0x29,0x4e,0x2c,0x0d,0x31,0xa9,0xea,0x44,0x0e,0x9e,0x0b,
   0xad,0x4a,0xa9,0xda,0xe8,0x1f,0xf0,0x70,0xad,0xbe,0x87,0x41,0x73,0x85,0x3d,0x7b,
   0xe6,0xa5,0x95,0x02,0x41,0x00,0xf9,0x1e,0x8f,0x4e,0x5d,0x65,0x52,0x0d,0x3a,0x1f,
   0xdb,0x83,0xfa,0x1d,0x6d,0xb7,0x61,0xdd,0xee,0x3a,0x91,0x93,0xd8,0x01,0x68,0x84,
   0xf7,0x7e,0xcd,0x0c,0xcd,0xfe,0x12,0xde,0x62,0xe3,0x49,0x24,0xb4,0xbf,0xac,0xf2,
   0xb6,0xc7,0x31,0x08,0xdd,0x08,0x08,0xef,0x3a,0x2f,0xb0,0xf3,0x6c,0xf4,0x99,0x07,
   0x91,0x26,0x56,0xc1,0x81,0xab,0x02,0x41,0x00,0xee,0x8b,0x59,0x7e,0x7f,0xd4,0xd6,
   0x90,0x95,0xd9,0x30,0xc8,0x5d,0xd1,0xac,0xf3,0x5c,0x43,0x5d,0x58,0x40,0x96,0x25,
   0xde,0xec,0xf6,0xb8,0x16,0x88,0xc1,0x3f,0x1a,0xac,0x1e,0x9c,0x28,0x9c,0xad,0xa8,
   0xaf,0x19,0xaa,0x33,0x28,0xe8,0xa8,0xfa,0xb3,0x3b,0xa2,0x26,0x91,0xba,0x6e,0x66,
   0xe8,0xc2,0x3a,0xf7,0x66,0x27,0xf2,0xa7,0x0f,0x02,0x40,0x05,0xe8,0x35,0x99,0xb4,
   0x19,0x3c,0xf2,0xd7,0x57,0xfe,0x0a,0x89,0x19,0xbd,0x8a,0x45,0xa5,0xcf,0x8a,0x4f,
   0xfd,0x63,0x77,0xd5,0x14,0xa2,0x11,0xbd,0xa6,0xfa,0x13,0x76,0x3b,0x13,0xb9,0x33,
   0xf8,0xcc,0xd8,0x66,0xaf,0x72,0xaa,0x12,0x7d,0x95,0x50,0x25,0x76,0x16,0xb9,0x1e,
   0xc7,0x06,0xe4,0x5d,0xe4,0x92,0x0a,0x88,0xb0,0x19,0xf5,0x02,0x40,0x53,0x96,0xc7,
   0x0c,0x79,0xd4,0xe6,0x3f,0x12,0x13,0x62,0x71,0xc3,0xd6,0x76,0x89,0x6c,0x9a,0x3a,
   0x7a,0x73,0x5f,0x69,0xf3,0xdd,0x0b,0x73,0x64,0x8a,0x15,0x55,0x7c,0x8e,0x35,0xc7,
   0xb8,0xbf,0x76,0x66,0xf6,0xbc,0xc2,0x94,0x5c,0xd0,0x72,0x6e,0x2f,0x22,0x45,0x66,
   0xc8,0x88,0x10,0xa9,0xc5,0x04,0x52,0xcf,0x60,0x9f,0xbc,0xfa,0xe7,0x02,0x40,0x2f,
   0x7c,0x46,0x81,0x38,0xac,0xce,0x9f,0xb7,0x8f,0xb3,0x51,0x54,0x90,0x83,0x31,0x07,
   0xcc,0xcf,0xb1,0xff,0xc7,0x70,0x94,0xeb,0x56,0x4b,0x1d,0xc8,0xac,0x2c,0x02,0xa2,
   0xbb,0xbc,0x6b,0x71,0x03,0xcd,0x12,0x3a,0x5b,0xda,0x34,0xda,0x3b,0xa1,0x86,0x6f,
   0x0f,0xdf,0x00,0x19,0x7e,0x60,0x05,0xe2,0x78,0x35,0xf5,0x4d,0xd5,0x74,0x43
};
static const uint8_t rsa1024_sig_sha256[128] = {
   0x55,0x13,0xc3,0x15,0xeb,0x5f,0x52,0x98,0x73,0xcd,0x76,0x87,0x0e,0x52,0xab,0x78,
   0x5a,0x07,0x57,0x9e,0xc5,0x76,0x1b,0xc8,0x5d,0x4b,0x95,0x83,0xf1,0x04,0xaa,0xf9,
   0x73,0x7f,0x10,0x7b,0x42,0x8c,0x49,0x78,0x41,0xfe,0x99,0x04,0xd2,0x68,0xb7,0x2d,
   0xba,0xca,0x16,0xe1,0x3f,0x06,0x83,0xd1,0xc8,0xa2,0xeb,0x3a,0x16,0x50,0x3c,0xc9,
   0x35,0x39,0x3c,0x8b,0x32,0x18,0x4c,0xd4,0xe1,0xc7,0xa8,0xcf,0xa4,0xff,0xd0,0x16,
   0x6c,0xb2,0xff,0xc7,0x58,0x22,0x01,0x4f,0x76,0x73,0x18,0x59,0x60,0xbc,0x09,0x8a,
   0xe8,0x78,0x17,0x27,0xb8,0x9b,0x91,0xeb,0x08,0x4a,0xc9,0xfb,0x74,0x09,0xcc,0xb9,
   0x22,0x72,0x2b,0x8f,0x6c,0xc0,0x57,0x6a,0x1b,0x4e,0xee,0xb1,0x1e,0xcf,0x6e,0x13
};
static const uint8_t rsa1024_sig_sha1[128] = {
   0x55,0x58,0x9d,0x11,0x6b,0x74,0x4a,0x2f,0xd2,0x6f,0xc0,0x55,0xc1,0xfd,0x65,0xa1,
   0x0d,0x59,0xd9,0xe0,0xe4,0x73,0xa7,0x68,0x3e,0x8d,0x8e,0x9c,0xc6,0x51,0x8c,0x05,
   0x87,0x83,0x3b,0x1e,0x9c,0x91,0x60,0xbc,0xb4,0x4d,0x82,0x17,0xae,0xd3,0x2a,0x44,
   0xdb,0xfc,0xa4,0x16,0x21,0x4b,0xae,0xe2,0xae,0xa2,0xf3,0x14,0xb8,0xab,0x88,0x98,
   0x76,0x00,0x82,0x7d,0xf4,0x38,0x74,0x63,0xa0,0x73,0x77,0x7f,0x91,0x51,0xff,0x64,
   0xf4,0x07,0x04,0xe9,0xdf,0x52,0x52,0xbf,0x3b,0xcb,0x47,0xa7,0x0a,0x78,0x57,0xc7,
   0x5f,0xa2,0xd7,0xa2,0xbb,0x72,0x98,0x38,0xac,0xc9,0x0a,0x54,0x91,0xc2,0xfd,0x40,
   0x83,0x47,0xc3,0x6b,0x3c,0x7a,0x78,0x1d,0x56,0x8f,0x05,0x0d,0x45,0x86,0xd1,0xf8
};
static const uint8_t rsa1024_sig_md5sha1[128] = {
   0x0c,0x1e,0xc3,0x4a,0x62,0xca,0xd7,0x46,0xd8,0xb1,0xc3,0xf0,0xe2,0x53,0xfb,0x66,
   0xc6,0x55,0xeb,0x05,0x7e,0x69,0xe8,0x3a,0x9a,0xb5,0x69,0xb5,0x22,0x13,0xc8,0xce,
   0xda,0x80,0x44,0x53,0xba,0xae,0xdc,0x97,0x03,0x05,0x3c,0xa8,0xd7,0x9a,0x92,0xfd,
   0x3b,0x9c,0x45,0xd9,0x51,0x96,0x06,0x5b,0x66,0x34,0x70,0x8f,0xc7,0x28,0xbc,0x6e,
   0x66,0x43,0xc3,0x67,0x22,0x8e,0xe0,0xbc,0xcd,0x60,0x8e,0x6b,0x8f,0x81,0xca,0x34,
   0xf7,0x9f,0xaf,0x06,0xce,0xef,0x2e,0x3a,0x23,0x95,0xe8,0x5e,0x6f,0xc2,0xb9,0x28,
   0x5e,0xe6,0xa9,0xef,0xde,0xee,0x66,0x78,0xb6,0xac,0x6c,0xf5,0x12,0x8c,0x6c,0x4c,
   0x54,0x20,0x7a,0x21,0x6f,0x8d,0xec,0x48,0xe0,0xd1,0x74,0x46,0xb1,0x9e,0x1e,0x52
};
static const uint8_t rsa1024_pkcs8_head[26] = {
   0x30,0x82,0x02,0x75,0x02,0x01,0x00,0x30,0x0d,0x06,0x09,0x2a,0x86,0x48,0x86,0xf7,
   0x0d,0x01,0x01,0x01,0x05,0x00,0x04,0x82,0x02,0x5f
};

static void sha256_of(const char *msg, uint8_t *out)
{
   struct sha256_state st;
   sha256_stream_init(&st, 0);
   sha256_stream_update(&st, (const uint8_t*)msg, strlen(msg));
   sha256_stream_final(&st, out);
}

START_TEST (test_b233)
{
   uint8_t pub[61], shared[30], r[30], s[30], d[32], bad[61], key[30];

   ck_assert_int_eq(b233_keygen(b233_rfc_x, pub), 0);
   ck_assert(memcmp(pub, b233_rfc_pub, 61) == 0);

   sha256_of("sample", d);
   ck_assert_int_eq(b233_ecdsa_sign(b233_rfc_x, d, 32, r, s), 0);
   ck_assert(memcmp(r, b233_rfc_sample_r, 30) == 0);
   ck_assert(memcmp(s, b233_rfc_sample_s, 30) == 0);
   ck_assert_int_eq(b233_ecdsa_verify(b233_rfc_pub, d, 32, r, s), 0);
   s[29] ^= 1;
   ck_assert_int_eq(b233_ecdsa_verify(b233_rfc_pub, d, 32, r, s), -1);
   sha256_of("test", d);
   ck_assert_int_eq(b233_ecdsa_verify(b233_rfc_pub, d, 32,
         b233_rfc_sample_r, b233_rfc_sample_s), -1);
   ck_assert_int_eq(b233_ecdsa_sign(b233_rfc_x, d, 32, r, s), 0);
   ck_assert(memcmp(r, b233_rfc_test_r, 30) == 0);
   ck_assert(memcmp(s, b233_rfc_test_s, 30) == 0);
   ck_assert_int_eq(b233_ecdsa_verify(b233_rfc_pub, d, 32, r, s), 0);
   /* a 20-octet digest is used whole */
   ck_assert_int_eq(b233_ecdsa_sign(b233_rfc_x, d, 20, r, s), 0);
   ck_assert_int_eq(b233_ecdsa_verify(b233_rfc_pub, d, 20, r, s), 0);
   ck_assert_int_eq(b233_ecdsa_verify(b233_rfc_pub, d, 32, r, s), -1);

   ck_assert_int_eq(b233_keygen(b233_ecdh_a_priv, pub), 0);
   ck_assert(memcmp(pub, b233_ecdh_a_pub, 61) == 0);
   ck_assert_int_eq(b233_ecdh(b233_ecdh_a_priv, b233_ecdh_b_pub, shared), 0);
   ck_assert(memcmp(shared, b233_ecdh_shared, 30) == 0);
   ck_assert_int_eq(b233_ecdh(b233_ecdh_b_priv, b233_ecdh_a_pub, shared), 0);
   ck_assert(memcmp(shared, b233_ecdh_shared, 30) == 0);

   ck_assert_int_eq(b233_ecdh(b233_ecdh_a_priv, b233_order_2n, shared), -1);
   memcpy(bad, b233_ecdh_b_pub, 61);
   bad[60] ^= 1;
   ck_assert_int_eq(b233_ecdh(b233_ecdh_a_priv, bad, shared), -1);
   memcpy(bad, b233_ecdh_b_pub, 61);
   bad[1] |= 2;   /* x past 2^233 */
   ck_assert_int_eq(b233_ecdh(b233_ecdh_a_priv, bad, shared), -1);
   memset(key, 0, sizeof(key));
   ck_assert_int_eq(b233_keygen(key, pub), -1);
}
END_TEST

START_TEST (test_rsa_sign)
{
   struct rsa_private_key key;
   uint8_t p8[sizeof(rsa1024_pkcs8_head) + sizeof(rsa1024_key)];
   uint8_t d[36], sig[128], k[sizeof(rsa1024_key)];
   MD5_CTX md5;

   ck_assert_int_eq(x509_rsa_private_key_parse(&key, rsa1024_key,
         sizeof(rsa1024_key)), 0);
   sha256_of("sample", d);
   ck_assert_int_eq(rsa_pkcs1_sign(&key, RSA_HASH_SHA256, d, 32, sig, 128), 0);
   ck_assert(memcmp(sig, rsa1024_sig_sha256, 128) == 0);
   ck_assert_int_eq(rsa_pkcs1_sign(&key, RSA_HASH_SHA256, d, 32, sig, 127), -1);
   ck_assert_int_eq(rsa_pkcs1_verify(key.n, key.n_len, key.e, key.e_len,
         RSA_HASH_SHA256, d, 32, rsa1024_sig_sha256, 128), 0);

   MD5_Init(&md5);
   MD5_Update(&md5, "sample", 6);
   MD5_Final(d, &md5);
   SHA1Digest((const uint8_t*)"sample", 6, d + 16);
   ck_assert_int_eq(rsa_pkcs1_sign(&key, RSA_HASH_SHA1, d + 16, 20, sig, 128), 0);
   ck_assert(memcmp(sig, rsa1024_sig_sha1, 128) == 0);
   ck_assert_int_eq(rsa_pkcs1_sign(&key, RSA_HASH_MD5_SHA1, d, 36, sig, 128), 0);
   ck_assert(memcmp(sig, rsa1024_sig_md5sha1, 128) == 0);
   ck_assert_int_eq(rsa_pkcs1_verify(key.n, key.n_len, key.e, key.e_len,
         RSA_HASH_MD5_SHA1, d, 36, sig, 128), 0);

   /* PKCS#8 wrapping */
   memcpy(p8, rsa1024_pkcs8_head, sizeof(rsa1024_pkcs8_head));
   memcpy(p8 + sizeof(rsa1024_pkcs8_head), rsa1024_key, sizeof(rsa1024_key));
   ck_assert_int_eq(x509_rsa_private_key_parse(&key, p8, sizeof(p8)), 0);
   sha256_of("sample", d);
   ck_assert_int_eq(rsa_pkcs1_sign(&key, RSA_HASH_SHA256, d, 32, sig, 128), 0);
   ck_assert(memcmp(sig, rsa1024_sig_sha256, 128) == 0);
   ck_assert_int_eq(x509_rsa_private_key_parse(&key, p8, sizeof(p8) - 1), -1);

   /* a wrong q^-1 mod p is refused rather than producing a signature
    * that would give away the factors */
   memcpy(k, rsa1024_key, sizeof(k));
   ck_assert_int_eq(x509_rsa_private_key_parse(&key, k, sizeof(k)), 0);
   k[sizeof(k) - 1] ^= 1;
   ck_assert_int_eq(rsa_pkcs1_sign(&key, RSA_HASH_SHA256, d, 32, sig, 128), -1);
}
END_TEST

START_TEST (test_smb_prereqs)
{
   struct aes_ctx a;
   uint8_t k[16], n[13], aad[8], pt[23], ct[40], tag[16], dec[23], d[16], kb[16];
   unsigned i;

   /* AES-CCM: RFC 3610 packet vector #1 (13-octet nonce, 8-octet tag)
    * and the SMB3 shape (11-octet nonce, 16-octet tag). */
   for (i = 0; i < 16; i++) k[i] = (uint8_t)(0xc0 + i);
   hex_to_pk(n, "00000003020100a0a1a2a3a4a5", 13);
   hex_to_pk(aad, "0001020304050607", 8);
   hex_to_pk(pt, "08090a0b0c0d0e0f101112131415161718191a1b1c1d1e", 23);
   ck_assert_int_eq(aes_init(&a, k, 16), 0);
   ck_assert_int_eq(aes_ccm_encrypt(&a, n, 13, aad, 8, pt, 23, ct, tag, 8), 0);
   ck_hex(ct, 23, "588c979a61c663d2f066d0c2c0f989806d5f6b61dac384");
   ck_hex(tag, 8, "17e8d12cfdf926e0");
   ck_assert_int_eq(aes_ccm_decrypt(&a, n, 13, aad, 8, ct, 23, tag, 8, dec), 0);
   ck_assert(memcmp(dec, pt, 23) == 0);
   tag[0] ^= 1;
   ck_assert_int_eq(aes_ccm_decrypt(&a, n, 13, aad, 8, ct, 23, tag, 8, dec), -1);
   ck_assert_int_eq(aes_ccm_encrypt(&a, n, 11, aad, 8, pt, 23, ct, tag, 16), 0);
   ck_hex(ct, 23, "aa2d3ecba66863758f03015116de30ed8ab542dcfa72d0");
   ck_hex(tag, 16, "32afd3d6fcc0340360db1d8a51b1d753");
   ck_assert_int_eq(aes_ccm_decrypt(&a, n, 11, aad, 8, ct, 23, tag, 16, dec), 0);
   ck_assert(memcmp(dec, pt, 23) == 0);
   ck_assert_int_eq(aes_ccm_encrypt(&a, n, 6, aad, 8, pt, 23, ct, tag, 16), -1);
   ck_assert_int_eq(aes_ccm_encrypt(&a, n, 11, aad, 8, pt, 23, ct, tag, 7), -1);

   /* MD4: RFC 1320 A.5 */
   md4((const uint8_t*)"", 0, d);
   ck_hex(d, 16, "31d6cfe0d16ae931b73c59d7e0c089c0");
   md4((const uint8_t*)"abc", 3, d);
   ck_hex(d, 16, "a448017aaf21d8525fc10ae87aa6729d");
   md4((const uint8_t*)"12345678901234567890123456789012345678901234567890123456789012345678901234567890", 80, d);
   ck_hex(d, 16, "e33b4ddc9c38f2199c3e7b164fcc0536");

   /* HMAC-MD5: RFC 2202 case 2 and the "quick brown fox" vector */
   hmac_md5((const uint8_t*)"Jefe", 4, (const uint8_t*)"what do ya want for nothing?", 28, d);
   ck_hex(d, 16, "750c783e6ab0b503eaa86e310a5db738");
   hmac_md5((const uint8_t*)"key", 3, (const uint8_t*)"The quick brown fox jumps over the lazy dog", 43, d);
   ck_hex(d, 16, "80070713463e7749b90c2dc24911e275");

   /* SP 800-108 counter mode, the SMB 3.0 signing-key shape */
   for (i = 0; i < 16; i++) k[i] = (uint8_t)i;
   kbkdf_hmac_sha256(k, 16, (const uint8_t*)"SMB2AESCMAC", 12,
         (const uint8_t*)"SmbSign", 8, kb, 16);
   ck_hex(kb, 16, "6234814cbb8ea9227440ebfeb5eacbe1");

   /* NTOWFv2: MS-NLMP 4.2.4.1.1 (User / Domain / Password) */
   ck_assert_int_eq(ntlm_ntowf_v2("Password", "User", "Domain", d), 0);
   ck_hex(d, 16, "0c868a403bfd7a93a3001ef22ef02e3f");
   ck_assert_int_eq(ntlm_ntowf_v2("Password", "user", "Domain", kb), 0);
   ck_assert(memcmp(d, kb, 16) == 0);   /* user name is upper-cased */
   ck_assert_int_eq(ntlm_ntowf_v2("Password", "User", "domain", kb), 0);
   ck_assert(memcmp(d, kb, 16) != 0);   /* the domain is not */
   ck_assert_int_eq(ntlm_ntowf_v2("\xff\xfe", "User", "Domain", kb), -1);
}
END_TEST

START_TEST (test_x509)
{
   struct x509_cert c, r, in;
   const uint8_t *chain[3];
   size_t lens[3];
   char info[128];

   ck_assert_int_eq(x509_parse(&r, x509_root, sizeof(x509_root)), 0);
   ck_assert_int_eq(r.key_type, X509_KEY_RSA);
   ck_assert_int_eq(r.sig_alg, X509_SIG_RSA_SHA384);
   ck_assert_int_eq(r.is_ca, 1);
   ck_assert(r.key_usage & X509_KU_KEY_CERT_SIGN);
   ck_assert_int_eq(x509_parse(&in, x509_inter, sizeof(x509_inter)), 0);
   ck_assert_int_eq(in.key_type, X509_KEY_P256);
   ck_assert_int_eq(in.path_len, 0);
   ck_assert_int_eq(x509_parse(&c, x509_leaf, sizeof(x509_leaf)), 0);
   ck_assert_int_eq(c.key_type, X509_KEY_RSA);
   ck_assert_int_eq(c.sig_alg, X509_SIG_ECDSA_SHA256);
   ck_assert_int_eq(c.is_ca, 0);
   ck_assert(c.not_before < X509_TEST_NOW && c.not_after > X509_TEST_NOW);

   /* signatures: RSA-SHA384 self-signed root, RSA-SHA256 over the
    * intermediate, ECDSA-SHA256 over the leaf */
   ck_assert_int_eq(x509_verify_signature(&r, &r), 0);
   ck_assert_int_eq(x509_verify_signature(&in, &r), 0);
   ck_assert_int_eq(x509_verify_signature(&c, &in), 0);
   ck_assert_int_eq(x509_verify_signature(&c, &r), -1);
   ck_assert_int_eq(x509_parse(&c, x509_badsig, sizeof(x509_badsig)), 0);
   ck_assert_int_eq(x509_verify_signature(&c, &in), -1);

   /* hostnames */
   ck_assert_int_eq(x509_parse(&c, x509_leaf, sizeof(x509_leaf)), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "example.com"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "EXAMPLE.com"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "a.wild.example.com"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "wild.example.com"), -1);
   ck_assert_int_eq(x509_match_hostname(&c, "a.b.wild.example.com"), -1);
   ck_assert_int_eq(x509_match_hostname(&c, "www.example.com"), -1);
   ck_assert_int_eq(x509_match_hostname(&c, "example.co"), -1);
   ck_assert_int_eq(x509_parse(&c, x509_cnonly, sizeof(x509_cnonly)), 0);
   ck_assert_int_eq(c.sig_alg, X509_SIG_ECDSA_SHA512);
   ck_assert_int_eq(x509_match_hostname(&c, "cn.example.com"), 0);

   /* chain against the test root as the only anchor */
   ck_assert_int_eq(x509_trust_load_pem(x509_root_pem, sizeof(x509_root_pem) - 1), 1);
   chain[0] = x509_leaf;  lens[0] = sizeof(x509_leaf);
   chain[1] = x509_inter; lens[1] = sizeof(x509_inter);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "example.com", X509_TEST_NOW, info, sizeof(info)), 0);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 2, NULL, X509_TEST_NOW, info, sizeof(info)), 0);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "other.com", X509_TEST_NOW, info, sizeof(info)), -1);
   ck_assert_str_eq(info, "hostname mismatch");
   ck_assert_int_eq(x509_verify_chain(chain, lens, 1, "example.com", X509_TEST_NOW, info, sizeof(info)), -1);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "example.com", X509_TEST_NOW + 200L * 86400, info, sizeof(info)), -1);
   ck_assert_str_eq(info, "certificate expired or not yet valid");
   chain[0] = x509_expired; lens[0] = sizeof(x509_expired);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "expired.example.com", X509_TEST_NOW, info, sizeof(info)), -1);
   chain[0] = x509_badsig; lens[0] = sizeof(x509_badsig);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "example.com", X509_TEST_NOW, info, sizeof(info)), -1);
   ck_assert_str_eq(info, "issuer not found or signature invalid");
   /* intermediate has pathLen 0: a CA below it is refused */
   chain[0] = x509_deep; lens[0] = sizeof(x509_deep);
   chain[1] = x509_sub2; lens[1] = sizeof(x509_sub2);
   chain[2] = x509_inter; lens[2] = sizeof(x509_inter);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 3, "deep.example.com", X509_TEST_NOW, info, sizeof(info)), -1);
   ck_assert_str_eq(info, "path length constraint violated");
   /* the chain may arrive with the root included, or out of order */
   chain[0] = x509_leaf;  lens[0] = sizeof(x509_leaf);
   chain[1] = x509_root;  lens[1] = sizeof(x509_root);
   chain[2] = x509_inter; lens[2] = sizeof(x509_inter);
   ck_assert_int_eq(x509_verify_chain(chain, lens, 3, "example.com", X509_TEST_NOW, info, sizeof(info)), 0);

   /* the shipped bundle: every anchor with an RSA or P-256 key parses,
    * read in place from its DER parts */
   {
      int n = x509_trust_load_der_parts(cacert_der_parts, cacert_der_sizes,
            CACERT_DER_PARTS);
      ck_assert_int_eq(n, 155);   /* every certificate in the bundle, all parts */
      ck_assert_int_eq(x509_trust_load_der_parts(cacert_der_parts, cacert_der_sizes,
            CACERT_DER_PARTS), n);
      ck_assert_int_eq(x509_verify_chain(chain, lens, 3, "example.com", X509_TEST_NOW, info, sizeof(info)), -1);
   }
   x509_trust_free();
   /* a part cut inside a certificate is refused, not read past */
   {
      const unsigned char *part = cacert_der_parts[0];
      size_t len = cacert_der_sizes[0] - 1;
      ck_assert_int_eq(x509_trust_load_der_parts(&part, &len, 1), -1);
   }
   x509_trust_free();
   /* CRLF line breaks decode as LF ones */
   {
      char   crlf[sizeof(x509_root_pem) * 2];
      size_t i, n = 0;
      for (i = 0; i < sizeof(x509_root_pem) - 1; i++)
      {
         if (x509_root_pem[i] == '\n')
            crlf[n++] = '\r';
         crlf[n++] = x509_root_pem[i];
      }
      ck_assert_int_eq(x509_trust_load_pem(crlf, n), 1);
   }
   x509_trust_free();
   /* an adopted bundle is decoded where it lies and trusted as a copied
    * one; one with nothing usable is freed, the published store kept */
   {
      char *pem = (char*)malloc(sizeof(x509_root_pem));
      ck_assert(pem != NULL);
      memcpy(pem, x509_root_pem, sizeof(x509_root_pem));
      chain[0] = x509_leaf;  lens[0] = sizeof(x509_leaf);
      chain[1] = x509_inter; lens[1] = sizeof(x509_inter);
      ck_assert_int_eq(x509_trust_adopt_pem(pem, sizeof(x509_root_pem) - 1), 1);
      ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "example.com", X509_TEST_NOW, info, sizeof(info)), 0);
      pem = (char*)malloc(sizeof(x509_root_pem));
      ck_assert(pem != NULL);
      memcpy(pem, x509_root_pem, sizeof(x509_root_pem));
      memset(strstr(pem, "-----BEGIN"), '-', 11);   /* no certificate begins */
      ck_assert_int_eq(x509_trust_adopt_pem(pem, sizeof(x509_root_pem) - 1), 0);
      ck_assert_int_eq(x509_verify_chain(chain, lens, 2, "example.com", X509_TEST_NOW, info, sizeof(info)), 0);
   }
   x509_trust_free();
}
END_TEST

/* AES inverse cipher (FIPS 197 C.1-C.3) and HMAC-SHA1 / PBKDF2-SHA1
 * (RFC 2202, RFC 6070): the pieces the Kerberos enctypes stand on. */
START_TEST (test_aes_decrypt_hmac_sha1)
{
   static const uint8_t pt[16] = {0x00,0x11,0x22,0x33,0x44,0x55,0x66,0x77,0x88,0x99,0xaa,0xbb,0xcc,0xdd,0xee,0xff};
   static const uint8_t key[32] = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31};
   static const uint8_t ct128[16] = {0x69,0xc4,0xe0,0xd8,0x6a,0x7b,0x04,0x30,0xd8,0xcd,0xb7,0x80,0x70,0xb4,0xc5,0x5a};
   static const uint8_t ct192[16] = {0xdd,0xa9,0x7c,0xa4,0x86,0x4c,0xdf,0xe0,0x6e,0xaf,0x70,0xa0,0xec,0x0d,0x71,0x91};
   static const uint8_t ct256[16] = {0x8e,0xa2,0xb7,0xca,0x51,0x67,0x45,0xbf,0xea,0xfc,0x49,0x90,0x4b,0x49,0x60,0x89};
   static const uint8_t mac2[20]  = {0xef,0xfc,0xdf,0x6a,0xe5,0xeb,0x2f,0xa2,0xd2,0x74,0x16,0xd5,0xf1,0x84,0xdf,0x9c,0x25,0x9a,0x7c,0x79};
   static const uint8_t mac7[20]  = {0xe8,0xe9,0x9d,0x0f,0x45,0x23,0x7d,0x78,0x6d,0x6b,0xba,0xa7,0x96,0x5c,0x78,0x08,0xbb,0xff,0x1a,0x91};
   static const uint8_t dk20[20]  = {0x4b,0x00,0x79,0x01,0xb7,0x65,0x48,0x9a,0xbe,0xad,0x49,0xd9,0x26,0xf7,0x21,0xd0,0x65,0xa4,0x29,0xc1};
   static const uint8_t dk25[25]  = {0x3d,0x2e,0xec,0x4f,0xe4,0x1c,0x84,0x9b,0x80,0xc8,0xd8,0x36,0x62,0xc0,0xe4,0x4a,0x8b,0x29,0x1a,0x96,0x4c,0xf2,0xf0,0x70,0x38};
   struct aes_ctx c;
   uint8_t out[32], big[80];
   unsigned i;

   aes_init(&c, key, 16); aes_decrypt_block(&c, ct128, out); ck_assert(memcmp(out, pt, 16) == 0);
   aes_init(&c, key, 24); aes_decrypt_block(&c, ct192, out); ck_assert(memcmp(out, pt, 16) == 0);
   aes_init(&c, key, 32); aes_decrypt_block(&c, ct256, out); ck_assert(memcmp(out, pt, 16) == 0);
   /* and the inverse of the forward cipher on this build's own path */
   for (i = 0; i < 64; i++)
   {
      uint8_t b[16], e[16], d[16];
      unsigned j;
      for (j = 0; j < 16; j++)
         b[j] = (uint8_t)(i * 37 + j * 11);
      aes_init(&c, key, 16 + 8 * (i % 3));
      aes_encrypt_block(&c, b, e);
      aes_decrypt_block(&c, e, d);
      ck_assert(memcmp(b, d, 16) == 0);
   }

   hmac_sha1((const uint8_t*)"Jefe", 4, (const uint8_t*)"what do ya want for nothing?", 28, out);
   ck_assert(memcmp(out, mac2, 20) == 0);
   memset(big, 0xaa, 80);
   hmac_sha1(big, 80, (const uint8_t*)"Test Using Larger Than Block-Size Key and Larger Than One Block-Size Data", 73, out);
   ck_assert(memcmp(out, mac7, 20) == 0);
   ck_assert(pbkdf2_hmac_sha1((const uint8_t*)"password", 8, (const uint8_t*)"salt", 4, 4096, out, 20) == 0);
   ck_assert(memcmp(out, dk20, 20) == 0);
   ck_assert(pbkdf2_hmac_sha1((const uint8_t*)"passwordPASSWORDpassword", 24,
            (const uint8_t*)"saltSALTsaltSALTsaltSALTsaltSALTsalt", 36, 4096, out, 25) == 0);
   ck_assert(memcmp(out, dk25, 25) == 0);
}
END_TEST

/* Kerberos AES enctypes: n-fold (RFC 3961 A.1), CTS (RFC 3962 B),
 * string-to-key (RFC 3962 B), and encrypt / decrypt with the
 * confounder and truncated HMAC, tampering and wrong usage refused. */
START_TEST (test_krb5_enctypes)
{
   static const struct { const char *in; unsigned n; const char *out; } nf[] = {
      { "012345", 8, "\xbe\x07\x26\x31\x27\x6b\x19\x55" },
      { "password", 7, "\x78\xa0\x7b\x6c\xaf\x85\xfa" },
      { "Rough Consensus, and Running Code", 8, "\xbb\x6e\xd3\x08\x70\xb7\xf0\xe0" },
      { "password", 21, "\x59\xe4\xa8\xca\x7c\x03\x85\xc3\xc3\x7b\x3f\x6d\x20\x00\x24\x7c\xb6\xe6\xbd\x5b\x3e" },
      { "MASSACHVSETTS INSTITVTE OF TECHNOLOGY", 24, "\xdb\x3b\x0d\x8f\x0b\x06\x1e\x60\x32\x82\xb3\x08\xa5\x08\x41\x22\x9a\xd7\x98\xfa\xb9\x54\x0c\x1b" },
      { "kerberos", 16, "\x6b\x65\x72\x62\x65\x72\x6f\x73\x7b\x9b\x5b\x2b\x93\x13\x2b\x93" },
      { "kerberos", 32, "\x6b\x65\x72\x62\x65\x72\x6f\x73\x7b\x9b\x5b\x2b\x93\x13\x2b\x93\x5c\x9b\xdc\xda\xd9\x5c\x98\x99\xc4\xca\xe4\xde\xe6\xd6\xca\xe4" },
   };
   static const uint8_t cts_key[16] = { 0x63,0x68,0x69,0x63,0x6b,0x65,0x6e,0x20,0x74,0x65,0x72,0x69,0x79,0x61,0x6b,0x69 };
   static const char    cts_pt[]    = "I would like the General Gau's Chicken, please, and wonton soup.";
   static const struct { unsigned len; const char *ct; } cts[] = {
      { 17, "\xc6\x35\x35\x68\xf2\xbf\x8c\xb4\xd8\xa5\x80\x36\x2d\xa7\xff\x7f\x97" },
      { 31, "\xfc\x00\x78\x3e\x0e\xfd\xb2\xc1\xd4\x45\xd4\xc8\xef\xf7\xed\x22\x97\x68\x72\x68\xd6\xec\xcc\xc0\xc0\x7b\x25\xe2\x5e\xcf\xe5" },
      { 32, "\x39\x31\x25\x23\xa7\x86\x62\xd5\xbe\x7f\xcb\xcc\x98\xeb\xf5\xa8\x97\x68\x72\x68\xd6\xec\xcc\xc0\xc0\x7b\x25\xe2\x5e\xcf\xe5\x84" },
      { 47, "\x97\x68\x72\x68\xd6\xec\xcc\xc0\xc0\x7b\x25\xe2\x5e\xcf\xe5\x84\xb3\xff\xfd\x94\x0c\x16\xa1\x8c\x1b\x55\x49\xd2\xf8\x38\x02\x9e\x39\x31\x25\x23\xa7\x86\x62\xd5\xbe\x7f\xcb\xcc\x98\xeb\xf5" },
      { 48, "\x97\x68\x72\x68\xd6\xec\xcc\xc0\xc0\x7b\x25\xe2\x5e\xcf\xe5\x84\x9d\xad\x8b\xbb\x96\xc4\xcd\xc0\x3b\xc1\x03\xe1\xa1\x94\xbb\xd8\x39\x31\x25\x23\xa7\x86\x62\xd5\xbe\x7f\xcb\xcc\x98\xeb\xf5\xa8" },
      { 64, "\x97\x68\x72\x68\xd6\xec\xcc\xc0\xc0\x7b\x25\xe2\x5e\xcf\xe5\x84\x39\x31\x25\x23\xa7\x86\x62\xd5\xbe\x7f\xcb\xcc\x98\xeb\xf5\xa8\x48\x07\xef\xe8\x36\xee\x89\xa5\x26\x73\x0d\xbc\x2f\x7b\xc8\x40\x9d\xad\x8b\xbb\x96\xc4\xcd\xc0\x3b\xc1\x03\xe1\xa1\x94\xbb\xd8" },
   };
   static const struct { int et; const char *pw; size_t pwl; const char *salt; uint32_t it; const char *key; } s2k[] = {
      { 17, "password", 8, "ATHENA.MIT.EDUraeburn", 1,    "\x42\x26\x3c\x6e\x89\xf4\xfc\x28\xb8\xdf\x68\xee\x09\x79\x9f\x15" },
      { 18, "password", 8, "ATHENA.MIT.EDUraeburn", 1,    "\xfe\x69\x7b\x52\xbc\x0d\x3c\xe1\x44\x32\xba\x03\x6a\x92\xe6\x5b\xbb\x52\x28\x09\x90\xa2\xfa\x27\x88\x39\x98\xd7\x2a\xf3\x01\x61" },
      { 17, "password", 8, "ATHENA.MIT.EDUraeburn", 2,    "\xc6\x51\xbf\x29\xe2\x30\x0a\xc2\x7f\xa4\x69\xd6\x93\xbd\xda\x13" },
      { 18, "password", 8, "ATHENA.MIT.EDUraeburn", 1200, "\x55\xa6\xac\x74\x0a\xd1\x7b\x48\x46\x94\x10\x51\xe1\xe8\xb0\xa7\x54\x8d\x93\xb0\xab\x30\xa8\xbc\x3f\xf1\x62\x80\x38\x2b\x8c\x2a" },
      { 17, "\xf0\x9d\x84\x9e", 4, "EXAMPLE.COMpianist", 50, "\xf1\x49\xc1\xf2\xe1\x54\xa7\x34\x52\xd4\x3e\x7f\xe6\x2a\x56\xe5" },
   };
   struct krb5_key k;
   uint8_t buf[80], out[80], msg[100], conf[16];
   size_t n, i, L, pl;

   for (i = 0; i < sizeof(nf) / sizeof(nf[0]); i++)
   {
      krb5_nfold((const uint8_t*)nf[i].in, (unsigned)strlen(nf[i].in), buf, nf[i].n);
      ck_assert(memcmp(buf, nf[i].out, nf[i].n) == 0);
   }
   for (i = 0; i < sizeof(cts) / sizeof(cts[0]); i++)
   {
      ck_assert(krb5_raw_cts(cts_key, 16, 0, (const uint8_t*)cts_pt, cts[i].len, buf) == 0);
      ck_assert(memcmp(buf, cts[i].ct, cts[i].len) == 0);
      ck_assert(krb5_raw_cts(cts_key, 16, 1, buf, cts[i].len, buf) == 0);   /* in place */
      ck_assert(memcmp(buf, cts_pt, cts[i].len) == 0);
   }
   for (i = 0; i < sizeof(s2k) / sizeof(s2k[0]); i++)
   {
      ck_assert(krb5_string_to_key(s2k[i].et, s2k[i].pw, s2k[i].pwl, s2k[i].salt, strlen(s2k[i].salt), s2k[i].it, &k) == 0);
      ck_assert(memcmp(k.k, s2k[i].key, k.len) == 0);
   }
   ck_assert(krb5_string_to_key(23, "x", 1, "y", 1, 1, &k) == -1);

   memset(conf, 0x11, sizeof(conf));
   for (i = 0; i < sizeof(msg); i++)
      msg[i] = (uint8_t)(i * 3);
   ck_assert(krb5_string_to_key(18, "pw", 2, "salt", 4, 3, &k) == 0);
   for (L = 0; L < 50; L += 7)
   {
      n = krb5_encrypt(&k, 3, conf, msg, L, buf);
      ck_assert(n == L + 16 + 12);
      ck_assert(krb5_decrypt(&k, 3, buf, n, out, &pl) == 0);
      ck_assert(pl == L && memcmp(out, msg, L) == 0);
      buf[5] ^= 1;
      ck_assert(krb5_decrypt(&k, 3, buf, n, out, &pl) == -1);
      buf[5] ^= 1;
      ck_assert(krb5_decrypt(&k, 4, buf, n, out, &pl) == -1);
      ck_assert(krb5_decrypt(&k, 3, buf, 27, out, &pl) == -1);
   }
}
END_TEST

/* The bulk paths - eight AES blocks at a time, four ChaCha20 blocks,
 * Poly1305 in 44-bit limbs - against the block functions they must
 * agree with, over lengths either side of each group size and counters
 * across the 32-bit wrap. */
static uint32_t bulk_rng = 0x9e3779b9u;
static uint32_t bulk_rand(void)
{
   bulk_rng ^= bulk_rng << 13; bulk_rng ^= bulk_rng >> 17; bulk_rng ^= bulk_rng << 5;
   return bulk_rng;
}

/* aes_ctr128_crypt: the counter is one 128-bit big-endian number, as
 * SP 800-38A's standard incrementing function. Against the F.5.1
 * vector, then a block at a time from counters whose low 32 bits are
 * about to wrap (the carry into octets 0..11), up to the whole block
 * wrapping to zero, in one call and in pieces on block boundaries. */
static void ctr128_inc(uint8_t *c)
{
   int i;
   for (i = 15; i >= 0; i--)
      if (++c[i])
         break;
}

START_TEST(test_aes_ctr128)
{
   static const uint8_t key[16] = {
      0x2b,0x7e,0x15,0x16,0x28,0xae,0xd2,0xa6,
      0xab,0xf7,0x15,0x88,0x09,0xcf,0x4f,0x3c };
   static const uint8_t ctr0[16] = {
      0xf0,0xf1,0xf2,0xf3,0xf4,0xf5,0xf6,0xf7,
      0xf8,0xf9,0xfa,0xfb,0xfc,0xfd,0xfe,0xff };
   static const uint8_t pt[64] = {
      0x6b,0xc1,0xbe,0xe2,0x2e,0x40,0x9f,0x96,0xe9,0x3d,0x7e,0x11,0x73,0x93,0x17,0x2a,
      0xae,0x2d,0x8a,0x57,0x1e,0x03,0xac,0x9c,0x9e,0xb7,0x6f,0xac,0x45,0xaf,0x8e,0x51,
      0x30,0xc8,0x1c,0x46,0xa3,0x5c,0xe4,0x11,0xe5,0xfb,0xc1,0x19,0x1a,0x0a,0x52,0xef,
      0xf6,0x9f,0x24,0x45,0xdf,0x4f,0x9b,0x17,0xad,0x2b,0x41,0x7b,0xe6,0x6c,0x37,0x10 };
   static const uint8_t ct[64] = {
      0x87,0x4d,0x61,0x91,0xb6,0x20,0xe3,0x26,0x1b,0xef,0x68,0x64,0x99,0x0d,0xb6,0xce,
      0x98,0x06,0xf6,0x6b,0x79,0x70,0xfd,0xff,0x86,0x17,0x18,0x7b,0xb9,0xff,0xfd,0xff,
      0x5a,0xe4,0xdf,0x3e,0xdb,0xd5,0xd3,0x5e,0x5b,0x4f,0x09,0x02,0x0d,0xb0,0x3e,0xab,
      0x1e,0x03,0x1d,0xda,0x2f,0xbe,0x03,0xd1,0x79,0x21,0x70,0xa0,0xf3,0x00,0x9c,0xee };
   static uint8_t in[2100], out[2100], ref[2100];
   uint8_t c[16], iv[16], blk[16], k[32];
   struct aes_ctx a;
   unsigned it, i;

   ck_assert_int_eq(aes_init(&a, key, 16), 0);
   memcpy(c, ctr0, 16);
   aes_ctr128_crypt(&a, c, pt, out, 64);
   ck_assert_int_eq(memcmp(out, ct, 64), 0);

   for (i = 0; i < sizeof(in); i++)
      in[i] = (uint8_t)bulk_rand();
   for (it = 0; it < 200; it++)
   {
      size_t len = bulk_rand() % 2049;
      for (i = 0; i < 32; i++)
         k[i] = (uint8_t)bulk_rand();
      ck_assert_int_eq(aes_init(&a, k, (it & 1) ? 32 : 16), 0);
      for (i = 0; i < 16; i++)
         iv[i] = (uint8_t)bulk_rand();
      /* The low word within 64 blocks of wrapping; every fourth run
       * with the octets above it all ones too, so the carry runs out
       * of the whole block */
      iv[12] = iv[13] = iv[14] = 0xff;
      iv[15] = (uint8_t)(0xc0 + (bulk_rand() % 64));
      if (!(it & 3))
         for (i = 0; i < 12; i++)
            iv[i] = 0xff;
      else if (it & 2)
         for (i = 4; i < 12; i++)
            iv[i] = 0xff;

      memcpy(c, iv, 16);
      for (i = 0; i < len; i++)
      {
         if (!(i % 16))
         {
            aes_encrypt_block(&a, c, blk);
            ctr128_inc(c);
         }
         ref[i] = in[i] ^ blk[i % 16];
      }
      memcpy(blk, c, 16); /* the counter the reference ends on */

      memcpy(c, iv, 16);
      aes_ctr128_crypt(&a, c, in, out, len);
      ck_assert_int_eq(memcmp(out, ref, len), 0);
      ck_assert_int_eq(memcmp(c, blk, 16), 0);

      /* In pieces of whole blocks, then the rest */
      memcpy(c, iv, 16);
      {
         size_t p = 0;
         while (p < len)
         {
            size_t n = 16 * (1 + bulk_rand() % 12);
            if (n > len - p)
               n = len - p;
            aes_ctr128_crypt(&a, c, in + p, out + p, n);
            p += n;
         }
      }
      ck_assert_int_eq(memcmp(out, ref, len), 0);
      ck_assert_int_eq(memcmp(c, blk, 16), 0);
   }
}
END_TEST

START_TEST(test_bulk_paths)
{
   static uint8_t in[2100], out[2100], ref[2100];
   uint8_t key[32], nonce[12], blk[64], iv[16], tag1[16], tag2[16];
   unsigned it, i;

   for (i = 0; i < sizeof(in); i++)
      in[i] = (uint8_t)bulk_rand();
   for (it = 0; it < 300; it++)
   {
      size_t   len = bulk_rand() % 2049;
      uint32_t ctr = (it & 1) ? bulk_rand() : 0xfffffff0u + (bulk_rand() % 16);
      struct aes_ctx a;
      for (i = 0; i < 32; i++)
         key[i] = (uint8_t)bulk_rand();
      for (i = 0; i < 12; i++)
         nonce[i] = (uint8_t)bulk_rand();

      /* ChaCha20: chacha20_xor against the keystream a block at a time */
      chacha20_xor(key, nonce, ctr, in, out, len);
      for (i = 0; i < len; i++)
      {
         if (!(i % 64))
            chacha20_block(key, nonce, ctr + (uint32_t)(i / 64), blk);
         ref[i] = in[i] ^ blk[i % 64];
      }
      ck_assert_int_eq(memcmp(out, ref, len), 0);

      /* AES-CTR: aes_ctr_crypt against aes_encrypt_block per counter */
      ck_assert_int_eq(aes_init(&a, key, (it & 2) ? 32 : 16), 0);
      memcpy(iv, nonce, 12);
      iv[12] = (uint8_t)(ctr >> 24); iv[13] = (uint8_t)(ctr >> 16);
      iv[14] = (uint8_t)(ctr >> 8);  iv[15] = (uint8_t)ctr;
      {
         uint8_t c[16];
         memcpy(c, iv, 16);
         aes_ctr_crypt(&a, c, in, out, len);
      }
      for (i = 0; i < len; i++)
      {
         if (!(i % 16))
         {
            uint32_t n = ctr + (uint32_t)(i / 16);
            iv[12] = (uint8_t)(n >> 24); iv[13] = (uint8_t)(n >> 16);
            iv[14] = (uint8_t)(n >> 8);  iv[15] = (uint8_t)n;
            aes_encrypt_block(&a, iv, blk);
         }
         ref[i] = in[i] ^ blk[i % 16];
      }
      ck_assert_int_eq(memcmp(out, ref, len), 0);

      /* Poly1305: random chunks against the one-shot tag */
      poly1305_auth(tag1, in, len, key);
      {
         struct poly1305_ctx pc;
         size_t p = 0;
         poly1305_init(&pc, key);
         while (p < len)
         {
            size_t k = bulk_rand() % 200;
            if (k > len - p)
               k = len - p;
            poly1305_update(&pc, in + p, k);
            p += k;
         }
         poly1305_final(&pc, tag2);
      }
      ck_assert_int_eq(memcmp(tag1, tag2, 16), 0);
   }
}
END_TEST

/* IP literals: parsed exactly, and matched only against iPAddress SAN
 * entries - never a dNSName or the commonName that happens to spell the
 * address. */
START_TEST (test_x509_ip_literals)
{
   static const uint8_t v6_loop[16] = { 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1 };
   static const uint8_t v6_mapped[16] = { 0,0,0,0,0,0,0,0,0,0,0xff,0xff,192,0,2,1 };
   /* GeneralNames contents: dNSName example.com, iPAddress 127.0.0.1,
    * iPAddress ::1, and a dNSName that merely reads "10.0.0.1" */
   static const uint8_t san[] = {
      0x82, 11, 'e','x','a','m','p','l','e','.','c','o','m',
      0x87, 4, 127, 0, 0, 1,
      0x87, 16, 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
      0x82, 8, '1','0','.','0','.','0','.','1'
   };
   static const uint8_t cn_ip[] = { '1','0','.','0','.','0','.','1' };
   struct x509_cert c;
   uint8_t ip[16];

   ck_assert_int_eq(x509_parse_ip("127.0.0.1", ip), 4);
   ck_assert(ip[0] == 127 && ip[1] == 0 && ip[2] == 0 && ip[3] == 1);
   ck_assert_int_eq(x509_parse_ip("::1", ip), 16);
   ck_assert(!memcmp(ip, v6_loop, 16));
   ck_assert_int_eq(x509_parse_ip("[::1]", ip), 16);
   ck_assert(!memcmp(ip, v6_loop, 16));
   ck_assert_int_eq(x509_parse_ip("0:0:0:0:0:0:0:1", ip), 16);
   ck_assert(!memcmp(ip, v6_loop, 16));
   ck_assert_int_eq(x509_parse_ip("fe80::1%25eth0", ip), 16);
   ck_assert(ip[0] == 0xfe && ip[1] == 0x80 && ip[15] == 1);
   ck_assert_int_eq(x509_parse_ip("::ffff:192.0.2.1", ip), 16);
   ck_assert(!memcmp(ip, v6_mapped, 16));
   ck_assert_int_eq(x509_parse_ip("::", ip), 16);
   /* not IP literals: host names, and malformed addresses */
   ck_assert_int_eq(x509_parse_ip("example.com", ip), 0);
   ck_assert_int_eq(x509_parse_ip("1.2.3", ip), 0);
   ck_assert_int_eq(x509_parse_ip("1.2.3.4.5", ip), 0);
   ck_assert_int_eq(x509_parse_ip("256.0.0.1", ip), 0);
   ck_assert_int_eq(x509_parse_ip("01.2.3.4", ip), 0);
   ck_assert_int_eq(x509_parse_ip("1::2::3", ip), 0);
   ck_assert_int_eq(x509_parse_ip("1:2:3:4:5:6:7:8:9", ip), 0);
   ck_assert_int_eq(x509_parse_ip("1:2:3:4:5:6:7:8::", ip), 0);
   ck_assert_int_eq(x509_parse_ip(":1", ip), 0);
   ck_assert_int_eq(x509_parse_ip("1:", ip), 0);
   ck_assert_int_eq(x509_parse_ip("12345::1", ip), 0);
   ck_assert_int_eq(x509_parse_ip("[::1", ip), 0);

   memset(&c, 0, sizeof(c));
   c.san     = san;
   c.san_len = sizeof(san);
   ck_assert_int_eq(x509_match_hostname(&c, "example.com"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "127.0.0.1"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "::1"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "0::0:1"), 0);
   ck_assert_int_eq(x509_match_hostname(&c, "127.0.0.2"), -1);
   ck_assert_int_eq(x509_match_hostname(&c, "::2"), -1);
   /* an address the certificate lists only as a dNSName string */
   ck_assert_int_eq(x509_match_hostname(&c, "10.0.0.1"), -1);
   /* nor through the commonName, with no subjectAltName at all */
   memset(&c, 0, sizeof(c));
   c.cn     = cn_ip;
   c.cn_len = sizeof(cn_ip);
   ck_assert_int_eq(x509_match_hostname(&c, "10.0.0.1"), -1);
}
END_TEST

/* The pieces of a message: up to three, cut at random points. */
static unsigned stream_cuts(size_t len, size_t *cut)
{
   unsigned n = bulk_rand() % 3, i;
   cut[0] = 0;
   for (i = 1; i <= n; i++)
      cut[i] = len ? bulk_rand() % (len + 1) : 0;
   cut[n + 1] = len;
   /* sorted, so pieces are in order (empty ones included) */
   for (i = 1; i <= n; i++)
   {
      unsigned j;
      for (j = i + 1; j <= n; j++)
         if (cut[j] < cut[i])
         {
            size_t t = cut[i]; cut[i] = cut[j]; cut[j] = t;
         }
   }
   return n + 1;
}

/* The streaming CMAC, GCM and CCM against their one-shot forms, the
 * message in pieces cut anywhere, including inside a block and empty
 * ones; and the GCM counter mode at any offset. */
START_TEST(test_streams)
{
   static uint8_t in[2100], out[2100], ref[2100], aad[100];
   uint8_t key[32], nonce[12], tag1[16], tag2[16];
   size_t  cut[4];
   unsigned it, i, k;

   for (i = 0; i < sizeof(in); i++)
      in[i] = (uint8_t)bulk_rand();
   for (i = 0; i < sizeof(aad); i++)
      aad[i] = (uint8_t)bulk_rand();
   for (it = 0; it < 400; it++)
   {
      size_t   len     = bulk_rand() % 2049;
      size_t   aad_len = bulk_rand() % 70;
      unsigned pieces;
      struct aes_ctx        a;
      struct aes_gcm_ctx    g;
      struct aes_cmac_ctx   m;
      struct aes_ccm_stream c;
      struct aes_gcm_stream gs;
      for (i = 0; i < 32; i++)
         key[i] = (uint8_t)bulk_rand();
      for (i = 0; i < 12; i++)
         nonce[i] = (uint8_t)bulk_rand();
      ck_assert_int_eq(aes_init(&a, key, 16), 0);
      ck_assert_int_eq(aes_gcm_init(&g, key, (it & 1) ? 32 : 16), 0);

      /* CMAC */
      aes_cmac(&a, in, len, tag1);
      pieces = stream_cuts(len, cut);
      aes_cmac_init(&m, &a);
      for (k = 0; k < pieces; k++)
         aes_cmac_update(&m, in + cut[k], cut[k + 1] - cut[k]);
      aes_cmac_final(&m, tag2);
      ck_assert_int_eq(memcmp(tag1, tag2, 16), 0);

      /* GCM: the tag over AAD and ciphertext in pieces, the counter
       * mode piece by piece at their offsets */
      aes_gcm_encrypt(&g, nonce, 12, aad, aad_len, in, len, ref, tag1);
      aes_gcm_stream_init(&gs, &g, nonce, 12);
      pieces = stream_cuts(aad_len, cut);
      for (k = 0; k < pieces; k++)
         aes_gcm_stream_aad(&gs, aad + cut[k], cut[k + 1] - cut[k]);
      pieces = stream_cuts(len, cut);
      for (k = 0; k < pieces; k++)
      {
         aes_gcm_stream_crypt(&gs, cut[k], in + cut[k], out + cut[k],
               cut[k + 1] - cut[k]);
         aes_gcm_stream_hash_ct(&gs, out + cut[k], cut[k + 1] - cut[k]);
      }
      aes_gcm_stream_tag(&gs, tag2);
      ck_assert_int_eq(memcmp(out, ref, len), 0);
      ck_assert_int_eq(memcmp(tag1, tag2, 16), 0);
      /* back again, last piece first, in place */
      for (k = pieces; k-- > 0; )
         aes_gcm_stream_crypt(&gs, cut[k], out + cut[k], out + cut[k],
               cut[k + 1] - cut[k]);
      ck_assert_int_eq(memcmp(out, in, len), 0);
      /* GMAC: the AAD alone */
      aes_gcm_encrypt(&g, nonce, 12, aad, aad_len, NULL, 0, NULL, tag1);
      aes_gcm_stream_init(&gs, &g, nonce, 12);
      pieces = stream_cuts(aad_len, cut);
      for (k = 0; k < pieces; k++)
         aes_gcm_stream_aad(&gs, aad + cut[k], cut[k + 1] - cut[k]);
      aes_gcm_stream_tag(&gs, tag2);
      ck_assert_int_eq(memcmp(tag1, tag2, 16), 0);

      /* CCM, the SMB3 shape: encrypt in pieces, decrypt in other
       * pieces in place */
      ck_assert_int_eq(aes_ccm_encrypt(&a, nonce, 11, aad, aad_len,
               in, len, ref, tag1, 16), 0);
      ck_assert_int_eq(aes_ccm_stream_init(&c, &a, nonce, 11, aad, aad_len,
               len, 16), 0);
      pieces = stream_cuts(len, cut);
      for (k = 0; k < pieces; k++)
         aes_ccm_stream_encrypt(&c, in + cut[k], out + cut[k],
               cut[k + 1] - cut[k]);
      aes_ccm_stream_tag(&c, tag2);
      ck_assert_int_eq(memcmp(out, ref, len), 0);
      ck_assert_int_eq(memcmp(tag1, tag2, 16), 0);
      ck_assert_int_eq(aes_ccm_stream_init(&c, &a, nonce, 11, aad, aad_len,
               len, 16), 0);
      pieces = stream_cuts(len, cut);
      for (k = 0; k < pieces; k++)
         aes_ccm_stream_decrypt(&c, out + cut[k], out + cut[k],
               cut[k + 1] - cut[k]);
      aes_ccm_stream_tag(&c, tag2);
      ck_assert_int_eq(memcmp(out, in, len), 0);
      ck_assert_int_eq(memcmp(tag1, tag2, 16), 0);
   }
}
END_TEST

/* CFB128: SP 800-38A F.3.13 and F.3.17 (128- and 256-bit keys), then
 * random streams split at random points against one call, decrypted
 * back, in place and not. */
START_TEST(test_aes_cfb128)
{
   static uint8_t in[600], out[600], ref[600], back[600];
   uint8_t  key[32], iv[16], v[16], pt[64], ct[64];
   unsigned it, num;
   size_t   i;
   struct aes_ctx a;

   unhex(pt, 64, "6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e51"
         "30c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710");
   unhex(key, 16, "2b7e151628aed2a6abf7158809cf4f3c");
   unhex(v, 16, "000102030405060708090a0b0c0d0e0f");
   ck_assert_int_eq(aes_init(&a, key, 16), 0);
   num = 0;
   aes_cfb128_encrypt(&a, v, &num, pt, ct, 64);
   ck_hex(ct, 64, "3b3fd92eb72dad20333449f8e83cfb4ac8a64537a0b3a93fcde3cdad9f1ce58b"
         "26751f67a3cbb140b1808cf187a4f4dfc04b05357c5d1c0eeac4c66f9ff7f2e6");
   unhex(key, 32, "603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4");
   unhex(v, 16, "000102030405060708090a0b0c0d0e0f");
   ck_assert_int_eq(aes_init(&a, key, 32), 0);
   num = 0;
   aes_cfb128_encrypt(&a, v, &num, pt, ct, 64);
   ck_hex(ct, 64, "dc7e84bfda79164b7ecd8486985d386039ffed143b28b1c832113c6331e5407b"
         "df10132415e54b92a13ed0a8267ae2f975a385741ab9cef82031623d55b1e471");

   for (it = 0; it < 200; it++)
   {
      size_t len = bulk_rand() % sizeof(in), at;
      for (i = 0; i < 32; i++)
         key[i] = (uint8_t)bulk_rand();
      for (i = 0; i < 16; i++)
         iv[i] = (uint8_t)bulk_rand();
      for (i = 0; i < len; i++)
         in[i] = (uint8_t)bulk_rand();
      ck_assert_int_eq(aes_init(&a, key, (it & 1) ? 32 : 16), 0);
      memcpy(v, iv, 16);
      num = 0;
      aes_cfb128_encrypt(&a, v, &num, in, ref, len);
      ck_assert_uint_eq(num, (unsigned)(len & 15));
      /* the same stream in random pieces */
      memcpy(v, iv, 16);
      num = 0;
      for (at = 0; at < len; )
      {
         size_t n = 1 + bulk_rand() % 40;
         if (n > len - at)
            n = len - at;
         aes_cfb128_encrypt(&a, v, &num, in + at, out + at, n);
         at += n;
      }
      ck_assert_int_eq(memcmp(out, ref, len), 0);
      /* and back, in place */
      memcpy(back, ref, len);
      memcpy(v, iv, 16);
      num = 0;
      for (at = 0; at < len; )
      {
         size_t n = 1 + bulk_rand() % 40;
         if (n > len - at)
            n = len - at;
         aes_cfb128_decrypt(&a, v, &num, back + at, back + at, n);
         at += n;
      }
      ck_assert_int_eq(memcmp(back, in, len), 0);
   }
}
END_TEST

/* CBC: SP 800-38A F.2.1, then interleaved chains - in place and not,
 * 128- and 256-bit keys - against one block at a time through
 * aes_encrypt_block(). */
START_TEST(test_aes_cbc)
{
   static uint8_t in[13][1024], out[13][1024], ref[13][1024];
   uint8_t key[32], iv[13][16], rv[16], ct[64], pt[64], v[16];
   unsigned it, l, i;
   struct aes_ctx a;

   unhex(key, 16, "2b7e151628aed2a6abf7158809cf4f3c");
   unhex(v, 16, "000102030405060708090a0b0c0d0e0f");
   unhex(pt, 64, "6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e51"
         "30c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710");
   ck_assert_int_eq(aes_init(&a, key, 16), 0);
   aes_cbc_encrypt(&a, v, pt, ct, 64);
   ck_hex(ct, 64, "7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b2"
         "73bed6b8e3c1743b7116e69e222295163ff1caa1681fac09120eca307586e1a7");
   ck_assert_int_eq(memcmp(v, ct + 48, 16), 0);

   for (it = 0; it < 200; it++)
   {
      unsigned       n       = 1 + bulk_rand() % 13;
      size_t         len     = 16 * (bulk_rand() % 65);
      int            inplace = (it & 2) != 0;
      uint8_t       *ivp[13], *outp[13];
      const uint8_t *inp[13];
      for (i = 0; i < 32; i++)
         key[i] = (uint8_t)bulk_rand();
      ck_assert_int_eq(aes_init(&a, key, (it & 1) ? 32 : 16), 0);
      for (l = 0; l < n; l++)
      {
         size_t off;
         for (i = 0; i < 16; i++)
            iv[l][i] = (uint8_t)bulk_rand();
         for (i = 0; i < len; i++)
            in[l][i] = (uint8_t)bulk_rand();
         memcpy(rv, iv[l], 16);
         for (off = 0; off < len; off += 16)
         {
            for (i = 0; i < 16; i++)
               rv[i] ^= in[l][off + i];
            aes_encrypt_block(&a, rv, rv);
            memcpy(ref[l] + off, rv, 16);
         }
         ivp[l]  = iv[l];
         inp[l]  = in[l];
         outp[l] = inplace ? in[l] : out[l];
      }
      aes_cbc_encrypt_lanes(&a, n, ivp, inp, outp, len);
      for (l = 0; l < n; l++)
      {
         ck_assert_int_eq(memcmp(outp[l], ref[l], len), 0);
         if (len)
            ck_assert_int_eq(memcmp(iv[l], ref[l] + len - 16, 16), 0);
      }
   }
}
END_TEST

/* CBC decryption: SP 800-38A F.2.2, then random runs - in place and
 * not, every key size, lengths through the eight-block and the single
 * block loops - against one block at a time through aes_decrypt_block(),
 * continued across two calls. */
START_TEST(test_aes_cbc_decrypt)
{
   static uint8_t in[1040], out[1040], ref[1040];
   uint8_t key[32], iv[16], rv[16], prev[16], pt[64], ct[64], v[16];
   unsigned it, i;
   struct aes_ctx a;

   unhex(key, 16, "2b7e151628aed2a6abf7158809cf4f3c");
   unhex(v, 16, "000102030405060708090a0b0c0d0e0f");
   unhex(ct, 64, "7649abac8119b246cee98e9b12e9197d5086cb9b507219ee95db113a917678b2"
         "73bed6b8e3c1743b7116e69e222295163ff1caa1681fac09120eca307586e1a7");
   ck_assert_int_eq(aes_init(&a, key, 16), 0);
   aes_cbc_decrypt(&a, v, ct, pt, 64);
   ck_hex(pt, 64, "6bc1bee22e409f96e93d7e117393172aae2d8a571e03ac9c9eb76fac45af8e51"
         "30c81c46a35ce411e5fbc1191a0a52eff69f2445df4f9b17ad2b417be66c3710");
   ck_assert_int_eq(memcmp(v, ct + 48, 16), 0);

   for (it = 0; it < 300; it++)
   {
      size_t   len     = 16 * (bulk_rand() % 66);
      size_t   cut     = len ? 16 * (bulk_rand() % (len / 16 + 1)) : 0;
      int      inplace = (it & 4) != 0;
      uint8_t *dst     = inplace ? in : out;
      size_t   off;
      for (i = 0; i < 32; i++)
         key[i] = (uint8_t)bulk_rand();
      ck_assert_int_eq(aes_init(&a, key, 16 + 8 * (it % 3)), 0);
      for (i = 0; i < 16; i++)
         iv[i] = (uint8_t)bulk_rand();
      for (i = 0; i < len; i++)
         in[i] = (uint8_t)bulk_rand();
      memcpy(prev, iv, 16);
      for (off = 0; off < len; off += 16)
      {
         aes_decrypt_block(&a, in + off, rv);
         for (i = 0; i < 16; i++)
            ref[off + i] = rv[i] ^ prev[i];
         memcpy(prev, in + off, 16);
      }
      aes_cbc_decrypt(&a, iv, in, dst, cut);
      aes_cbc_decrypt(&a, iv, in + cut, dst + cut, len - cut);
      ck_assert_int_eq(memcmp(dst, ref, len), 0);
      ck_assert_int_eq(memcmp(iv, prev, 16), 0);
   }
}
END_TEST

/* XTS-AES-128: IEEE 1619 vectors 1 and 2, then random data units -
 * in place and not, both key sizes, lengths through the eight-block and
 * the single-block loops - against one block at a time through
 * aes_encrypt_block()/aes_decrypt_block(), and back. */
START_TEST(test_aes_xts)
{
   static uint8_t in[1040], out[1040], ref[1040], back[1040];
   uint8_t k1[32], k2[32], tw[16], t[16], b[16], pt[32];
   unsigned it, i;
   size_t off;
   struct aes_ctx a, c;

   memset(k1, 0, 16);
   memset(k2, 0, 16);
   memset(tw, 0, 16);
   memset(pt, 0, 32);
   ck_assert_int_eq(aes_init(&a, k1, 16), 0);
   ck_assert_int_eq(aes_init(&c, k2, 16), 0);
   aes_xts_encrypt(&a, &c, tw, pt, out, 32);
   ck_hex(out, 32, "917cf69ebd68b2ec9b9fe9a3eadda692cd43d2f59598ed858c02c2652fbf922e");
   aes_xts_decrypt(&a, &c, tw, out, out, 32);
   ck_assert_int_eq(memcmp(out, pt, 32), 0);

   memset(k1, 0x11, 16);
   memset(k2, 0x22, 16);
   memset(tw, 0, 16);
   memset(tw, 0x33, 5);
   memset(pt, 0x44, 32);
   ck_assert_int_eq(aes_init(&a, k1, 16), 0);
   ck_assert_int_eq(aes_init(&c, k2, 16), 0);
   aes_xts_encrypt(&a, &c, tw, pt, out, 32);
   ck_hex(out, 32, "c454185e6a16936e39334038acef838bfb186fff7480adc4289382ecd6d394f0");

   for (it = 0; it < 300; it++)
   {
      size_t   len     = 16 * (bulk_rand() % 66);
      int      inplace = (it & 4) != 0;
      unsigned ks      = (it & 1) ? 32 : 16;
      for (i = 0; i < 32; i++)
      {
         k1[i] = (uint8_t)bulk_rand();
         k2[i] = (uint8_t)bulk_rand();
      }
      for (i = 0; i < 16; i++)
         tw[i] = (uint8_t)bulk_rand();
      for (i = 0; i < len; i++)
         in[i] = (uint8_t)bulk_rand();
      ck_assert_int_eq(aes_init(&a, k1, ks), 0);
      ck_assert_int_eq(aes_init(&c, k2, ks), 0);
      aes_encrypt_block(&c, tw, t);
      for (off = 0; off < len; off += 16)
      {
         uint8_t carry = 0;
         for (i = 0; i < 16; i++)
            b[i] = in[off + i] ^ t[i];
         aes_encrypt_block(&a, b, b);
         for (i = 0; i < 16; i++)
            ref[off + i] = b[i] ^ t[i];
         for (i = 0; i < 16; i++)
         {
            uint8_t next = t[i] >> 7;
            t[i]  = (uint8_t)((t[i] << 1) | carry);
            carry = next;
         }
         t[0] ^= (uint8_t)(0x87 & (0 - carry));
      }
      memcpy(back, in, len);
      aes_xts_encrypt(&a, &c, tw, in, inplace ? in : out, len);
      ck_assert_int_eq(memcmp(inplace ? in : out, ref, len), 0);
      aes_xts_decrypt(&a, &c, tw, inplace ? in : out, inplace ? in : out, len);
      ck_assert_int_eq(memcmp(inplace ? in : out, back, len), 0);
   }
}
END_TEST

START_TEST(test_md5_unaligned)
{
   static const uint8_t expected[16] = {
      0xef,0xc4,0x04,0xfa,0x60,0x9a,0x79,0x9c,
      0x78,0x01,0x27,0x3d,0xe6,0xd6,0x5e,0x84
   };
   uint8_t *input = (uint8_t*)malloc(4098);
   uint8_t digest[16];
   MD5_CTX ctx;
   unsigned i;
   ck_assert(input != NULL);
   input[0] = input[4097] = 0xa7;
   for (i = 0; i < 4096; i++)
      input[i + 1] = (uint8_t)(i * 37 + 11);
   MD5_Init(&ctx);
   MD5_Update(&ctx, input + 1, 4096);
   MD5_Final(digest, &ctx);
   ck_assert(!memcmp(digest, expected, sizeof(expected)));
   MD5_Init(&ctx);
   for (i = 0; i < 4096; i++)
      MD5_Update(&ctx, input + 1 + i, 1);
   MD5_Final(digest, &ctx);
   ck_assert(!memcmp(digest, expected, sizeof(expected)));
   ck_assert(input[0] == 0xa7 && input[4097] == 0xa7);
   for (i = 0; i < 4096; i++)
      ck_assert(input[i + 1] == (uint8_t)(i * 37 + 11));
   free(input);
}
END_TEST
Suite *create_suite(void)
{
   Suite *s = suite_create(SUITE_NAME);
   TCase *tc_core = tcase_create("Core");
   tcase_set_timeout(tc_core, 60);
   tcase_add_test(tc_core, test_md5_unaligned);
   tcase_add_test(tc_core, test_aes_xts);
   tcase_add_test(tc_core, test_aes_block);
   tcase_add_test(tc_core, test_aes_cmac);
   tcase_add_test(tc_core, test_aes_gcm);
   tcase_add_test(tc_core, test_chacha20);
   tcase_add_test(tc_core, test_poly1305);
   tcase_add_test(tc_core, test_aead);
   tcase_add_test(tc_core, test_hmac_hkdf_pbkdf2);
   tcase_add_test(tc_core, test_drbg);
   tcase_add_test(tc_core, test_util);
   tcase_add_test(tc_core, test_sha512);
   tcase_add_test(tc_core, test_bn);
   tcase_add_test(tc_core, test_rsa);
   tcase_add_test(tc_core, test_rsa_pss);
   tcase_add_test(tc_core, test_x25519);
   tcase_add_test(tc_core, test_x509_policy);
   tcase_add_test(tc_core, test_p256);
   tcase_add_test(tc_core, test_p256_vectors);
   tcase_add_test(tc_core, test_p256_der);
   tcase_add_test(tc_core, test_p384);
   tcase_add_test(tc_core, test_b233);
   tcase_add_test(tc_core, test_rsa_sign);
   tcase_add_test(tc_core, test_smb_prereqs);
   tcase_add_test(tc_core, test_x509);
   tcase_add_test(tc_core, test_x509_ip_literals);
   tcase_add_test(tc_core, test_aes_decrypt_hmac_sha1);
   tcase_add_test(tc_core, test_krb5_enctypes);
   tcase_add_test(tc_core, test_bulk_paths);
   tcase_add_test(tc_core, test_aes_ctr128);
   tcase_add_test(tc_core, test_streams);
   tcase_add_test(tc_core, test_aes_cfb128);
   tcase_add_test(tc_core, test_aes_cbc);
   tcase_add_test(tc_core, test_aes_cbc_decrypt);
   suite_add_tcase(s, tc_core);
   return s;
}

int main(void)
{
   int num_fail;
   Suite *s = create_suite();
   SRunner *sr = srunner_create(s);
   srunner_run_all(sr, CK_NORMAL);
   num_fail = srunner_ntests_failed(sr);
   srunner_free(sr);
   return (num_fail == 0) ? EXIT_SUCCESS : EXIT_FAILURE;
}
