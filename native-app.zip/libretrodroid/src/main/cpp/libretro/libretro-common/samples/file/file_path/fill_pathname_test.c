/* Copyright  (C) 2010-2026 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (fill_pathname_test.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* Regression for the fill_pathname() out-of-bounds write observed in
 * production iOS crash reports as
 *   __chk_fail_overflow -> __strlcpy_chk -> fill_pathname
 *      -> database_info_list_iterate_found_match (task_database.c)
 *
 * fill_pathname() is:
 *
 *     size_t _len = strlcpy(s, in_path, len);
 *     if ((tok = strrchr(path_basename(s), '.'))) { *tok = '\0'; _len = tok - s; }
 *     _len += strlcpy(s + _len, replace, len - _len);
 *
 * strlcpy() returns strlen(in_path), not the number of bytes written.
 * If strlen(in_path) >= len AND the truncated copy contains no '.' in
 * its basename, the conditional does not fire and _len stays at the
 * (large) source length.  The second strlcpy then runs as
 *   strlcpy(s + _len, replace, len - _len)
 * with len - _len underflowed to a huge size_t.  s + _len is well past
 * the end of the destination buffer, and strlcpy happily writes
 * strlen(replace) + 1 bytes there.
 *
 * On Apple platforms strlcpy is a libc symbol covered by FORTIFY, so
 * __strlcpy_chk catches the bogus length and aborts (this is the
 * SIGTRAP visible in the crash logs).  On Linux there is no FORTIFY
 * for strlcpy, so we detect the overrun by surrounding the destination
 * with sentinel bytes and checking they survive the call.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <retro_miscellaneous.h>
#include <compat/strl.h>
#include <file/file_path.h>

static int failures = 0;

#define DST_LEN     64
#define GUARD_LEN   256
#define SENTINEL    0xCC

/* Long input with no '.' anywhere -- forces fill_pathname() to take
 * the "no extension to strip" branch with _len > len. */
static void test_overlong_input_no_dot(void)
{
   char *region;
   char *dst;
   size_t i;
   size_t in_len = DST_LEN * 4;   /* 256 chars, well past DST_LEN */
   char *in_path;

   region = (char*)malloc(DST_LEN + GUARD_LEN);
   if (!region)
      abort();
   memset(region, SENTINEL, DST_LEN + GUARD_LEN);
   dst = region;

   in_path = (char*)malloc(in_len + 1);
   if (!in_path)
      abort();
   for (i = 0; i < in_len; i++)
      in_path[i] = 'a';
   in_path[in_len] = '\0';

   fill_pathname(dst, in_path, ".lpl", DST_LEN);

   /* The destination's first DST_LEN bytes are fair game for the
    * function to write into.  Anything in [DST_LEN, DST_LEN+GUARD_LEN)
    * must be untouched. */
   for (i = DST_LEN; i < (size_t)(DST_LEN + GUARD_LEN); i++)
   {
      if ((unsigned char)region[i] != SENTINEL)
      {
         printf("[FAILED] fill_pathname overran dst: byte %zu changed from 0x%02x to 0x%02x\n",
               i, SENTINEL, (unsigned char)region[i]);
         failures++;
         break;
      }
   }
   if (i == (size_t)(DST_LEN + GUARD_LEN))
      printf("[SUCCESS] overlong no-dot input did not overrun destination\n");

   free(in_path);
   free(region);
}

/* Long input where the truncated copy DOES contain a '.' -- the
 * conditional resets _len so this path was never broken, but include
 * it as a regression so a future "fix" doesn't silently break the
 * normal extension-replacement case. */
static void test_overlong_input_with_dot(void)
{
   char dst[DST_LEN];
   /* "aaaa.aaaa..." for in_len bytes -- truncation will still leave
    * dots inside the destination. */
   size_t in_len = DST_LEN * 4;
   char *in_path = (char*)malloc(in_len + 1);
   size_t i;

   if (!in_path)
      abort();
   for (i = 0; i < in_len; i++)
      in_path[i] = (i % 5 == 4) ? '.' : 'a';
   in_path[in_len] = '\0';

   memset(dst, 0, sizeof(dst));
   fill_pathname(dst, in_path, ".lpl", sizeof(dst));

   /* Result must be NUL-terminated within the buffer. */
   if (memchr(dst, '\0', sizeof(dst)) == NULL)
   {
      printf("[FAILED] fill_pathname did not NUL-terminate within buffer\n");
      failures++;
   }
   else
      printf("[SUCCESS] overlong with-dot input stayed NUL-terminated in buffer\n");

   free(in_path);
}

/* Helper: run fill_pathname with a 64-byte buffer and assert the
 * resulting string matches @want. */
static void check_spec(const char *label, const char *in_path,
      const char *replace, const char *want)
{
   char dst[64];
   memset(dst, 0, sizeof(dst));
   fill_pathname(dst, in_path, replace, sizeof(dst));
   if (strcmp(dst, want) != 0)
   {
      printf("[FAILED] %s: fill_pathname(\"%s\", \"%s\") = \"%s\" (expected \"%s\")\n",
            label, in_path, replace, dst, want);
      failures++;
      return;
   }
   printf("[SUCCESS] %s\n", label);
}

/* Edge case: input is exactly len-1, no extension, replace appended.
 * The first strlcpy returns strlen(in_path) == len-1, no '.' in the
 * truncated copy, _len = len-1, so len - _len = 1.  The second
 * strlcpy gets len=1 and writes only the NUL.  Must not overrun. */
static void test_exact_fit_no_extension(void)
{
   char *region = (char*)malloc(DST_LEN + GUARD_LEN);
   char *dst;
   char in_path[DST_LEN];
   size_t i;

   if (!region)
      abort();
   memset(region, SENTINEL, DST_LEN + GUARD_LEN);
   dst = region;

   for (i = 0; i < DST_LEN - 1; i++)
      in_path[i] = 'b';
   in_path[DST_LEN - 1] = '\0';

   fill_pathname(dst, in_path, ".lpl", DST_LEN);

   for (i = DST_LEN; i < (size_t)(DST_LEN + GUARD_LEN); i++)
   {
      if ((unsigned char)region[i] != SENTINEL)
      {
         printf("[FAILED] fill_pathname overran dst on exact-fit input: byte %zu changed\n", i);
         failures++;
         break;
      }
   }
   if (i == (size_t)(DST_LEN + GUARD_LEN))
      printf("[SUCCESS] exact-fit no-extension input did not overrun destination\n");

   free(region);
}

/* fill_pathname_join() reports the length it wanted, so >= len is how a
 * caller detects truncation. Callers that size a path buffer from a
 * bound held somewhere else rely on that, and on nothing outside the
 * buffer being touched when the join does not fit. */
static void test_join_truncation(void)
{
   char *region = (char*)malloc(DST_LEN + GUARD_LEN);
   char dir[DST_LEN];
   size_t want;
   size_t i;

   if (!region)
      abort();
   memset(region, SENTINEL, DST_LEN + GUARD_LEN);

   for (i = 0; i < DST_LEN - 1; i++)
      dir[i] = 'd';
   dir[DST_LEN - 1] = '\0';

   want = fill_pathname_join(region, dir, "hires.txt", DST_LEN);

   if (want < DST_LEN)
   {
      printf("[FAILED] fill_pathname_join reported %zu for a join that cannot fit in %d\n",
            want, DST_LEN);
      failures++;
   }
   else
      printf("[SUCCESS] oversized join reported truncation (%zu >= %d)\n",
            want, DST_LEN);

   for (i = DST_LEN; i < (size_t)(DST_LEN + GUARD_LEN); i++)
   {
      if ((unsigned char)region[i] != SENTINEL)
      {
         printf("[FAILED] fill_pathname_join overran dst: byte %zu changed\n", i);
         failures++;
         break;
      }
   }
   if (i == (size_t)(DST_LEN + GUARD_LEN))
      printf("[SUCCESS] oversized join did not overrun destination\n");

   if (region[DST_LEN - 1] != '\0')
   {
      printf("[FAILED] fill_pathname_join left dst unterminated\n");
      failures++;
   }

   /* A join that fits reports its own length and inserts one separator. */
   memset(region, SENTINEL, DST_LEN + GUARD_LEN);
   want = fill_pathname_join(region, "/packs/game.hdpack", "tiles.png", DST_LEN);
   if (want != strlen("/packs/game.hdpack/tiles.png")
         || strcmp(region, "/packs/game.hdpack/tiles.png"))
   {
      printf("[FAILED] fitting join gave \"%s\" (%zu)\n", region, want);
      failures++;
   }
   else
      printf("[SUCCESS] fitting join reported its own length\n");

   free(region);
}

/* mingw-w64 has no setenv(). */
static void set_home(const char *home)
{
#ifdef _WIN32
   _putenv_s("HOME", home);
#else
   setenv("HOME", home, 1);
#endif
}

/* fill_pathname_abbreviated_or_relative() resolves a relative @in_path
 * against @in_refpath's directory before choosing between the
 * relative and abbreviated forms.  That join still carries its '..'
 * segments, so it can be much longer than the result: a 256-byte
 * output (config_file's '#reference' buffer) must still receive a
 * short reference whose un-normalised join is past 256 bytes. */
static void test_abbreviated_or_relative_long_join(void)
{
   char refpath[PATH_MAX_LENGTH];
   char out[256];
   const char *rel = "../../../../x/preset_b.slangp";
   size_t _len     = 0;
   size_t i;

   set_home("/nonexistent-home");

   _len = strlcpy(refpath, "/r/s/t/u/v/w/", sizeof(refpath));
   for (i = 0; i < 230; i++)
      refpath[_len++] = 'a';
   strlcpy(refpath + _len, "/b/c/d/preset_a.slangp", sizeof(refpath) - _len);

   _len = fill_pathname_abbreviated_or_relative(out, refpath, rel, sizeof(out));
   if (_len != strlen(rel) || strcmp(out, rel))
   {
      printf("[FAILED] long-join reference gave \"%s\" (%zu)\n", out, _len);
      failures++;
   }
   else
      printf("[SUCCESS] long-join reference kept intact\n");

   /* Same reference from a shallow preset: the absolute form is
    * shallower than the relative one, so it is chosen. */
   _len = fill_pathname_abbreviated_or_relative(out,
         "/r/a/b/c/d/preset_a.slangp", rel, sizeof(out));
   if (     _len != strlen("/r/x/preset_b.slangp")
         || strcmp(out, "/r/x/preset_b.slangp"))
   {
      printf("[FAILED] short reference gave \"%s\" (%zu)\n", out, _len);
      failures++;
   }
   else
      printf("[SUCCESS] shallow preset resolves to the absolute path\n");

   /* An absolute path sharing no directory with the preset stays
    * absolute when the relative form would be deeper. */
   _len = fill_pathname_abbreviated_or_relative(out,
         "/r/a/b/c/d/preset_a.slangp", "/z/p.slangp", sizeof(out));
   if (strcmp(out, "/z/p.slangp"))
   {
      printf("[FAILED] absolute reference gave \"%s\"\n", out);
      failures++;
   }
   else
      printf("[SUCCESS] absolute reference preferred over deeper relative\n");
}

/* Equal but for which slash separates. */
static int path_same(const char *a, const char *b)
{
   for (; *a && *b; a++, b++)
      if (*a != *b && !(PATH_CHAR_IS_SLASH(*a) && PATH_CHAR_IS_SLASH(*b)))
         return 0;
   return *a == *b;
}

/* fill_pathname_expand_special() replaces '~' and the slash after it.
 * The input is a heap copy, so ASan sees a read past its NUL. */
static void test_expand_special_home(void)
{
   static const char *const in[]   =
         { "~",   "~/",  "~/x",  "~x",   "", "a/~" };
   static const char *const want[] =
         { "/h/", "/h/", "/h/x", "/h/x", "", "a/~" };
   char   out[64];
   size_t i;

   set_home("/h");
   for (i = 0; i < sizeof(in) / sizeof(in[0]); i++)
   {
      size_t n   = strlen(in[i]) + 1;
      char *path = (char*)malloc(n);
      if (!path)
      {
         printf("[FAILED] expand \"%s\": out of memory\n", in[i]);
         failures++;
         continue;
      }
      memcpy(path, in[i], n);
      fill_pathname_expand_special(out, path, sizeof(out));
      free(path);
      if (!path_same(out, want[i]))
      {
         printf("[FAILED] expand \"%s\" gave \"%s\" (expected \"%s\")\n",
               in[i], out, want[i]);
         failures++;
      }
      else
         printf("[SUCCESS] expand \"%s\"\n", in[i]);
   }
}

/* A home directory longer than the buffer: the expansion is cut at the
 * buffer's end and nothing is written past it.  The buffer is a heap
 * block of exactly its size, so ASan sees a write past the end. */
static void test_expand_special_truncation(void)
{
   const size_t len = 8;
   char  *out       = (char*)malloc(len);
   size_t got;

   if (!out)
   {
      printf("[FAILED] expand truncation: out of memory\n");
      failures++;
      return;
   }
   set_home("/a-home-directory-longer-than-the-buffer");
   got = fill_pathname_expand_special(out, "~/file", len);
   if (got != len - 1 || strlen(out) != len - 1
         || strncmp(out, "/a-home", len - 1))
   {
      printf("[FAILED] expand truncation gave \"%s\" (%u)\n",
            out, (unsigned)got);
      failures++;
   }
   else
      printf("[SUCCESS] expand truncation\n");
   free(out);
}

/* A saf:// path is the tree URI serialized with its '%' and '/'
 * escaped, then the path inside the tree. Directly under the tree the
 * parent component is that URI, and the folder it names is the last
 * component of the tree's document ID. */
#define SAF_TREE(id) "saf://content%3A%2F%2Fcom.android.externalstorage.documents%2Ftree%2F" id

static void check_parent_dir_name(const char *label, const char *in,
      size_t len, const char *expected)
{
   char   buf[GUARD_LEN];
   size_t n;
   memset(buf, SENTINEL, sizeof(buf));
   n = fill_pathname_parent_dir_name(buf, in, len);
   if (     strcmp(buf, expected)
         || n != strlen(expected)
         || (unsigned char)buf[len] != SENTINEL)
   {
      printf("[ERROR] parent dir name: %s: got \"%s\" (%u), want \"%s\"\n",
            label, buf, (unsigned)n, expected);
      failures++;
   }
   else
      printf("[SUCCESS] parent dir name: %s\n", label);
}

static void test_parent_dir_name_saf(void)
{
   check_parent_dir_name("plain path", "/roms/snes/game.sfc",
         DST_LEN, "snes");
   check_parent_dir_name("saf folder grant",
         SAF_TREE("primary%253ARoms") "/game.sfc", DST_LEN, "Roms");
   check_parent_dir_name("saf nested folder grant",
         SAF_TREE("primary%253AGames%252FRoms") "/game.sfc", DST_LEN, "Roms");
   check_parent_dir_name("saf lowercase escapes",
         "saf://content%3a%2f%2fcom.android.externalstorage.documents%2ftree%2f1234-ABCD%253aSNES/game.sfc",
         DST_LEN, "SNES");
   check_parent_dir_name("saf volume root",
         SAF_TREE("primary%253A") "/game.sfc", DST_LEN, "");
   check_parent_dir_name("saf subfolder is a plain component",
         SAF_TREE("primary%253ARoms") "/snes/game.sfc", DST_LEN, "snes");
   check_parent_dir_name("saf tree pointing at a document",
         SAF_TREE("primary%253ARoms%2Fdocument%2Fprimary%253ARoms%252Fx") "/game.sfc",
         DST_LEN, "");
   check_parent_dir_name("saf tree longer than the buffer",
         SAF_TREE("primary%253ARoms") "/game.sfc", 16, "Roms");
   check_parent_dir_name("saf name longer than the buffer",
         SAF_TREE("primary%253ARoms") "/game.sfc", 4, "");
   check_parent_dir_name("saf name exactly fits",
         SAF_TREE("primary%253ARoms") "/game.sfc", 5, "Roms");
}

int main(void)
{
   /* Documented semantics. */
   check_spec("normal extension replacement preserved",
         "/foo/bar/baz/boo.c", ".asm", "/foo/bar/baz/boo.asm");
   check_spec("no extension -> concatenate replace",
         "foo", ".lpl", "foo.lpl");
   check_spec("empty replace strips extension",
         "foo.c", "", "foo");
   check_spec("dot in dirname does not count as extension",
         "/foo.bar/baz", ".x", "/foo.bar/baz.x");
   check_spec("only the last dot in the basename is stripped",
         "foo.bar.baz", ".x", "foo.bar.x");

   /* Out-of-bounds behavior. */
   test_overlong_input_with_dot();
   test_exact_fit_no_extension();
   test_overlong_input_no_dot();
   test_join_truncation();
   test_abbreviated_or_relative_long_join();
   test_expand_special_home();
   test_expand_special_truncation();
   test_parent_dir_name_saf();

   if (failures)
   {
      printf("\n%d fill_pathname test(s) failed\n", failures);
      return 1;
   }
   printf("\nAll fill_pathname regression tests passed.\n");
   return 0;
}
