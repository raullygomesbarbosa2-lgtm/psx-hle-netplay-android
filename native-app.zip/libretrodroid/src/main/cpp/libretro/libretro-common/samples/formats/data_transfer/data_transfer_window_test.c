/* Copyright  (C) 2010-2026 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (data_transfer_window_test.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* Regression test for data_transfer's cyclic window mode.
 *
 * Window mode backs looping background music: the consumer sees one
 * stable base for the whole file, but only the head - kept forever,
 * because a loop lands there - plus a moving window around the play
 * position is actually resident.  That makes its contract different
 * from the other two modes in a way worth pinning down.
 *
 *   - the head must be readable from the moment the window opens, and
 *     must still be readable after a lap, since the jump back happens
 *     on the audio thread before any feeder tick runs.
 *   - whatever the window covers must match the file, on the first
 *     lap and on a second one, where the bytes are re-read rather
 *     than retained.
 *   - extending past the end must clamp, not fail.
 *   - grow_keep must enlarge the permanently resident head without
 *     disturbing what is already in it.
 *   - and the point of the mode: residency must stay bounded by the
 *     window rather than tracking the file, which the last check
 *     measures directly where the platform can report it.
 *
 * One asymmetry is worth stating outright, because it is surprising
 * and it decides how a feeder bug presents.  Reading *behind* the
 * window - bytes the feeder has advanced past - yields zeros on a
 * normal build, so a consumer that looks back gets silence.  Reading
 * *ahead* of the frontier is not like that: the reservation is mapped
 * PROT_NONE until committed, so a consumer that outruns its feeder
 * takes a fault, not zeros.  A feeder must therefore keep its
 * lookahead genuinely ahead of the consumer; falling behind is fatal
 * rather than merely wrong.  The last check pins that behaviour so a
 * change to the window logic cannot quietly turn a crash into silent
 * corruption, or the reverse.
 *
 * The test reports whether this build can reserve address space. Where
 * it cannot, window mode degrades to holding the whole file and the
 * correctness checks still apply - only the residency bound does not.
 *
 * Build:  make            (SANITIZER=address,undefined for a checked run)
 * Run:    ./data_transfer_window_test
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <formats/data_transfer.h>
#include <streams/data_transfer_file.h>
#include <memmap.h>
#ifdef DT_COUNT_IO
#include <streams/file_stream.h>
static unsigned io_seeks, io_reads, io_ats;
static uint64_t io_bytes;
int64_t __real_filestream_seek(RFILE *stream, int64_t offset, int origin);
int64_t __real_filestream_read(RFILE *stream, void *data, int64_t length);
int64_t __real_filestream_read_at(RFILE *stream, void *data, int64_t length,
      int64_t offset);
int64_t __wrap_filestream_seek(RFILE *stream, int64_t offset, int origin)
{
   io_seeks++;
   return __real_filestream_seek(stream, offset, origin);
}
int64_t __wrap_filestream_read(RFILE *stream, void *data, int64_t length)
{
   io_reads++;
   if (length > 0) io_bytes += (uint64_t)length;
   return __real_filestream_read(stream, data, length);
}
/* A read at an offset is a read and no seek; a -1 is counted by the
 * seek and read that follow it */
int64_t __wrap_filestream_read_at(RFILE *stream, void *data, int64_t length,
      int64_t offset)
{
   int64_t got = __real_filestream_read_at(stream, data, length, offset);
   if (got >= 0)
   {
      io_reads++; io_ats++;
      if (length > 0) io_bytes += (uint64_t)length;
   }
   return got;
}
#endif
#if defined(__linux__)
#include <unistd.h>
#endif

static int bad = 0;
static void ok(const char *w){ printf("[ok]   %s\n", w); }
static void fail(const char *w){ printf("[FAIL] %s\n", w); bad = 1; }

#define KEEP     (64u * 1024)
#define LOOKAHD  (256u * 1024)
#define MARGIN   (64u * 1024)


#if defined(__linux__)
static size_t rss_kb(void)
{
   FILE *f = fopen("/proc/self/statm", "r");
   long size = 0, resident = 0;
   if (!f)
      return 0;
   if (fscanf(f, "%ld %ld", &size, &resident) != 2)
      resident = 0;
   fclose(f);
   return (size_t)resident * (size_t)(sysconf(_SC_PAGESIZE) / 1024);
}

/* Play a large file through a small window and watch the resident set:
 * it must stay near the window rather than near the file. */
static int residency_check(void)
{
   const char *path = "dtwin_resident.bin";
   size_t n = 64u << 20, i, tell, before, peak = 0;
   uint8_t *buf = (uint8_t*)malloc(n);
   data_transfer_t *dt; const uint8_t *base; size_t blen = 0;
   FILE *f;
   if (!buf)
      return 0;
   for (i = 0; i < n; i++)
      buf[i] = (uint8_t)i;
   f = fopen(path, "wb"); fwrite(buf, 1, n, f); fclose(f);
   free(buf);                       /* the reference copy must not count */

   before = rss_kb();
   if (!(dt = data_transfer_open_window(path, KEEP)))
   { remove(path); return 0; }
   base = data_transfer_window_base(dt, &blen);
   for (tell = 0; tell < n; tell += 65536)
   {
      size_t r;
      data_transfer_window_feed(dt, tell, LOOKAHD, MARGIN);
      { volatile uint8_t s = base[tell]; (void)s; }
      if ((r = rss_kb()) > peak)
         peak = r;
   }
   data_transfer_free(dt);
   remove(path);
   {
      size_t grew  = (peak > before) ? peak - before : 0;
      size_t bound = (n >> 10) / 4;   /* a quarter of the file, generous */
      if (grew >= bound)
      { printf("[FAIL] residency grew %zu KiB for a %zu MiB file\n",
               grew, n >> 20); return 1; }
      printf("[ok]   residency bound: grew %zu KiB for a %zu MiB file\n",
             grew, n >> 20);
   }
   return 0;
}
#endif


/* The budgeted feeder.  Four things are the contract, and each has a
 * failure mode this pins:
 *
 *  1. While the frontier covers the consumer, one call reads at most
 *     'budget' new bytes - the burst bound the API exists for.
 *  2. The bound it reports never falls behind the consumer, and the
 *     bytes up to it match the file - a feeder that budgets itself
 *     below the consumer's position has turned pacing into a fault.
 *  3. Repeated calls at a fixed tell converge on exactly what the
 *     unbudgeted feed produces (tell + lookahead), and budget == 0
 *     produces it in one call - the ceiling changes when bytes become
 *     resident, never which.
 *  4. A frontier BEHIND the consumer (a lap landing past the head, a
 *     rebase) is closed in ONE call, budget notwithstanding: pacing a
 *     read the consumer is standing on does not shrink a burst, it
 *     leaves the very next consumer read on unresident pages. */
static int feed_budget_check(void)
{
   const char *path = "dtwin_budget.bin";
   size_t n = 8u << 20, i, tell;
   size_t budget = 32u * 1024;
   uint8_t *ref = (uint8_t*)malloc(n);
   data_transfer_t *dt; const uint8_t *base; size_t blen = 0;
   size_t res = 0, prev, target;
   int r = 0;
   FILE *f;

   if (!ref)
      return 0;
   for (i = 0; i < n; i++)
      ref[i] = (uint8_t)(i * 131u + (i >> 13));
   f = fopen(path, "wb"); fwrite(ref, 1, n, f); fclose(f);

   if (!(dt = data_transfer_open_window(path, KEEP)))
   { free(ref); remove(path); return 0; }
   base = data_transfer_window_base(dt, &blen);

   /* 1 + 2: a consumer pacing forward under the budget */
   prev = KEEP;                       /* the open's resident head */
   for (tell = 0; tell < (2u << 20); tell += 16u * 1024)
   {
      if (!data_transfer_window_feed_budget(dt, tell, LOOKAHD, MARGIN,
               budget, &res))
      { fail("budget: feed failed mid-run"); r = 1; break; }
      if (data_transfer_window_is_reserved(dt))
      {
         if (res > prev && res - prev > budget)
         {
            printf("[FAIL] budget: one call read %zu bytes "
                   "(budget %zu)\n", res - prev, budget);
            r = 1; break;
         }
         prev = res;
      }
      if (res < tell)
      {
         printf("[FAIL] budget: bound %zu fell behind consumer %zu\n",
               res, tell);
         r = 1; break;
      }
      if (memcmp(base + tell, ref + tell,
               (res - tell < 4096) ? res - tell : 4096))
      { fail("budget: resident bytes disagree with the file"); r = 1; break; }
   }
   if (!r)
      ok("budget: bounded per call, never behind, bytes correct");

   /* 3: convergence at a fixed tell equals the unbudgeted feed */
   tell   = 2u << 20;
   target = tell + LOOKAHD;
   for (i = 0; i < 1 + LOOKAHD / budget + 2; i++)
      data_transfer_window_feed_budget(dt, tell, LOOKAHD, MARGIN,
            budget, &res);
   if (data_transfer_window_is_reserved(dt) && res != target)
   {
      printf("[FAIL] budget: converged at %zu, unbudgeted feed "
             "reaches %zu\n", res, target);
      r = 1;
   }
   else
      ok("budget: converges on the unbudgeted target");
   if (!data_transfer_window_feed_budget(dt, tell + 16384, LOOKAHD,
            MARGIN, 0, &res)
         || (data_transfer_window_is_reserved(dt)
            && res != tell + 16384 + LOOKAHD))
   { fail("budget: 0 must behave as window_feed"); r = 1; }
   else
      ok("budget: 0 is window_feed by another name");

   /* 4: a lap landing far past the frontier closes in one call */
   data_transfer_window_feed_budget(dt, 4096, LOOKAHD, MARGIN,
         budget, &res);                 /* loop: rewind to the head */
   tell = 6u << 20;                     /* far past the reset frontier */
   if (!data_transfer_window_feed_budget(dt, tell, LOOKAHD, MARGIN,
            budget, &res))
   { fail("budget: catch-up feed failed"); r = 1; }
   else if (data_transfer_window_is_reserved(dt)
         && res != tell + LOOKAHD)
   {
      printf("[FAIL] budget: catch-up left the bound at %zu with the "
             "consumer at %zu - the next read faults\n", res, tell);
      r = 1;
   }
   else
   {
      volatile uint8_t s = base[tell];  /* must be resident right now */
      (void)s;
      if (memcmp(base + tell, ref + tell, 4096))
      { fail("budget: catch-up bytes disagree with the file"); r = 1; }
      else
         ok("budget: a frontier behind the consumer closes in one call");
   }

   data_transfer_free(dt);
   free(ref);
   remove(path);
   return r;
}

#if defined(__unix__) || defined(__APPLE__)
#include <sys/wait.h>

/* Reading ahead of the frontier must fault rather than yield zeros.
 * Run it in a child so either answer is observable. */
static int ahead_of_frontier_check(void)
{
   const char *path = "dtwin_ahead.bin";
   size_t n = 16u << 20, i;
   uint8_t *buf = (uint8_t*)malloc(n);
   FILE *f;
   pid_t pid;
   int status = 0;

   if (!buf)
      return 0;
   for (i = 0; i < n; i++)
      buf[i] = (uint8_t)(i | 1);
   f = fopen(path, "wb"); fwrite(buf, 1, n, f); fclose(f);
   free(buf);

   if (!data_transfer_reserve_supported())
   {
      printf("[skip] read-ahead fault: no reservations on this build\n");
      remove(path);
      return 0;
   }

   /* A sanitizer traps the access itself and terminates the child its
    * own way, so the signal this check looks for never arrives and the
    * fault it is verifying would be reported as an absence.  The other
    * checks still run under sanitizers; this one only means anything
    * without them. */
#if defined(__SANITIZE_ADDRESS__)
   printf("[skip] read-ahead fault: the sanitizer intercepts it\n");
   remove(path);
   return 0;
#elif defined(__has_feature)
#if __has_feature(address_sanitizer)
   printf("[skip] read-ahead fault: the sanitizer intercepts it\n");
   remove(path);
   return 0;
#endif
#endif

   if ((pid = fork()) == 0)
   {
      data_transfer_t *dt = data_transfer_open_window(path, KEEP);
      const uint8_t *base; size_t blen = 0;
      volatile uint8_t s;
      if (!dt)
         _exit(3);
      base = data_transfer_window_base(dt, &blen);
      s = base[0];              /* the head is resident */
      s = base[8u << 20];       /* far ahead, with no feed between */
      _exit(42);                /* reached only if it did not fault */
      (void)s;
   }
   waitpid(pid, &status, 0);
   remove(path);

   if (WIFEXITED(status) && WEXITSTATUS(status) == 42)
   {
      printf("[FAIL] read ahead of the frontier did not fault "
             "(a feeder falling behind would corrupt silently)\n");
      return 1;
   }
   printf("[ok]   read ahead of the frontier faults, as designed\n");
   return 0;
}
#else
static int ahead_of_frontier_check(void)
{
   printf("[skip] read-ahead fault: needs fork()\n");
   return 0;
}
#endif

/* The prefix surface must be inert on a window handle.
 *
 * A window keeps a live RFILE and a reservation, so discard(),
 * refill() and iterate() all pass their own guards on one.  Left
 * unguarded they do not merely misbehave, they disagree with the
 * window's bookkeeping: discard() walks a 'low' frontier that knows
 * nothing of keep/wlo/whi/wfreed and releases from offset 0 - through
 * the permanently resident head - and the release is non-strict, so
 * the head returns as zeros rather than faulting.  That is silent
 * corruption of exactly the bytes a loop lands on.  iterate() is the
 * milder sibling: it finds avail == len, settles done, and complete()
 * starts answering yes about a file that was never read.
 *
 * No caller mixes the two surfaces today - gfx_thumbnail keeps its
 * windowed and read-pending states mutually exclusive by hand, and
 * the webm core only discards a handle it opened as a prefix - so
 * both hazards are held off by discipline rather than by the module.
 * This pins the module's own guard, so the next consumer cannot reach
 * them by accident. */
static int surface_mixing_check(void)
{
   const char *path = "dtwin_mix.bin";
   size_t n = 4u << 20, i, blen = 0, avail_before;
   uint8_t *ref = (uint8_t*)malloc(n);
   data_transfer_t *dt;
   const uint8_t *base;
   FILE *f;
   int rv = 0;

   if (!ref)
      return 0;
   for (i = 0; i < n; i++)
      ref[i] = (uint8_t)(i * 97 + 5);
   f = fopen(path, "wb"); fwrite(ref, 1, n, f); fclose(f);

   if (!(dt = data_transfer_open_window(path, KEEP)))
   {
      printf("[FAIL] open_window for the mixing check\n");
      free(ref); remove(path);
      return 1;
   }

   base         = data_transfer_window_base(dt, &blen);
   avail_before = data_transfer_avail(dt);

   /* discard() must not release the head it knows nothing about */
   data_transfer_discard(dt, KEEP + (512u * 1024));
   if (memcmp(base, ref, KEEP))
   {
      printf("[FAIL] discard() on a window released the resident head\n");
      rv = 1;
   }
   else
      ok("discard() on a window is inert: head still intact");

   /* refill() is a no-op here, but must not report failure */
   if (!data_transfer_refill(dt, 0))
   {
      printf("[FAIL] refill() on a window reported failure\n");
      rv = 1;
   }
   else
      ok("refill() on a window is inert and reports success");

   /* iterate() must not settle a handle that has no fill to run */
   data_transfer_iterate(dt, 64u * 1024);
   if (data_transfer_avail(dt) != avail_before)
   {
      printf("[FAIL] iterate() on a window moved avail\n");
      rv = 1;
   }
   else if (   data_transfer_window_is_reserved(dt)
            && data_transfer_complete(dt))
   {
      printf("[FAIL] iterate() on a window settled complete()\n");
      rv = 1;
   }
   else
      ok("iterate() on a window is inert: nothing settled");

   /* and the window must still work afterwards */
   if (!data_transfer_window_feed(dt, KEEP, LOOKAHD, MARGIN))
   {
      printf("[FAIL] feed after the mixing attempts\n");
      rv = 1;
   }
   else if (memcmp(base + KEEP, ref + KEEP, 65536))
   {
      printf("[FAIL] window contents wrong after the mixing attempts\n");
      rv = 1;
   }
   else
      ok("window still plays correctly after the mixing attempts");

   data_transfer_free(dt);
   free(ref); remove(path);
   return rv;
}

/* Ranges that arrive from the caller must be bounded before use.
 *
 * The two differ sharply in how badly, and it is worth saying which
 * is which.
 *
 * window_punch() was the dangerous one.  It rounds (from, to) and
 * hands memdecommit map + f for t - f bytes, unclamped, and a
 * non-strict decommit is madvise(MADV_DONTNEED) - which does not fail
 * politely on a range that runs off the end of the reservation.  It
 * zeroes whatever anonymous pages it does cover, and past a 4 MiB
 * reservation a 64 MiB overrun reliably covers live heap.  Against
 * the unfixed module the first punch below takes the process down
 * with SIGSEGV inside the call, before it can return.
 *
 * window_peek() is the mild one: it tested off + n against the
 * length, which a wrapping sum passes, but the oversized read then
 * fails at the I/O layer and peek returns false anyway.  That check
 * pins the contract rather than catching a fault. */
static int range_bounds_check(void)
{
   const char *path = "dtwin_bounds.bin";
   size_t n = 4u << 20, i, blen = 0;
   uint8_t *ref = (uint8_t*)malloc(n);
   uint8_t tmp[64];
   data_transfer_t *dt;
   const uint8_t *base;
   FILE *f;
   int rv = 0;

   if (!ref)
      return 0;
   for (i = 0; i < n; i++)
      ref[i] = (uint8_t)(i * 31 + 7);
   f = fopen(path, "wb"); fwrite(ref, 1, n, f); fclose(f);

   if (!(dt = data_transfer_open_window(path, KEEP)))
   {
      printf("[FAIL] open_window for the bounds check\n");
      free(ref); remove(path);
      return 1;
   }
   base = data_transfer_window_base(dt, &blen);

   /* an (off, n) whose sum wraps to zero must not read as in range */
   if (data_transfer_window_peek(dt, n - 16, tmp,
            (size_t)0 - (n - 16)))
   {
      printf("[FAIL] peek accepted a wrapping (off, n)\n");
      rv = 1;
   }
   else if (data_transfer_window_peek(dt, n - 16, tmp, 64))
   {
      printf("[FAIL] peek accepted a range past the end\n");
      rv = 1;
   }
   else if (!data_transfer_window_peek(dt, n - 64, tmp, 64))
   {
      printf("[FAIL] peek refused the last 64 bytes of the file\n");
      rv = 1;
   }
   else if (memcmp(tmp, ref + n - 64, 64))
   {
      printf("[FAIL] peek returned the wrong bytes at the end\n");
      rv = 1;
   }
   else
      ok("peek bounds its range and still reads the last bytes");

   /* a punch running far past the mapping must not be taken at its
    * word, and must leave the head alone either way */
   data_transfer_window_punch(dt, n - 4096, n + (64u << 20));
   data_transfer_window_punch(dt, n + (64u << 20), n + (128u << 20));
   if (memcmp(base, ref, KEEP))
   {
      printf("[FAIL] an out-of-range punch damaged the head\n");
      rv = 1;
   }
   else if (!data_transfer_window_feed(dt, KEEP, LOOKAHD, MARGIN))
   {
      printf("[FAIL] feed after an out-of-range punch\n");
      rv = 1;
   }
   else if (memcmp(base + KEEP, ref + KEEP, 65536))
   {
      printf("[FAIL] window contents wrong after an out-of-range punch\n");
      rv = 1;
   }
   else
      ok("out-of-range punch is bounded, window unaffected");

   data_transfer_free(dt);
   free(ref); remove(path);
   return rv;
}

#if defined(__unix__) || defined(__APPLE__)
#include <unistd.h>

/* A short read while extending must settle the handle.
 *
 * extend() and grow_keep() used to report an I/O failure by returning
 * false and nothing else: the handle still looked healthy, and whi
 * stayed put while the pages the call had already committed sat there
 * unfilled.  Two live call sites discard the return - the audio mixer
 * raises the head to cover the decoder's loop landing, and feeds the
 * window each tick, without looking at either answer - so the value
 * alone was never going to be noticed.  The loop landing is read on
 * the audio thread before any feeder tick, which makes a silent
 * failure there audible and untraceable.
 *
 * Truncating the file underneath an open window produces the short
 * read: len was fixed at open, so extending into what is now past the
 * end reads fewer bytes than asked for. */
static int extend_settles_check(void)
{
   const char *path = "dtwin_settle.bin";
   size_t n = 4u << 20, i, blen = 0;
   uint8_t *ref = (uint8_t*)malloc(n);
   data_transfer_t *dt;
   FILE *f;
   int rv = 0;

   if (!ref)
      return 0;
   for (i = 0; i < n; i++)
      ref[i] = (uint8_t)(i * 53 + 11);
   f = fopen(path, "wb"); fwrite(ref, 1, n, f); fclose(f);

   if (!(dt = data_transfer_open_window(path, KEEP)))
   {
      printf("[FAIL] open_window for the settle check\n");
      free(ref); remove(path);
      return 1;
   }
   data_transfer_window_base(dt, &blen);

   if (!data_transfer_reserve_supported())
   {
      /* the fallback holds the whole file and extend never reads */
      printf("[skip] extend settles: no reservations on this build\n");
      data_transfer_free(dt); free(ref); remove(path);
      return 0;
   }

   if (!data_transfer_window_feed(dt, KEEP, LOOKAHD, MARGIN))
      { printf("[FAIL] feed before the truncation\n"); rv = 1; }
   else if (data_transfer_failed(dt))
   { printf("[FAIL] handle already failed before the truncation\n"); rv = 1; }

   /* the file shrinks under the open transfer */
   if (!rv && truncate(path, (off_t)(KEEP + LOOKAHD)) != 0)
   {
      printf("[skip] extend settles: truncate unavailable\n");
      data_transfer_free(dt); free(ref); remove(path);
      return 0;
   }

   if (!rv)
   {
      if (data_transfer_window_extend(dt, n))
      {
         printf("[FAIL] extend past a truncation reported success\n");
         rv = 1;
      }
      else if (!data_transfer_failed(dt))
      {
         printf("[FAIL] a short read in extend did not settle the "
                "handle\n");
         rv = 1;
      }
      else if (data_transfer_complete(dt))
      {
         printf("[FAIL] a settled window reports complete()\n");
         rv = 1;
      }
      else
         ok("a short read in extend settles the handle");
   }

   /* and the surface is frozen: a caller that ignores the return must
    * not be able to drive it further */
   if (!rv)
   {
      if (   data_transfer_window_extend(dt, n)
          || data_transfer_window_grow_keep(dt, KEEP * 4)
          || data_transfer_window_feed(dt, 0, LOOKAHD, MARGIN)
          || data_transfer_window_peek(dt, 0, ref, 16))
      {
         printf("[FAIL] a settled window still accepts work\n");
         rv = 1;
      }
      else
         ok("a settled window refuses every further call");
   }

   data_transfer_free(dt);
   free(ref); remove(path);
   return rv;
}
#else
static int extend_settles_check(void)
{
   printf("[skip] extend settles: needs truncate()\n");
   return 0;
}
#endif

/* Every entry point must tolerate a NULL handle.
 *
 * Most of the surface already did, and window_is_reserved() did, but
 * its immediate neighbour window_base() dereferenced without looking
 * - despite having an exact NULL-safe twin in data_transfer_ptr().
 * A caller cannot infer a rule from a surface that is split like
 * that, so the rule is now: bool returns false, pointer returns NULL,
 * void does nothing.
 *
 * This runs in a child because the failure is a segfault, not a
 * wrong answer. */
#if defined(__unix__) || defined(__APPLE__)
static int null_handle_check(void)
{
   pid_t pid = fork();
   int   status = 0;

   if (pid < 0)
   {
      printf("[skip] NULL handles: fork unavailable\n");
      return 0;
   }
   if (pid == 0)
   {
      uint8_t buf[16];
      size_t  len = 12345;
      int     bad = 0;

      /* window surface */
      if (data_transfer_window_is_reserved(NULL))          bad = 1;
      if (data_transfer_window_base(NULL, &len))           bad = 1;
      if (len != 0)                                        bad = 1;
      if (data_transfer_window_base(NULL, NULL))           bad = 1;
      if (data_transfer_window_extend(NULL, 4096))         bad = 1;
      if (data_transfer_window_grow_keep(NULL, 4096))      bad = 1;
      if (data_transfer_window_peek(NULL, 0, buf, 16))     bad = 1;
      if (data_transfer_window_feed(NULL, 0, 4096, 4096))  bad = 1;
      data_transfer_window_advance(NULL, 4096);
      data_transfer_window_rewind(NULL);
      data_transfer_window_punch(NULL, 0, 4096);

      /* shared surface */
      if (data_transfer_iterate(NULL, 4096))               bad = 1;
      len = 12345;
      if (data_transfer_ptr(NULL, &len))                   bad = 1;
      if (len != 0)                                        bad = 1;
      if (data_transfer_avail(NULL))                       bad = 1;
      if (data_transfer_complete(NULL))                    bad = 1;
      if (data_transfer_capped(NULL))                      bad = 1;
      if (data_transfer_failed(NULL))                      bad = 1;
      if (data_transfer_refill(NULL, 0))                   bad = 1;
      data_transfer_discard(NULL, 4096);
      data_transfer_free(NULL);

      _exit(bad ? 61 : 60);
   }
   waitpid(pid, &status, 0);

   if (WIFSIGNALED(status))
   {
      printf("[FAIL] a NULL handle killed the process (signal %d)\n",
            WTERMSIG(status));
      return 1;
   }
   if (WIFEXITED(status) && WEXITSTATUS(status) == 61)
   {
      printf("[FAIL] a NULL handle produced a non-empty answer\n");
      return 1;
   }
   if (WIFEXITED(status) && WEXITSTATUS(status) == 60)
   {
      printf("[ok]   every entry point tolerates a NULL handle\n");
      return 0;
   }
   printf("[FAIL] the NULL-handle child ended unexpectedly\n");
   return 1;
}
#else
static int null_handle_check(void)
{
   printf("[skip] NULL handles: needs fork()\n");
   return 0;
}
#endif

#if defined(__unix__) || defined(__APPLE__)
/* Settling must take back everything above the frontier.
 *
 * A failed extend() has already committed the range it was about to
 * fill, so without the release those pages read as zeros - in the one
 * place the mode guarantees a fault.  The check forces the failure by
 * truncating, then reads far above the last good frontier in a child:
 * the child must die.  Against a module that settles without
 * releasing, it survives and reads zeros instead.
 *
 * The release is strict in every build, so this does not need
 * DT_STRICT. */
static int settle_releases_check(void)
{
   const char *path = "dtwin_release.bin";
   size_t n = 8u << 20, i;
   uint8_t *ref = (uint8_t*)malloc(n);
   FILE *f;
   pid_t pid;
   int status = 0;

   if (!ref)
      return 0;
   for (i = 0; i < n; i++)
      ref[i] = (uint8_t)(i * 17 + 3);
   f = fopen(path, "wb"); fwrite(ref, 1, n, f); fclose(f);
   free(ref);

   if (!data_transfer_reserve_supported())
   {
      printf("[skip] settle releases: no reservations on this build\n");
      remove(path);
      return 0;
   }
#if defined(__SANITIZE_ADDRESS__)
   printf("[skip] settle releases: the sanitizer intercepts it\n");
   remove(path);
   return 0;
#elif defined(__has_feature)
#if __has_feature(address_sanitizer)
   printf("[skip] settle releases: the sanitizer intercepts it\n");
   remove(path);
   return 0;
#endif
#endif

   if ((pid = fork()) == 0)
   {
      data_transfer_t *dt = data_transfer_open_window(path, KEEP);
      const uint8_t *base;
      size_t blen = 0;
      volatile uint8_t v;

      if (!dt)
         _exit(3);
      base = data_transfer_window_base(dt, &blen);
      if (!data_transfer_window_feed(dt, KEEP, LOOKAHD, MARGIN))
         _exit(4);
      /* cut the file just above the frontier, then ask for the rest:
       * the extend commits far ahead and then reads short */
      if (truncate(path, (off_t)(KEEP + LOOKAHD)) != 0)
         _exit(5);
      if (data_transfer_window_extend(dt, n))
         _exit(6);                /* it was supposed to fail */
      if (!data_transfer_failed(dt))
         _exit(7);
      v = base[n - 4096];         /* deep inside the failed commit */
      _exit(42);                  /* reached only if it did not fault */
      (void)v;
   }
   waitpid(pid, &status, 0);
   remove(path);

   if (WIFEXITED(status) && WEXITSTATUS(status) == 42)
   {
      printf("[FAIL] a settled window still reads zeros above the "
             "frontier instead of faulting\n");
      return 1;
   }
   if (WIFEXITED(status) && WEXITSTATUS(status) >= 3
         && WEXITSTATUS(status) <= 7)
   {
      printf("[FAIL] the settle-release child bailed at setup (%d)\n",
            WEXITSTATUS(status));
      return 1;
   }
   /* Anything else is the fault: a signal normally, or the sanitizer
    * ending the process its own way with its own exit code. */
   printf("[ok]   settling releases above the frontier: it faults\n");
   return 0;
}
#else
static int settle_releases_check(void)
{
   printf("[skip] settle releases: needs fork()\n");
   return 0;
}
#endif

static int sparse_skip_check(void)
{
   const char *path = "dtwin_sparse.bin";
   data_transfer_t *dt = NULL;
   const uint8_t *base;
   uint8_t *ref;
   size_t page = mempagesize(), n, i, len, pos;
   FILE *file;
   int rv = 1;
   data_transfer_window_skip(NULL, 0);
   if (!page) return 0;
   n = KEEP + 8 * page;
   ref = (uint8_t*)malloc(n);
   if (!ref) return 1;
   for (i = 0; i < n; i++) ref[i] = (uint8_t)(i * 17 + i / page);
   file = fopen(path, "wb");
   if (!file) goto done;
   if (fwrite(ref, 1, n, file) != n) { fclose(file); goto done; }
   fclose(file);
   dt = data_transfer_open_window(path, KEEP);
   if (!dt) goto done;
   base = data_transfer_window_base(dt, &len);
   if (!base || len != n) goto done;
#ifdef DT_COUNT_IO
   io_bytes = 0;
#endif
   for (i = 1; i <= 3; i++)
   {
      pos = KEEP + 2 * i * page + 3;
      data_transfer_window_skip(dt, pos);
      data_transfer_window_skip(dt, 0);
      if (!data_transfer_window_extend(dt, pos + 10)
            || memcmp(base + pos, ref + pos, 10)
            || memcmp(base, ref, KEEP)) goto done;
   }
#ifdef DT_COUNT_IO
   if (data_transfer_window_is_reserved(dt) && io_bytes != 30) goto done;
#endif
   rv = 0;
done:
   data_transfer_free(dt);
   free(ref);
   remove(path);
   printf("[%s]   sparse window reads only the requested bytes\n", rv ? "FAIL" : "ok");
   return rv;
}

static int pin_check(void)
{
   const char *path = "dtwin_pin.bin";
   data_transfer_t *dt = NULL;
   const uint8_t *base;
   uint8_t *ref = NULL;
   size_t n = 8u << 20, i, blen, page = mempagesize(), lo, hi, before;
   FILE *file;
   int rv = 1;
   if (!page || page > KEEP) return 0;
   ref = (uint8_t*)malloc(n);
   if (!ref) return 1;
   for (i = 0; i < n; i++) ref[i] = (uint8_t)(i * 13 + i / 4096);
   file = fopen(path, "wb");
   if (!file) goto done;
   if (fwrite(ref, 1, n, file) != n) { fclose(file); goto done; }
   fclose(file);
   dt = data_transfer_open_window(path, KEEP);
   if (!dt) goto done;
   base = data_transfer_window_base(dt, &blen);
   if (!base || blen != n || !data_transfer_window_extend(dt, KEEP + LOOKAHD)) goto done;
   lo = KEEP + 2 * page; hi = lo + 2 * page;
   if (!data_transfer_window_pin(dt, lo, hi)) goto done;
   if (data_transfer_window_pin(dt, n, n + 1)) goto done;
   data_transfer_window_rewind(dt);
   data_transfer_window_rebase(dt, 4u << 20);
   if (!data_transfer_window_extend(dt, (4u << 20) + LOOKAHD / 2)) goto done;
   if (memcmp(base + lo, ref + lo, hi - lo) || memcmp(base, ref, KEEP)) goto done;
   before = data_transfer_window_resident(dt);
   if (data_transfer_window_is_reserved(dt) && before > KEEP + LOOKAHD + 2 * page) goto done;
   /* Shrinking an out-of-window pin releases only its retired pages. */
   if (!data_transfer_window_pin(dt, lo + page, hi)
         || memcmp(base + lo + page, ref + lo + page, page)) goto done;
   if (data_transfer_window_is_reserved(dt)
         && data_transfer_window_resident(dt) + page != before) goto done;
   if (!data_transfer_window_pin(dt, 0, 0)) goto done;
   if (data_transfer_window_is_reserved(dt)
         && data_transfer_window_resident(dt) + 2 * page != before) goto done;
   if (memcmp(base + (4u << 20), ref + (4u << 20), LOOKAHD / 2)) goto done;
#if defined(__linux__) && defined(DT_STRICT)
   if (data_transfer_window_is_reserved(dt))
   {
      int status;
      pid_t child = fork();
      if (child < 0) goto done;
      if (!child) { volatile uint8_t value = base[lo + page]; (void)value; _exit(42); }
      waitpid(child, &status, 0);
      if (WIFEXITED(status) && WEXITSTATUS(status) == 42) goto done;
   }
#endif
   /* A pin inside the moving window does not get released on clear. */
   if (!data_transfer_window_pin(dt, (4u << 20) + page, (4u << 20) + 2 * page)
         || !data_transfer_window_pin(dt, 0, 0)
         || memcmp(base + (4u << 20), ref + (4u << 20), LOOKAHD / 2)) goto done;
   data_transfer_window_rewind(dt);
   if (!data_transfer_window_extend(dt, KEEP + LOOKAHD)
         || !data_transfer_window_pin(dt, lo, hi)
         || !data_transfer_window_grow_keep(dt, hi + page)
         || !data_transfer_window_pin(dt, 0, 0)
         || memcmp(base, ref, hi + page)) goto done;
   ok("coded pin survives rebase; retired pages released, window/head overlaps retained");
   rv = 0;
done:
   if (rv) fail("coded window pin lifecycle/accounting");
   data_transfer_free(dt); free(ref); remove(path);
   return rv;
}

typedef struct callback_source
{
   size_t length, calls;
   int short_read, error, oversized;
} callback_source;
static int64_t callback_read_at(void *ud, uint64_t offset, uint8_t *dst, size_t bytes)
{
   callback_source *source = (callback_source*)ud;
   size_t i;
   source->calls++;
   if (offset > source->length || bytes > source->length - (size_t)offset)
      return -1;
   if (source->error) return -1;
   if (source->oversized) return (int64_t)bytes + 1;
   if (source->short_read && bytes) bytes--;
   for (i = 0; i < bytes; i++) dst[i] = (uint8_t)((offset + i) * 17 + 3);
   return (int64_t)bytes;
}
static int callback_window_check(void)
{
   callback_source source;
   data_transfer_t *dt;
   const uint8_t *base;
   size_t length, offset, i, calls;
   memset(&source,0,sizeof(source)); source.length = 8 * 1024 * 1024;
   if (data_transfer_open_window_reader(0,KEEP,callback_read_at,&source) ||
       data_transfer_open_window_reader(source.length,KEEP,NULL,&source))
      fail("callback window rejects missing source/length");
   dt = data_transfer_open_window_reader(source.length,KEEP,callback_read_at,&source);
   if (!dt) { fail("callback window open"); return 1; }
   base = data_transfer_ptr(dt,&length);
   if (!base || length != source.length) fail("callback window stable shape");
   for (offset = KEEP; offset < source.length; offset += LOOKAHD)
   {
      size_t end = offset + LOOKAHD;
      if (end > source.length) end = source.length;
      if (!data_transfer_window_feed(dt,offset,LOOKAHD,MARGIN) ||
          data_transfer_ptr(dt,NULL) != base)
      { fail("callback window fill/advance"); break; }
      for (i = offset; i < end; i++)
         if (base[i] != (uint8_t)(i * 17 + 3))
         { fail("callback window direct destination bytes"); break; }
   }
   data_transfer_window_rewind(dt);
   if (!data_transfer_window_extend(dt,KEEP + 4096) ||
       base[KEEP + 123] != (uint8_t)((KEEP + 123) * 17 + 3))
      fail("callback window rewind");
   if (data_transfer_window_is_reserved(dt) &&
       data_transfer_window_resident(dt) > KEEP + LOOKAHD + MARGIN + 65536)
      fail("callback window bounded residency");
   calls = source.calls; data_transfer_free(dt);
   if (source.calls != calls) fail("closing borrowed source performs no read");
   source.short_read = 1;
   if (data_transfer_open_window_reader(source.length,KEEP,callback_read_at,&source))
      fail("callback short head is rejected");
   source.short_read = 0;
   dt = data_transfer_open_window_reader(source.length,KEEP,callback_read_at,&source);
   if (!dt) { fail("callback error fixture"); return 1; }
   if (data_transfer_window_is_reserved(dt))
   {
      source.error = 1;
      if (data_transfer_window_extend(dt,KEEP+4096) || !data_transfer_failed(dt))
         fail("callback I/O failure settles window");
      calls = source.calls;
      if (data_transfer_window_extend(dt,KEEP+8192) || source.calls != calls)
         fail("settled callback window remains inert");
   }
   data_transfer_free(dt); source.error = 0; source.oversized = 1;
   if (data_transfer_open_window_reader(source.length,KEEP,callback_read_at,&source))
      fail("callback oversized count is rejected");
   ok("borrowed callback window: direct reads, rewind, bounded residency and faults");
   return 0;
}

/* A consumer far into a large file - one that starts there, moves on,
 * then steps back, which the feed takes for a lap - is fed from margin
 * bytes behind it: the gap it has passed is never read in, whatever the
 * frontier was. */
typedef struct far_source { size_t length; size_t bytes; } far_source;
static int64_t far_read_at(void *ud, uint64_t offset, uint8_t *dst,
      size_t bytes)
{
   far_source *src = (far_source*)ud;
   size_t i;
   if (offset > src->length || bytes > src->length - (size_t)offset)
      return -1;
   for (i = 0; i < bytes; i++)
      dst[i] = (uint8_t)((offset + i) * 29 + 7);
   src->bytes += bytes;
   return (int64_t)bytes;
}
static int far_matches(const uint8_t *base, size_t at, size_t n)
{
   size_t i;
   for (i = 0; i < n; i++)
      if (base[at + i] != (uint8_t)((at + i) * 29 + 7))
         return 0;
   return 1;
}
static int far_feed_check(void)
{
   far_source src;
   data_transfer_t *dt;
   const uint8_t *base;
   size_t blen = 0, step, tell, bound = MARGIN + LOOKAHD + (2u << 20);
   const size_t len = 256u << 20;
   if (!data_transfer_reserve_supported())
   {
      printf("[skip] far feed: no reservations on this build\n");
      return 0;
   }
   memset(&src, 0, sizeof(src));
   src.length = len;
   if (!(dt = data_transfer_open_window_reader(len, KEEP, far_read_at, &src)))
   { fail("far feed: open"); return 1; }
   base = data_transfer_window_base(dt, &blen);
   for (step = 0; step < 3; step++)
   {
      size_t before = src.bytes;
      tell = len - (1u << 20) + (step == 1 ? 300u * 1024 : step == 2 ? 260u * 1024 : 0);
      if (!data_transfer_window_feed(dt, tell, LOOKAHD, MARGIN)
            || !far_matches(base, tell, 4096))
      {
         printf("[FAIL] far feed: step %u, bytes at tell\n", (unsigned)step);
         bad = 1;
         break;
      }
      if (src.bytes - before > bound
            || data_transfer_window_resident(dt) > KEEP + bound)
      {
         printf("[FAIL] far feed: step %u read %lu bytes, resident %lu\n",
               (unsigned)step, (unsigned long)(src.bytes - before),
               (unsigned long)data_transfer_window_resident(dt));
         bad = 1;
         break;
      }
   }
   data_transfer_free(dt);
   if (step < 3)
      return 1;
   ok("far feed: started, moved and stepped back far into a file, read only near the consumer");
   return 0;
}

int main(void)
{
   const char *path = "dtwin.bin";
   size_t n = 4u << 20, i, tell;
   uint8_t *ref = malloc(n);
   data_transfer_t *dt;
   const uint8_t *base; size_t blen = 0;
   FILE *f;

   for (i = 0; i < n; i++) ref[i] = (uint8_t)(i * 211 + 13);
   f = fopen(path, "wb"); fwrite(ref, 1, n, f); fclose(f);

   printf("reservations %s on this build\n",
         data_transfer_reserve_supported() ? "supported (true windowing)"
                                           : "unavailable (whole-file fallback)");

   if (!(dt = data_transfer_open_window(path, KEEP)))
   { fail("open_window"); return 1; }

   base = data_transfer_window_base(dt, &blen);
   if (blen != n) fail("window base length");

   /* the head is resident from the start */
   if (memcmp(base, ref, KEEP)) fail("head contents after open");
   else ok("head resident and correct immediately after open");

#ifdef DT_COUNT_IO
   if (data_transfer_window_is_reserved(dt))
   {
      uint8_t probe[16];
      io_seeks = io_reads = io_ats = 0;
      if (!data_transfer_window_extend(dt, KEEP + 4096)
            || !data_transfer_window_extend(dt, KEEP + 8192)
            || memcmp(base + KEEP, ref + KEEP, 8192))
         fail("consecutive window reads retain exact bytes");
      if (io_seeks || io_reads != 2)
         fail("consecutive window reads need no seeks");
      else ok("consecutive window reads need no seeks");
      if (!data_transfer_window_peek(dt, KEEP * 3 + 7, probe, 8)
            || !data_transfer_window_peek(dt, KEEP * 3 + 15, probe + 8, 8)
            || memcmp(probe, ref + KEEP * 3 + 7, sizeof(probe))
            || !data_transfer_window_extend(dt, KEEP + 12288)
            || memcmp(base + KEEP, ref + KEEP, 12288))
         fail("metadata probes and window refill retain exact bytes");
      /* reads at offsets never seek */
      if (io_seeks != (io_ats ? 0u : 2u) || io_reads != 5)
         fail("metadata probes only seek when changing ranges");
      else ok("metadata probes only seek when changing ranges");
      printf("window I/O: %u reads, %u seeks\n", io_reads, io_seeks);
   }
#endif

   /* play forward, feeding as a decoder would */
   for (tell = 0; tell < n; tell += 32768)
   {
      size_t want = (tell + 32768 <= n) ? 32768 : n - tell;
      if (!data_transfer_window_feed(dt, tell, LOOKAHD, MARGIN))
      { fail("feed during forward play"); break; }
      if (memcmp(base + tell, ref + tell, want))
      { fail("window contents during forward play"); break; }
   }
   if (!bad) ok("forward play: every chunk matched the file");

   /* loop back to the start: a backwards tell means a new lap */
   if (!data_transfer_window_feed(dt, 0, LOOKAHD, MARGIN))
      fail("feed after loop");
   else if (memcmp(base, ref, KEEP))
      fail("head contents after loop");
   else ok("loop back to 0: head still correct");

   /* second lap re-reads from the file rather than holding memory */
   for (tell = 0; tell < n / 2; tell += 65536)
   {
      if (!data_transfer_window_feed(dt, tell, LOOKAHD, MARGIN))
      { fail("feed during second lap"); break; }
      if (memcmp(base + tell, ref + tell, 65536))
      { fail("window contents during second lap"); break; }
   }
   if (!bad) ok("second lap: contents re-read correctly");

   /* extend past the end clamps rather than failing */
   if (!data_transfer_window_extend(dt, n + (1u << 20)))
      fail("extend past end refused");
   else ok("extend past the end clamps to the length");

   /* growing the permanently-resident head keeps it readable */
   if (!data_transfer_window_grow_keep(dt, KEEP * 2))
      fail("grow_keep refused");
   else if (memcmp(base, ref, KEEP * 2))
      fail("head contents after grow_keep");
   else ok("grow_keep: enlarged head is correct");

   data_transfer_free(dt);
   free(ref); remove(path);

   /* The point of the mode: a long file must not become resident.
    * Measured only where the platform reports a resident set, and
    * only meaningful when address space can actually be reserved. */
#if defined(__linux__)
   if (data_transfer_reserve_supported())
      bad |= residency_check();
   else
      printf("[skip] residency bound: no reservations on this build\n");
#else
   printf("[skip] residency bound: not measurable on this platform\n");
#endif

   bad |= callback_window_check();
   bad |= far_feed_check();
   bad |= sparse_skip_check();
   bad |= pin_check();
   bad |= feed_budget_check();
   bad |= ahead_of_frontier_check();
   bad |= surface_mixing_check();
   bad |= range_bounds_check();
   bad |= extend_settles_check();
   bad |= null_handle_check();
   bad |= settle_releases_check();

   printf("%s\n", bad ? "FAILED" : "PASS");
   return bad;
}
