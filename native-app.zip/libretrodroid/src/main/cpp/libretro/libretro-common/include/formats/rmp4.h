/* rmp4 -- MP4 (ISO Base Media File Format) demuxer for libretro-common.
 *
 * Parses the ISO-BMFF box structure that MP4 uses and hands out the
 * elementary-stream packets it carries.  This is a DEMUXER only: it does
 * not decode.  It reports the tracks (codec, type, and the parameters a
 * decoder needs) and streams out the coded packets in file order, each
 * tagged with its track, timestamp and key-frame flag -- the same
 * contract as the rwebm demuxer, so the rwebm_video/rwebm_audio-style
 * glue can drive either container identically.
 *
 * Recognised video codecs: VP8 ('vp08'), VP9 ('vp09'),
 * H.264 ('avc1'/'avc3'), H.265/HEVC ('hvc1'/'hev1')
 * and AV1 ('av01') video; Opus ('Opus'), Vorbis and AAC ('mp4a' by
 * object type) audio. Track recognition does not imply decoder support.
 * Other codecs are reported with their sample-entry fourcc
 * in codec_id and the codec field left RMP4_CODEC_UNKNOWN so callers
 * can skip them.
 *
 * Both progressive files (sample tables in moov/trak/mdia/minf/stbl)
 * and fragmented movies (an mvex-marked moov followed by moof/mdat
 * pairs) are supported.
 *
 * The whole input buffer is supplied up front (memory-only, like the
 * rest of libretro-common's format layer) and is borrowed, not copied:
 * it must outlive the demuxer, and returned packet pointers alias into
 * it. Decoder configuration records are owned by the demuxer and remain
 * valid until rmp4_close, including when a streaming caller releases
 * consumed input pages. Opus setup is repacked from dOps to OpusHead.
 */
#ifndef __LIBRETRO_SDK_FORMAT_RMP4_H__
#define __LIBRETRO_SDK_FORMAT_RMP4_H__

#include <stdint.h>
#include <stddef.h>

#include <retro_common_api.h>
#include <formats/video_color.h>

RETRO_BEGIN_DECLS

enum rmp4_track_type
{
   RMP4_TRACK_NONE = 0,
   RMP4_TRACK_VIDEO,
   RMP4_TRACK_AUDIO,
   RMP4_TRACK_OTHER
};

enum rmp4_language_kind
{
   RMP4_LANGUAGE_NONE = 0,
   RMP4_LANGUAGE_MDHD,
   RMP4_LANGUAGE_BCP47
};

enum rmp4_codec
{
   RMP4_CODEC_UNKNOWN = 0,
   RMP4_CODEC_VP8,
   RMP4_CODEC_VP9,
   RMP4_CODEC_H264,
   RMP4_CODEC_VORBIS,
   RMP4_CODEC_OPUS,
   RMP4_CODEC_AAC,
   RMP4_CODEC_H265,
   RMP4_CODEC_AV1,
   RMP4_CODEC_AC3
};

typedef struct
{
   enum rmp4_track_type type;
   enum rmp4_codec       codec;
   int                    number;      /* MP4 track_ID (1-based)          */
   /* Video */
   unsigned               width, height;
   /* From the sample entry's colr box (nclx/nclc); 0 when untagged, in
    * which case converters pick defaults by resolution. */
   video_mastering_display_t mastering;
   unsigned               max_cll, max_fall;
   unsigned               color_primaries;
   unsigned               matrix_coefficients;
   unsigned               transfer_characteristics;
   unsigned               full_range;
   unsigned               color_description_present, range_present;
   /* Audio */
   unsigned               sample_rate;
   unsigned               channels;
   /* Media-timescale units the track's edit list trims from the
    * start (the usual encoder-delay edit; sample count for audio).
    * Zero when absent. A leading empty edit may precede this trim;
    * arbitrary multi-entry or non-unity-rate edits remain unsupported. */
   uint64_t               media_skip;
   /* Decoder setup data, owned by the demuxer until rmp4_close.
    * Opus: repacked OpusHead; Vorbis: xiph-laced headers from esds;
    * H.264/HEVC/AV1: avcC/hvcC/av1C. VP8/VP9: complete vpcC payload. */
   const uint8_t         *codec_private;
   size_t                 codec_private_size;
   /* Sample-entry fourcc, NUL-terminated (e.g. "vp09", "avc1"). */
   char                   codec_id[24];
   /* Leading empty edit in movie time, converted to nanoseconds. */
   int64_t                presentation_delay_ns;
   /* Duration of the supported nonempty unity-rate edit, excluding the
    * leading delay. -1 when no such edit declares a play length. */
   int64_t                presentation_duration_ns;
   /* An mp4v or mp4a entry's esds objectTypeIndication: what the
    * fourcc does not say (mp4v carries MPEG-4 Visual 0x20, MPEG-2
    * video 0x60..0x65, MPEG-1 video 0x6A or JPEG 0x6C; mp4a MPEG-4
    * Audio 0x40, MPEG-2 AAC 0x66..0x68 or MP3 0x69/0x6B). 0 for other
    * entries, or without an esds. An mp4v's DecoderSpecificInfo (the
    * MPEG-4 VOS/VOL headers) is its codec_private. */
   unsigned               object_type;
} rmp4_track;

typedef struct
{
   const uint8_t *data;      /* aliases into the input buffer            */
   size_t         size;
   int            track;     /* index into the track array (0-based)     */
   int64_t        timestamp; /* presentation time in nanoseconds         */
   int            keyframe;
   /* Always 0 for MP4 (end trimming is carried by edit lists, which the
    * preview use cases do not need); present so packet handling code
    * can be shared with rwebm. */
   int64_t        discard_padding;
} rmp4_packet;

typedef struct rmp4 rmp4_t;

/* Parse the container (ftyp/moov and the per-track sample tables). The
 * buffer is borrowed and must outlive the returned demuxer. Returns
 * NULL if the data is not a recognisable MP4 stream. */
rmp4_t *rmp4_open_memory(const uint8_t *data, size_t size);

void rmp4_close(rmp4_t *mp4);

/* False while later fragment sample tables have not been indexed. */
int rmp4_index_complete(const rmp4_t *mp4);

/* Track enumeration. */
int               rmp4_num_tracks(const rmp4_t *mp4);

/* Bounded-memory streaming support: the lowest media byte any track's
 * first sample sits at (everything below is metadata the demuxer and
 * its callers keep borrowed pointers into - it must stay resident),
 * and the highest sample end delivered so far. */
size_t            rmp4_media_floor(const rmp4_t *m);
size_t            rmp4_consumed(const rmp4_t *m);
const rmp4_track *rmp4_get_track(const rmp4_t *mp4, int index);
/* Raw mdhd two-byte field or elng bytes (including terminator/padding).
 * Borrowed with the input; supported elng takes precedence. No language
 * validation or conversion, including Macintosh versus packed ISO639 mdhd codes. */
const uint8_t *rmp4_get_track_language(const rmp4_t *mp4, int index,
      size_t *length, enum rmp4_language_kind *kind);

/* Total duration in nanoseconds (from mvhd), or 0 if the file does not
 * declare one. */
int64_t rmp4_duration_ns(const rmp4_t *mp4);

/* Read the next elementary-stream packet in file order into *pkt.
 * Returns 1 on success, 0 at end of stream, -1 on a parse error. The
 * packet's data pointer aliases the input buffer and is valid until the
 * demuxer is closed. */
/* Returned by rmp4_read_packet when the next sample's bytes lie beyond
 * the prefix made available so far (see rmp4_set_avail): nothing was
 * consumed; call again after more bytes arrive. */
#define RMP4_READ_AGAIN 2

int rmp4_read_packet(rmp4_t *mp4, rmp4_packet *pkt);

/* Next packet byte range from sample tables; reads no media bytes. */
void rmp4_read_span(rmp4_t *mp4, size_t *lo, size_t *hi);

/* Open against a partially-read buffer: only the first 'avail' bytes
 * are valid (the rest may be uninitialised) and are never read.  Box
 * bodies are hopped arithmetically, so a trailing moov (a file muxed
 * without faststart) is found as soon as its own bytes arrive; a
 * fragmented movie indexes resident headers and requests later headers
 * through rmp4_read_span as its samples are consumed.  On failure, *need_more (when
 * non-NULL) is set when the failure was running out of available
 * bytes rather than malformed data - retry with a larger avail.
 * rmp4_open_memory is this with avail == size. */
/* need_lo/need_hi (optional): when the open stalls on the available
 * prefix, the exact byte range that would let it progress - a box
 * header past the wall, or the whole moov body.  A windowed caller
 * can commit just that range instead of reading everything up to it;
 * both stay 0 when the stall has no such range. */
rmp4_t *rmp4_open_memory_avail(const uint8_t *data, size_t size,
      size_t avail, int *need_more, size_t *need_lo, size_t *need_hi);

/* Raise the number of valid bytes (monotonic; clamped to the file
 * size). */
void rmp4_set_avail(rmp4_t *mp4, size_t avail);

/* Borrow a track's presentation timestamps (decode order), straight
 * from the sample tables - available as soon as the moov is parsed,
 * with no reference to the media data.  Returns NULL for an invalid
 * track; the array lives until rmp4_close. */
const int64_t *rmp4_track_pts(const rmp4_t *mp4, int track,
      uint32_t *count);

/* Metadata-only key flag for a track sample: 0/1, -1 if invalid.
 * Does not read sample bytes or change any packet cursor. */
int rmp4_track_sample_key(const rmp4_t *mp4, int track, uint32_t sample);

/* Metadata-only half-open file span. Does not read sample bytes or
 * change cursors. Invalid input leaves the outputs unchanged. */
int rmp4_track_sample_span(const rmp4_t *mp4, int track, uint32_t sample,
      size_t *begin, size_t *end);

/* Exact text/other sample duration in nanoseconds, -1 if unavailable.
 * Video/audio tracks do not retain an extra duration table. */
int64_t rmp4_track_text_duration(const rmp4_t *mp4, int track, uint32_t sample);

/* Text interval in movie nanoseconds, clipped to the supported edit.
 * Equal endpoints mean the sample is outside that edit. No media reads. */
int rmp4_track_text_time(const rmp4_t *mp4, int track, uint32_t sample,
      int64_t *start, int64_t *end);

/* Read only this track from sample onward until rewind. Other tracks
 * are parked at their ends. No sample bytes are read; the next read
 * still obeys the current availability bound. Invalid input leaves
 * all cursors unchanged. Returns 1 on success, 0 on failure. */
int rmp4_select_track_sample(rmp4_t *mp4, int track, uint32_t sample);

/* Restart packet reading from the first sample. */
void rmp4_rewind(rmp4_t *mp4);

RETRO_END_DECLS

#endif
