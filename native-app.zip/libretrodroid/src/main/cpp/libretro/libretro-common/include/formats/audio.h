/* Copyright  (C) 2010-2024 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (audio.h).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef __LIBRETRO_SDK_FORMAT_AUDIO_H__
#define __LIBRETRO_SDK_FORMAT_AUDIO_H__

#include <stdint.h>
#include <stddef.h>

#include <boolean.h>
#include <retro_common_api.h>

RETRO_BEGIN_DECLS

/* Codec-agnostic audio decode interface.
 *
 * This is the audio-side counterpart of formats/image.h: a thin dispatch
 * layer that sits above the concrete decoders (rwav/rflac/rvorbis/rmp3/
 * rmodtracker/ropus/raac) and lets callers decode any supported format
 * through one API, exactly the way image_transfer_* sits above
 * rpng/rjpeg/etc.
 *
 * The arms implement different subsets of what follows - input modes,
 * whether s16 and f32 may be mixed, whether a length is reported, seek
 * and windowing support.  audio_transfer.c opens with the per-codec
 * matrix; the notes here give only what a caller must know to use the
 * call at all.
 *
 * The lifecycle mirrors the image layer 1:1 - new -> start -> read (repeat)
 * -> free, no direct file I/O (the caller owns the encoded bytes and passes
 * them via audio_transfer_set_buffer_ptr). Two things differ from images,
 * because mixer audio is an unbounded pull stream rather than a bounded
 * decode-to-completion:
 *   - audio_transfer_seek(), for looping (images never seek);
 *   - audio_transfer_info(), because format (channels/rate) must be known up
 *     front to size buffers and configure resampling, whereas an image
 *     reports its dimensions out of the decode step itself.
 * The read step comes in s16 and f32 variants so an integer output path and
 * a float output path can each stay in their own format end to end. */

enum audio_process_code
{
   AUDIO_PROCESS_ERROR     = -2,
   AUDIO_PROCESS_ERROR_END = -1,
   AUDIO_PROCESS_NEXT      =  0,   /* more PCM remains in the stream */
   AUDIO_PROCESS_END       =  1    /* end of stream reached          */
};

enum audio_type_enum
{
   AUDIO_TYPE_NONE = 0,
   AUDIO_TYPE_WAV,
   AUDIO_TYPE_FLAC,
   AUDIO_TYPE_VORBIS, /* Ogg Vorbis (rvorbis); also WebM buffers (.weba) */
   AUDIO_TYPE_MP3,
   AUDIO_TYPE_MOD,  /* tracker module: MOD / S3M / XM (rmodtracker) */
   AUDIO_TYPE_OPUS, /* Opus (ropus); demuxed, Ogg (.opus) or WebM (.weba) */
   AUDIO_TYPE_AAC,  /* AAC-LC (raac); demuxed path, an ADTS buffer
                    * (.aac), or a whole MP4/M4A buffer when rmp4 is
                    * built in                                          */
   AUDIO_TYPE_LPCM, /* linear PCM (rlpcm); the samples themselves, from
                     * a .lpcm or .pcm buffer. The shape comes from a
                     * DVD or Blu-ray header the buffer opens with, or
                     * from a caller that filled the format in before
                     * starting - raw samples say nothing about
                     * themselves                                      */
   AUDIO_TYPE_AC3,  /* AC-3 or E-AC-3 (rac3); a buffer of syncframes
                    * (.ac3, .eac3, .ec3). Up
                    * to 5.1, handed over in the WAV shape for its
                    * channel count (the mixer folds by count): a
                    * lone surround becomes a phantom pair, and the
                    * LFE is kept only in 5.1                           */
   AUDIO_TYPE_WMA,  /* Native WMA1/WMA2/Pro in ASF or RIFF/XWMA. */
   AUDIO_TYPE_ATRAC /* ATRAC3 (ratrac3) or ATRAC3plus (ratrac3p), in
                     * OpenMG (.oma, .aa3) or WAVE (.at3); up to 7.1,
                     * handed over in the WAV shape for its channel
                     * count, as AC-3 is. Encrypted OpenMG is refused. */
};

/* The linear-PCM format an AUDIO_TYPE_LPCM handle will use, for a
 * caller that knows the shape of raw samples - a track ripped from a
 * disc, a core's own buffer - to fill in before starting. NULL for
 * any other type. A buffer that opens with a DVD or Blu-ray header
 * needs none of this: leave the format zeroed and the header is
 * read. Set kind to DVD explicitly when the header's origin is known;
 * fully supplied DVD shapes describe headerless packed sample storage.
 * DVD short reads retain a bounded decoded block; seeks remain exact. */
void *audio_transfer_lpcm_format(void *data);

/* Guess the codec from a file-name/extension (counterpart of
 * image_texture_get_type). Returns AUDIO_TYPE_NONE if unrecognised.
 * Covers WAV, FLAC, Ogg Vorbis, MP3, AC-3 and the tracker modules only:
 * .opus, .aac, .m4a, .weba, .mka, .mkv and .oga have no extension
 * mapping, and .ogg names a container rather than a codec - Vorbis,
 * Opus and FLAC all travel in one - so those types come from the
 * caller or from the content sniffers below. */
enum audio_type_enum audio_decode_get_type(const char *path);

/* ---- shared lifecycle: 1:1 with image_transfer_* ---- */

/* Allocate an opaque decode context for the given codec. */
void *audio_transfer_new(enum audio_type_enum type);

/* Point the context at the encoded bytes. No file I/O is performed; the
 * caller retains ownership of the buffer and must keep it alive for the
 * lifetime of the decoder. Call before audio_transfer_start. */
void  audio_transfer_set_buffer_ptr(void *data, enum audio_type_enum type,
      void *ptr, size_t len);

/* Container audio selection, before start and after buffer/avail setup.
 * -1 retains automatic first-supported selection; nonnegative values are
 * zero-based demuxer track indices (including video/subtitle tracks).
 * An explicit missing, non-audio or different-codec track makes start fail;
 * it never silently substitutes another track. No allocation or input copy.
 * Supports Matroska/WebM Opus/Vorbis/FLAC/AAC and MP4 AAC when compiled in.
 * An active or partially opened decoder refuses changes: prepare a new
 * decoder on its owning worker and adopt it through the caller's lifecycle. */
bool audio_transfer_set_container_track(void *data, enum audio_type_enum type,
      int track);
/* Query after successful start: the actual container index, or -1 for raw
 * input/unsupported codecs. Retained across seeks; it never exposes a request
 * as an opened track before the codec has been constructed. */
int audio_transfer_container_track(const void *data, enum audio_type_enum type);

/* Point the context at a DEMUXED elementary stream instead of a
 * self-framed file: 'setup' is the codec's out-of-band configuration
 * (a container's CodecPrivate -- e.g. the Vorbis identification/comment/
 * setup headers, xiph-laced, or an Opus OpusHead), and 'packets' is the
 * concatenation of the coded frames in decode order.  Some codecs need
 * the coded frames delimited; 'sizes'/'num_packets', when provided, give
 * the byte length of each packet in order (pass NULL/0 when the codec's
 * frames are self-delimiting).  All buffers are borrowed and must outlive
 * the decoder.  Used by container demuxers (e.g. WebM) that have already
 * separated setup from payload; call instead of set_buffer_ptr, before
 * audio_transfer_start. Returns false if the codec has no demuxed path.
 * Vorbis, Opus and AAC may start with an empty packet set: setup alone
 * exposes the channel count and sample rate. Packets may arrive later
 * under the growth contract below.
 *
 * GROWTH CONTRACT: this call may be repeated after audio_transfer_start,
 * mid-stream, to grow the packet set for a progressive source - e.g. a
 * player appending packets as a file arrives.  It only rebases the
 * borrowed pointers and counts; no decoder or consumption state is
 * touched (all demuxed arms track their position by packet index and
 * byte offset, dereferencing the bases fresh at each read), so the new
 * arrays may live at a different address (realloc).  Caller contract:
 * counts and sizes are monotonic and the common prefix is identical.
 * A read that exhausted the packets returned 0 frames without latching
 * end-of-stream, so growth resumes decoding even after starvation. */
bool  audio_transfer_set_demuxed_ptr(void *data, enum audio_type_enum type,
      const void *setup, size_t setup_size,
      const void *packets, size_t packets_size,
      const uint32_t *sizes, size_t num_packets);

/* Exact decoded contribution of one borrowed demuxed packet, without
 * decoding or changing the active cursor. Call after start(). index is
 * its zero-based position since the stream head: Vorbis packet zero
 * primes overlap and yields no frames. Counts precede start/end trim.
 * Returns -1 when a measurement is unavailable. This is not a full
 * coded-payload validation; the decoder still validates each packet. */
int audio_transfer_demuxed_packet_frames(void *data, enum audio_type_enum type,
      const void *packet, size_t size, size_t index);


/* Frames the container trims from the start of the stream (e.g. the
 * AAC encoder delay from an MP4 edit list).  Call between
 * set_demuxed_ptr and audio_transfer_start; only codecs whose trim is
 * not carried in the codec setup itself accept it (currently AAC --
 * Opus pre-skip comes from the OpusHead and needs no call). */
bool  audio_transfer_set_start_trim(void *data, enum audio_type_enum type,
      uint64_t frames);

/* Ask for PCM at a particular sample rate, before audio_transfer_start.
 * This is a hint, not a conversion: no arm resamples. It reaches the
 * codecs that synthesise rather than decode - a tracker replayer will
 * mix at whatever rate it is given - and is ignored by the ones whose
 * rate the stream itself fixes, which is most of them. Check what was
 * actually done with audio_transfer_info; a caller passing its own
 * output rate and getting it back has saved a resampling stage, and one
 * getting something else resamples as it would have anyway. */
void audio_transfer_set_output_rate(void *data, enum audio_type_enum type,
      unsigned rate);

/* Tell a decoder how many bytes from the start of the buffer set by
 * set_buffer_ptr are actually resident.  A windowed feeder calls this
 * before audio_transfer_start, so a container header parse is bounded
 * by the permanently-resident head instead of running to the end of
 * the file, and again as the window slides.  Monotonic; 0 means the
 * whole buffer is there, which is the default and what every
 * non-windowed caller wants.  Only the WebM container arms use it;
 * a no-op elsewhere. */
void audio_transfer_set_avail(void *data, enum audio_type_enum type,
      size_t avail);

/* Windowed Opus only: inject the stream's last-page granule so the
 * decoder's buffer setup does not scan the whole file for it (the tail
 * is not resident under windowing).  No-op for non-Opus types. */
void audio_transfer_set_end_granule(void *data, enum audio_type_enum type,
      int64_t end_granule);

/* Identify the codec of an Ogg buffer from its first page's
 * identification header: AUDIO_TYPE_OPUS, AUDIO_TYPE_VORBIS or
 * AUDIO_TYPE_FLAC, whose buffer modes all accept the whole file;
 * AUDIO_TYPE_NONE if it is not Ogg or carries an unsupported codec.
 * An .ogg or .oga extension can legitimately wrap any of the three. */
enum audio_type_enum audio_transfer_ogg_audio_type(const void *buf,
      size_t len);

/* Identify the first supported audio codec of a WebM or Matroska
 * buffer (.weba, .mka, .mkv): AUDIO_TYPE_OPUS, AUDIO_TYPE_VORBIS,
 * AUDIO_TYPE_AAC or AUDIO_TYPE_FLAC, whose buffer modes all accept the
 * whole file; AUDIO_TYPE_NONE if it is not one of those containers or
 * carries no supported track. */
enum audio_type_enum audio_transfer_webm_audio_type(const void *buf,
      size_t len);
/* MP4 AAC/AC-3 metadata probe, bounded by the resident prefix.
 * Track is a demuxer index, or -1 for the first supported audio track. */
enum audio_type_enum audio_transfer_mp4_audio_track_type(const void *buf,
      size_t len, size_t avail, int track);

/* WebM sniff restricted to a demuxer index, or -1 for automatic. */
enum audio_type_enum audio_transfer_webm_audio_track_type(const void *buf,
      size_t len, int track);

/* The arm for a whole file, from its bytes: ID3v2 tags in front are
 * looked past, then FLAC, Ogg (audio_transfer_ogg_audio_type), WebM and
 * Matroska (audio_transfer_webm_audio_type), WAVE (PCM and float as
 * AUDIO_TYPE_WAV, WMA in RIFF and xWMA as AUDIO_TYPE_WMA, ATRAC3 and
 * ATRAC3plus as AUDIO_TYPE_ATRAC), OpenMG (AUDIO_TYPE_ATRAC), ASF, MP4 and
 * M4A (AUDIO_TYPE_AAC; start finds the AAC track, if there is one),
 * tracker modules, then raw streams - AC-3, ADTS and MPEG audio - by a
 * frame header with another where it says the next frame starts, in
 * the first 64 KiB. Only the arms this build has; AUDIO_TYPE_NONE for
 * anything else. @skip (may be NULL) is where the arm's buffer starts:
 * past the ID3v2 tags, and past junk before a raw stream's first frame,
 * which the buffer modes of AAC and AC-3 do not look past themselves. */
enum audio_type_enum audio_transfer_sniff_type(const void *buf, size_t len,
      size_t *skip);

/* The fold to stereo of @channels channels (1 to 8) in the order @type's
 * arm hands them over: [channel][0 = left, 1 = right], Q15 (unity
 * 32768). Vorbis and Opus in Vorbis order, the rest in WAVE order;
 * centre and surrounds at -3 dB into each side, a lone back centre at
 * -6 dB, LFE dropped; mono to both sides at unity. NULL past eight. */
const int32_t (*audio_transfer_fold_q15(enum audio_type_enum type,
      unsigned channels))[2];

/* Open the decoder over the buffer set above. Returns false on malformed
 * input. */
bool  audio_transfer_start(void *data, enum audio_type_enum type);

/* Whether the context holds a successfully opened decoder. */
bool  audio_transfer_is_valid(void *data, enum audio_type_enum type);

/* Release the decoder and the context. */
void  audio_transfer_free(void *data, enum audio_type_enum type);

/* ---- audio-specific additions ---- */

/* Stream format, valid after a successful start. Any out pointer may be
 * NULL. total_frames is 0 when the stream length is unknown. */
/* The fold of a started stream's channels to stereo: matrix[channel]
 * [0 = left, 1 = right], Q15 (unity 32768), zero past the stream's
 * channels. WMA's by the stream's WAVE speaker mask; every other arm's
 * by its channel count, in the order the arm hands channels over
 * (audio_transfer_fold_q15). False before a successful start or past
 * eight channels. */
bool audio_transfer_stereo_matrix(void *data, enum audio_type_enum type,
      int32_t matrix[8][2]);
/* Float mixing keeps sqrt(1/2) coefficients without Q15 rounding. */
bool audio_transfer_stereo_matrix_f32(void *data, enum audio_type_enum type,
      float matrix[8][2]);

bool  audio_transfer_info(void *data, enum audio_type_enum type,
      unsigned *channels, unsigned *rate, uint64_t *total_frames);

/* Decode the next chunk of up to 'frames' interleaved PCM frames. This is
 * the repeatable, caller-paced analogue of image_transfer_process: it writes
 * into 'out', stores the number of frames actually produced in *frames_out
 * (may be NULL), and returns AUDIO_PROCESS_NEXT while data remains,
 * AUDIO_PROCESS_END at end of stream (frames produced 0), or
 * AUDIO_PROCESS_ERROR.  NEXT with zero frames produced means starved,
 * not finished: a windowed source stopped at its resident bound
 * (audio_transfer_set_avail) and the same call succeeds once the
 * feeder has raised it - the caller must not treat the empty read as
 * the stream ending, or a looping voice rewinds mid-file whenever its
 * feeder runs a tick behind.  s16 is exact for the integer codecs (FLAC, and
 * WAV other than its float form); f32 is
 * the native path for the float mixer.  Producing fewer frames than asked
 * is not end of stream, and END is not latched: a demuxed packet set that
 * has been grown resumes on the next call.  Opus latches the format at
 * the first read and errors on the other entry point for the life of the
 * context, its two pipelines being separate decoders rather than two
 * edges of one; every other arm may be mixed freely. */
int   audio_transfer_read_s16(void *data, enum audio_type_enum type,
      int16_t *out, size_t frames, size_t *frames_out);
int   audio_transfer_read_f32(void *data, enum audio_type_enum type,
      float *out, size_t frames, size_t *frames_out);

/* The codec's current byte offset within the buffer set by
 * set_buffer_ptr - how far into the compressed stream the decoder
 * has read.  Monotonic during playback, jumps back to the head on a
 * loop seek.  A windowed source's feeder uses it to keep residency
 * around the read position.  Returns 0 if the codec does not track
 * a buffer offset: the demuxed arms and MOD.  A WebM buffer reports
 * the demuxer's walk position, which never falls below the header
 * material the demuxer keeps borrowed pointers into. DVD LPCM reports the
 * encoded read frontier; a partially emitted block lives in owned carry. */
size_t audio_transfer_buffer_tell(void *data, enum audio_type_enum type);
/* Complete encoded element blocking the next read, or zero. Query only
 * with exclusive decoder ownership. This is admission demand, never a
 * byte-release frontier. */
size_t audio_transfer_buffer_read_end(void *data, enum audio_type_enum type);

/* Seek to an absolute PCM frame (used to loop). Internally demuxed
 * container audio uses movie coordinates, including gaps and tail;
 * caller-demuxed input keeps source-sample coordinates. true accepts
 * the request. Packet duration queries locate Vorbis and Opus preroll;
 * MP4 AAC uses its sample tables. Unsupported input modes may refuse.
 *
 * Seeking is not always cheap, and what it costs is spent on the
 * calling thread: MOD walks the sequence to get where it is going,
 * while Opus and AAC step over the packets before the target without
 * decoding them and then decode a short pre-roll before it.  That
 * pre-roll is why a seek in a lossy codec does not resume bit-exactly -
 * the decoder converges rather than arriving in the state a playthrough
 * would have left it in. An Opus seek starts at the following read
 * because preroll settles the output format. Container preparation may
 * return NEXT with zero output while metadata/preroll work remains;
 * retry normally, feeding the requested byte frontier when starved. */
bool  audio_transfer_seek(void *data, enum audio_type_enum type,
      uint64_t frame);

/* Exclusive-owner bounded seek preparation, MP4 AAC and Matroska/WebM
 * AAC, Opus and Vorbis.
 * Targets use container movie frames, including gaps and the declared tail.
 * AAC maps <=256 sample-table timestamps per metadata slice, then selects
 * indexed preroll without reading media bytes. WebM steps header mapping
 * and decoder preroll separately; FLAC discards at most one coded frame.
 * Step decodes at most one access unit or examines <=256 packet/sample
 * headers: -1 failure, 0 retry (including input
 * starvation), 1 positioned for the next read. Feed buffer_tell before
 * retrying a resident wall. A new successful begin replaces the request.
 * Do not interleave reads or legacy seek with an unfinished request.
 * Failure to begin leaves the previous request/decoder untouched. */
bool audio_transfer_seek_begin(void *data, enum audio_type_enum type,
      uint64_t frame);
/* Select the WebM pending PCM format before preparation (AAC and FLAC
 * are format independent). The default begin above prepares float PCM. */
bool audio_transfer_seek_begin_format(void *data, enum audio_type_enum type,
      uint64_t frame, bool s16);

int audio_transfer_seek_step(void *data, enum audio_type_enum type);

RETRO_END_DECLS

#endif
