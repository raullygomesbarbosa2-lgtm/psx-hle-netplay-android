/* rwebm_video -- WebM video-to-image glue for libretro-common.
 *
 * Combines the rwebm demuxer with the rvp8/rvp9 decoders to present a
 * WebM file's video track through the same two interfaces the image
 * formats use, so the menu thumbnail pipeline can treat a .webm exactly
 * like an animated .webp:
 *
 *   - Still image: rwebm_video_alloc / set_buf_ptr / process_image
 *     decode the first displayed frame (the rwebp_t-style contract that
 *     image_transfer.c drives for the initial texture upload).
 *
 *   - Streaming animation: rwebm_video_stream_* decode one displayed
 *     frame per call, in stream order, with per-frame durations derived
 *     from the container's block timestamps (the rwebp_anim_stream_t
 *     contract that gfx_thumbnail_animate() drives).
 *
 * VP8 tracks require the rvp8 decoder (built with HAVE_RWEBP or
 * HAVE_RWEBM); VP9 tracks additionally require HAVE_RVP9. Tracks whose
 * codec is not compiled in are skipped. Audio tracks are ignored, and
 * alpha (BlockAdditions) is ignored: output is always opaque.
 *
 * Frames are returned as w*h uint32 pixels. The animation stream emits
 * ABGR words (memory order R,G,B,A on little-endian), matching the
 * animated WebP stream; the still-image path honours supports_rgba the
 * same way rwebp_process_image does (ARGB words when false).
 */
#ifndef __LIBRETRO_SDK_FORMAT_RWEBM_VIDEO_H__
#define __LIBRETRO_SDK_FORMAT_RWEBM_VIDEO_H__

#include <stdint.h>
#include <stddef.h>

#include <boolean.h>
#include <retro_common_api.h>
#include <formats/video_hw_frame.h>
#include <formats/video_audio_track.h>

RETRO_BEGIN_DECLS

/* ---- Still image (first displayed frame) ---- */

typedef struct rwebm_video rwebm_video_t;

rwebm_video_t *rwebm_video_alloc(void);

void rwebm_video_free(rwebm_video_t *webm);

/* 10-bit 4:2:0 -> 32-bit RGB.  Planes are uint16 samples with strides in
 * PIXELS.  matrix / transfer / range are ISO/IEC 23001-8 code points as
 * carried by the webm Colour element (0 = absent; HD-appropriate
 * defaults are chosen).  transfer 16 (PQ / HDR10) is tone-mapped to SDR
 * (hable curve, auto exposure, MaxCLL-driven peak with a
 * 1000-nit fallback, BT.2020 -> 709
 * gamut); anything else is converted as SDR and rounded to 8 bits.
 * abgr nonzero packs R in the low byte (thumbnail convention); zero
 * packs XRGB8888 (libretro frontend convention). */
void rwebm_video_blit_i420_hbd(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range,
      unsigned max_cll, int abgr);

/* Native 10-bit variant: same SDR-encoded colour as the _hbd path (PQ/HDR10
 * tone-mapped, BT.2020 -> 709 gamut, sRGB transfer) but emitted at 10-bit
 * precision into packed XRGB2101010 (bits [29:20]=R [19:10]=G [9:0]=B, native
 * endian) instead of narrowing to 8 bits, so gradients band less. Used when
 * the frontend accepts RETRO_PIXEL_FORMAT_XRGB2101010. The frontend HDR path
 * expects an SDR-encoded source, so this raises bit depth only and does not
 * pass PQ through. */
void rwebm_video_blit_i420_10bit(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range,
      unsigned max_cll);

/* HDR variant: a PQ (transfer 16) or HLG (transfer 18) source as linear
 * scRGB - 80 nits is 1.0, the 709 primaries, components outside 709
 * kept negative - in RGBA half floats, 8 bytes a pixel, memory order
 * R,G,B,A with A 1.0. No tone map: for a display that shows HDR. dst_stride
 * is in pixels. Returns 0, writing nothing, for any other transfer, which
 * is not HDR and takes the 8-bit or 10-bit paths above. */
int rwebm_video_blit_i420_fp16(uint16_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range);

/* Source-primary-aware counterparts. primaries 1 is already BT.709;
 * 9 is BT.2020, also the HDR default for absent/unspecified primaries.
 * The legacy entry points above retain their BT.2020 HDR assumption.
 * Primaries affect HDR gamut conversion and the linear HLG OOTF only;
 * matrix remains the independent YCbCr matrix code point. */
/* Caller-owned PQ table. Initialize before publishing it to row-band
 * workers; keep immutable until those workers finish. The legacy blits
 * remain stateless and need no shared cache or allocation. */
typedef struct rwebm_video_hdr_tone
{
   uint16_t pq[1024];
   unsigned peak;
   int ready;
} rwebm_video_hdr_tone_t;

void rwebm_video_hdr_tone_init(rwebm_video_hdr_tone_t *tone, unsigned max_cll);
void rwebm_video_blit_i420_hbd_tone(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range,
      unsigned max_cll, unsigned primaries, int abgr,
      const rwebm_video_hdr_tone_t *tone);
void rwebm_video_blit_i420_10bit_tone(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range,
      unsigned max_cll, unsigned primaries,
      const rwebm_video_hdr_tone_t *tone);

void rwebm_video_blit_i420_hbd_color(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range,
      unsigned max_cll, unsigned primaries, int abgr);
void rwebm_video_blit_i420_10bit_color(uint32_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range,
      unsigned max_cll, unsigned primaries);
int rwebm_video_blit_i420_fp16_color(uint16_t *dst, unsigned dst_stride,
      unsigned w, unsigned h, const uint16_t *y, int ys,
      const uint16_t *u, const uint16_t *v, int uvs,
      unsigned matrix, unsigned transfer, unsigned range, unsigned primaries);

bool rwebm_video_set_buf_ptr(rwebm_video_t *webm, void *data, size_t len);

/* Request packed XRGB2101010 (10-bit) output for 10-bit HDR sources; 8-bit
 * sources are unaffected. Off by default. */
void rwebm_video_set_want_10bit(rwebm_video_t *webm, int want);

/* Partial-read support for the still decode: declare how many leading
 * bytes of the buffer are valid (monotonic; 0 means fully resident).
 * With a short avail, rwebm_video_process_image returns
 * IMAGE_PROCESS_WAIT instead of failing when it needs bytes that have
 * not arrived (the header, at least two scanned frames, or the first
 * displayed frame's blocks). */
void rwebm_video_set_avail(rwebm_video_t *webm, size_t avail);

/* True if the last rwebm_video_process_image() produced XRGB2101010. */
bool rwebm_video_is_10bit(const rwebm_video_t *webm);

/* Half floats for an HDR still: with want set, a PQ or HLG source's
 * first frame is decoded as linear scRGB (rwebm_video_blit_i420_fp16)
 * straight into the frame process hands out, 8 bytes a pixel; is_fp16
 * says whether the last one came out so. Any other source decodes as
 * it always did. */
void rwebm_video_set_want_fp16(rwebm_video_t *webm, int want);
bool rwebm_video_is_fp16(const rwebm_video_t *webm);

/* Decodes the first displayed frame of the first supported video track
 * into a freshly malloc'd buffer at *buf. Returns IMAGE_PROCESS_END on
 * success, IMAGE_PROCESS_ERROR on failure (no supported video track,
 * malformed stream, or out of memory). */
int rwebm_video_process_image(rwebm_video_t *webm, void **buf,
      size_t len, unsigned *width, unsigned *height, bool supports_rgba);

/* ---- Streaming animation ---- */

typedef struct rwebm_video_stream rwebm_video_stream_t;

/* Zero-based audio ordinal; metadata borrows the live stream. */
bool rwebm_video_stream_audio_track(const rwebm_video_stream_t *stream,
      unsigned ordinal, video_audio_track_t *out);

/* Take ownership of the stream a successful rwebm_video_process_image
 * left open, positioned just past the first displayed frame, so the
 * caller can continue the video as an animation without re-opening
 * (and re-pre-scanning) the file.  Returns NULL if no stream is held
 * (no process call yet, it failed, or the stream was already
 * detached).  The stream borrows the buffer given via
 * rwebm_video_set_buf_ptr, which must outlive it; close it with
 * rwebm_video_stream_close.  10-bit output requested for the still is
 * dropped: detached streams emit 8-bit frames. */
rwebm_video_stream_t *rwebm_video_detach_stream(rwebm_video_t *webm);

/* The buffer is BORROWED and must remain valid and unmodified until
 * rwebm_video_stream_close. Returns NULL when the data is not a WebM
 * stream, has no video track with a compiled-in codec, or contains no
 * video packets. */
rwebm_video_stream_t *rwebm_video_stream_open(const uint8_t *buf,
      size_t len);

/* Open against a partially-read buffer: 'avail' leading bytes are
 * valid (raise later with the stream set_avail).  On NULL, *need_more
 * distinguishes "feed more bytes and retry" from malformed data.  For WebM the
 * pre-scan is truncated at the wall once two frames are known (call
 * rwebm_video_stream_complete_scan when the file has fully arrived). */
rwebm_video_stream_t *rwebm_video_stream_open_avail(const uint8_t *buf,
      size_t len, size_t avail, int *need_more);

/* Hardware-only AV1 candidate, without a CPU canvas. Call set_hw before
 * decoding. The buffer, including pending packets, remains borrowed. */
rwebm_video_stream_t *rwebm_video_stream_open_hw_avail(const uint8_t *buf,
      size_t len, size_t avail, int *need_more);

void rwebm_video_stream_close(rwebm_video_stream_t *stream);

/* num_frames is the number of coded video packets, saturating at the
 * pre-scan cap (a few thousand): treat it as "at least this many", an
 * upper bound on displayed frames only below the cap (the stream may
 * carry non-shown frames).  loop_count is always 0: video loops
 * indefinitely. */
void rwebm_video_stream_get_info(const rwebm_video_stream_t *stream,
      unsigned *width, unsigned *height, int *num_frames, int *loop_count);

/* Decode the next displayed frame. Returns the frame pixels (valid until
 * the next call on this stream) and writes its display duration in ms
 * (0 when unknown; the caller applies its default), or NULL at the end
 * of one pass; call rwebm_video_stream_rewind to loop.  Pixels are in
 * memory order R,G,B,A by default; see rwebm_video_stream_set_argb. */
const uint32_t *rwebm_video_stream_next(rwebm_video_stream_t *stream,
      int *duration_ms);

/* Decode and discard the next displayed frame without color conversion or
 * GPU surface export. References and timestamps advance normally. Returns 1
 * for a displayed frame, 2 for retry, 0 at end/error. While waiting, retry the
 * same operation (next or skip), or rewind/close to cancel it. */
int rwebm_video_stream_skip(rwebm_video_stream_t *stream, int *duration_ms);

/* Enable registered hardware before playback (VP9 rewinds on success), or
 * query the active mode with enable == 0. AV1 candidates have no software
 * decoder; other failures retain software state.
 * GPU next returns a non-pixel token; take the lease with hw_frame.
 * A NULL next while waiting is a retry, not EOS. Owner-thread calls. */
int rwebm_video_stream_set_hw(rwebm_video_stream_t *stream, int enable);
/* Exclusive decoder owner; withdraw hardware preference and restart. */
void rwebm_video_stream_stop_hw(rwebm_video_stream_t *stream);
int rwebm_video_stream_hw_frame(rwebm_video_stream_t *stream,
      video_hw_frame_t *out);
int rwebm_video_stream_waiting(const rwebm_video_stream_t *stream);
void *rwebm_video_stream_h264(rwebm_video_stream_t *stream);
void *rwebm_video_stream_h265(rwebm_video_stream_t *stream);

/* Select the channel order of subsequent frames: non-zero emits ARGB
 * words (memory order B,G,R,A on little-endian), zero restores the
 * default R,G,B,A memory order.  Applies to the 8-bit output paths;
 * 10-bit XRGB2101010 output is unaffected.  The order is baked by the
 * blit, so this costs nothing per frame - it exists so a caller whose
 * upload format is ARGB does not need its own full-frame swizzle pass.
 * Takes effect from the next decoded frame; may be changed between
 * frames.  A stream detached from a still-image transfer starts at
 * the default order. */
void rwebm_video_stream_set_argb(rwebm_video_stream_t *stream, int argb);

/* Blit decoded frames into @out - width * height words, the caller's,
 * which then comes back from rwebm_video_stream_next - instead of the
 * stream's own frame, so a caller uploading from its own buffer needs
 * no copy out of the stream. NULL restores the stream's frame, allocated
 * on its first displayed software frame. Takes effect from the next
 * decoded frame; @out must stay valid until the next call that decodes
 * has returned. */
void rwebm_video_stream_set_output(rwebm_video_stream_t *stream,
      uint32_t *out);

/* As set_output, with rows @stride pixels apart (0: width), including
 * FP16 pixels. NULL restores the canvas. False leaves output unchanged
 * if the stride is too short or its frame extent overflows size_t. */
int rwebm_video_stream_set_output_stride(rwebm_video_stream_t *stream,
      uint32_t *out, unsigned stride);

/* Linear scRGB half floats for an HDR source: a 10-bit PQ or HLG frame
 * decoded into the caller's frame (rwebm_video_stream_set_output),
 * which then holds 8 bytes a pixel, through rwebm_video_blit_i420_fp16
 * - no tone map. Every other frame, and every frame without a caller's
 * output, takes the paths it always did. is_fp16 answers for the last
 * frame decoded; is_hdr for the source, from its track's transfer. */
void rwebm_video_stream_set_want_fp16(rwebm_video_stream_t *stream,
      int want);
int rwebm_video_stream_is_fp16(const rwebm_video_stream_t *stream);
int rwebm_video_stream_is_hdr(const rwebm_video_stream_t *stream);

/* The decoded planes of an 8-bit 4:2:0 SDR source, for a caller whose
 * GPU converts them: can_planar answers from the container before any
 * decode; with set_planar on (0 where the stream cannot), each frame
 * decoded into the caller's frame (rwebm_video_stream_set_output) is
 * packed I420 of the stream's size - Y, then Cb, then Cr - and a
 * frame that cannot be so ends the stream. planar_yuv is that
 * frame's IMAGE_YUV_FLAG_* (BT709, FULL_RANGE). */
int rwebm_video_stream_can_planar(const rwebm_video_stream_t *stream);
/* planar 2 borrows arbitrary strides, 3 only tightly packed planes,
 * instead of filling the output
 * slot where possible. The next successful frame returns that slot as
 * usual; borrowed_planar tells whether to read the planes instead.
 * The borrow ends at the next decode, seek, rewind or stream free. */
int rwebm_video_stream_set_planar(rwebm_video_stream_t *stream, int planar);
struct texture_planar;
const struct texture_planar *rwebm_video_stream_borrowed_planar(
      const rwebm_video_stream_t *stream);
unsigned rwebm_video_stream_planar_yuv(const rwebm_video_stream_t *stream);

/* Convert decoded frames in @bands row bands on @pool (an rthreads
 * tpool_t of at least bands - 1 threads; the calling thread takes one
 * band and joins the rest), and decode a VP9 frame's tile columns on
 * the same threads (rvp9_set_tile_pool). NULL or bands <= 1 keeps
 * everything on the calling thread. The pool is the caller's and must
 * outlive every decode call made while it is set. */
void rwebm_video_stream_set_blit_pool(rwebm_video_stream_t *stream,
      void *pool, unsigned bands);

/* Partial-read support: raise the number of leading buffer bytes that
 * are valid (monotonic).  A blocked step resumes once the needed
 * block's bytes are inside the window; fully-resident streams never
 * block. */
void rwebm_video_stream_set_avail(rwebm_video_stream_t *stream,
      size_t avail);

/* Bounded-memory streaming support: media_floor is the fixed byte
 * offset where the cluster data begins (nothing below it is ever
 * read); consumed is the earliest byte still needed by pending packets
 * or laces.  Together they bound the window a feeder must keep
 * resident: [media_floor, consumed + lookahead). */
size_t rwebm_video_stream_media_floor(rwebm_video_stream_t *stream);
size_t rwebm_video_stream_consumed(rwebm_video_stream_t *stream);
/* Read demand may lead the release frontier while a coded packet is held
 * for timestamp lookahead. A window owner pins the returned encoded span
 * before moving to the demand frontier; prefix owners retain consumed(). */
size_t rwebm_video_stream_feed_frontier(rwebm_video_stream_t *stream);
void rwebm_video_stream_pin_span(rwebm_video_stream_t *stream,
      size_t *lo, size_t *hi);
/* Exclusively owned feeder query: pending complete element, not a release
 * frontier. Keep the normal per-poll I/O budget while admitting its span. */
void rwebm_video_stream_read_span(rwebm_video_stream_t *stream,
      size_t *lo, size_t *hi);

/* Container duration in nanoseconds, 0 when the file does not say. */
int64_t rwebm_video_stream_duration_ns(rwebm_video_stream_t *stream);

/* For a stream adopted from a still decoded against a partial read:
 * once the whole file is in the buffer, finish the timestamp
 * pre-scan the partial open truncated at its byte wall, making every
 * per-frame duration identical to a stream opened over the complete
 * file (a wall-truncated table otherwise paces frames past it by a
 * single-interval estimate - for ms-rounded 30 fps content, a
 * constant 33 where the true cadence alternates 33/34, i.e. a third
 * of a millisecond of drift per frame until the table's cap).
 * A bounded, header-only walk of at most the table cap's packets. */
void rwebm_video_stream_complete_scan(rwebm_video_stream_t *stream,
      const uint8_t *buf, size_t len);

/* Last advance exhausted input and drained output without failure. */
int rwebm_video_stream_completed(const rwebm_video_stream_t *stream);

void rwebm_video_stream_rewind(rwebm_video_stream_t *stream);

/* Owner-thread seek. Begin selects a cue (or rewinds without
 * one); each step reads <=256 headers or decodes one packet. Step is
 * -1 failure, 0 retry/feed consumed(), 1 target ready for next(). The
 * first video packet at or after ns is retained without decoding.
 * New begin/rewind cancels. AV1 hardware preroll yields on backpressure
 * or after at most 32 stream steps / 4 ms. VP9 hardware preroll decodes
 * one packet per step and retains submission state across backpressure. */
/* Query only while the stream is exclusively owned, before publishing a
 * playback session. AV1 requires an admitted hardware decoder. */
int64_t rwebm_video_stream_start_ns(const rwebm_video_stream_t *stream);
/* Last displayed packet timestamp, on the exclusive decode owner;
 * -1 before a picture or after rewind. Hidden packets do not advance it. */
int64_t rwebm_video_stream_frame_time_ns(const rwebm_video_stream_t *stream);
/* Movie coordinates preserve requested positions in leading/tail video
 * intervals; the raw bounded seek APIs remain unchanged. */
int rwebm_video_stream_seek_movie_begin_ns(rwebm_video_stream_t *stream, int64_t ns);
int rwebm_video_stream_seek_movie_step(rwebm_video_stream_t *stream,
      int64_t *position_us);
/* Format capability is available before native admission. The seek itself
 * still requires an admitted decoder on the exclusive stream owner. */
int rwebm_video_stream_seekable(const rwebm_video_stream_t *stream);
int rwebm_video_stream_seek_begin_ns(rwebm_video_stream_t *stream, int64_t ns);
int rwebm_video_stream_seek_span(rwebm_video_stream_t *stream,
      size_t *lo, size_t *hi);
int rwebm_video_stream_seek_step(rwebm_video_stream_t *stream,
      int64_t *position_us);


RETRO_END_DECLS

#endif
