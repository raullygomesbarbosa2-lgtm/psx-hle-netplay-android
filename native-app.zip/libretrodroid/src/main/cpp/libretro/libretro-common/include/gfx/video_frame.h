/* Copyright  (C) 2010-2020 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (video_frame.h).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#ifndef _LIBRETRO_SDK_VIDEO_FRAME_H
#define _LIBRETRO_SDK_VIDEO_FRAME_H

#include <stdint.h>
#include <stddef.h>
#include <limits.h>
#include <string.h>
#include <boolean.h>
#include <retro_common_api.h>
#include <retro_inline.h>

#include <gfx/scaler/scaler.h>

#include <libretro.h>

RETRO_BEGIN_DECLS

#define scaler_ctx_scale_direct(ctx, output, input) \
{ \
   if (ctx && ctx->unscaled && ctx->direct_pixconv) \
      /* Just perform straight pixel conversion. */ \
      ctx->direct_pixconv(output, input, \
            ctx->out_width,  ctx->out_height, \
            ctx->out_stride, ctx->in_stride); \
   else \
      scaler_ctx_scale(ctx, output, input); \
}

static INLINE void video_frame_convert_rgb16_to_rgb32(
      struct scaler_ctx *scaler,
      void *output,
      const void *input,
      int width, int height,
      int in_pitch)
{
   if (width != scaler->in_width || height != scaler->in_height)
   {
      scaler->in_width    = width;
      scaler->in_height   = height;
      scaler->out_width   = width;
      scaler->out_height  = height;
      scaler->in_fmt      = SCALER_FMT_RGB565;
      scaler->out_fmt     = SCALER_FMT_ARGB8888;
      scaler->scaler_type = SCALER_TYPE_POINT;
      scaler_ctx_gen_filter(scaler);
   }

   scaler->in_stride  = in_pitch;
   scaler->out_stride = width * sizeof(uint32_t);

   scaler_ctx_scale_direct(scaler, output, input);
}

static INLINE void video_frame_scale(
      struct scaler_ctx *scaler,
      void *output,
      const void *input,
      enum scaler_pix_fmt format,
      unsigned scaler_width,
      unsigned scaler_height,
      unsigned scaler_pitch,
      unsigned width,
      unsigned height,
      unsigned pitch)
{
   if (
            width  != (unsigned)scaler->in_width
         || height != (unsigned)scaler->in_height
         || format != scaler->in_fmt
         || pitch  != (unsigned)scaler->in_stride
      )
   {
      scaler->in_fmt    = format;
      scaler->in_width  = width;
      scaler->in_height = height;
      scaler->in_stride = pitch;

      scaler->out_width  = scaler_width;
      scaler->out_height = scaler_height;
      scaler->out_stride = scaler_pitch;

      scaler_ctx_gen_filter(scaler);
   }

   scaler_ctx_scale_direct(scaler, output, input);
}

static INLINE void video_frame_record_scale(
      struct scaler_ctx *scaler,
      void *output,
      const void *input,
      unsigned scaler_width,
      unsigned scaler_height,
      unsigned scaler_pitch,
      unsigned width,
      unsigned height,
      unsigned pitch,
      bool bilinear)
{
   if (
            width  != (unsigned)scaler->in_width
         || height != (unsigned)scaler->in_height
      )
   {
      scaler->in_width    = width;
      scaler->in_height   = height;
      scaler->in_stride   = pitch;

      scaler->scaler_type = bilinear ?
         SCALER_TYPE_BILINEAR : SCALER_TYPE_POINT;

      scaler->out_width  = scaler_width;
      scaler->out_height = scaler_height;
      scaler->out_stride = scaler_pitch;

      scaler_ctx_gen_filter(scaler);
   }

   scaler_ctx_scale_direct(scaler, output, input);
}

static INLINE void video_frame_convert_argb8888_to_abgr8888(
      struct scaler_ctx *scaler,
      void *output, const void *input,
      int width, int height, int in_pitch)
{
   if (width != scaler->in_width || height != scaler->in_height)
   {
      scaler->in_width    = width;
      scaler->in_height   = height;
      scaler->out_width   = width;
      scaler->out_height  = height;
      scaler->in_fmt      = SCALER_FMT_ARGB8888;
      scaler->out_fmt     = SCALER_FMT_ABGR8888;
      scaler->scaler_type = SCALER_TYPE_POINT;
      scaler_ctx_gen_filter(scaler);
   }

   scaler->in_stride  = in_pitch;
   scaler->out_stride = width * sizeof(uint32_t);

   scaler_ctx_scale_direct(scaler, output, input);
}

static INLINE bool video_frame_convert_to_bgr24(
      struct scaler_ctx *scaler,
      void *output, const void *input,
      int in_width, int in_height, int in_pitch,
      int out_width, int out_height, int out_pitch)
{
   if (in_width <= 0 || in_height <= 0 || out_width <= 0
         || out_height <= 0 || out_width > INT_MAX / 3)
      return false;

   /* Sample and convert in one pass; thumbnails need no full-size ARGB copy. */
   if (in_width >= out_width && in_height >= out_height
         && (in_width != out_width || in_height != out_height)
         && (scaler->in_fmt == SCALER_FMT_ARGB8888
            || scaler->in_fmt == SCALER_FMT_RGB565
            || scaler->in_fmt == SCALER_FMT_BGR24))
   {
      int y, x;
      int64_t x_step = ((int64_t)in_width << 16) / out_width;
      int64_t y_step = ((int64_t)in_height << 16) / out_height;
      /* the sample nearest each output pixel's centre, as the point
       * scaler picks */
      int64_t x_start = ((int64_t)in_width << 15) / out_width;
      int64_t y_pos = ((int64_t)in_height << 15) / out_height;
      unsigned bpp = scaler->in_fmt == SCALER_FMT_RGB565 ? 2
         : (scaler->in_fmt == SCALER_FMT_BGR24 ? 3 : 4);
      for (y = 0; y < out_height; y++, y_pos += y_step)
      {
         uint8_t *dst = (uint8_t*)output + (ptrdiff_t)y * out_pitch;
         const uint8_t *row = (const uint8_t*)input
            + (ptrdiff_t)(y_pos >> 16) * in_pitch;
         int64_t x_pos = x_start;
         for (x = 0; x < out_width; x++, x_pos += x_step)
         {
            const uint8_t *src = row + (size_t)(x_pos >> 16) * bpp;
            if (scaler->in_fmt == SCALER_FMT_RGB565)
            {
               uint16_t pixel;
               memcpy(&pixel, src, sizeof(pixel));
               dst[3 * x + 0] = (uint8_t)((pixel & 31) << 3) | (pixel & 31) >> 2;
               dst[3 * x + 1] = (uint8_t)(((pixel >> 5) & 63) << 2)
                  | ((pixel >> 5) & 63) >> 4;
               dst[3 * x + 2] = (uint8_t)((pixel >> 11) << 3) | (pixel >> 11) >> 2;
            }
            else if (scaler->in_fmt == SCALER_FMT_ARGB8888)
            {
               uint32_t pixel;
               memcpy(&pixel, src, sizeof(pixel));
               dst[3 * x + 0] = (uint8_t)pixel;
               dst[3 * x + 1] = (uint8_t)(pixel >> 8);
               dst[3 * x + 2] = (uint8_t)(pixel >> 16);
            }
            else
               memcpy(dst + 3 * x, src, 3);
         }
      }
      return true;
   }

   scaler->in_width    = in_width;
   scaler->in_height   = in_height;
   scaler->out_width   = out_width;
   scaler->out_height  = out_height;

   scaler->out_fmt     = SCALER_FMT_BGR24;
   scaler->scaler_type = SCALER_TYPE_POINT;

   if (!scaler_ctx_gen_filter(scaler))
      return false;

   scaler->in_stride   = in_pitch;
   scaler->out_stride  = out_pitch;

   scaler_ctx_scale_direct(scaler, output, input);
   return true;
}

static INLINE void video_frame_convert_rgba_to_bgr(
      const void *src_data,
      void *dst_data,
      unsigned src_pitch,
      unsigned dst_pitch,
      unsigned width,
      unsigned height)
{
   unsigned x, y;
   uint8_t       *dst = (uint8_t*)dst_data;
   const uint8_t *src = (const uint8_t*)src_data;

   for (y = 0; y < height; y++, dst += dst_pitch, src += src_pitch)
   {
      uint8_t       *d = dst;
      const uint8_t *s = src;
      for (x = 0; x < width; x++, d += 3, s += 4)
      {
         d[0] = s[2];
         d[1] = s[1];
         d[2] = s[0];
      }
   }
}

/* Copy w x h 32-bit pixels into a dst_w x dst_h buffer of B,G,R,X
 * bytes with a row pitch of dst_w * 4, keeping the source row order.
 * src_rgba: source bytes are R,G,B,A and are swapped; otherwise they
 * are already B,G,R,A/X and rows are copied as-is. Anything outside
 * the w x h source region is cleared to black. */
static INLINE void video_frame_copy_to_bgrx(
      uint8_t *dst, unsigned dst_w, unsigned dst_h,
      const uint8_t *src, size_t src_pitch,
      unsigned w, unsigned h, bool src_rgba)
{
   unsigned x, y;

   if (w > dst_w)
      w = dst_w;
   if (h > dst_h)
      h = dst_h;
   if (w < dst_w || h < dst_h)
      memset(dst, 0, (size_t)dst_w * dst_h * 4);

   for (y = 0; y < h; y++, dst += (size_t)dst_w * 4, src += src_pitch)
   {
      if (!src_rgba)
         memcpy(dst, src, (size_t)w * 4);
      else
         for (x = 0; x < w; x++)
         {
            dst[4 * x + 0] = src[4 * x + 2];
            dst[4 * x + 1] = src[4 * x + 1];
            dst[4 * x + 2] = src[4 * x + 0];
            dst[4 * x + 3] = 0xff;
         }
   }
}

static INLINE void video_pixel_frame_scale(
      struct scaler_ctx *scaler,
      void *output, const void *data,
      unsigned width, unsigned height,
      size_t pitch)
{
   scaler->in_width      = width;
   scaler->in_height     = height;
   scaler->out_width     = width;
   scaler->out_height    = height;
   scaler->in_stride     = (int)pitch;
   scaler->out_stride    = width * sizeof(uint16_t);
   scaler_ctx_scale_direct(scaler, output, data);
}

RETRO_END_DECLS

#endif
