/* Copyright  (C) 2010-2020 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (audio_mixer.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* audio_mixer -- fixed-voice sound-effect and music mixer.
 * <audio/audio_mixer.h> declares the API.
 *
 * The model: a sound is loaded once from a memory buffer
 * (audio_mixer_load_wav / _ogg / _flac / _mp3 / _m4a / _opus / _weba /
 * _mod, each present when its codec is built in), then played on one
 * of AUDIO_MIXER_MAX_VOICES voices with a volume, an optional repeat,
 * and a stop callback; audio_mixer_mix and audio_mixer_mix_s16 fold
 * every live voice into the frontend's output block at the rate given
 * to audio_mixer_init, resampling each voice from its source rate.
 * Sounds are shared and immutable; voices hold the playback state.
 *
 * Two voice pipelines, kept apart on purpose.  audio_mixer_play makes
 * a float voice mixed by audio_mixer_mix; audio_mixer_play_s16 makes a
 * fixed-point voice, resampled by the integer sinc resampler (quality
 * mapped by the resampler layer) and mixed with integer gain and
 * saturation by audio_mixer_mix_s16.  Nothing is decoded in one
 * pipeline and converted into the other - a WAV sound keeps its source
 * bytes so either pipeline builds from the original, and frame counts
 * are tracked per pipeline because the two resamplers need not agree
 * to the sample.  audio_mixer_has_float_voices lets the frontend skip
 * the float mix entirely when nothing needs it.
 *
 * WAV plays from a decoded buffer (or streams, via load_wav_stream);
 * every compressed format streams: those voices pull PCM through
 * audio_transfer in AUDIO_MIXER_TEMP_BUFFER-sized blocks as the mix
 * consumes it, which is also where repeat is implemented - a loop is
 * audio_transfer_seek back to the first frame, not a reload.  Sounds
 * can borrow their compressed bytes from a larger owned object
 * (data_owner/data_release) instead of copying, and windowed sources -
 * a file still arriving - bound the header parse with the resident
 * byte count and, for Ogg-Opus, the injected end granule, with
 * multichannel sources folded to stereo by the downmix tables.
 *
 * Voices are claimed and released from mixer and caller threads
 * through a per-voice owner word (a lock only where the atomics are
 * the volatile fallback), and stop callbacks run outside it. */

#ifdef HAVE_CONFIG_H
#include "../../config.h"
#endif

#include <audio/audio_mixer.h>
#include <audio/audio_resampler.h>

#ifdef HAVE_RWAV
#include <formats/rwav.h>
#endif
#include <memalign.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

/* Which builds have stream voices - the shared play/mix/release path
 * over audio_transfer - asked in one place rather than spelled out at
 * each of the six sites that need it.  WAV joined the set when it
 * gained a streaming sound type, and a console build carrying WAV and
 * no compressed codec is exactly the configuration that finds a site
 * left behind. */
#if defined(HAVE_RWAV) || defined(HAVE_RVORBIS) || defined(HAVE_RFLAC) \
 || defined(HAVE_RMP3) || defined(HAVE_RMODTRACKER) || defined(HAVE_RAAC) \
 || defined(HAVE_ROPUS) || (defined(HAVE_RAC3) || defined(HAVE_RWMA))
#define AUDIO_MIXER_HAS_STREAM 1
#include <formats/audio.h>
#ifdef HAVE_RLPCM
#include <formats/rlpcm.h>
#endif
#endif



#include <retro_atomic.h>

/* A voice has one owner at a time: the mix while it decodes and mixes
 * it, or a caller while it plays or stops it. Ownership is one word,
 * taken with a compare-and-swap. The mix never waits for it - a voice
 * a caller holds is being built or torn down and is passed over - and
 * a caller waits only for the pass in progress on that voice. Only a
 * backend whose compare-and-swap is not atomic (the volatile one)
 * keeps a lock per voice; the PS2's interrupt-masked one is atomic. */
#ifdef HAVE_THREADS
#include <rthreads/rthreads.h>
#if defined(RETRO_ATOMIC_LOCK_FREE) || defined(RETRO_ATOMIC_BACKEND_PS2)
#include <rthreads/retro_eventcount.h>
#define AUDIO_MIXER_VOICE_OWNERSHIP
#endif
#endif

#define AUDIO_MIXER_MAX_VOICES      8
#define AUDIO_MIXER_TEMP_BUFFER 8192

/* A stream voice's decode scratch and resampled buffer come out of one
 * 64-byte aligned block: the scratch first, then one 64-byte pad, then
 * the buffer. The scratch is exactly 32 KiB in the float path and 16
 * KiB in the s16 path, so without the pad the two would be a multiple
 * of 4 KiB apart and the resampler, which reads one while writing the
 * other, would stall on low-address-bit aliasing. Element counts. */
#define AUDIO_MIXER_STREAM_BUF_OFFSET(elem_size) \
   (AUDIO_MIXER_TEMP_BUFFER + 64 / (elem_size))

struct audio_mixer_sound
{
   enum audio_mixer_type type;
   unsigned tag;

   union
   {
      struct
      {
         /* wav */
         const float* pcm;
         const int16_t* pcm_s16;
         /* Frame counts are kept per pipeline. The float and the
          * fixed-point resampler each report what they actually
          * produced, and nothing guarantees the two agree to the
          * sample; one shared count would let the s16 mixer read past
          * the end of a shorter buffer. */
         unsigned frames;
         unsigned frames_s16;
#ifdef HAVE_RWAV
         /* The WAV's own sample bytes, owned by the sound. Kept so
          * that whichever pipeline is asked for can be built from the
          * source, rather than derived from the other pipeline's
          * finished output - an s16 voice must never end up playing
          * audio that was resampled in float and quantised after. */
         uint8_t* src;
         rwav_t   hdr;
#endif
      } wav;

#ifdef AUDIO_MIXER_HAS_STREAM
      struct
      {
         /* shared streaming source (WAV / OGG / FLAC / MP3 / ...) */
         const void* data;
         /* size_t, not unsigned: a windowed container is the whole
          * file's length, and a 7 GB one truncated to 32 bits became
          * 3.5 GB - the demuxer then treated every sample past that
          * as out of range and the stream ended seconds in. */
         size_t size;
      } stream;
#endif


   } types;
   /* Borrowed compressed data: when owner is set, destroy releases
    * the source through release(owner) instead of free()ing it -
    * the load's caller lent the bytes from inside a larger owned
    * object (a file mapping, a data_transfer) and no copy was made. */
   void  *data_owner;
   void (*data_release)(void *owner);
   /* Windowed Ogg-Opus: the last-page granule supplied by the feeder,
    * injected into the decoder at play so it skips the full-file end
    * scan.  0 = not supplied (normal full scan). */
   int64_t end_granule;
   /* Windowed sources: bytes resident from the start of the buffer at
    * play time, bounding the decoder's header parse.  0 = all of it. */
   size_t avail;
#ifdef AUDIO_MIXER_HAS_STREAM
   void *prepared_transfer;
   enum audio_type_enum prepared_type;
   unsigned prepared_rate;
   unsigned container_track; /* zero: automatic; otherwise demux index + 1 */
   bool prepared_s16;
#endif
   bool initial_paused;
};

struct audio_mixer_voice
{
   struct
   {
      struct
      {
         unsigned position;
      } wav;

#ifdef AUDIO_MIXER_HAS_STREAM
      /* Shared streaming voice state (WAV / OGG / FLAC / MP3). The codec is
       * identified by voice->type and passed to audio_transfer as an
       * enum audio_type_enum; the bookkeeping is identical across them. */
      struct
      {
         void       *stream;
         void       *resampler_data;
         const retro_resampler_t *resampler;
         float      *buffer;
         /* Decode scratch for the float mix path.  Owned by the voice
          * because the mix runs on the audio thread, where a malloc is
          * a stall waiting to happen. */
         float      *decode_buf;
         unsigned    position;
         unsigned    samples;
         unsigned    buf_samples;
         unsigned    channels;    /* source channels; mono is duplicated */
#ifdef HAVE_RWMA
         int32_t     wma_matrix[8][2];
#endif
         /* Both resampler APIs take the ratio as a double, and the s16
          * path computes it as one. Holding it as a float here meant
          * that value was narrowed on the way in and widened again on
          * the way out, losing precision for nothing. The float path
          * computes a float and widens exactly, so it is unaffected. */
         double      ratio;
         /* s16 pipeline (parallel; used when voice->is_s16) */
         int16_t    *buffer_s16;
         /* Decode scratch, mirroring decode_buf above.  This lived on
          * the mix function's stack as int16_t[AUDIO_MIXER_TEMP_BUFFER]
          * (16 KB): a third of a 48 KB L1d evicted per voice per flush,
          * and past the stack-probe threshold on Windows, so every call
          * paid a chkstk page walk before doing any work. */
         int16_t    *decode_buf_s16;
         retro_resampler_int16_t resampler_int16;
      } stream;
#endif


   } types;
   audio_mixer_sound_t *sound;
   audio_mixer_stop_cb_t stop_cb;
   /* Which codec the voice carries, AUDIO_MIXER_TYPE_NONE when idle.
    * Published with a release store when a voice is claimed and cleared
    * the same way once it is released, so the mix loops and the voice
    * counts can test a voice for idle without owning it. Every
    * read that goes on to touch the rest of the voice owns it first
    * and reads this again then. */
   retro_atomic_int_t type;
   /* volume drives the float pipeline, gain the s16 one. They are held
    * separately rather than converted on demand so that an s16 voice
    * never needs a float operation on the audio thread. Atomic, so a
    * caller sets or reads either with no lock while the voice mixes:
    * volume holds the float's bits, gain the Q16.16 value. */
   retro_atomic_int_t volume;
   retro_atomic_int_t gain;
   /* A transport pause preserves decoder, resampler and buffered PCM.
    * The owner requests it; the mixer samples it once per block. */
   retro_atomic_int_t paused;
   retro_atomic_int_t repeat;
   size_t mixed_frames;              /* mix owner's, modulo SIZE_MAX+1 */
   retro_atomic_size_t clock_frames; /* published output-frame count */
   retro_atomic_int_t clock_rate;    /* output Hz, fixed for this play */
   retro_atomic_size_t clock_serial; /* unique play, zero while reset */
   /* What a windowed source's feeder exchanges with the mix, without
    * owning the voice. tell is the decoder's byte position as of the last mix
    * and lap counts the stream's start and its rewinds; avail_req is
    * the resident bound the feeder wants, applied before the next
    * decode. A bound carries the lap its position was read in and is
    * dropped once the decoder has rewound: the bytes it promised may
    * be gone. Lap 0 is a bound not derived from a position, -1 none. */
   retro_atomic_size_t tell;
   retro_atomic_size_t read_end; /* complete encoded element requested */
   retro_atomic_int_t  lap;
   retro_atomic_size_t avail_req;
   retro_atomic_size_t avail_serial; /* the play a bound belongs to */
   retro_atomic_int_t  avail_lap;
   retro_atomic_int_t  feeder_lap;   /* the lap the feeder last read */
   size_t   avail_done;              /* the mix's: the bound it applied */
   int      avail_done_lap;
   bool     avail_done_valid;
   bool     is_s16;
#if defined(AUDIO_MIXER_VOICE_OWNERSHIP)
   retro_atomic_int_t owner;    /* AUDIO_MIXER_VOICE_* */
#elif defined(HAVE_THREADS)
   slock_t *lock;
#endif
};

/* TODO/FIXME - static globals */
static struct audio_mixer_voice s_voices[AUDIO_MIXER_MAX_VOICES];
/* Not reset by audio_mixer_init/done: an old session must recognize a
 * new play even when the same voice and output rate are reused. */
static retro_atomic_size_t s_clock_serial = { 0 };

#if defined(AUDIO_MIXER_VOICE_OWNERSHIP)
#define AUDIO_MIXER_VOICE_FREE   0
#define AUDIO_MIXER_VOICE_HELD   1
#define AUDIO_MIXER_VOICE_WANTED 2   /* held, and a caller is parked */

/* What a caller waiting for a voice parks on. Only a voice marked
 * wanted is notified as it is let go, so the mix's passes reach no
 * eventcount - nor, where its bookkeeping is locked, its lock. */
static retro_eventcount_t s_voice_ec;
static bool               s_voice_ec_ok;

/* The mix's: false when a caller holds the voice. */
static bool audio_mixer_voice_try_own(audio_mixer_voice_t *voice)
{
   return retro_atomic_cas_int(&voice->owner,
         AUDIO_MIXER_VOICE_FREE, AUDIO_MIXER_VOICE_HELD);
}

/* A caller's: waits out the pass, or the other caller, that has it.
 * A notify wakes every caller parked, and each marks the voice again
 * before it parks; taken after a wait it is left marked, which costs
 * at most one notify. */
static void audio_mixer_voice_own(audio_mixer_voice_t *voice)
{
   if (retro_atomic_cas_int(&voice->owner,
            AUDIO_MIXER_VOICE_FREE, AUDIO_MIXER_VOICE_HELD))
      return;
   while (retro_atomic_exchange_int(&voice->owner, AUDIO_MIXER_VOICE_WANTED)
         != AUDIO_MIXER_VOICE_FREE)
   {
      int key;
      if (!s_voice_ec_ok)
      {
         sthread_yield();
         continue;
      }
      key = retro_eventcount_prepare_wait(&s_voice_ec);
      if (retro_atomic_load_acquire_int(&voice->owner)
            == AUDIO_MIXER_VOICE_WANTED)
         retro_eventcount_commit_wait(&s_voice_ec, key);
      else
         retro_eventcount_cancel_wait(&s_voice_ec);
   }
}

static void audio_mixer_voice_disown(audio_mixer_voice_t *voice)
{
   if (     retro_atomic_exchange_int(&voice->owner, AUDIO_MIXER_VOICE_FREE)
         == AUDIO_MIXER_VOICE_WANTED
         && s_voice_ec_ok)
      retro_eventcount_notify(&s_voice_ec);
}
#elif defined(HAVE_THREADS)
static bool audio_mixer_voice_try_own(audio_mixer_voice_t *voice)
{
   return !voice->lock || slock_try_lock(voice->lock);
}

static void audio_mixer_voice_own(audio_mixer_voice_t *voice)
{
   slock_lock(voice->lock);
}

static void audio_mixer_voice_disown(audio_mixer_voice_t *voice)
{
   slock_unlock(voice->lock);
}
#else
#define audio_mixer_voice_try_own(voice) (true)
#define audio_mixer_voice_own(voice)     ((void)0)
#define audio_mixer_voice_disown(voice)  ((void)0)
#endif
static unsigned s_rate = 0;

static void audio_mixer_release(audio_mixer_voice_t* voice);

static INLINE int audio_mixer_float_bits(float f)
{
   int i;
   memcpy(&i, &f, sizeof(i));
   return i;
}

static INLINE float audio_mixer_bits_float(int i)
{
   float f;
   memcpy(&f, &i, sizeof(f));
   return f;
}

#ifdef AUDIO_MIXER_HAS_STREAM
/* ---- folding a multichannel stream to the stereo a voice mixes ------
 *
 * A voice mixes stereo, so anything wider is folded here - the arms
 * deliberately do no channel conversion.  The fold for each arm's
 * channel order is audio_transfer's (audio_transfer_fold_q15): Vorbis
 * and Opus in Vorbis order, the rest in WAVE order, WMA by its speaker
 * mask.  Q15 in int32; the s16 fold stays clear of float. */
static int16_t audio_mixer_sat_s16_64(int64_t v)
{
   if (v >  32767)
      return  32767;
   if (v < -32768)
      return -32768;
   return (int16_t)v;
}

/* Which order an arm hands its channels over in. */
static const int32_t (*audio_mixer_downmix_table(
      enum audio_type_enum type, unsigned ch, const audio_mixer_voice_t *voice))[2]
{
   (void)voice;
#ifdef HAVE_RWMA
   if (type == AUDIO_TYPE_WMA) return voice->types.stream.wma_matrix;
#endif
   return audio_transfer_fold_q15(type, ch);
}

/* Frames a temp buffer of 'samples' holds at 'ch' channels: what a
 * read may ask for, which is not the stereo figure once ch exceeds
 * two. */
static size_t audio_mixer_frames_for(unsigned ch, size_t samples)
{
   return ch ? samples / ch : 0;
}

/* Fold 'frames' interleaved frames of 'ch' channels down to stereo,
 * in place and ascending: the destination index never overtakes the
 * source while ch is at least two. */
static void audio_mixer_downmix_s16(int16_t *buf, size_t frames,
      unsigned ch, const int32_t (*co)[2])
{
   size_t i;
   for (i = 0; i < frames; i++)
   {
      /* 64-bit: a full-scale sample times unity is already 2^30, and
       * eight channels of it summed reaches 5.9e9 - an int32 would
       * wrap on loud surround rather than clamp. */
      int64_t  l = 0, r = 0;
      unsigned c;
      for (c = 0; c < ch; c++)
      {
         int32_t v = buf[i * ch + c];
         l += (int64_t)v * co[c][0];
         r += (int64_t)v * co[c][1];
      }
      /* Round half away from zero rather than truncating, which the
       * shift alone would do and which costs half an LSB of bias. */
      buf[2 * i]     = audio_mixer_sat_s16_64(
            (l >= 0 ? l + 16384 : l - 16384) >> 15);
      buf[2 * i + 1] = audio_mixer_sat_s16_64(
            (r >= 0 ? r + 16384 : r - 16384) >> 15);
   }
}

static void audio_mixer_downmix_f32(float *buf, size_t frames,
      unsigned ch, const int32_t (*co)[2])
{
   size_t i;
   for (i = 0; i < frames; i++)
   {
      float    l = 0.0f, r = 0.0f;
      unsigned c;
      for (c = 0; c < ch; c++)
      {
         float v = buf[i * ch + c];
         l += v * (float)co[c][0] * (1.0f / 32768.0f);
         r += v * (float)co[c][1] * (1.0f / 32768.0f);
      }
      buf[2 * i]     = l;
      buf[2 * i + 1] = r;
   }
}
#endif /* AUDIO_MIXER_HAS_STREAM */

#ifdef HAVE_RWAV
/* One sample of a WAV frame, whatever width the file stores, in the
 * unit scale the float pipeline mixes at.  Only the multichannel fold
 * below needs it; the one- and two-channel paths stay specialised. */
static float wav_sample_unit(const rwav_t *wav, const uint8_t *src,
      size_t frame, unsigned c)
{
   size_t         w = (size_t)wav->bitspersample / 8;
   const uint8_t *p = src + (frame * wav->numchannels + c) * w;
   switch (wav->bitspersample)
   {
      case 32:
         return rwav_f32(p);
      case 24:
         return rwav_s24_to_float(p);
      case 8:
         return ((float)*p - 128.0f) / 128.0f;
      default:
         return (float)rwav_s16(p) / 32768.0f;
   }
}

/* Fold a WAV of more than two channels straight to the stereo the
 * mixer wants.  Without this the converters below, which only know
 * one channel and two, leave the output buffer untouched - and it
 * comes from memalign_alloc, so what played was uninitialised memory
 * rather than even silence. */
static void wav_fold_to_stereo(const rwav_t *wav, const uint8_t *src,
      float *dst, size_t frames)
{
   const int32_t (*co)[2] = audio_transfer_fold_q15(AUDIO_TYPE_WAV, wav->numchannels);
   size_t i;
   for (i = 0; i < frames; i++)
   {
      float    l = 0.0f, r = 0.0f;
      unsigned c;
      for (c = 0; c < wav->numchannels; c++)
      {
         float v = wav_sample_unit(wav, src, i, c);
         l += v * (float)co[c][0] * (1.0f / 32768.0f);
         r += v * (float)co[c][1] * (1.0f / 32768.0f);
      }
      dst[2 * i]     = l;
      dst[2 * i + 1] = r;
   }
}

static bool wav_to_float(const rwav_t* wav, const uint8_t* src,
      float** pcm, size_t len)
{
   size_t i;
   /* Allocate on a 16-byte boundary, and pad to a multiple of 16 bytes */
   float *f           = (float*)memalign_alloc(16,
         ((len + 15) & ~15) * sizeof(float));

   if (!f)
      return false;

   *pcm = f;

   /* The companded and block-coded payloads are not readable a sample
    * at a time - rwav decodes those, natively to s16, and the fold or
    * the scale below works from that.  Everything else is read in
    * place as it always was. */
   if (wav->format != RWAV_FORMAT_PCM && wav->format != RWAV_FORMAT_FLOAT)
   {
      rwav_t   h   = *wav;
      int16_t *tmp;
      size_t   i, got;
      h.dataoffset = 0;
      if (wav->numchannels <= 2)
      {
         /* Decoded into the tail of the output itself, no scratch:
          * the s16 take a half (stereo) or a quarter (mono) of the
          * buffer's bytes, at its end, and the forward pass writes
          * each float at or before the bytes of every sample still
          * to be read.  Those are read through memcpy, a byte access,
          * so no float store can be ordered ahead of one. */
         size_t         n = wav->numsamples * wav->numchannels;
         const uint8_t *t = (const uint8_t*)(f + len) - n * sizeof(int16_t);
         int16_t        v;
         got = rwav_decode_s16(&h, src, 0, wav->numsamples,
               (int16_t*)t);
         if (wav->numchannels == 1)
            for (i = 0; i < got; i++)
            {
               memcpy(&v, t + i * sizeof(v), sizeof(v));
               f[2 * i]     = (float)v * (1.0f / 32768.0f);
               f[2 * i + 1] = f[2 * i];
            }
         else
            for (i = 0; i < got * 2; i++)
            {
               memcpy(&v, t + i * sizeof(v), sizeof(v));
               f[i] = (float)v * (1.0f / 32768.0f);
            }
         return true;
      }
      if (!(tmp = (int16_t*)malloc(wav->numsamples
            * wav->numchannels * sizeof(int16_t))))
      {
         memalign_free(f);
         *pcm = NULL;
         return false;
      }
      got = rwav_decode_s16(&h, src, 0, wav->numsamples, tmp);
      {
         const int32_t (*co)[2] =
               audio_transfer_fold_q15(AUDIO_TYPE_WAV, wav->numchannels);
         unsigned c;
         for (i = 0; i < got; i++)
         {
            float l = 0.0f, r = 0.0f;
            for (c = 0; c < wav->numchannels; c++)
            {
               float v = (float)tmp[i * wav->numchannels + c]
                       * (1.0f / 32768.0f);
               l += v * (float)co[c][0] * (1.0f / 32768.0f);
               r += v * (float)co[c][1] * (1.0f / 32768.0f);
            }
            f[2 * i]     = l;
            f[2 * i + 1] = r;
         }
      }
      free(tmp);
      return true;
   }

   /* More channels than the specialised paths below know: fold. */
   if (wav->numchannels > 2 && wav->numchannels <= 8)
   {
      wav_fold_to_stereo(wav, src, f, wav->numsamples);
      return true;
   }
   if (wav->numchannels < 1 || wav->numchannels > 8)
   {
      memalign_free(f);
      *pcm = NULL;
      return false;
   }

   /* Canonical PCM->float scaling, matching audio/conversion/s16_to_float
    * (s16 / 0x8000) and audio_mix's 8-bit path ((u8 - 128) / 128). The
    * previous (s + 32768) / 65535 * 2 - 1 mapping introduced a small
    * positive DC offset (0 -> +1.5e-5) and a non-canonical scale; using
    * the same factor as the rest of the pipeline keeps the mixer's float
    * representation consistent (and the result deterministic) across the
    * s16/float boundaries the voices are mixed and clamped at. The mono
    * channel-duplication below is why the audio/conversion helpers can't
    * be called verbatim here.
    *
    * src points into the caller's file bytes, so every read goes
    * through rwav.h's accessors rather than a typed pointer: the data
    * is little-endian whatever the host is, and a data chunk is only
    * guaranteed even-aligned. */
   if (wav->bitspersample == 32)
   {
      /* IEEE-float samples are already in the mixer's own unit scale:
       * pass them through (duplicating mono), converting nothing -
       * this is the quantisation-free path float producers target. */
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src += 4)
         {
            float sample = rwav_f32(src);
            *f++ = sample;
            *f++ = sample;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 8)
         {
            *f++ = rwav_f32(src);
            *f++ = rwav_f32(src + 4);
         }
      }
   }
   else if (wav->bitspersample == 8)
   {
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src++)
         {
            float sample = ((float)*src - 128.0f) * (1.0f / 128.0f);
            *f++         = sample;
            *f++         = sample;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 2)
         {
            *f++ = ((float)src[0] - 128.0f) * (1.0f / 128.0f);
            *f++ = ((float)src[1] - 128.0f) * (1.0f / 128.0f);
         }
      }
   }
   else if (wav->bitspersample == 24)
   {
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src += 3)
         {
            float sample = rwav_s24_to_float(src);
            *f++         = sample;
            *f++         = sample;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 6)
         {
            *f++ = rwav_s24_to_float(src);
            *f++ = rwav_s24_to_float(src + 3);
         }
      }
   }
   else
   {
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src += 2)
         {
            float sample = (float)rwav_s16(src) * (1.0f / 0x8000);
            *f++         = sample;
            *f++         = sample;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 4)
         {
            *f++ = (float)rwav_s16(src)     * (1.0f / 0x8000);
            *f++ = (float)rwav_s16(src + 2) * (1.0f / 0x8000);
         }
      }
   }

   return true;
}

static bool one_shot_resample(const float* in, size_t samples_in,
      unsigned rate, const char *resampler_ident, enum resampler_quality quality,
      float** out, size_t* samples_out)
{
   struct resampler_data info;
   void* data                         = NULL;
   const retro_resampler_t* resampler = NULL;
   float ratio;

   /* A zero on either side leaves nothing to resample toward: the
    * mixer has not been given its rate, or the source header claims
    * none. The resampler run on such a ratio emits frames the output
    * estimate never accounted for, past the end of the buffer. */
   if (!s_rate || !rate)
      return false;
   ratio = (double)s_rate / (double)rate;

   if (!retro_resampler_realloc(&data, &resampler,
         resampler_ident, quality, ratio))
      return false;

   /* Allocate on a 16-byte boundary, and pad to a multiple of 16 bytes.
    * The pad has to scale with the ratio: resampler->process reports
    * more output than the estimate below, and the excess grows with
    * upsampling, so a fixed pad is enough at 44.1->48 and not enough
    * at 8->96, where the clamp underneath silently took the tail back
    * off again. Ideally, audio resamplers should have a function to
    * return the number of samples they will output given a count of
    * input samples. */
   {
      size_t alloc_samples;
      size_t pad                      = 2 * (size_t)(ratio + 1.0) + 32;
      *samples_out                    = (size_t)(samples_in * ratio);
      alloc_samples                   = ((*samples_out + pad) + 15) & ~15;
      *out                            = (float*)memalign_alloc(16,
            alloc_samples * sizeof(float));

      if (*out == NULL)
         return false;

      info.data_in                    = in;
      info.data_out                   = *out;
      info.input_frames               = samples_in / 2;
      info.output_frames              = 0;
      info.ratio                      = ratio;

      resampler->process(data, &info);
      resampler->free(data);

      /* Take the count the resampler reports rather than the estimate
       * it was sized by.  The estimate truncates, so the last frames
       * the filter had to give were being left in the buffer and not
       * counted - a resampled sound ended a fraction early, and did not
       * match the same audio played through a stream voice, which does
       * hand them over.  The 16-sample pad above is what the overshoot
       * the comment describes lands in; clamp to it. */
      *samples_out                    = info.output_frames * 2;
      if (*samples_out > alloc_samples)
         *samples_out                 = alloc_samples;
   }
   return true;
}
#endif

void audio_mixer_init(unsigned rate)
{
   unsigned i;

   s_rate = rate;

   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++)
   {
      audio_mixer_voice_t *voice = &s_voices[i];

      retro_atomic_store_release_int(&voice->type, AUDIO_MIXER_TYPE_NONE);
#if !defined(AUDIO_MIXER_VOICE_OWNERSHIP) && defined(HAVE_THREADS)
      if (!voice->lock)
         voice->lock = slock_new();
#endif
   }
#if defined(AUDIO_MIXER_VOICE_OWNERSHIP)
   if (!s_voice_ec_ok)
   {
      if (retro_eventcount_init(&s_voice_ec))
         s_voice_ec_ok = true;
      else
         retro_eventcount_free(&s_voice_ec);
   }
#endif
}

void audio_mixer_done(void)
{
   unsigned i;

   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++)
   {
      audio_mixer_voice_t *voice = &s_voices[i];

      audio_mixer_voice_own(voice);
      audio_mixer_release(voice);
      audio_mixer_voice_disown(voice);
#if !defined(AUDIO_MIXER_VOICE_OWNERSHIP) && defined(HAVE_THREADS)
      slock_free(voice->lock);
      voice->lock = NULL;
#endif
   }
#if defined(AUDIO_MIXER_VOICE_OWNERSHIP)
   if (s_voice_ec_ok)
   {
      s_voice_ec_ok = false;
      retro_eventcount_free(&s_voice_ec);
   }
#endif
}

/* --------------------------------------------------------------------------
 * Fixed-point (s16) mixer pipeline.
 *
 * A full parallel to the float pipeline above: voices decode straight to
 * int16, resample with the deterministic integer SINC resampler, and are
 * summed with saturation into an int16 output buffer. Nothing crosses
 * between the two pipelines, so neither incurs an int16<->float round-trip.
 * ------------------------------------------------------------------------ */

static int16_t audio_mixer_sat_s16(int32_t v)
{
   if (v >  32767)
      return  32767;
   if (v < -32768)
      return -32768;
   return (int16_t)v;
}

/* Apply a Q16 gain to an s16 sample, rounding half away from zero and
 * accumulating in 64 bits (matches the fixed-point volume applied on the
 * core int16 audio path in audio_driver_flush).
 *
 * The product must not be accumulated in int32: voice volume ranges over
 * -80..+12 dB, so gain_q16 reaches 260904, and 32768 * 260904 needs 34
 * bits. Anything above 0 dB overflows on loud input and wraps to the
 * wrong sign, turning peaks into clicks rather than clamping them.
 *
 * Rounding rather than truncating halves the quantisation error and
 * mirrors the bias across the sign, which keeps the transform
 * odd-symmetric and therefore DC-free on symmetric signals. */
static int32_t audio_mixer_gain_s16(int16_t s, int32_t gain_q16)
{
   int64_t p = (int64_t)s * gain_q16;
   return (int32_t)((p >= 0)
         ?  ((  p + 0x8000) >> 16)
         : -(((-p + 0x8000) >> 16)));
}

#ifdef AUDIO_MIXER_HAS_STREAM
/* Only the WAV and streaming s16 resample paths consult this; a MOD-only or
 * no-codec build would otherwise flag it as unused. */
#endif

#ifdef HAVE_RWAV
static bool wav_to_s16(const rwav_t* wav, const uint8_t* src,
      int16_t** pcm, size_t len)
{
   size_t i;
   /* Allocate on a 16-byte boundary, and pad to a multiple of 16 bytes */
   int16_t *s = (int16_t*)memalign_alloc(16,
         ((len + 15) & ~15) * sizeof(int16_t));

   if (!s)
      return false;

   *pcm = s;

   /* The companded and block-coded payloads are not readable a sample
    * at a time - rwav decodes those, natively to s16.  The header is
    * copied with its data offset zeroed because the caller hands over
    * the payload alone, not the file it came from. */
   if (wav->format != RWAV_FORMAT_PCM && wav->format != RWAV_FORMAT_FLOAT)
   {
      rwav_t   h   = *wav;
      int16_t *tmp;
      size_t   i, got;
      h.dataoffset = 0;
      if (wav->numchannels <= 2)
      {
         /* Decoded straight into the output, no scratch: stereo is
          * already its layout, and mono lands in the first half and
          * is spread out from the end, each pair written at or past
          * the sample it is read from. */
         got = rwav_decode_s16(&h, src, 0, wav->numsamples, s);
         if (wav->numchannels == 1)
            for (i = got; i-- > 0; )
            {
               int16_t v    = s[i];
               s[2 * i]     = v;
               s[2 * i + 1] = v;
            }
         return true;
      }
      if (!(tmp = (int16_t*)malloc(wav->numsamples
            * wav->numchannels * sizeof(int16_t))))
      {
         memalign_free(s);
         *pcm = NULL;
         return false;
      }
      got = rwav_decode_s16(&h, src, 0, wav->numsamples, tmp);
      {
         const int32_t (*co)[2] =
               audio_transfer_fold_q15(AUDIO_TYPE_WAV, wav->numchannels);
         unsigned c;
         for (i = 0; i < got; i++)
         {
            int64_t l = 0, r = 0;
            for (c = 0; c < wav->numchannels; c++)
            {
               int32_t v = tmp[i * wav->numchannels + c];
               l += (int64_t)v * co[c][0];
               r += (int64_t)v * co[c][1];
            }
            s[2 * i]     = audio_mixer_sat_s16_64(
                  (l >= 0 ? l + 16384 : l - 16384) >> 15);
            s[2 * i + 1] = audio_mixer_sat_s16_64(
                  (r >= 0 ? r + 16384 : r - 16384) >> 15);
         }
      }
      free(tmp);
      return true;
   }

   /* See wav_to_float: more channels than the paths below know about
    * get folded, and a count no fold covers fails rather than leaving
    * the buffer as memalign_alloc left it. */
   if (wav->numchannels > 2 && wav->numchannels <= 8)
   {
      size_t   i2;
      unsigned c;
      const int32_t (*co)[2] =
            audio_transfer_fold_q15(AUDIO_TYPE_WAV, wav->numchannels);
      for (i2 = 0; i2 < wav->numsamples; i2++)
      {
         int64_t l = 0, r = 0;
         for (c = 0; c < wav->numchannels; c++)
         {
            int32_t v = (int32_t)(wav_sample_unit(wav, src, i2, c)
                  * 32768.0f);
            l += (int64_t)v * co[c][0];
            r += (int64_t)v * co[c][1];
         }
         s[2 * i2]     = audio_mixer_sat_s16_64(
               (l >= 0 ? l + 16384 : l - 16384) >> 15);
         s[2 * i2 + 1] = audio_mixer_sat_s16_64(
               (r >= 0 ? r + 16384 : r - 16384) >> 15);
      }
      return true;
   }
   if (wav->numchannels < 1 || wav->numchannels > 8)
   {
      memalign_free(s);
      *pcm = NULL;
      return false;
   }

   /* Native s16 conversion (no float detour). 16-bit samples are taken
    * verbatim; 8-bit unsigned samples are centered and scaled to s16
    * ((u8 - 128) * 256, i.e. the same magnitude as wav_to_float's
    * (u8 - 128) / 128 mapped to full scale - a multiply rather than a
    * shift because the centered value is negative for half the input
    * range and shifting a negative left is undefined); 24-bit is
    * rounded through
    * the shared accessor; mono is duplicated to stereo, matching
    * wav_to_float's channel handling. Only a float source brings float
    * into this path.
    *
    * src points into the caller's file bytes, so the reads go through
    * rwav.h's accessors: little-endian whatever the host is, and a data
    * chunk is only guaranteed even-aligned. */
   if (wav->bitspersample == 32)
   {
      /* float source on the float-free voice path: the one place a
       * float wav is quantised, rounded and saturated in the float
       * domain (casting out-of-range or non-finite values is
       * undefined; non-finite pins to zero). */
      size_t n = wav->numsamples * ((wav->numchannels == 2) ? 2 : 1);
      int16_t *d = s;

      for (i = 0; i < n; i++)
      {
         float v = rwav_f32(src + i * 4) * 32768.0f;
         int16_t q;
         if (!(v > -1e9f && v < 1e9f))
            v = 0.0f;
         v += (v >= 0.0f) ? 0.5f : -0.5f;
         if (v >  32767.0f) v =  32767.0f;
         if (v < -32768.0f) v = -32768.0f;
         q = (int16_t)(int)v;
         if (wav->numchannels == 1)
         {
            *d++ = q;
            *d++ = q;
         }
         else
            *d++ = q;
      }
   }
   else if (wav->bitspersample == 8)
   {
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src++)
         {
            int16_t v = (int16_t)(((int)*src - 128) * 256);
            *s++      = v;
            *s++      = v;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 2)
         {
            *s++ = (int16_t)(((int)src[0] - 128) * 256);
            *s++ = (int16_t)(((int)src[1] - 128) * 256);
         }
      }
   }
   else if (wav->bitspersample == 24)
   {
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src += 3)
         {
            int16_t v = rwav_s24_to_s16(src);
            *s++      = v;
            *s++      = v;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 6)
         {
            *s++ = rwav_s24_to_s16(src);
            *s++ = rwav_s24_to_s16(src + 3);
         }
      }
   }
   else
   {
      if (wav->numchannels == 1)
      {
         for (i = wav->numsamples; i != 0; i--, src += 2)
         {
            int16_t v = rwav_s16(src);
            *s++      = v;
            *s++      = v;
         }
      }
      else if (wav->numchannels == 2)
      {
         for (i = wav->numsamples; i != 0; i--, src += 4)
         {
            *s++ = rwav_s16(src);
            *s++ = rwav_s16(src + 2);
         }
      }
   }

   return true;
}

static bool one_shot_resample_s16(const int16_t* in, size_t samples_in,
      unsigned rate, const char *resampler_ident,
      enum resampler_quality quality,
      int16_t** out, size_t* samples_out)
{
   struct resampler_data_int16 info;
   retro_resampler_int16_t rs;
   size_t alloc_samples;
   size_t pad;
   void  *re    = NULL;
   double ratio;

   /* As in one_shot_resample(): no rate on either side, no resample. */
   if (!s_rate || !rate)
      return false;
   ratio = (double)s_rate / (double)rate;

   if (!retro_resampler_int16_new(&rs, resampler_ident, quality,
            (ratio < 1.0) ? ratio : 1.0, false))
      return false;
   re = rs.data;

   /* Size by the predicted output count plus a ratio-scaled safeguard,
    * exactly like one_shot_resample, so the s16 buffer carries the same
    * frame count as the float buffer. The excess the resampler reports
    * over the estimate grows with upsampling, so the pad has to grow
    * with it too; a fixed pad let the clamp below truncate the tail at
    * large ratios. The buffer is zeroed so any undershoot tail reads as
    * silence. */
   pad           = 2 * (size_t)(ratio + 1.0) + 32;
   *samples_out  = (size_t)(samples_in * ratio);
   alloc_samples = ((*samples_out + pad) + 15) & ~15;
   *out          = (int16_t*)memalign_alloc(16,
         alloc_samples * sizeof(int16_t));

   if (*out == NULL)
   {
      rs.free(re);
      return false;
   }

   memset(*out, 0, alloc_samples * sizeof(int16_t));

   info.data_in       = in;
   info.data_out      = *out;
   info.input_frames  = samples_in / 2;
   info.output_frames = 0;
   info.ratio         = ratio;

   rs.process(re, &info);
   rs.free(re);

   /* As in one_shot_resample: report what came out, not what was
    * predicted, so the tail is not dropped. */
   *samples_out = info.output_frames * 2;
   if (*samples_out > alloc_samples)
      *samples_out = alloc_samples;
   return true;
}
#endif

/* Defined below, next to each other so the two pipelines stay
 * visibly parallel; declared here because load_wav builds whichever
 * one the caller asked for. */
static bool wav_build_float(audio_mixer_sound_t* sound,
      const char *resampler_ident, enum resampler_quality quality);
static bool wav_build_s16(audio_mixer_sound_t* sound,
      const char *resampler_ident, enum resampler_quality quality);

audio_mixer_sound_t* audio_mixer_load_wav(void *buffer, size_t size,
      const char *resampler_ident, enum resampler_quality quality,
      bool want_s16)
{
#ifdef HAVE_RWAV
   /* WAV data */
   rwav_t wav;
   /* Result */
   audio_mixer_sound_t* sound = NULL;
   uint8_t* src               = NULL;

   wav.bitspersample          = 0;
   wav.numchannels            = 0;
   wav.samplerate             = 0;
   wav.numsamples             = 0;
   wav.subchunk2size          = 0;
   wav.samples                = NULL;
   wav.dataoffset             = 0;

   /* Header only: the converters read the samples straight out of the
    * buffer handed here, so the decoded copy rwav_load would have made
    * - as large as the file, and thrown away as soon as it had been
    * converted - never exists. */
   if (rwav_parse(&wav, buffer, size) != RWAV_ITERATE_DONE)
      return NULL;

   if (!wav.subchunk2size)
      return NULL;

   /* Keep the source samples. The caller owns the buffer it passed and
    * frees it as soon as this returns, so the sound cannot borrow
    * them; and without them the only way to produce the second
    * pipeline later would be to derive it from the first pipeline's
    * output, which is exactly what this replaces. Cost is the data
    * chunk, held for the life of the sound. */
   if (!(src = (uint8_t*)malloc(wav.subchunk2size)))
      return NULL;

   memcpy(src, (const uint8_t*)buffer + wav.dataoffset,
         wav.subchunk2size);

   if (!(sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound))))
   {
      free(src);
      return NULL;
   }

   sound->type          = AUDIO_MIXER_TYPE_WAV;
   sound->types.wav.src = src;
   sound->types.wav.hdr = wav;
   /* dataoffset addressed the caller's buffer; the copy starts at the
    * samples, so nothing may use it again */
   sound->types.wav.hdr.dataoffset = 0;
   sound->types.wav.hdr.samples    = NULL;

   /* Build the pipeline the caller asked for now, so that triggering
    * the sound later allocates nothing. The other one is built only
    * if a mode flip actually asks for it. */
   if (want_s16 ? wav_build_s16(sound, resampler_ident, quality)
                : wav_build_float(sound, resampler_ident, quality))
      return sound;

   audio_mixer_destroy(sound);
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_wav_stream(void *buffer, size_t size)
{
#ifdef HAVE_RWAV
   audio_mixer_sound_t* sound;

   if (!buffer || size <= 0)
      return NULL;

   if ((sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound))))
   {
      /* nothing is decoded here: the voice reads frames out of these
       * bytes as it mixes them */
      sound->type              = AUDIO_MIXER_TYPE_WAV_STREAM;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_ogg(void *buffer, size_t size)
{
#if defined(HAVE_RVORBIS) || defined(HAVE_ROPUS) || defined(HAVE_RFLAC)
   audio_mixer_sound_t* sound;
   enum audio_mixer_type mt = AUDIO_MIXER_TYPE_OGG;

   if (!buffer || size <= 0)
      return NULL;

#ifdef HAVE_RFLAC
   /* And FLAC (RFC 5334), which .oga usually carries and .ogg may. */
   if (audio_transfer_ogg_audio_type(buffer, (size_t)size)
         == AUDIO_TYPE_FLAC)
      mt = AUDIO_MIXER_TYPE_FLAC;
#endif
#ifdef HAVE_ROPUS
   /* An .ogg file legitimately wraps Opus as well as Vorbis; route by
    * the identification header, not the extension.  The Opus arm's
    * Ogg buffer mode takes the whole file as-is. */
   if (audio_transfer_ogg_audio_type(buffer, (size_t)size)
         == AUDIO_TYPE_OPUS)
      mt = AUDIO_MIXER_TYPE_OPUS;
#endif
#ifndef HAVE_RVORBIS
   if (mt == AUDIO_MIXER_TYPE_OGG)
      return NULL;
#endif

   sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = mt;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_flac(void *buffer, size_t size)
{
#ifdef HAVE_RFLAC
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_FLAC;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_mp3(void *buffer, size_t size)
{
#ifdef HAVE_RMP3
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_MP3;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_m4a_track_avail(void *buffer, size_t size,
      size_t avail, int track)
{
#ifdef HAVE_RAAC
   audio_mixer_sound_t* sound;
#endif
#if defined(HAVE_RAC3) && defined(HAVE_RMP4)
   if (audio_transfer_mp4_audio_track_type(buffer, size, avail, track) == AUDIO_TYPE_AC3)
   {
      audio_mixer_sound_t *ac3 = audio_mixer_load_ac3(buffer, size);
      if (ac3) ac3->container_track = (unsigned)track + 1;
      return ac3;
   }
#endif
   (void)avail;
#ifdef HAVE_RAAC
   if (track < -1)
      return NULL;
   sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_M4A;
      sound->container_track   = (unsigned)track + 1;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#else
   (void)buffer; (void)size; (void)track;
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_m4a_track(void *buffer, size_t size, int track)
{
   return audio_mixer_load_m4a_track_avail(buffer, size, size, track);
}

audio_mixer_sound_t* audio_mixer_load_m4a(void *buffer, size_t size)
{
   return audio_mixer_load_m4a_track(buffer, size, -1);
}

audio_mixer_sound_t* audio_mixer_load_ac3(void *buffer, size_t size)
{
#ifdef HAVE_RAC3
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_AC3;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_wma(void *buffer, size_t size)
{
#ifdef HAVE_RWMA
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_WMA;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_lpcm(void *buffer, size_t size)
{
#ifdef HAVE_RLPCM
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_LPCM;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_opus(void *buffer, size_t size)
{
#ifdef HAVE_ROPUS
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_OPUS;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

audio_mixer_sound_t* audio_mixer_load_weba_track(void *buffer, size_t size,
      size_t avail, int track)
{
#if defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) || defined(HAVE_RVORBIS) \
 || defined(HAVE_RAAC) || defined(HAVE_RFLAC))
   audio_mixer_sound_t* sound;
   /* Bound the sniff to what is resident.  This runs before the sound
    * exists, so sound_set_avail cannot have been applied yet - and
    * with the whole file's length it walked the segment straight off
    * the committed head of a windowed buffer and died inside
    * rwebm_open_memory_avail. */
   enum audio_type_enum ty = audio_transfer_webm_audio_track_type(buffer,
         (avail && avail < size) ? avail : size, track);
   enum audio_mixer_type mt;

   /* Resolve to the existing sound type whose streaming arm accepts
    * the whole WebM buffer; nothing downstream ever sees WEBA. */
   if (ty == AUDIO_TYPE_OPUS)
      mt = AUDIO_MIXER_TYPE_OPUS;
   else if (ty == AUDIO_TYPE_VORBIS)
      mt = AUDIO_MIXER_TYPE_OGG;
#ifdef HAVE_RAAC
   else if (ty == AUDIO_TYPE_AAC)
      mt = AUDIO_MIXER_TYPE_M4A;
#endif
#ifdef HAVE_RFLAC
   else if (ty == AUDIO_TYPE_FLAC)
      mt = AUDIO_MIXER_TYPE_FLAC;
#endif
   else
      return NULL;

   if (!(sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound))))
      return NULL;
   sound->type           = mt;
   sound->container_track = (unsigned)track + 1;
   sound->types.stream.size = size;
   sound->types.stream.data = buffer;
   return sound;
#else
   (void)buffer; (void)size; (void)avail; (void)track;
   return NULL;
#endif
}

audio_mixer_sound_t* audio_mixer_load_weba_avail(void *buffer, size_t size,
      size_t avail)
{
   return audio_mixer_load_weba_track(buffer, size, avail, -1);
}

audio_mixer_sound_t* audio_mixer_load_weba(void *buffer, size_t size)
{
   return audio_mixer_load_weba_avail(buffer, size, 0);
}

audio_mixer_sound_t* audio_mixer_load_mod(void *buffer, size_t size)
{
#ifdef HAVE_RMODTRACKER
   audio_mixer_sound_t* sound = (audio_mixer_sound_t*)calloc(1, sizeof(*sound));

   if (sound)
   {
      sound->type              = AUDIO_MIXER_TYPE_MOD;
      sound->types.stream.size = size;
      sound->types.stream.data = buffer;
      return sound;
   }
#endif
   return NULL;
}

void audio_mixer_sound_set_data_owner(audio_mixer_sound_t *sound,
      void *owner, void (*release)(void *owner))
{
   if (!sound)
   {
      /* ownership transfers in every outcome */
      if (owner && release)
         release(owner);
      return;
   }
   sound->data_owner   = owner;
   sound->data_release = release;
}

/* NOT under HAVE_ROPUS.  The resident bound applies to every windowed
 * arm, not just Ogg-Opus, and add_stream calls this unconditionally -
 * leaving the definition behind the Opus guard broke the link on every
 * target built without it (3DS and the other console ports).  The
 * field is unconditional, so the body needs no guard either; only the
 * end-granule setter below is genuinely Opus-specific. */
#ifdef AUDIO_MIXER_HAS_STREAM
static enum audio_type_enum audio_mixer_sound_audio_type(
      const audio_mixer_sound_t *sound)
{
   switch (sound->type)
   {
      case AUDIO_MIXER_TYPE_WAV_STREAM: return AUDIO_TYPE_WAV;
      case AUDIO_MIXER_TYPE_OGG: return AUDIO_TYPE_VORBIS;
      case AUDIO_MIXER_TYPE_FLAC: return AUDIO_TYPE_FLAC;
      case AUDIO_MIXER_TYPE_MP3: return AUDIO_TYPE_MP3;
      case AUDIO_MIXER_TYPE_MOD: return AUDIO_TYPE_MOD;
      case AUDIO_MIXER_TYPE_M4A: return AUDIO_TYPE_AAC;
      case AUDIO_MIXER_TYPE_OPUS: return AUDIO_TYPE_OPUS;
      case AUDIO_MIXER_TYPE_AC3: return AUDIO_TYPE_AC3;
      case AUDIO_MIXER_TYPE_WMA: return AUDIO_TYPE_WMA;
      case AUDIO_MIXER_TYPE_LPCM: return AUDIO_TYPE_LPCM;
      default: break;
   }
   return AUDIO_TYPE_NONE;
}
#endif

bool audio_mixer_sound_set_prepared_transfer(audio_mixer_sound_t *sound,
      void *transfer, unsigned mix_rate, bool s16)
{
#ifdef AUDIO_MIXER_HAS_STREAM
   enum audio_type_enum type;
   if (!sound || !transfer || !mix_rate || sound->prepared_transfer)
      return false;
   type = audio_mixer_sound_audio_type(sound);
   if (type == AUDIO_TYPE_NONE || !audio_transfer_is_valid(transfer, type)
         || (sound->container_track && audio_transfer_container_track(transfer, type)
               != (int)(sound->container_track - 1)))
      return false;
   sound->prepared_transfer = transfer;
   sound->prepared_type = type;
   sound->prepared_rate = mix_rate;
   sound->prepared_s16 = s16;
   return true;
#else
   (void)sound; (void)transfer; (void)mix_rate; (void)s16;
   return false;
#endif
}

void audio_mixer_sound_set_initial_paused(audio_mixer_sound_t *sound,
      bool paused)
{
   if (sound) sound->initial_paused = paused;
}

void audio_mixer_sound_set_tag(audio_mixer_sound_t *sound, unsigned tag)
{
   if (sound)
      sound->tag = tag;
}

unsigned audio_mixer_sound_tag(const audio_mixer_sound_t *sound)
{
   return sound ? sound->tag : 0;
}

void audio_mixer_sound_set_avail(audio_mixer_sound_t *sound, size_t avail)
{
   if (sound)
      sound->avail = avail;
}

#ifdef HAVE_ROPUS
void audio_mixer_sound_set_end_granule(audio_mixer_sound_t *sound,
      int64_t end_granule)
{
   if (sound)
      sound->end_granule = end_granule;
}
#endif

/* The decoder's compressed-byte position within its source buffer.
 * The decoder is the mix's: call with the voice owned. */
static size_t audio_mixer_voice_tell_owned(audio_mixer_voice_t *voice)
{
   size_t r = 0;
#ifdef AUDIO_MIXER_HAS_STREAM
   switch (retro_atomic_load_relaxed_int(&voice->type))
   {
#ifdef HAVE_ROPUS
      case AUDIO_MIXER_TYPE_OPUS:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_OPUS);
         break;
#endif
#ifdef HAVE_RWAV
      case AUDIO_MIXER_TYPE_WAV_STREAM:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_WAV);
         break;
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_MIXER_TYPE_OGG:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_VORBIS);
         break;
#endif
#ifdef HAVE_RMP3
      case AUDIO_MIXER_TYPE_MP3:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_MP3);
         break;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_MIXER_TYPE_FLAC:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_FLAC);
         break;
#endif
#ifdef HAVE_RAAC
      case AUDIO_MIXER_TYPE_M4A:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_AAC);
         break;
#endif
#ifdef HAVE_RAC3
      case AUDIO_MIXER_TYPE_AC3:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_AC3);
         break;
#endif
#ifdef HAVE_RWMA
      case AUDIO_MIXER_TYPE_WMA:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_WMA);
         break;
#endif
#ifdef HAVE_RLPCM
      case AUDIO_MIXER_TYPE_LPCM:
         r = audio_transfer_buffer_tell(voice->types.stream.stream,
               AUDIO_TYPE_LPCM);
         break;
#endif
      default:
         break;
   }
#else
   (void)voice;
#endif
   return r;
}

/* Hand the decoder its resident bound.  Only the windowed arms act on
 * it.  Call with the voice owned. */
static void audio_mixer_voice_avail_owned(audio_mixer_voice_t *voice,
      size_t avail)
{
#if defined(AUDIO_MIXER_HAS_STREAM) \
 && ((defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) || defined(HAVE_RVORBIS))) \
 || defined(HAVE_RAAC) || defined(HAVE_RFLAC) || (defined(HAVE_RAC3) || defined(HAVE_RWMA)))
   switch (retro_atomic_load_relaxed_int(&voice->type))
   {
#ifdef HAVE_RAC3
      case AUDIO_MIXER_TYPE_AC3:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_AC3, avail);
         break;
#endif
#ifdef HAVE_RWMA
      case AUDIO_MIXER_TYPE_WMA:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_WMA, avail);
         break;
#endif
#ifdef HAVE_RLPCM
      case AUDIO_MIXER_TYPE_LPCM:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_LPCM, avail);
         break;
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_MIXER_TYPE_OGG:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_VORBIS, avail);
         break;
#endif
#ifdef HAVE_ROPUS
      case AUDIO_MIXER_TYPE_OPUS:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_OPUS, avail);
         break;
#endif
#ifdef HAVE_RAAC
      /* The arm a windowed M4A actually lands on.  Its absence meant
       * every feeder raise was accepted and dropped: the decoder kept
       * the bound it was given at add_stream, hit it a second or so
       * in, reported end of stream, and a looping voice restarted -
       * the same second of audio over and over. */
      case AUDIO_MIXER_TYPE_M4A:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_AAC, avail);
         break;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_MIXER_TYPE_FLAC:
         audio_transfer_set_avail(voice->types.stream.stream,
               AUDIO_TYPE_FLAC, avail);
         break;
#endif
      default:
         break;
   }
#else
   (void)voice; (void)avail;
#endif
}

static int audio_mixer_lap_next(int lap)
{
   return (lap > 0 && lap < 0x7fffffff) ? lap + 1 : 1;
}

/* A voice being claimed: no bound asked for, a lap of its own.  Before
 * the store that publishes the voice's type. */
static void audio_mixer_feed_reset(audio_mixer_voice_t *voice, bool paused)
{
   size_t serial = retro_atomic_fetch_add_size(&s_clock_serial, 1) + 1;
   if (!serial)
      serial = retro_atomic_fetch_add_size(&s_clock_serial, 1) + 1;
   retro_atomic_store_release_size(&voice->clock_serial, 0);
   retro_atomic_store_relaxed_int(&voice->paused, paused ? 1 : 0);
   voice->mixed_frames = 0;
   /* A reader that sees either new field must also see the invalid
    * serial before it, even if it began on the preceding play. */
   retro_atomic_store_release_size(&voice->clock_frames, 0);
   retro_atomic_store_release_int(&voice->clock_rate, (int)s_rate);
   retro_atomic_store_release_int(&voice->avail_lap, -1);
   retro_atomic_store_relaxed_int(&voice->feeder_lap, 0);
   retro_atomic_store_release_size(&voice->tell, 0);
   retro_atomic_store_release_size(&voice->read_end, 0);
   retro_atomic_store_release_int(&voice->lap, audio_mixer_lap_next(
            retro_atomic_load_relaxed_int(&voice->lap)));
   voice->avail_done_valid = false;
   retro_atomic_store_release_size(&voice->clock_serial, serial);
}

/* Before a decode: take the bound the feeder asked for, if it is new
 * and its lap is still the decoder's.  The feeder writes the lap, the
 * bound, the lap; a lap that changed across the read is a write in
 * progress, left for the next mix. */
static void audio_mixer_feed_apply(audio_mixer_voice_t *voice)
{
   size_t avail, serial;
   int lap = retro_atomic_load_acquire_int(&voice->avail_lap);
   if (lap < 0)
      return;
   serial = retro_atomic_load_acquire_size(&voice->avail_serial);
   avail = retro_atomic_load_acquire_size(&voice->avail_req);
   if (     retro_atomic_load_acquire_int(&voice->avail_lap) != lap
         || !serial
         || retro_atomic_load_acquire_size(&voice->avail_serial) != serial
         || retro_atomic_load_acquire_size(&voice->clock_serial) != serial
         || (lap && lap != retro_atomic_load_relaxed_int(&voice->lap)))
      return;
   if (     voice->avail_done_valid
         && voice->avail_done     == avail
         && voice->avail_done_lap == lap)
      return;
   audio_mixer_voice_avail_owned(voice, avail);
   voice->avail_done       = avail;
   voice->avail_done_lap   = lap;
   voice->avail_done_valid = true;
}

/* After a decode: where the decoder stands now. */
static void audio_mixer_feed_publish(audio_mixer_voice_t *voice)
{
   size_t end = 0;
#ifdef AUDIO_MIXER_HAS_STREAM
   enum audio_type_enum type = AUDIO_TYPE_NONE;
   switch (retro_atomic_load_relaxed_int(&voice->type))
   {
#ifdef HAVE_ROPUS
      case AUDIO_MIXER_TYPE_OPUS: type = AUDIO_TYPE_OPUS; break;
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_MIXER_TYPE_OGG: type = AUDIO_TYPE_VORBIS; break;
#endif
#ifdef HAVE_RAAC
      case AUDIO_MIXER_TYPE_M4A: type = AUDIO_TYPE_AAC; break;
#endif
#ifdef HAVE_RAC3
      case AUDIO_MIXER_TYPE_AC3: type = AUDIO_TYPE_AC3; break;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_MIXER_TYPE_FLAC: type = AUDIO_TYPE_FLAC; break;
#endif
      default: break;
   }
   if (type != AUDIO_TYPE_NONE)
      end = audio_transfer_buffer_read_end(voice->types.stream.stream, type);
#endif
   retro_atomic_store_release_size(&voice->read_end, end);
   retro_atomic_store_release_size(&voice->clock_frames, voice->mixed_frames);
   retro_atomic_store_release_size(&voice->tell,
         audio_mixer_voice_tell_owned(voice));
}

/* The decoder went back to the top.  Position before lap: the feeder
 * reads them the other way round, so it never pairs the old lap's
 * position with the new lap.  A bound that is no position's stands
 * across the rewind and is handed over again. */
static void audio_mixer_feed_rewound(audio_mixer_voice_t *voice)
{
   audio_mixer_feed_publish(voice);
   retro_atomic_store_release_int(&voice->lap, audio_mixer_lap_next(
            retro_atomic_load_relaxed_int(&voice->lap)));
   voice->avail_done_valid = false;
   audio_mixer_feed_apply(voice);
}

void audio_mixer_voice_set_avail_bound(audio_mixer_voice_t *voice,
      size_t avail, size_t serial)
{
   if (     !voice || !serial
         || retro_atomic_load_acquire_int(&voice->type)
            == AUDIO_MIXER_TYPE_NONE)
      return;
   retro_atomic_store_release_int(&voice->avail_lap, -1);
   retro_atomic_store_release_size(&voice->avail_req, avail);
   retro_atomic_store_release_size(&voice->avail_serial, serial);
   retro_atomic_store_release_int(&voice->avail_lap,
         retro_atomic_load_relaxed_int(&voice->feeder_lap));
}

void audio_mixer_voice_set_avail(audio_mixer_voice_t *voice, size_t avail)
{
   if (voice)
      audio_mixer_voice_set_avail_bound(voice, avail,
            retro_atomic_load_acquire_size(&voice->clock_serial));
}

bool audio_mixer_voice_clock(audio_mixer_voice_t *voice,
      size_t *frames, unsigned *rate, size_t *serial)
{
   size_t generation, count;
   unsigned hz;
   if (frames) *frames = 0;
   if (rate) *rate = 0;
   if (serial) *serial = 0;
   if (!voice || retro_atomic_load_acquire_int(&voice->type)
         == AUDIO_MIXER_TYPE_NONE)
      return false;
   generation = retro_atomic_load_acquire_size(&voice->clock_serial);
   if (!generation)
      return false;
   hz = (unsigned)retro_atomic_load_acquire_int(&voice->clock_rate);
   count = retro_atomic_load_acquire_size(&voice->clock_frames);
   if (generation != retro_atomic_load_acquire_size(&voice->clock_serial))
      return false; /* a restart, retry next poll; never spin */
   if (rate) *rate = hz;
   if (frames) *frames = count;
   if (serial) *serial = generation;
   return true;
}

size_t audio_mixer_voice_buffer_tell(audio_mixer_voice_t *voice)
{
   if (     !voice
         || retro_atomic_load_acquire_int(&voice->type)
            == AUDIO_MIXER_TYPE_NONE)
      return 0;
   retro_atomic_store_relaxed_int(&voice->feeder_lap,
         retro_atomic_load_acquire_int(&voice->lap));
   return retro_atomic_load_acquire_size(&voice->tell);
}

size_t audio_mixer_voice_buffer_read_end(audio_mixer_voice_t *voice, size_t serial)
{
   size_t end;
   if (!voice || !serial
         || retro_atomic_load_acquire_size(&voice->clock_serial) != serial)
      return 0;
   end = retro_atomic_load_acquire_size(&voice->read_end);
   if (retro_atomic_load_acquire_size(&voice->clock_serial) != serial) return 0;
   return end;
}

void audio_mixer_destroy(audio_mixer_sound_t* sound)
{
   void *handle = NULL;
   if (!sound)
      return;

#ifdef AUDIO_MIXER_HAS_STREAM
   if (sound->prepared_transfer)
      audio_transfer_free(sound->prepared_transfer, sound->prepared_type);
#endif

   if (sound->data_owner)
      /* the compressed source was borrowed: hand it back; the
       * per-type paths below leave borrowed data alone */
      sound->data_release(sound->data_owner);

   switch (sound->type)
   {
      case AUDIO_MIXER_TYPE_WAV:
         handle = (void*)sound->types.wav.pcm;
         if (handle)
            memalign_free(handle);
         handle = (void*)sound->types.wav.pcm_s16;
         if (handle)
            memalign_free(handle);
#ifdef HAVE_RWAV
         handle = (void*)sound->types.wav.src;
         if (handle)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_WAV_STREAM:
#ifdef HAVE_RWAV
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_OGG:
#ifdef HAVE_RVORBIS
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_MOD:
#ifdef HAVE_RMODTRACKER
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_FLAC:
#ifdef HAVE_RFLAC
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_MP3:
#ifdef HAVE_RMP3
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_M4A:
#ifdef HAVE_RAAC
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_AC3:
#ifdef HAVE_RAC3
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_WMA:
#ifdef HAVE_RWMA
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_LPCM:
#ifdef HAVE_RLPCM
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_OPUS:
#ifdef HAVE_ROPUS
         handle = (void*)sound->types.stream.data;
         if (handle && !sound->data_owner)
            free(handle);
#endif
         break;
      case AUDIO_MIXER_TYPE_WEBA: /* resolved at load; never stored */
      case AUDIO_MIXER_TYPE_NONE:
         break;
   }

   free(sound);
}

/* Build one pipeline's PCM from the WAV's own source samples.
 *
 * Each pipeline runs its own converter and its own resampler over the
 * source; neither is ever derived from the other's finished output.
 * That is the whole point: the previous wav_ensure_* pair produced an
 * s16 buffer by quantising the float resampler's result, so an s16
 * voice on a float-free platform could play audio that had been
 * through a float resampler after all.
 *
 * Called at load for the mode the caller asked for, so triggering a
 * sound allocates nothing. The only path that builds at play time is
 * a mode flip with the sound still loaded (a core switch), and it now
 * builds from the source instead of from the other pipeline. */
#ifdef HAVE_RWAV
/* Whether a WAV's pipelines can be sized at all: two output samples a
 * frame, padded to 16 and held as floats, a decode scratch of one s16
 * a channel a frame where more than two are folded, and the frame
 * count kept as an unsigned.  rwav bounds the count by the payload,
 * but the pipelines expand it up to eightfold (8-bit mono to stereo
 * float), which still wraps a 32-bit size_t on a large enough file. */
static bool wav_pipeline_fits(const rwav_t *wav)
{
   size_t ch = (wav->numchannels > 2) ? (size_t)wav->numchannels : 2;
   return     wav->numsamples <= (SIZE_MAX / sizeof(float) - 16) / ch
          &&  (size_t)(unsigned)wav->numsamples == wav->numsamples;
}

static bool wav_build_float(audio_mixer_sound_t* sound,
      const char *resampler_ident, enum resampler_quality quality)
{
   float  *pcm     = NULL;
   size_t  samples;

   if (sound->types.wav.pcm)
      return true;
   if (     !sound->types.wav.src
         || !wav_pipeline_fits(&sound->types.wav.hdr))
      return false;

   samples = sound->types.wav.hdr.numsamples * 2;

   if (!wav_to_float(&sound->types.wav.hdr, sound->types.wav.src,
         &pcm, samples))
      return false;

   if (sound->types.wav.hdr.samplerate != s_rate)
   {
      float *resampled = NULL;

      if (!one_shot_resample(pcm, samples,
            sound->types.wav.hdr.samplerate, resampler_ident, quality,
            &resampled, &samples))
      {
         memalign_free((void*)pcm);
         return false;
      }

      memalign_free((void*)pcm);
      pcm = resampled;
   }

   sound->types.wav.pcm    = pcm;
   sound->types.wav.frames = (unsigned)(samples / 2);
   return true;
}

static bool wav_build_s16(audio_mixer_sound_t* sound,
      const char *resampler_ident, enum resampler_quality quality)
{
   int16_t *pcm    = NULL;
   size_t   samples;

   if (sound->types.wav.pcm_s16)
      return true;
   if (     !sound->types.wav.src
         || !wav_pipeline_fits(&sound->types.wav.hdr))
      return false;

   samples = sound->types.wav.hdr.numsamples * 2;

   if (!wav_to_s16(&sound->types.wav.hdr, sound->types.wav.src,
         &pcm, samples))
      return false;

   if (sound->types.wav.hdr.samplerate != s_rate)
   {
      int16_t *resampled = NULL;

      if (!one_shot_resample_s16(pcm, samples,
            sound->types.wav.hdr.samplerate, resampler_ident, quality,
            &resampled, &samples))
      {
         memalign_free((void*)pcm);
         return false;
      }

      memalign_free((void*)pcm);
      pcm = resampled;
   }

   sound->types.wav.pcm_s16    = pcm;
   sound->types.wav.frames_s16 = (unsigned)(samples / 2);
   return true;
}
#else
/* Without RWAV a decoded WAV sound can never be created, so these are
 * unreachable. They exist so the play switch needs no guard of its
 * own. */
static bool wav_build_float(audio_mixer_sound_t* sound,
      const char *resampler_ident, enum resampler_quality quality)
{
   (void)sound;
   (void)resampler_ident;
   (void)quality;
   return false;
}

static bool wav_build_s16(audio_mixer_sound_t* sound,
      const char *resampler_ident, enum resampler_quality quality)
{
   (void)sound;
   (void)quality;
   return false;
}
#endif

/* No volume parameter: it was never read, and taking a float here put
 * one in the s16 play path for nothing. */
static bool audio_mixer_play_wav(audio_mixer_sound_t* sound,
      audio_mixer_voice_t* voice, bool repeat,
      audio_mixer_stop_cb_t stop_cb)
{
   voice->types.wav.position = 0;
   return true;
}

#ifdef AUDIO_MIXER_HAS_STREAM
/* Shared streaming path (WAV / OGG / FLAC / MP3). audio_transfer already
 * abstracts the codec, so one set of play/mix/release functions serves
 * them all; the caller passes the matching enum audio_type_enum. */
static bool audio_mixer_play_stream(
      audio_mixer_sound_t* sound,
      audio_mixer_voice_t* voice,
      bool repeat, float volume,
      const char *resampler_ident,
      enum resampler_quality quality,
      audio_mixer_stop_cb_t stop_cb,
      enum audio_type_enum type)
{
   unsigned rate                   = 0;
   float ratio                     = 1.0f;
   unsigned samples                = 0;
   void *sbuf                      = NULL;
   void *resampler_data            = NULL;
   const retro_resampler_t* resamp = NULL;
   void *xfer = sound->prepared_transfer;
   bool prepared = xfer != NULL;

   if (prepared)
   {
      if (sound->prepared_rate != s_rate || sound->prepared_s16 != false)
         return false;
      sound->prepared_transfer = NULL;
   }
   else
      xfer = audio_transfer_new(type);
   if (!xfer)
      return false;

   if (!prepared)
   {
      audio_transfer_set_buffer_ptr(xfer, type,
            (void*)sound->types.stream.data, sound->types.stream.size);

#if (defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) || defined(HAVE_RVORBIS) \
      || defined(HAVE_RAAC) || defined(HAVE_RFLAC))) \
    || (defined(HAVE_RAAC) && defined(HAVE_RMP4)) || defined(HAVE_RWMA)
      /* Windowed container: bound the header parse to the resident head,
       * so opening does not walk to the end of a file whose middle is
       * reserved rather than populated.  MP4/AAC takes this too now that
       * its arm honours the bound - the guard used to admit only the
       * WebM-backed arms, so an M4A stream could be handed an avail that
       * was then compiled out and silently ignored. */
      if (sound->avail)
         audio_transfer_set_avail(xfer, type, sound->avail);
#endif
#ifdef HAVE_ROPUS
      /* Windowed Ogg-Opus: hand the decoder the last-page granule the
       * feeder found, so its buffer setup skips the full-file end scan
       * (the tail is not resident under windowing).  No-op for 0 (not
       * supplied) and for every non-Opus type. */
      if (sound->end_granule > 0)
         audio_transfer_set_end_granule(xfer, type, sound->end_granule);
#endif

      /* Say what rate we mix at: an arm that can synthesise there will,
       * and the resampler below then has nothing to do. */
      audio_transfer_set_output_rate(xfer, type, (unsigned)s_rate);

#ifdef HAVE_RLPCM
      /* Raw linear PCM says nothing about itself, and a mixer sound is
       * just a file someone dropped in a directory - there is no one to
       * ask. So samples with no disc header take 16-bit stereo at 48 kHz,
       * little-endian, which is what such a file usually is; a buffer
       * that does open with a DVD or Blu-ray header keeps what the
       * header says, since the arm reads that first. */
      if (type == AUDIO_TYPE_LPCM)
      {
         rlpcm_format_t *fmt = (rlpcm_format_t*)audio_transfer_lpcm_format(xfer);
         if (fmt && !fmt->bits)
         {
            fmt->sample_rate = 48000;
            fmt->bits        = 16;
            fmt->channels    = 2;
            fmt->big_endian  = false;
         }
      }
#endif

      if (sound->container_track && !audio_transfer_set_container_track(xfer,
               type, (int)(sound->container_track - 1)))
         goto error;

      if (!audio_transfer_start(xfer, type))
         goto error;

   }
   {
      unsigned ch = 0;
      audio_transfer_info(xfer, type, &ch, &rate, NULL);
      /* Wider than stereo is folded at fill time rather than refused:
       * the decoders reach eight channels (Opus) and sixteen
       * (Vorbis), and a voice mixes stereo.  Past the table's reach
       * there is no sensible fold, so those are still turned away. */
      if (ch < 1 || ch > 8)
         goto error;
      voice->types.stream.channels = ch;
#ifdef HAVE_RWMA
      if (type == AUDIO_TYPE_WMA && !audio_transfer_stereo_matrix(xfer,type,voice->types.stream.wma_matrix))
         goto error;
#endif
   }

   if (rate != s_rate)
   {
      /* A source claiming no rate, or a mixer not yet given one,
       * cannot be brought to the output rate; see one_shot_resample(). */
      if (!s_rate || !rate)
         goto error;
      ratio = (double)s_rate / (double)rate;

      if (!retro_resampler_realloc(&resampler_data,
               &resamp, resampler_ident, quality,
               ratio))
         goto error;
   }

   /* Allocate on a 16-byte boundary, and pad to a multiple of 16 bytes.
    * process() reports more than the estimate below - a call ends on a
    * phase it did not start on, so one input frame's worth of output
    * lands on top - and the excess scales with the ratio, as it does in
    * one_shot_resample(). buf_samples is what the fill clamps to. */
   samples                         = (unsigned)(AUDIO_MIXER_TEMP_BUFFER * ratio);
   samples                         = ((samples + 2 * (unsigned)(ratio + 1.0)
                                       + 32) + 15) & ~15;
   voice->types.stream.decode_buf  = (float*)memalign_alloc(64,
         (AUDIO_MIXER_STREAM_BUF_OFFSET(sizeof(float))
          + samples) * sizeof(float));

   if (!voice->types.stream.decode_buf)
   {
      /* error: only frees the transfer. */
      if (resamp && resampler_data)
         resamp->free(resampler_data);
      goto error;
   }
   /* The resampled buffer is a view into the decode block; release
    * frees the block through decode_buf. */
   sbuf = voice->types.stream.decode_buf
        + AUDIO_MIXER_STREAM_BUF_OFFSET(sizeof(float));

   voice->types.stream.resampler      = resamp;
   voice->types.stream.resampler_data = resampler_data;
   voice->types.stream.buffer         = (float*)sbuf;
   voice->types.stream.buf_samples    = samples;
   voice->types.stream.ratio          = ratio;
   voice->types.stream.stream         = xfer;
   voice->types.stream.position       = 0;
   voice->types.stream.samples        = 0;

   return true;

error:
   audio_transfer_free(xfer, type);
   return false;
}

static void audio_mixer_release_stream(audio_mixer_voice_t* voice,
      enum audio_type_enum type)
{
   if (voice->types.stream.stream)
      audio_transfer_free(voice->types.stream.stream, type);
   if (voice->types.stream.resampler && voice->types.stream.resampler_data)
      voice->types.stream.resampler->free(voice->types.stream.resampler_data);
   /* buffer and buffer_s16 are views into the decode blocks. */
   if (voice->types.stream.decode_buf)
      memalign_free(voice->types.stream.decode_buf);
   voice->types.stream.buffer = NULL;
   if (voice->types.stream.decode_buf_s16)
      memalign_free(voice->types.stream.decode_buf_s16);
   voice->types.stream.buffer_s16 = NULL;
   if (voice->types.stream.resampler_int16.data)
      voice->types.stream.resampler_int16.free(
            voice->types.stream.resampler_int16.data);
}

static bool audio_mixer_play_stream_s16(
      audio_mixer_sound_t* sound,
      audio_mixer_voice_t* voice,
      bool repeat, int32_t gain,
      const char *resampler_ident,
      enum resampler_quality quality,
      audio_mixer_stop_cb_t stop_cb,
      enum audio_type_enum type)
{
   double   ratio       = 1.0;
   unsigned samples     = 0;
   unsigned channels    = 0;
   unsigned rate        = 0;
   void    *sbuf        = NULL;
   retro_resampler_int16_t rs;
   void *xfer = sound->prepared_transfer;
   bool prepared = xfer != NULL;

   /* No resampling leaves it zeroed, which the fill reads as "none". */
   memset(&rs, 0, sizeof(rs));
   (void)repeat;
   (void)gain;
   (void)stop_cb;

   if (prepared)
   {
      if (sound->prepared_rate != s_rate || sound->prepared_s16 != true)
         return false;
      sound->prepared_transfer = NULL;
   }
   else
      xfer = audio_transfer_new(type);
   if (!xfer)
      return false;
   if (!prepared)
   {
      audio_transfer_set_buffer_ptr(xfer, type,
            (void*)sound->types.stream.data, sound->types.stream.size);
#if (defined(HAVE_RWEBM) && (defined(HAVE_ROPUS) || defined(HAVE_RVORBIS) \
      || defined(HAVE_RAAC) || defined(HAVE_RFLAC))) \
    || (defined(HAVE_RAAC) && defined(HAVE_RMP4)) || defined(HAVE_RWMA)
      /* Windowed container: bound the header parse to the head (see the
       * f32 path). */
      if (sound->avail)
         audio_transfer_set_avail(xfer, type, sound->avail);
#endif
#ifdef HAVE_ROPUS
      /* Windowed Ogg-Opus: skip the decoder's full-file end scan by
       * handing it the feeder's last-page granule (see the f32 path). */
      if (sound->end_granule > 0)
         audio_transfer_set_end_granule(xfer, type, sound->end_granule);
#endif
      /* Say what rate we mix at: an arm that can synthesise there will,
       * and the resampler below then has nothing to do. */
      audio_transfer_set_output_rate(xfer, type, (unsigned)s_rate);

#ifdef HAVE_RLPCM
      /* As above: raw samples with no header take the shape a headerless
       * file usually has, and a disc header keeps its own. */
      if (type == AUDIO_TYPE_LPCM)
      {
         rlpcm_format_t *fmt = (rlpcm_format_t*)audio_transfer_lpcm_format(xfer);
         if (fmt && !fmt->bits)
         {
            fmt->sample_rate = 48000;
            fmt->bits        = 16;
            fmt->channels    = 2;
            fmt->big_endian  = false;
         }
      }
#endif

      if (sound->container_track && !audio_transfer_set_container_track(xfer,
               type, (int)(sound->container_track - 1)))
      {
         audio_transfer_free(xfer, type);
         return false;
      }

      if (!audio_transfer_start(xfer, type))
      {
         audio_transfer_free(xfer, type);
         return false;
      }
   }
   audio_transfer_info(xfer, type, &channels, &rate, NULL);

   /* Mono is expanded and anything above stereo folded at fill time,
    * as on the float path; past the downmix table's reach there is no
    * sensible fold. */
   if (channels < 1 || channels > 8)
      goto error;
   /* The fill reads this to size its read and pick its fold.  Only the
    * float path used to set it, which was harmless while this one was
    * stereo-only and its fill assumed as much. */
   voice->types.stream.channels = channels;
#ifdef HAVE_RWMA
   if (type == AUDIO_TYPE_WMA && !audio_transfer_stereo_matrix(xfer,type,voice->types.stream.wma_matrix))
      goto error;
#endif

   if (rate != s_rate)
   {
      if (!s_rate || !rate)
         goto error;
      ratio      = (double)s_rate / (double)rate;
      if (!retro_resampler_int16_new(&rs, resampler_ident, quality,
               (ratio < 1.0) ? ratio : 1.0, false))
         goto error;
   }

   samples     = (unsigned)(AUDIO_MIXER_TEMP_BUFFER * ratio);
   samples     = ((samples + 2 * (unsigned)(ratio + 1.0) + 32) + 15) & ~15;
   voice->types.stream.decode_buf_s16 = (int16_t*)memalign_alloc(64,
         (AUDIO_MIXER_STREAM_BUF_OFFSET(sizeof(int16_t))
          + samples) * sizeof(int16_t));

   if (!voice->types.stream.decode_buf_s16)
   {
      if (rs.data)
         rs.free(rs.data);
      goto error;
   }
   /* The resampled buffer is a view into the decode block; release
    * frees the block through decode_buf_s16. */
   sbuf = voice->types.stream.decode_buf_s16
        + AUDIO_MIXER_STREAM_BUF_OFFSET(sizeof(int16_t));

   voice->types.stream.resampler       = NULL;
   voice->types.stream.resampler_data  = NULL;
   voice->types.stream.buffer          = NULL;
   voice->types.stream.resampler_int16 = rs;
   voice->types.stream.buffer_s16      = (int16_t*)sbuf;
   voice->types.stream.buf_samples     = samples;
   voice->types.stream.ratio           = ratio;
   voice->types.stream.stream          = xfer;
   voice->types.stream.position        = 0;
   voice->types.stream.samples         = 0;

   return true;

error:
   audio_transfer_free(xfer, type);
   return false;
}

#endif



audio_mixer_voice_t* audio_mixer_play(audio_mixer_sound_t* sound,
      bool repeat, float volume,
      const char *resampler_ident,
      enum resampler_quality quality,
      audio_mixer_stop_cb_t stop_cb)
{
   unsigned i;
   bool res                   = false;
   audio_mixer_voice_t* voice = s_voices;

   if (!sound)
      return NULL;

   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++, voice++)
   {
      if (retro_atomic_load_acquire_int(&voice->type)
            != AUDIO_MIXER_TYPE_NONE)
         continue;

      audio_mixer_voice_own(voice);

      if (retro_atomic_load_relaxed_int(&voice->type)
            != AUDIO_MIXER_TYPE_NONE)
      {
         audio_mixer_voice_disown(voice);
         continue;
      }

      /* claim the voice, also helps with cleanup on error */
      audio_mixer_feed_reset(voice, sound->initial_paused);
      retro_atomic_store_release_int(&voice->type, sound->type);

      switch (sound->type)
      {
         case AUDIO_MIXER_TYPE_WAV:
            /* float voice: build the float pipeline from the source
             * if it is not there yet (the sound was loaded for s16
             * before a mode flip) */
            res = wav_build_float(sound, resampler_ident, quality)
               && audio_mixer_play_wav(sound, voice, repeat, stop_cb);
            break;
         case AUDIO_MIXER_TYPE_WAV_STREAM:
#ifdef HAVE_RWAV
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_WAV);
#endif
            break;
         case AUDIO_MIXER_TYPE_OGG:
#ifdef HAVE_RVORBIS
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_VORBIS);
#endif
            break;
         case AUDIO_MIXER_TYPE_MOD:
#ifdef HAVE_RMODTRACKER
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_MOD);
#endif
            break;
         case AUDIO_MIXER_TYPE_FLAC:
#ifdef HAVE_RFLAC
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_FLAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_MP3:
#ifdef HAVE_RMP3
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_MP3);
#endif
            break;
         case AUDIO_MIXER_TYPE_M4A:
#ifdef HAVE_RAAC
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_AAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_AC3:
#ifdef HAVE_RAC3
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_AC3);
#endif
            break;
         case AUDIO_MIXER_TYPE_WMA:
#ifdef HAVE_RWMA
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_WMA);
#endif
            break;
         case AUDIO_MIXER_TYPE_LPCM:
#ifdef HAVE_RLPCM
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_LPCM);
#endif
            break;
         case AUDIO_MIXER_TYPE_OPUS:
#ifdef HAVE_ROPUS
            res = audio_mixer_play_stream(sound, voice, repeat, volume,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_OPUS);
#endif
            break;
         case AUDIO_MIXER_TYPE_WEBA: /* resolved at load; never stored */
         case AUDIO_MIXER_TYPE_NONE:
            break;
      }

      break;
   }

   if (res)
   {
      retro_atomic_store_relaxed_int(&voice->repeat, repeat ? 1 : 0);
      retro_atomic_store_relaxed_int(&voice->volume,
            audio_mixer_float_bits(volume));
      voice->sound    = sound;
      voice->stop_cb  = stop_cb;
      audio_mixer_feed_publish(voice);
      audio_mixer_voice_disown(voice);
   }
   else
   {
      if (i < AUDIO_MIXER_MAX_VOICES)
      {
         audio_mixer_release(voice);
         audio_mixer_voice_disown(voice);
      }
      voice = NULL;
   }

   return voice;
}

audio_mixer_voice_t* audio_mixer_play_s16(audio_mixer_sound_t* sound,
      bool repeat, int32_t gain,
      const char *resampler_ident,
      enum resampler_quality quality,
      audio_mixer_stop_cb_t stop_cb)
{
   unsigned i;
   bool res                   = false;
   audio_mixer_voice_t* voice = s_voices;

   if (!sound)
      return NULL;

   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++, voice++)
   {
      if (retro_atomic_load_acquire_int(&voice->type)
            != AUDIO_MIXER_TYPE_NONE)
         continue;

      audio_mixer_voice_own(voice);

      if (retro_atomic_load_relaxed_int(&voice->type)
            != AUDIO_MIXER_TYPE_NONE)
      {
         audio_mixer_voice_disown(voice);
         continue;
      }

      /* is_s16 before the release store that publishes the voice: the
       * unlocked voice counts read the flag only once type says the
       * voice is claimed, so it has to be set by then. */
      voice->is_s16 = true;
      audio_mixer_feed_reset(voice, sound->initial_paused);
      retro_atomic_store_release_int(&voice->type, sound->type);

      switch (sound->type)
      {
         case AUDIO_MIXER_TYPE_FLAC:
#ifdef HAVE_RFLAC
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_FLAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_WAV_STREAM:
#ifdef HAVE_RWAV
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_WAV);
#endif
            break;
         case AUDIO_MIXER_TYPE_OGG:
#ifdef HAVE_RVORBIS
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_VORBIS);
#endif
            break;
         case AUDIO_MIXER_TYPE_MP3:
#ifdef HAVE_RMP3
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_MP3);
#endif
            break;
         case AUDIO_MIXER_TYPE_M4A:
#ifdef HAVE_RAAC
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_AAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_AC3:
#ifdef HAVE_RAC3
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_AC3);
#endif
            break;
         case AUDIO_MIXER_TYPE_WMA:
#ifdef HAVE_RWMA
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_WMA);
#endif
            break;
         case AUDIO_MIXER_TYPE_LPCM:
#ifdef HAVE_RLPCM
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_LPCM);
#endif
            break;
         case AUDIO_MIXER_TYPE_OPUS:
#ifdef HAVE_ROPUS
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_OPUS);
#endif
            break;
         case AUDIO_MIXER_TYPE_MOD:
#ifdef HAVE_RMODTRACKER
            res = audio_mixer_play_stream_s16(sound, voice, repeat, gain,
                  resampler_ident, quality, stop_cb, AUDIO_TYPE_MOD);
#endif
            break;
         case AUDIO_MIXER_TYPE_WAV:
            /* s16 voice: build the s16 pipeline from the source if it
             * is not there yet (the sound was loaded for float before
             * a mode flip) */
            res = wav_build_s16(sound, resampler_ident, quality)
               && audio_mixer_play_wav(sound, voice, repeat, stop_cb);
            break;
         case AUDIO_MIXER_TYPE_WEBA: /* resolved at load; never stored */
         case AUDIO_MIXER_TYPE_NONE:
            break;
      }

      break;
   }

   if (res)
   {
      retro_atomic_store_relaxed_int(&voice->repeat, repeat ? 1 : 0);
      retro_atomic_store_relaxed_int(&voice->gain, (int)gain);
      voice->sound    = sound;
      voice->stop_cb  = stop_cb;
      audio_mixer_feed_publish(voice);
      audio_mixer_voice_disown(voice);
   }
   else
   {
      if (i < AUDIO_MIXER_MAX_VOICES)
      {
         audio_mixer_release(voice);
         audio_mixer_voice_disown(voice);
      }
      voice = NULL;
   }

   return voice;
}

/* The caller owns the voice.  */
static void audio_mixer_release(audio_mixer_voice_t* voice)
{
   if (!voice)
      return;

   switch (retro_atomic_load_relaxed_int(&voice->type))
   {
#ifdef HAVE_RWAV
      case AUDIO_MIXER_TYPE_WAV_STREAM:
         audio_mixer_release_stream(voice, AUDIO_TYPE_WAV);
         break;
#endif
#ifdef HAVE_RVORBIS
      case AUDIO_MIXER_TYPE_OGG:
         audio_mixer_release_stream(voice, AUDIO_TYPE_VORBIS);
         break;
#endif
#ifdef HAVE_RMODTRACKER
      case AUDIO_MIXER_TYPE_MOD:
         audio_mixer_release_stream(voice, AUDIO_TYPE_MOD);
         break;
#endif
#ifdef HAVE_RFLAC
      case AUDIO_MIXER_TYPE_FLAC:
         audio_mixer_release_stream(voice, AUDIO_TYPE_FLAC);
         break;
#endif
#ifdef HAVE_RMP3
      case AUDIO_MIXER_TYPE_MP3:
         audio_mixer_release_stream(voice, AUDIO_TYPE_MP3);
         break;
#endif
#ifdef HAVE_RAAC
      case AUDIO_MIXER_TYPE_M4A:
         audio_mixer_release_stream(voice, AUDIO_TYPE_AAC);
         break;
#endif
#ifdef HAVE_RAC3
      case AUDIO_MIXER_TYPE_AC3:
         audio_mixer_release_stream(voice, AUDIO_TYPE_AC3);
         break;
#endif
#ifdef HAVE_RWMA
      case AUDIO_MIXER_TYPE_WMA:
         audio_mixer_release_stream(voice, AUDIO_TYPE_WMA);
         break;
#endif
#ifdef HAVE_RLPCM
      case AUDIO_MIXER_TYPE_LPCM:
         audio_mixer_release_stream(voice, AUDIO_TYPE_LPCM);
         break;
#endif
#ifdef HAVE_ROPUS
      case AUDIO_MIXER_TYPE_OPUS:
         audio_mixer_release_stream(voice, AUDIO_TYPE_OPUS);
         break;
#endif
      default:
         break;
   }

   memset(&voice->types, 0, sizeof(voice->types));
   retro_atomic_store_release_int(&voice->type, AUDIO_MIXER_TYPE_NONE);
   voice->is_s16 = false;
}

void audio_mixer_stop(audio_mixer_voice_t* voice)
{
   audio_mixer_stop_cb_t stop_cb = NULL;
   audio_mixer_sound_t* sound    = NULL;

   if (voice)
   {
      audio_mixer_voice_own(voice);
      stop_cb     = voice->stop_cb;
      sound       = voice->sound;

      audio_mixer_release(voice);

      audio_mixer_voice_disown(voice);

      if (stop_cb)
         stop_cb(sound, AUDIO_MIXER_SOUND_STOPPED);
   }
}

static void audio_mixer_mix_wav(float* buffer, size_t num_frames,
      audio_mixer_voice_t* voice,
      float volume)
{
   int i;
   unsigned buf_free                = (unsigned)(num_frames * 2);
   const audio_mixer_sound_t* sound = voice->sound;
   unsigned pcm_available           = sound->types.wav.frames
      * 2 - voice->types.wav.position;
   const float* pcm                 = sound->types.wav.pcm +
      voice->types.wav.position;

again:
   if (pcm_available < buf_free)
   {
      voice->mixed_frames += pcm_available / 2;
      for (i = pcm_available; i != 0; i--)
         *buffer++ += *pcm++ * volume;

      if (retro_atomic_load_acquire_int(&voice->repeat))
      {
         if (voice->stop_cb)
            voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_REPEATED);

         buf_free                  -= pcm_available;
         pcm_available              = sound->types.wav.frames * 2;
         pcm                        = sound->types.wav.pcm;
         voice->types.wav.position  = 0;
         goto again;
      }

      if (voice->stop_cb)
         voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_FINISHED);

      audio_mixer_release(voice);
   }
   else
   {
      for (i = buf_free; i != 0; i--)
         *buffer++ += *pcm++ * volume;

      voice->types.wav.position += buf_free;
      voice->mixed_frames += buf_free / 2;
   }
}

/* The game audio a mix is summed onto without having been copied to
 * the mix first. The first voice to mix reads it in place of the mix;
 * what it leaves is copied across before the next voice. */
static const int16_t *mix_base;
static const int16_t *mix_base_start;
static int16_t       *mix_base_dst;
static size_t         mix_base_samples;

static INLINE const int16_t *audio_mixer_base_take(const int16_t *buffer,
      size_t samples)
{
   const int16_t *in;
   if (!mix_base)
      return buffer;
   in        = mix_base;
   mix_base += samples;
   return in;
}

static void audio_mixer_base_flush(void)
{
   size_t done;
   if (!mix_base)
      return;
   done = (size_t)(mix_base - mix_base_start);
   if (done < mix_base_samples)
      memcpy(mix_base_dst + done, mix_base,
            (mix_base_samples - done) * sizeof(int16_t));
   mix_base = NULL;
}

static void audio_mixer_mix_wav_s16(int16_t* buffer, size_t num_frames,
      audio_mixer_voice_t* voice,
      int32_t gain_q16)
{
   int i;
   unsigned buf_free                = (unsigned)(num_frames * 2);
   const audio_mixer_sound_t* sound = voice->sound;
   unsigned pcm_available           = sound->types.wav.frames_s16
      * 2 - voice->types.wav.position;
   const int16_t* pcm               = sound->types.wav.pcm_s16 +
      voice->types.wav.position;
   const int16_t* in;

again:
   if (pcm_available < buf_free)
   {
      voice->mixed_frames += pcm_available / 2;
      in = audio_mixer_base_take(buffer, pcm_available);
      for (i = pcm_available; i != 0; i--)
      {
         *buffer = audio_mixer_sat_s16((int32_t)*in++
               + audio_mixer_gain_s16(*pcm++, gain_q16));
         buffer++;
      }

      if (retro_atomic_load_acquire_int(&voice->repeat))
      {
         if (voice->stop_cb)
            voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_REPEATED);

         buf_free                  -= pcm_available;
         pcm_available              = sound->types.wav.frames_s16 * 2;
         pcm                        = sound->types.wav.pcm_s16;
         voice->types.wav.position  = 0;
         goto again;
      }

      if (voice->stop_cb)
         voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_FINISHED);

      audio_mixer_release(voice);
   }
   else
   {
      in = audio_mixer_base_take(buffer, buf_free);
      for (i = buf_free; i != 0; i--)
      {
         *buffer = audio_mixer_sat_s16((int32_t)*in++
               + audio_mixer_gain_s16(*pcm++, gain_q16));
         buffer++;
      }

      voice->types.wav.position += buf_free;
      voice->mixed_frames += buf_free / 2;
   }
}

#ifdef AUDIO_MIXER_HAS_STREAM



static void audio_mixer_mix_stream(float* buffer, size_t num_frames,
      audio_mixer_voice_t* voice,
      float volume,
      enum audio_type_enum type)
{
   int i;
   float* temp_buffer               = voice->types.stream.decode_buf;
   unsigned buf_free                = (unsigned)(num_frames * 2);
   unsigned temp_samples            = 0;
   float* pcm                       = NULL;
   int rewound                      = 0;
   int st                           = AUDIO_PROCESS_END;

   if (!voice->types.stream.stream)
      return;

   if (voice->types.stream.samples == 0)
   {
again:
      {
         size_t got = 0;
         st = AUDIO_PROCESS_END;
         if (voice->types.stream.channels == 1)
         {
            /* mono source: read into the front, then expand to
             * interleaved stereo in place, descending - sample n-1
             * is read before any destination at or above it is
             * written, so the source is never clobbered */
            unsigned n;
            st = audio_transfer_read_f32(voice->types.stream.stream, type,
                  temp_buffer, AUDIO_MIXER_TEMP_BUFFER / 2, &got);
            for (n = (unsigned)got; n > 0; n--)
            {
               float s            = temp_buffer[n - 1];
               temp_buffer[2*n-2] = s;
               temp_buffer[2*n-1] = s;
            }
         }
         else if (voice->types.stream.channels == 2)
            st = audio_transfer_read_f32(voice->types.stream.stream, type,
                  temp_buffer, AUDIO_MIXER_TEMP_BUFFER / 2, &got);
         else
         {
            /* Wider than stereo: the frames a read may ask for follow
             * the channel count, not the stereo figure, or the buffer
             * overruns.  Folded in place afterwards. */
            unsigned sch = voice->types.stream.channels;
            st = audio_transfer_read_f32(voice->types.stream.stream, type,
                  temp_buffer,
                  audio_mixer_frames_for(sch, AUDIO_MIXER_TEMP_BUFFER),
                  &got);
            audio_mixer_downmix_f32(temp_buffer, got, sch,
                  audio_mixer_downmix_table(type, sch, voice));
         }
         temp_samples = (unsigned)(got * 2);
      }

      if (temp_samples == 0)
      {
         /* Empty because the stream is starved, not finished: the
          * windowed source's feeder has not raised the resident bound
          * past the next packet yet.  Contribute silence to this call
          * and keep the voice exactly where it is - the next mix
          * retries.  Rewinding here is what played the same seconds
          * over and over, and releasing on the second stall is what
          * killed the voice outright, the moment a feeder ran one or
          * two ticks behind. */
         if (st == AUDIO_PROCESS_NEXT)
            return;

         /* A repeat that comes back empty from the start of the stream
          * has nothing left to hand out, and going round again would
          * not change that - it would spin here forever, holding the
          * mixer, with no frame ever produced.  One rewind is allowed
          * per empty read; a second in a row ends the voice the way a
          * stream that simply finished does. */
         if (     retro_atomic_load_acquire_int(&voice->repeat)
               && !rewound
               && audio_transfer_seek(voice->types.stream.stream, type, 0))
         {
            rewound = 1;
            audio_mixer_feed_rewound(voice);

            if (voice->stop_cb)
               voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_REPEATED);

            goto again;
         }

         if (voice->stop_cb)
            voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_FINISHED);

         audio_mixer_release(voice);
         return;
      }

      /* Frames came out, so the next empty read is a fresh end of
       * stream and gets its own rewind.  A sound shorter than one
       * mixing buffer loops more than once per call and must not be
       * cut off by the guard above. */
      rewound = 0;

      if (voice->types.stream.resampler)
      {
         struct resampler_data info;
         info.data_in = temp_buffer;
         info.data_out = voice->types.stream.buffer;
         info.input_frames = temp_samples / 2;
         info.output_frames = 0;
         info.ratio = voice->types.stream.ratio;

         voice->types.stream.resampler->process(
               voice->types.stream.resampler_data, &info);
         voice->types.stream.samples = (unsigned)(info.output_frames * 2);
         if (voice->types.stream.samples > voice->types.stream.buf_samples)
            voice->types.stream.samples = voice->types.stream.buf_samples;
      }
      else
      {
         voice->types.stream.samples = temp_samples;
      }

      voice->types.stream.position = 0;
   }

   /* With no resampler the samples are read where they were decoded */
   pcm = (voice->types.stream.resampler
         ? voice->types.stream.buffer : temp_buffer)
      + voice->types.stream.position;

   if (voice->types.stream.samples < buf_free)
   {
      voice->mixed_frames += voice->types.stream.samples / 2;
      for (i = voice->types.stream.samples; i != 0; i--)
         *buffer++ += *pcm++ * volume;

      buf_free -= voice->types.stream.samples;
      /* A partial contribution exhausted this buffer. If the refill
       * stalls, the next mix must retry decoding rather than replay
       * these already-counted samples. */
      voice->types.stream.samples = 0;
      voice->types.stream.position = 0;
      goto again;
   }

   for (i = buf_free; i != 0; --i )
      *buffer++ += *pcm++ * volume;

   voice->types.stream.position += buf_free;
   voice->types.stream.samples  -= buf_free;
   voice->mixed_frames += buf_free / 2;
}

static void audio_mixer_mix_stream_s16(int16_t* buffer, size_t num_frames,
      audio_mixer_voice_t* voice,
      int32_t gain_q16,
      enum audio_type_enum type)
{
   int i;
   struct resampler_data_int16 info;
   int16_t *temp_buffer  = voice->types.stream.decode_buf_s16;
   const int16_t *in;
   unsigned buf_free     = (unsigned)(num_frames * 2);
   unsigned temp_samples = 0;
   int16_t *pcm          = NULL;
   int rewound           = 0;
   int st                = AUDIO_PROCESS_END;

   if (!voice->types.stream.stream)
      return;

   if (voice->types.stream.samples == 0)
   {
again:
      {
         unsigned sch;
         size_t got = 0;
         st  = AUDIO_PROCESS_END;
         sch = voice->types.stream.channels;
         if (sch == 1)
         {
            /* Mono: the resampler downstream reads input_frames as
             * stereo pairs, so a mono read leaves the upper half of
             * every frame stale.  Expand in place, descending, so a
             * sample is read before anything at or above it is
             * written - the f32 path has always done this and this
             * one never did. */
            unsigned n;
            st = audio_transfer_read_s16(voice->types.stream.stream, type,
                  temp_buffer, AUDIO_MIXER_TEMP_BUFFER / 2, &got);
            for (n = (unsigned)got; n > 0; n--)
            {
               int16_t v          = temp_buffer[n - 1];
               temp_buffer[2*n-2] = v;
               temp_buffer[2*n-1] = v;
            }
         }
         else if (sch > 2)
         {
            /* See the f32 path: read what the buffer holds at this
             * channel count, then fold to stereo in place. */
            st = audio_transfer_read_s16(voice->types.stream.stream, type,
                  temp_buffer,
                  audio_mixer_frames_for(sch, AUDIO_MIXER_TEMP_BUFFER),
                  &got);
            audio_mixer_downmix_s16(temp_buffer, got, sch,
                  audio_mixer_downmix_table(type, sch, voice));
         }
         else
            st = audio_transfer_read_s16(voice->types.stream.stream, type,
                  temp_buffer, AUDIO_MIXER_TEMP_BUFFER / 2, &got);
         temp_samples = (unsigned)(got * 2);
      }
      if (temp_samples == 0)
      {
         /* Starved, not finished: see audio_mixer_mix_stream.  Silence
          * for this call; the voice stays put and the next mix
          * retries. */
         if (st == AUDIO_PROCESS_NEXT)
            return;

         /* See audio_mixer_mix_stream: one rewind per empty read, so a
          * repeat that yields nothing twice ends the voice instead of
          * spinning here with no frame ever produced. */
         if (     retro_atomic_load_acquire_int(&voice->repeat)
               && !rewound
               && audio_transfer_seek(voice->types.stream.stream, type, 0))
         {
            rewound = 1;
            audio_mixer_feed_rewound(voice);
            if (voice->stop_cb)
               voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_REPEATED);
            goto again;
         }
         if (voice->stop_cb)
            voice->stop_cb(voice->sound, AUDIO_MIXER_SOUND_FINISHED);
         audio_mixer_release(voice);
         return;
      }

      rewound = 0;

      info.data_in       = temp_buffer;
      info.data_out      = voice->types.stream.buffer_s16;
      info.input_frames  = temp_samples / 2;
      info.output_frames = 0;
      info.ratio         = voice->types.stream.ratio;

      if (voice->types.stream.resampler_int16.data)
      {
         voice->types.stream.resampler_int16.process(
               voice->types.stream.resampler_int16.data, &info);
         voice->types.stream.samples = (unsigned)(info.output_frames * 2);
         if (voice->types.stream.samples > voice->types.stream.buf_samples)
            voice->types.stream.samples = voice->types.stream.buf_samples;
      }
      else
         voice->types.stream.samples = temp_samples;
      voice->types.stream.position = 0;
   }

   /* With no resampler the samples are read where they were decoded */
   pcm = (voice->types.stream.resampler_int16.data
         ? voice->types.stream.buffer_s16 : temp_buffer)
      + voice->types.stream.position;

   if (voice->types.stream.samples < buf_free)
   {
      voice->mixed_frames += voice->types.stream.samples / 2;
      in = audio_mixer_base_take(buffer, voice->types.stream.samples);
      for (i = voice->types.stream.samples; i != 0; i--)
      {
         *buffer = audio_mixer_sat_s16((int32_t)*in++
               + audio_mixer_gain_s16(*pcm++, gain_q16));
         buffer++;
      }
      buf_free -= voice->types.stream.samples;
      voice->types.stream.samples = 0;
      voice->types.stream.position = 0;
      goto again;
   }

   in = audio_mixer_base_take(buffer, buf_free);
   for (i = buf_free; i != 0; --i)
   {
      *buffer = audio_mixer_sat_s16((int32_t)*in++
            + audio_mixer_gain_s16(*pcm++, gain_q16));
      buffer++;
   }

   voice->types.stream.position += buf_free;
   voice->types.stream.samples  -= buf_free;
   voice->mixed_frames += buf_free / 2;
}
#endif



void audio_mixer_mix(float* buffer, size_t num_frames,
      float volume_override, bool override)
{
   unsigned i;
   size_t j                   = 0;
   float* sample              = NULL;
   audio_mixer_voice_t* voice = s_voices;

   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++, voice++)
   {
      float volume;

      /* An idle voice holds nothing to mix, and one a caller holds is
       * not ready to be: both are passed over, the second without
       * waiting. The switch below reads type again once the voice is
       * the mix's, so one released in between lands on its NONE case. */
      if (     retro_atomic_load_acquire_int(&voice->type)
               == AUDIO_MIXER_TYPE_NONE
            || !audio_mixer_voice_try_own(voice))
         continue;

      if (voice->is_s16 || retro_atomic_load_acquire_int(&voice->paused))
      {
         audio_mixer_voice_disown(voice);
         continue;
      }

      volume = (override) ? volume_override
         : audio_mixer_bits_float(
               retro_atomic_load_relaxed_int(&voice->volume));

      audio_mixer_feed_apply(voice);

      switch (retro_atomic_load_relaxed_int(&voice->type))
      {
         case AUDIO_MIXER_TYPE_WAV:
            audio_mixer_mix_wav(buffer, num_frames, voice, volume);
            break;
         case AUDIO_MIXER_TYPE_WAV_STREAM:
#ifdef HAVE_RWAV
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_WAV);
#endif
            break;
         case AUDIO_MIXER_TYPE_OGG:
#ifdef HAVE_RVORBIS
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_VORBIS);
#endif
            break;
         case AUDIO_MIXER_TYPE_MOD:
#ifdef HAVE_RMODTRACKER
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_MOD);
#endif
            break;
         case AUDIO_MIXER_TYPE_FLAC:
#ifdef HAVE_RFLAC
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_FLAC);
#endif
            break;
            case AUDIO_MIXER_TYPE_MP3:
#ifdef HAVE_RMP3
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_MP3);
#endif
            break;
         case AUDIO_MIXER_TYPE_M4A:
#ifdef HAVE_RAAC
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_AAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_AC3:
#ifdef HAVE_RAC3
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_AC3);
#endif
            break;
         case AUDIO_MIXER_TYPE_WMA:
#ifdef HAVE_RWMA
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_WMA);
#endif
            break;
         case AUDIO_MIXER_TYPE_LPCM:
#ifdef HAVE_RLPCM
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_LPCM);
#endif
            break;
         case AUDIO_MIXER_TYPE_OPUS:
#ifdef HAVE_ROPUS
            audio_mixer_mix_stream(buffer, num_frames, voice, volume, AUDIO_TYPE_OPUS);
#endif
            break;
         case AUDIO_MIXER_TYPE_WEBA: /* resolved at load; never stored */
         case AUDIO_MIXER_TYPE_NONE:
            break;
      }

      audio_mixer_feed_publish(voice);
      audio_mixer_voice_disown(voice);
   }

   for (j = 0, sample = buffer; j < num_frames * 2; j++, sample++)
   {
      if (*sample < -1.0f)
         *sample = -1.0f;
      else if (*sample > 1.0f)
         *sample = 1.0f;
   }
}

void audio_mixer_mix_s16_over(int16_t *dst, const int16_t *base,
      size_t num_frames, int32_t gain_override, bool override)
{
   mix_base         = base;
   mix_base_start   = base;
   mix_base_dst     = dst;
   mix_base_samples = num_frames * 2;
   audio_mixer_mix_s16(dst, num_frames, gain_override, override);
   audio_mixer_base_flush();
}

void audio_mixer_mix_s16(int16_t* buffer, size_t num_frames,
      int32_t gain_override, bool override)
{
   unsigned i;
   audio_mixer_voice_t* voice = s_voices;

   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++, voice++)
   {
      int32_t gain_q16;

      /* Idle voices and ones a caller holds are passed over, as in
       * audio_mixer_mix() above */
      if (     retro_atomic_load_acquire_int(&voice->type)
               == AUDIO_MIXER_TYPE_NONE
            || !audio_mixer_voice_try_own(voice))
         continue;

      if (!voice->is_s16 || retro_atomic_load_acquire_int(&voice->paused))
      {
         audio_mixer_voice_disown(voice);
         continue;
      }

      /* Already Q16 on both sides, so nothing is computed here. This
       * used to convert a float per voice per mix call, on the audio
       * thread, in the pipeline that exists to avoid float. */
      gain_q16 = (override) ? gain_override
         : (int32_t)retro_atomic_load_relaxed_int(&voice->gain);

      audio_mixer_feed_apply(voice);

      switch (retro_atomic_load_relaxed_int(&voice->type))
      {
         case AUDIO_MIXER_TYPE_FLAC:
#ifdef HAVE_RFLAC
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_FLAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_WAV_STREAM:
#ifdef HAVE_RWAV
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_WAV);
#endif
            break;
         case AUDIO_MIXER_TYPE_OGG:
#ifdef HAVE_RVORBIS
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_VORBIS);
#endif
            break;
         case AUDIO_MIXER_TYPE_MP3:
#ifdef HAVE_RMP3
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_MP3);
#endif
            break;
         case AUDIO_MIXER_TYPE_M4A:
#ifdef HAVE_RAAC
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_AAC);
#endif
            break;
         case AUDIO_MIXER_TYPE_AC3:
#ifdef HAVE_RAC3
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_AC3);
#endif
            break;
         case AUDIO_MIXER_TYPE_WMA:
#ifdef HAVE_RWMA
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_WMA);
#endif
            break;
         case AUDIO_MIXER_TYPE_LPCM:
#ifdef HAVE_RLPCM
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_LPCM);
#endif
            break;
         case AUDIO_MIXER_TYPE_OPUS:
#ifdef HAVE_ROPUS
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_OPUS);
#endif
            break;
         case AUDIO_MIXER_TYPE_MOD:
#ifdef HAVE_RMODTRACKER
            audio_mixer_mix_stream_s16(buffer, num_frames, voice, gain_q16, AUDIO_TYPE_MOD);
#endif
            break;
         case AUDIO_MIXER_TYPE_WAV:
            audio_mixer_mix_wav_s16(buffer, num_frames, voice, gain_q16);
            break;
         case AUDIO_MIXER_TYPE_WEBA: /* resolved at load; never stored */
         case AUDIO_MIXER_TYPE_NONE:
            break;
      }

      audio_mixer_base_flush();
      audio_mixer_feed_publish(voice);
      audio_mixer_voice_disown(voice);
   }
   /* No final clamp: audio_mixer_mix_*_s16 saturate as they accumulate. */
}

float audio_mixer_voice_get_volume(audio_mixer_voice_t *voice)
{
   if (!voice)
      return 0.0f;

   return audio_mixer_bits_float(
         retro_atomic_load_relaxed_int(&voice->volume));
}

/* Whether any active voice would be handled by audio_mixer_mix (float) /
 * audio_mixer_mix_s16 (int16).  The frontend uses these to skip the
 * cross-format fold when every active voice already matches the buffer it
 * is mixing into. */
bool audio_mixer_has_float_voices(void)
{
   unsigned i;
   const audio_mixer_voice_t *voice = s_voices;
   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++, voice++)
      if (retro_atomic_load_acquire_int(&voice->type)
               != AUDIO_MIXER_TYPE_NONE && !voice->is_s16)
         return true;
   return false;
}

bool audio_mixer_has_s16_voices(void)
{
   unsigned i;
   const audio_mixer_voice_t *voice = s_voices;
   for (i = 0; i < AUDIO_MIXER_MAX_VOICES; i++, voice++)
      if (retro_atomic_load_acquire_int(&voice->type)
               != AUDIO_MIXER_TYPE_NONE && voice->is_s16)
         return true;
   return false;
}

int32_t audio_mixer_voice_get_gain(audio_mixer_voice_t *voice)
{
   if (!voice)
      return 0;

   return (int32_t)retro_atomic_load_relaxed_int(&voice->gain);
}

void audio_mixer_voice_set_repeat(audio_mixer_voice_t *voice, bool repeat)
{
   if (voice)
      retro_atomic_store_release_int(&voice->repeat, repeat ? 1 : 0);
}

void audio_mixer_voice_set_paused(audio_mixer_voice_t *voice, bool paused)
{
   if (voice)
      retro_atomic_store_release_int(&voice->paused, paused ? 1 : 0);
}

void audio_mixer_voice_set_gain(audio_mixer_voice_t *voice, int32_t gain)
{
   if (!voice)
      return;

   retro_atomic_store_relaxed_int(&voice->gain, (int)gain);
}

void audio_mixer_voice_set_volume(audio_mixer_voice_t *voice, float val)
{
   if (!voice)
      return;

   retro_atomic_store_relaxed_int(&voice->volume,
         audio_mixer_float_bits(val));
   /* Keep the s16 gain in step, so a caller that only knows the float
    * form still drives an s16 voice. The conversion happens here, on
    * the control path, and not on the audio thread. */
   retro_atomic_store_relaxed_int(&voice->gain,
         (int)(int32_t)(val * 65536.0f + 0.5f));
}
