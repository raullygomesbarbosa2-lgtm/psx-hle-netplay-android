/* Copyright  (C) 2026 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (net_socket_ssl_retro.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

/* TLS 1.2 and 1.3 client on the cleanroom crypto (crypto/), behind
 * the ssl_socket_* API. ECDHE over X25519, P-256 or P-384, RSA or ECDSA
 * server authentication against net/cacert.h, AES-128/256-GCM or
 * ChaCha20-Poly1305 records, SHA-256 or SHA-384 handshake and PRF as
 * the suite dictates; SNI sent. A connection given its own settings
 * (ssl_socket_retro_configure()) may also trust its own anchors, answer
 * a 1.2 CertificateRequest with an RSA certificate, and run the RSA key
 * exchange and AES-CBC suites. No renegotiation. The handshake runs to
 * completion inside ssl_socket_connect() as the other backends' do. */

#include <stddef.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <net/net_compat.h>
#include <net/net_socket.h>
#include <retro_atomic.h>
#include <boolean.h>
#include <queues/retro_retire.h>
#include <net/net_socket_ssl.h>
#include <crypto/crypto.h>
#include <crypto/kdf.h>
#include <crypto/pk.h>
#include <crypto/x509.h>
#include <lrc_hash.h>
#include <retro_miscellaneous.h>
#include <compat/strl.h>

#include "cacert.h"

#define TLS_REC_MAX      16384
/* explicit IV, MAC and padding of a CBC record; an AEAD's explicit
 * nonce and tag take less */
#define TLS_REC_OVERHEAD (16 + 48 + 16)
/* a ciphertext record carries at most 2^14 + 2048 octets */
#define TLS_REC_IN_MAX   (TLS_REC_MAX + 2048)
#define TLS_RX_SIZE      (5 + TLS_REC_IN_MAX)
#define TLS_HS_MAX       (64 * 1024)       /* certificate chains */

#define TLS_CT_CCS       20
#define TLS_CT_ALERT     21
#define TLS_CT_HANDSHAKE 22
#define TLS_CT_APPDATA   23

#define TLS_HS_CLIENT_HELLO     1
#define TLS_HS_SERVER_HELLO     2
#define TLS_HS_CERTIFICATE      11
#define TLS_HS_SERVER_KEX       12
#define TLS_HS_CERT_REQUEST     13
#define TLS_HS_SERVER_DONE      14
#define TLS_HS_CLIENT_KEX       16
#define TLS_HS_FINISHED         20

#define TLS_SUITE_ECDHE_ECDSA_AES128_GCM   0xc02b
#define TLS_SUITE_ECDHE_ECDSA_AES256_GCM   0xc02c
#define TLS_SUITE_ECDHE_RSA_AES128_GCM     0xc02f
#define TLS_SUITE_ECDHE_RSA_AES256_GCM     0xc030
#define TLS_SUITE_ECDHE_RSA_CHACHA20       0xcca8
#define TLS_SUITE_ECDHE_ECDSA_CHACHA20     0xcca9
/* TLS 1.3 (RFC 8446), the two SHA-256 suites */
#define TLS13_AES_128_GCM_SHA256           0x1301
#define TLS13_AES_256_GCM_SHA384           0x1302
#define TLS13_CHACHA20_POLY1305_SHA256     0x1303
#define TLS_HS_ENCRYPTED_EXTENSIONS 8
#define TLS_HS_CERTIFICATE_VERIFY   15
#define TLS_HS_KEY_UPDATE           24
#define TLS_HS_NEW_SESSION_TICKET   4

/* Error codes reported through ssl_socket_last_error(); negative like
 * mbedtls's so callers' "library error" logging stays meaningful. */
#define TLS_ERR_SOCKET      0
#define TLS_ERR_RECORD     -1
#define TLS_ERR_ALERT      -2
#define TLS_ERR_HANDSHAKE  -3
#define TLS_ERR_CIPHER     -4
#define TLS_ERR_CERT       -5
#define TLS_ERR_SIGNATURE  -6
#define TLS_ERR_KEX        -7
#define TLS_ERR_MEMORY     -8
#define TLS_ERR_VERSION    -9

/* Verification policy: written from the settings thread, read by
 * every connection thread, so it is an atomic that each connection
 * copies once at creation and keeps for its lifetime. 0 required,
 * 1 optional, 2 disabled. */
static retro_atomic_int_t tls_verify_mode_setting;

/* Session cache for resumption (RFC 5246 7.4.1.2 session ids, RFC 5077
 * tickets): one entry per host, oldest replaced. A resumed handshake
 * skips the certificate chain and the ECDHE exchange; the server
 * proves it holds the master secret from the verified full handshake
 * that produced the entry. Process-wide, never written to disk. */
#define TLS_CACHE_SLOTS   8
#define TLS_CACHE_MAX_AGE (6 * 60 * 60)

struct tls_session
{
   mpsc_stack_node_t node;   /* lock-free: on the retire list */
   uint8_t *ticket;
   size_t   ticket_len;
   time_t   when;
   unsigned suite;
   size_t   sid_len;
   uint8_t  sid[32];
   uint8_t  master[48];
   /* TLS 1.3: the ticket doubles as the PSK identity, psk is the
    * resumption secret expanded with the ticket nonce */
   uint8_t  is13;
   uint8_t  psk[48];
   uint32_t age_add;
   char     host[256];
};

/* What a handshake learns for a host: a ticket (TLS 1.2), a master
 * secret and suite (a full TLS 1.2 handshake), or a TLS 1.3 ticket and
 * its PSK. */
#define TLS_PUT_TICKET 1
#define TLS_PUT_MASTER 2
#define TLS_PUT_PSK    4

struct tls_session_put
{
   const uint8_t *ticket;
   size_t         ticket_len;
   const uint8_t *master;
   const uint8_t *sid;
   size_t         sid_len;
   const uint8_t *psk;
   unsigned       suite;
   uint32_t       age_add;
   unsigned       what;
};

/* @put into @e, whose ticket it takes over when it carries one: false
 * with @e untouched when the ticket cannot be copied. */
static bool tls_session_apply(struct tls_session *e,
      const struct tls_session_put *put)
{
   if (put->what & (TLS_PUT_TICKET | TLS_PUT_PSK))
   {
      uint8_t *t = (uint8_t*)malloc(put->ticket_len);
      if (!t)
         return false;
      memcpy(t, put->ticket, put->ticket_len);
      free(e->ticket);
      e->ticket     = t;
      e->ticket_len = put->ticket_len;
   }
   if (put->what & TLS_PUT_MASTER)
   {
      memcpy(e->master, put->master, 48);
      e->is13    = 0;
      e->suite   = put->suite;
      e->sid_len = put->sid_len;
      if (put->sid_len)
         memcpy(e->sid, put->sid, put->sid_len);
   }
   if (put->what & TLS_PUT_PSK)
   {
      e->is13    = 1;
      e->suite   = put->suite;
      e->sid_len = 0;
      e->age_add = put->age_add;
      memcpy(e->psk, put->psk, 48);
   }
   e->when = time(NULL);
   return true;
}

/* Connections are made from several threads (updater, achievements,
 * cloud sync); the cache is the one thing they share. */
#if defined(HAVE_THREADS) && defined(RETRO_RETIRE_LOCK_FREE) \
      && !defined(TLS_CACHE_TEST_FLAG)
/* Without a lock. Each slot points at an entry that is never changed
 * once published: a handshake that learns something builds the host's
 * entry anew and swaps it in, and a replaced entry goes once no reader
 * is in (retro_retire.h). */
#define TLS_CACHE_LOCK_FREE 1
static retro_atomic_ptr_t tls_cache[TLS_CACHE_SLOTS];
static retro_retire_t     tls_cache_retire;

static void tls_session_free(mpsc_stack_node_t *node)
{
   struct tls_session *e = (struct tls_session*)node;
   free(e->ticket);
   crypto_memzero(e, sizeof(*e));
   free(e);
}

static struct tls_session *tls_cache_at(unsigned i)
{
   return (struct tls_session*)retro_atomic_load_acquire_ptr(&tls_cache[i]);
}

#define TLS_CACHE_READ_BEGIN() retro_retire_enter(&tls_cache_retire)
#define TLS_CACHE_READ_END()   retro_retire_leave(&tls_cache_retire, tls_session_free)
#else
static struct tls_session tls_cache_store_[TLS_CACHE_SLOTS];
#define tls_cache_at(i) (&tls_cache_store_[(i)])

#ifdef HAVE_THREADS
#include <rthreads/rthreads.h>
/* A flag, not an slock: every section it guards is a lookup, a few
 * copies and at most one allocation, nothing that waits on another
 * thread, and with no lock object to make there is none that can fail
 * to be made. */
static retro_atomic_int_t tls_cache_busy;
static void tls_cache_lock(void)
{
   while (!retro_atomic_cas_int(&tls_cache_busy, 0, 1))
      sthread_yield();
}
#define TLS_CACHE_READ_BEGIN() tls_cache_lock()
#define TLS_CACHE_READ_END()   retro_atomic_store_release_int(&tls_cache_busy, 0)
#else
#define TLS_CACHE_READ_BEGIN() do { } while (0)
#define TLS_CACHE_READ_END()   do { } while (0)
#endif
#endif

static bool tls_cache_begin(bool nonblock)
{
#if defined(HAVE_THREADS) && !defined(TLS_CACHE_LOCK_FREE)
   if (nonblock)
      return retro_atomic_cas_int(&tls_cache_busy, 0, 1);
#else
   (void)nonblock;
#endif
   TLS_CACHE_READ_BEGIN();
   return true;
}

/* Between TLS_CACHE_READ_BEGIN() and _END(): the host's live entry. */
static struct tls_session *tls_cache_find(const char *host)
{
   unsigned i;
   if (!host || !*host)
      return NULL;
   for (i = 0; i < TLS_CACHE_SLOTS; i++)
   {
      struct tls_session *e = tls_cache_at(i);
      if (e && e->when && strcmp(e->host, host) == 0)
      {
#ifdef TLS_CACHE_TEST_HOLD
         TLS_CACHE_TEST_HOLD();
#endif
         if (time(NULL) - e->when > TLS_CACHE_MAX_AGE)
            return NULL;
         return e;
      }
   }
   return NULL;
}

/* The slot for @host: its own, else an empty one, else the oldest. */
static unsigned tls_cache_slot_for(const char *host)
{
   unsigned i, oldest = 0;
   for (i = 0; i < TLS_CACHE_SLOTS; i++)
   {
      struct tls_session *e = tls_cache_at(i);
      if (e && e->when && strcmp(e->host, host) == 0)
         return i;
   }
   for (i = 0; i < TLS_CACHE_SLOTS; i++)
   {
      struct tls_session *e = tls_cache_at(i);
      struct tls_session *o = tls_cache_at(oldest);
      if (!e || !e->when)
         return i;
      if (o && e->when < o->when)
         oldest = i;
   }
   return oldest;
}

/* @put into @host's entry, made if it has none. */
static void tls_cache_put(const char *host, const struct tls_session_put *put,
      bool nonblock)
{
#ifdef TLS_CACHE_LOCK_FREE
   if (!host || !*host)
      return;
   for (;;)
   {
      struct tls_session *old, *e;
      unsigned slot;
      retro_retire_enter(&tls_cache_retire);
      slot = tls_cache_slot_for(host);
      old  = tls_cache_at(slot);
      if (!(e = (struct tls_session*)calloc(1, sizeof(*e))))
      {
         retro_retire_leave(&tls_cache_retire, tls_session_free);
         return;
      }
      if (old && old->when && strcmp(old->host, host) == 0)
      {
         /* all but the link, which retiring @old may be writing */
         memcpy(&e->ticket, &old->ticket,
               sizeof(*e) - offsetof(struct tls_session, ticket));
         e->ticket = NULL;
         if (     old->ticket && !(put->what & (TLS_PUT_TICKET | TLS_PUT_PSK))
               && (e->ticket = (uint8_t*)malloc(old->ticket_len)))
            memcpy(e->ticket, old->ticket, old->ticket_len);
         else
            e->ticket_len = 0;
      }
      else
         strlcpy(e->host, host, sizeof(e->host));
      retro_retire_leave(&tls_cache_retire, tls_session_free);
      if (!tls_session_apply(e, put))
      {
         tls_session_free(&e->node);
         return;
      }
      /* the entry we built on, if still the slot's, is ours to replace */
      if (retro_atomic_cas_ptr(&tls_cache[slot], old, e))
      {
         retro_retire(&tls_cache_retire, old ? &old->node : NULL,
               tls_session_free);
         return;
      }
      tls_session_free(&e->node);
      if (nonblock)
         return;
   }
#else
   struct tls_session *e;
   if (!host || !*host)
      return;
   if (!tls_cache_begin(nonblock))
      return;
   e = tls_cache_at(tls_cache_slot_for(host));
   if (!e->when || strcmp(e->host, host))
   {
      free(e->ticket);
      crypto_memzero(e, sizeof(*e));
      strlcpy(e->host, host, sizeof(e->host));
   }
   tls_session_apply(e, put);
   TLS_CACHE_READ_END();
#endif
}

/* The trust bundle is net/cacert.h's DER parts, a system bundle
 * preloaded at startup, or a test's PEM. Both statics are written
 * before any network thread exists. */
static const char *tls_test_pem       = NULL;
static size_t      tls_test_pem_len   = 0;
static int         tls_system_anchors = 0;
static char        tls_system_source[PATH_MAX_LENGTH];
static retro_atomic_int_t tls_trust_logged;

#ifndef TLS_LOG_TRUST_STORE
#define TLS_LOG_TRUST_STORE ssl_socket_log_trust_store
#endif

int ssl_socket_retro_adopt_trust_pem(char *pem, size_t len,
      const char *name)
{
   int loaded;
   if (tls_system_anchors || tls_test_pem || !pem || !len)
   {
      free(pem);
      return tls_system_anchors;
   }
   if ((loaded = x509_trust_adopt_pem(pem, len)) <= 0)
      return 0;
   tls_system_anchors = loaded;
   strlcpy(tls_system_source, name ? name : "",
         sizeof(tls_system_source));
   return loaded;
}

void ssl_socket_retro_set_trust_pem(const char *pem, size_t len)
{
   if (tls_system_anchors)
      return;
   tls_test_pem     = pem;
   tls_test_pem_len = len;
}

static int tls_trust_load(void)
{
   if (tls_test_pem)
      return x509_trust_load_pem(tls_test_pem, tls_test_pem_len);
   return x509_trust_load_der_parts(cacert_der_parts, cacert_der_sizes,
         CACERT_DER_PARTS);
}

enum tls_connect_phase
{
   TLS_CONNECT_START = 0,
   TLS_CONNECT_HELLO,
   TLS_CONNECT_CERT12,
   TLS_CONNECT_KEX12,
   TLS_CONNECT_DONE12,
   TLS_CONNECT_SEND_CERT12,
   TLS_CONNECT_SEND_KEX12,
   TLS_CONNECT_SEND_VERIFY12,
   TLS_CONNECT_SEND_CCS12,
   TLS_CONNECT_SEND_FIN12,
   TLS_CONNECT_TICKET12,
   TLS_CONNECT_CCS12,
   TLS_CONNECT_FIN12,
   TLS_CONNECT_COMPLETE12,
   TLS_CONNECT_KEYS13,
   TLS_CONNECT_EXT13,
   TLS_CONNECT_CERT13,
   TLS_CONNECT_VERIFY13,
   TLS_CONNECT_FIN13,
   TLS_CONNECT_SEND_CCS13,
   TLS_CONNECT_SEND_FIN13,
   TLS_CONNECT_COMPLETE13,
   TLS_CONNECT_FAILED
};

struct tls_handshake_progress
{
   struct x509_cert leaf; /* borrows DER in the handshake accumulator */
   size_t peer_len;
   enum tls_connect_phase phase;
   uint8_t peer[97];
};

struct ssl_state
{
   uint8_t *rx;             /* raw record buffer */
   uint8_t *hs;             /* handshake message accumulator */
   uint8_t *connect_message; /* encoded handshake, owned until sealed */
   /* decrypted application data pending: a record's plaintext where
    * it was decrypted, in rx - the next record read comes only once
    * this is drained, so it is handed out with no copy of its own */
   const uint8_t *pt;
   const char *domain;
   size_t   rx_len;
   size_t   hs_len;
   size_t   hs_off;
   size_t   pt_len;
   size_t   pt_off;
   size_t   connect_length;
   size_t   connect_offset;
   uint64_t cseq;
   uint64_t sseq;
   struct sha256_state transcript;
   struct sha512_state transcript384;
   int      fd;
   /* atomic: in duplex mode the receiving and the sending thread can
    * both fail at once */
   retro_atomic_int_t last_err;
   unsigned suite;
   unsigned group;          /* 23 P-256, 24 P-384 */
   uint8_t  client_random[32];
   uint8_t  server_random[32];
   uint8_t  master[48];
   uint8_t  cwk[32];
   uint8_t  swk[32];
   /* AES-GCM key schedules for cwk / swk, built when a key is first
    * used and again only when it changes, not once per record */
   struct tls_gcm_cache
   {
      struct aes_gcm_ctx g;
      uint8_t  key[32];
      unsigned key_len;             /* 0: nothing built yet */
   } wgcm, rgcm;
   uint8_t  civ[12];
   uint8_t  siv[12];
   uint8_t  priv[48];
   uint8_t  premaster[48];
   uint8_t  rx_encrypted;
   uint8_t  tx_encrypted;
   uint8_t  handshake_done;
   uint8_t  closed;
   uint8_t  notified;       /* close_notify sent: no more records out */
   bool connect_nonblock;
   bool connect_read;
   bool connect_write;
   /* Handshake flights are corked: the client's records go out in one
    * write, since sending ClientKeyExchange, ChangeCipherSpec and
    * Finished as three small writes trips Nagle against the server's
    * delayed ACK and costs a 40 ms stall per full handshake. */
   uint8_t *cork;
   size_t   cork_len;
   size_t   cork_off;
   uint8_t  corked;
   /* A KeyUpdate of ours is owed: set by the receiving side when the
    * server asks for one, sent and cleared by the sending side (in
    * duplex mode those are two threads) */
   retro_atomic_int_t key_update;
   /* One sealed application-data record not yet fully on the wire,
    * for ssl_socket_send_all_nonblocking(): bytes are sealed as they
    * are accepted, and what the socket did not take waits here.
    * Allocated on first use. */
   uint8_t *tx;
   size_t   tx_len;
   size_t   tx_off;
   uint8_t  resumed;        /* this connection resumed a session */
   uint8_t  expect_ticket;  /* server said it will send a NewSessionTicket */
   uint8_t  offered_sid[32];
   size_t   offered_sid_len;
   /* TLS 1.3 */
   unsigned verify_mode;    /* this connection's copy of the policy */
   uint8_t  v13;            /* the server chose 1.3 */
   uint8_t  pub[65];        /* our P-256 key share */
   uint8_t  xpriv[32];      /* our X25519 key share */
   uint8_t  xpub[32];
   uint8_t  hs_secret[48];  /* handshake secret, for the master derivation */
   uint8_t  c_app[48];      /* client/server application traffic secrets */
   uint8_t  s_app[48];
   uint8_t  s_hs[48];       /* server handshake traffic secret (Finished key) */
   uint8_t  c_hs[48];
   uint8_t  cert_hash[48];  /* transcript hash up to Certificate, for CertificateVerify */
   uint8_t  tls13_peer[65]; /* server key share from the ServerHello */
   size_t   tls13_peer_len;
   uint8_t  master13[48];   /* 1.3 master secret until the resumption secret is taken */
   uint8_t  res_master[48]; /* resumption master secret, for the tickets */
   uint8_t  psk[48];        /* PSK offered in this ClientHello */
   uint8_t  psk_offered;
   uint8_t  psk_accepted;
   /* ssl_socket_retro_configure() */
   struct ssl_socket_retro_config cfg;
   uint8_t  configured;
   uint8_t  offer13;        /* the ClientHello offers TLS 1.3 */
   unsigned offered[24];    /* suites offered, for the ServerHello check */
   unsigned offered_count;
   unsigned cached_suite;
   /* CertificateRequest: 1 to answer with our chain, 2 with none */
   uint8_t  cert_requested;
   unsigned cv_alg;         /* the scheme our CertificateVerify signs with */
   struct sha1_state transcript1;   /* for an rsa_pkcs1_sha1 CertificateVerify */
   size_t   premaster_len;
   /* CBC suites: MAC keys and the AES schedules for cwk / swk */
   uint8_t  cmac[48];
   uint8_t  smac[48];
   struct tls_cbc_cache
   {
      struct aes_ctx a;
      uint8_t  key[32];
      unsigned key_len;
   } wcbc, rcbc;
   struct tls_handshake_progress connect;
   /* The blocking mode this connection last gave its socket: 0 not known,
    * 1 nonblocking, 2 blocking. The socket is the connection's, so it is
    * set only when it changes, not with two system calls on every
    * receive and send. */
   uint8_t  fd_mode;
};

/* SSL_RETRO_DUPLEX: one thread receives while another sends */
static INLINE int tls_duplex(const struct ssl_state *s)
{
   return s->configured && (s->cfg.flags & SSL_RETRO_DUPLEX);
}

/* The socket blocking (@block) or not, without a system call when it
 * already is */
static bool tls_set_block(struct ssl_state *s, bool block)
{
   uint8_t want = block ? 2 : 1;
   if (s->fd_mode == want)
      return true;
   if (!socket_set_block(s->fd, block))
   {
      s->fd_mode = 0;
      return false;
   }
   s->fd_mode = want;
   return true;
}

/* ---- byte helpers ------------------------------------------------- */

static void tls_put16(uint8_t *p, unsigned v)
{
   p[0] = (uint8_t)(v >> 8);
   p[1] = (uint8_t)v;
}

static unsigned tls_get16(const uint8_t *p)
{
   return ((unsigned)p[0] << 8) | p[1];
}

static unsigned tls_get24(const uint8_t *p)
{
   return ((unsigned)p[0] << 16) | ((unsigned)p[1] << 8) | p[2];
}

/* ---- PRF ---------------------------------------------------------- */

/* Every suite the client knows: the key exchange, the record cipher,
 * key and MAC lengths (0: an AEAD), and whether the 1.2 PRF and
 * transcript run on SHA-384. */
#define TLS_KX_ECDHE 0
#define TLS_KX_RSA   1
#define TLS_KX_13    2

#define TLS_CIPHER_GCM    0
#define TLS_CIPHER_CHACHA 1
#define TLS_CIPHER_CBC    2

struct tls_suite_info
{
   unsigned id;
   uint8_t  kx;
   uint8_t  cipher;
   uint8_t  key_len;
   uint8_t  mac_len;
   uint8_t  sha384;
};

static const struct tls_suite_info tls_suite_table[] = {
   { 0x1301, TLS_KX_13,    TLS_CIPHER_GCM,    16, 0,  0 },
   { 0x1302, TLS_KX_13,    TLS_CIPHER_GCM,    32, 0,  1 },
   { 0x1303, TLS_KX_13,    TLS_CIPHER_CHACHA, 32, 0,  0 },
   { 0xc02b, TLS_KX_ECDHE, TLS_CIPHER_GCM,    16, 0,  0 },
   { 0xc02c, TLS_KX_ECDHE, TLS_CIPHER_GCM,    32, 0,  1 },
   { 0xc02f, TLS_KX_ECDHE, TLS_CIPHER_GCM,    16, 0,  0 },
   { 0xc030, TLS_KX_ECDHE, TLS_CIPHER_GCM,    32, 0,  1 },
   { 0xcca8, TLS_KX_ECDHE, TLS_CIPHER_CHACHA, 32, 0,  0 },
   { 0xcca9, TLS_KX_ECDHE, TLS_CIPHER_CHACHA, 32, 0,  0 },
   /* offered only when a connection asks for them */
   { 0xc013, TLS_KX_ECDHE, TLS_CIPHER_CBC,    16, 20, 0 },
   { 0xc014, TLS_KX_ECDHE, TLS_CIPHER_CBC,    32, 20, 0 },
   { 0xc027, TLS_KX_ECDHE, TLS_CIPHER_CBC,    16, 32, 0 },
   { 0xc028, TLS_KX_ECDHE, TLS_CIPHER_CBC,    32, 48, 1 },
   { 0x009c, TLS_KX_RSA,   TLS_CIPHER_GCM,    16, 0,  0 },
   { 0x009d, TLS_KX_RSA,   TLS_CIPHER_GCM,    32, 0,  1 },
   { 0x002f, TLS_KX_RSA,   TLS_CIPHER_CBC,    16, 20, 0 },
   { 0x0035, TLS_KX_RSA,   TLS_CIPHER_CBC,    32, 20, 0 },
   { 0x003c, TLS_KX_RSA,   TLS_CIPHER_CBC,    16, 32, 0 },
   { 0x003d, TLS_KX_RSA,   TLS_CIPHER_CBC,    32, 32, 0 }
};

static const struct tls_suite_info *tls_suite(unsigned id)
{
   unsigned i;
   for (i = 0; i < sizeof(tls_suite_table) / sizeof(tls_suite_table[0]); i++)
      if (tls_suite_table[i].id == id)
         return &tls_suite_table[i];
   return NULL;
}

static int tls_suite_is_13(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i && i->kx == TLS_KX_13;
}

static int tls_suite_is_chacha(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i && i->cipher == TLS_CIPHER_CHACHA;
}

static int tls_suite_is_cbc(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i && i->cipher == TLS_CIPHER_CBC;
}

static int tls_suite_is_aes256(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i && i->cipher != TLS_CIPHER_CHACHA && i->key_len == 32;
}

static size_t tls_suite_key_len(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i ? i->key_len : 16;
}

static size_t tls_suite_mac_len(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i ? i->mac_len : 0;
}

/* The GCM context for @key (cwk or swk), rebuilt only when the key
 * differs from the one it was built from. */
static const struct aes_gcm_ctx *tls_gcm(struct ssl_state *s,
      struct tls_gcm_cache *c, const uint8_t *key)
{
   unsigned klen = tls_suite_is_aes256(s->suite) ? 32 : 16;
   if (c->key_len != klen || memcmp(c->key, key, klen) != 0)
   {
      if (aes_gcm_init(&c->g, key, klen) != 0)
      {
         c->key_len = 0;
         return NULL;
      }
      memcpy(c->key, key, klen);
      c->key_len = klen;
   }
   return &c->g;
}

/* The CBC schedule for @key, built as tls_gcm() builds its own. */
static const struct aes_ctx *tls_cbc(struct ssl_state *s,
      struct tls_cbc_cache *c, const uint8_t *key)
{
   unsigned klen = (unsigned)tls_suite_key_len(s->suite);
   if (c->key_len != klen || memcmp(c->key, key, klen) != 0)
   {
      if (aes_init(&c->a, key, klen) != 0)
      {
         c->key_len = 0;
         return NULL;
      }
      memcpy(c->key, key, klen);
      c->key_len = klen;
   }
   return &c->a;
}

/* The record MAC of a CBC suite: HMAC(key, seq || type || version ||
 * length || data), SHA-1, SHA-256 or SHA-384 by the suite. @pad more
 * octets go through a throwaway hash, so that a record's MAC costs the
 * same whatever its padding length (Lucky 13). */
static void tls_cbc_mac(const struct ssl_state *s, const uint8_t *key,
      const uint8_t *hdr, const uint8_t *data, size_t len, size_t pad,
      uint8_t *out)
{
   static const uint8_t zeros[256] = {0};
   size_t mlen = tls_suite_mac_len(s->suite);
   union
   {
      struct hmac_sha1_ctx   h1;
      struct hmac_sha256_ctx h256;
      struct hmac_sha384_ctx h384;
   } h;
   union
   {
      struct sha1_state   s1;
      struct sha256_state s256;
      struct sha512_state s384;
   } d;

   if (mlen == 20)
   {
      hmac_sha1_init(&h.h1, key, 20);
      hmac_sha1_update(&h.h1, hdr, 13);
      hmac_sha1_update(&h.h1, data, len);
      hmac_sha1_final(&h.h1, out);
      sha1_stream_init(&d.s1);
      sha1_stream_update(&d.s1, zeros, pad);
   }
   else if (mlen == 32)
   {
      hmac_sha256_init(&h.h256, key, 32);
      hmac_sha256_update(&h.h256, hdr, 13);
      hmac_sha256_update(&h.h256, data, len);
      hmac_sha256_final(&h.h256, out);
      sha256_stream_init(&d.s256, 0);
      sha256_stream_update(&d.s256, zeros, pad);
   }
   else
   {
      hmac_sha384_init(&h.h384, key, 48);
      hmac_sha384_update(&h.h384, hdr, 13);
      hmac_sha384_update(&h.h384, data, len);
      hmac_sha384_final(&h.h384, out);
      sha512_stream_init(&d.s384, 1);
      sha512_stream_update(&d.s384, zeros, pad);
   }
}

static int tls_suite_is_sha384(unsigned suite)
{
   const struct tls_suite_info *i = tls_suite(suite);
   return i && i->sha384;
}

/* TLS 1.2 PRF: P_<hash>(secret, label || seed), hash per suite. */
static void tls_prf(const struct ssl_state *s,
      const uint8_t *secret, size_t secret_len,
      const char *label, const uint8_t *seed1, size_t seed1_len,
      const uint8_t *seed2, size_t seed2_len, uint8_t *out, size_t out_len)
{
   union
   {
      struct hmac_sha256_ctx h256;
      struct hmac_sha384_ctx h384;
   } h;
   const int use384  = tls_suite_is_sha384(s->suite);
   const size_t hlen = use384 ? 48 : 32;
   uint8_t a[48];
   uint8_t p[48];
   size_t  label_len = strlen(label);

#define TLS_HMAC_INIT()   do { if (use384) hmac_sha384_init(&h.h384, secret, secret_len); else hmac_sha256_init(&h.h256, secret, secret_len); } while (0)
#define TLS_HMAC_UPD(d, l) do { if (use384) hmac_sha384_update(&h.h384, d, l); else hmac_sha256_update(&h.h256, d, l); } while (0)
#define TLS_HMAC_FIN(o)   do { if (use384) hmac_sha384_final(&h.h384, o); else hmac_sha256_final(&h.h256, o); } while (0)

   /* A(1) = HMAC(secret, A(0)), A(0) = label || seed */
   TLS_HMAC_INIT();
   TLS_HMAC_UPD((const uint8_t*)label, label_len);
   TLS_HMAC_UPD(seed1, seed1_len);
   TLS_HMAC_UPD(seed2, seed2_len);
   TLS_HMAC_FIN(a);

   while (out_len)
   {
      size_t take = out_len < hlen ? out_len : hlen;
      TLS_HMAC_INIT();
      TLS_HMAC_UPD(a, hlen);
      TLS_HMAC_UPD((const uint8_t*)label, label_len);
      TLS_HMAC_UPD(seed1, seed1_len);
      TLS_HMAC_UPD(seed2, seed2_len);
      TLS_HMAC_FIN(p);
      memcpy(out, p, take);
      out     += take;
      out_len -= take;

      TLS_HMAC_INIT();
      TLS_HMAC_UPD(a, hlen);
      TLS_HMAC_FIN(a);
   }
#undef TLS_HMAC_INIT
#undef TLS_HMAC_UPD
#undef TLS_HMAC_FIN
   crypto_memzero(a, sizeof(a));
   crypto_memzero(p, sizeof(p));
}

/* Transcript hash so far, in the suite's hash; both digests run until
 * the ServerHello picks one. */
static size_t tls_transcript(const struct ssl_state *s, uint8_t *out)
{
   if (tls_suite_is_sha384(s->suite))
   {
      struct sha512_state t = s->transcript384;
      sha512_stream_final(&t, out);
      return 48;
   }
   else
   {
      struct sha256_state t = s->transcript;
      sha256_stream_final(&t, out);
      return 32;
   }
}

/* ---- record layer ------------------------------------------------- */

/* Sends one record of @type carrying @len octets of @data, encrypting
 * once the client write keys are in force. */
#define TLS_CORK_MAX 1024

static void tls_cork(struct ssl_state *s)
{
   s->corked   = 1;
   s->cork_len = s->cork_off = 0;
}

/* Sends what was corked in one write. */
static int tls_uncork(struct ssl_state *s)
{
   int ok = 1;
   s->corked = 0;
   if (s->connect_nonblock)
      return 0;
   if (s->cork_len)
      ok = socket_send_all_blocking(s->fd, s->cork, s->cork_len, true);
   s->cork_len = 0;
   if (!ok)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
      return -1;
   }
   return 0;
}

/* Seal @len bytes of @type into @rec (room for 5 + len +
 * TLS_REC_OVERHEAD), advancing the write sequence.  *@out_len is the
 * record's length on the wire. */
static int tls_seal_record(struct ssl_state *s, uint8_t type,
      const uint8_t *data, size_t len, uint8_t *rec, size_t *out_len)
{
   size_t   rec_len;

   if (len > TLS_REC_MAX)
      return -1;

   rec[0] = type;
   rec[1] = 3;
   rec[2] = 3;

   if (!s->tx_encrypted)
   {
      tls_put16(rec + 3, (unsigned)len);
      memcpy(rec + 5, data, len);
      rec_len = 5 + len;
   }
   else if (s->v13)
   {
      /* TLS 1.3: outer type application_data, inner = data || type,
       * nonce = iv XOR seq, AAD = the 5-octet header */
      uint8_t aad[5];
      uint8_t nonce[12];
      uint8_t *body = rec + 5;
      size_t  i;

      rec[0] = TLS_CT_APPDATA;
      memcpy(body, data, len);
      body[len] = type;
      rec_len = 5 + len + 1 + 16;
      aad[0] = TLS_CT_APPDATA; aad[1] = 3; aad[2] = 3;
      tls_put16(aad + 3, (unsigned)(rec_len - 5));
      memcpy(nonce, s->civ, 12);
      for (i = 0; i < 8; i++)
         nonce[4 + i] ^= (uint8_t)(s->cseq >> (56 - 8 * i));
      if (tls_suite_is_chacha(s->suite))
      {
         if (aead_encrypt(AEAD_CHACHA20_POLY1305, s->cwk, 32, nonce, 12,
                  aad, 5, body, len + 1, body, body + len + 1, 16) != 0)
            goto fail;
      }
      else
      {
         const struct aes_gcm_ctx *g = tls_gcm(s, &s->wgcm, s->cwk);
         if (!g || aes_gcm_encrypt(g, nonce, 12, aad, 5, body, len + 1,
                     body, body + len + 1) != 0)
            goto fail;
      }
      tls_put16(rec + 3, (unsigned)(rec_len - 5));
      s->cseq++;
   }
   else if (tls_suite_is_cbc(s->suite))
   {
      /* MAC-then-encrypt (RFC 5246 6.2.3.2): an explicit random IV,
       * then data || MAC || padding under AES-CBC */
      const struct aes_ctx *a = tls_cbc(s, &s->wcbc, s->cwk);
      size_t   plen = len + tls_suite_mac_len(s->suite);
      size_t   pad  = 16 - (plen & 15);
      uint8_t *body = rec + 5 + 16;
      uint8_t  hdr[13];
      uint8_t  iv[16];

      if (!a || crypto_random_bytes(rec + 5, 16) != 0)
         goto fail;
      crypto_store64_be(hdr, s->cseq);
      hdr[8]  = type;
      hdr[9]  = 3;
      hdr[10] = 3;
      tls_put16(hdr + 11, (unsigned)len);
      memcpy(body, data, len);
      tls_cbc_mac(s, s->cmac, hdr, data, len, 0, body + len);
      memset(body + plen, (int)(pad - 1), pad);
      memcpy(iv, rec + 5, 16);
      aes_cbc_encrypt(a, iv, body, body, plen + pad);
      rec_len = 5 + 16 + plen + pad;
      tls_put16(rec + 3, (unsigned)(rec_len - 5));
      s->cseq++;
   }
   else
   {
      uint8_t aad[13];
      uint8_t nonce[12];
      uint8_t *body = rec + 5;
      size_t  i;

      crypto_store64_be(aad, s->cseq);
      aad[8] = type;
      aad[9] = 3;
      aad[10] = 3;
      tls_put16(aad + 11, (unsigned)len);

      if (tls_suite_is_chacha(s->suite))
      {
         /* nonce = write_iv XOR (0^4 || seq) */
         memcpy(nonce, s->civ, 12);
         for (i = 0; i < 8; i++)
            nonce[4 + i] ^= (uint8_t)(s->cseq >> (56 - 8 * i));
         if (aead_encrypt(AEAD_CHACHA20_POLY1305, s->cwk, 32, nonce, 12,
                  aad, 13, data, len, body, body + len, 16) != 0)
            goto fail;
         rec_len = 5 + len + 16;
      }
      else
      {
         /* nonce = write_iv (4) || explicit (8) = seq; explicit sent */
         const struct aes_gcm_ctx *g = tls_gcm(s, &s->wgcm, s->cwk);
         memcpy(nonce, s->civ, 4);
         crypto_store64_be(nonce + 4, s->cseq);
         memcpy(body, nonce + 4, 8);
         if (!g || aes_gcm_encrypt(g, nonce, 12, aad, 13, data, len,
                     body + 8, body + 8 + len) != 0)
            goto fail;
         rec_len = 5 + 8 + len + 16;
      }
      tls_put16(rec + 3, (unsigned)(rec_len - 5));
      s->cseq++;
   }

   *out_len = rec_len;
   return 0;

fail:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_CIPHER);
   return -1;
}

/* Put a pending non-blocking record on the wire before anything else
 * goes out, so records leave in sequence order. */
static int tls_control_push(struct ssl_state *s);

static int tls_tx_drain_blocking(struct ssl_state *s)
{
   int result;
   while ((result = tls_control_push(s)) == 0)
   {
      bool write = true;
      if (!socket_wait(s->fd, NULL, &write, SSL_SOCKET_IO_TIMEOUT_MS) || !write)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
         return -1;
      }
   }
   tls_set_block(s, true);
   return result < 0 ? -1 : 0;
}

/* Seal into the cork or the application's reusable record buffer. */
static int tls_connect_record(struct ssl_state *s, uint8_t type,
      const uint8_t *data, size_t len)
{
   size_t sealed;
   if (5 + len + TLS_REC_OVERHEAD <= TLS_CORK_MAX - s->cork_len)
   {
      if (tls_seal_record(s, type, data, len,
               s->cork + s->cork_len, &sealed) != 0)
         return -1;
      s->cork_len += sealed;
      return 0;
   }
   if (s->tx_off < s->tx_len)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   if (!s->tx && !(s->tx = (uint8_t*)malloc(5 + TLS_REC_MAX + TLS_REC_OVERHEAD)))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
      return -1;
   }
   if (tls_seal_record(s, type, data, len, s->tx, &s->tx_len) != 0)
      return -1;
   s->tx_off = 0;
   return 0;
}

static int tls_connect_push(struct ssl_state *s, bool cork)
{
   uint8_t *data = cork ? s->cork : s->tx;
   size_t *offset = cork ? &s->cork_off : &s->tx_off;
   size_t *length = cork ? &s->cork_len : &s->tx_len;
   ssize_t n = socket_send_all_nonblocking(s->fd, data + *offset,
         *length - *offset, true);
   if (n < 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
      return -1;
   }
   *offset += (size_t)n;
   if (*offset == *length)
      *offset = *length = 0;
   else
      s->connect_write = true;
   return 0;
}

/* One record is sealed or one pending span is written per call. */
static int tls_connect_output(struct ssl_state *s)
{
   if (s->tx_off < s->tx_len)
      return tls_connect_push(s, s->cork_off < s->cork_len);
   if (s->connect_message)
   {
      size_t length = s->connect_length - s->connect_offset;
      if (length > TLS_REC_MAX)
         length = TLS_REC_MAX;
      if (s->cork_len && 5 + length + TLS_REC_OVERHEAD > TLS_CORK_MAX - s->cork_len)
         return tls_connect_push(s, true);
      if (tls_connect_record(s, TLS_CT_HANDSHAKE,
               s->connect_message + s->connect_offset, length) != 0)
         return -1;
      s->connect_offset += length;
      if (s->connect_offset == s->connect_length)
      {
         free(s->connect_message);
         s->connect_message = NULL;
         s->connect_length = s->connect_offset = 0;
      }
      return 0;
   }
   if (!s->corked && s->cork_off < s->cork_len)
      return tls_connect_push(s, true);
   return 1;
}

static int tls_send_record(struct ssl_state *s, uint8_t type,
      const uint8_t *data, size_t len)
{
   uint8_t *rec;
   size_t   rec_len;
   int      ok;

   if (len > TLS_REC_MAX)
      return -1;
   if (s->connect_nonblock)
      return tls_connect_record(s, type, data, len);
   if (!s->corked && tls_tx_drain_blocking(s) != 0)
      return -1;

   if (!(rec = (uint8_t*)malloc(5 + len + TLS_REC_OVERHEAD)))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
      return -1;
   }
   if (tls_seal_record(s, type, data, len, rec, &rec_len) != 0)
   {
      free(rec);
      return -1;
   }

   if (s->corked && s->cork_len + rec_len > TLS_CORK_MAX && s->cork_len)
   {
      /* a flight larger than the cork (a client certificate chain)
       * goes out in more than one write */
      ok = socket_send_all_blocking(s->fd, s->cork, s->cork_len, true);
      s->cork_len = 0;
      if (!ok)
      {
         free(rec);
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
         return -1;
      }
   }
   if (s->corked && rec_len <= TLS_CORK_MAX)
   {
      memcpy(s->cork + s->cork_len, rec, rec_len);
      s->cork_len += rec_len;
      free(rec);
      return 0;
   }
   ok = socket_send_all_blocking(s->fd, rec, rec_len, true);
   free(rec);
   if (!ok)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
      return -1;
   }
   return 0;
}

/* The socket is in blocking mode, so recv() itself would wait for good
 * on a server that stops mid-handshake or mid-record; each recv() here
 * waits for the socket to be readable first, for at most
 * SSL_SOCKET_IO_TIMEOUT_MS, and a wait that runs out fails the read. */
static bool tls_recv_exact(struct ssl_state *s, uint8_t *buf, size_t len)
{
   while (len)
   {
      bool    rd  = true;
      bool    err = false;
      ssize_t n;
      if (!socket_wait(s->fd, &rd, NULL, SSL_SOCKET_IO_TIMEOUT_MS) || !rd)
         return false;
      if ((n = socket_receive_all_nonblocking(s->fd, &err, buf, len)) < 0)
         return false;
      buf += n;
      len -= (size_t)n;
   }
   return true;
}

/* Retain incomplete headers and bodies in the record buffer. */
static int tls_record_part(struct ssl_state *s, size_t target, bool nonblock)
{
   if (s->rx_len < target)
   {
      if (nonblock)
      {
         bool error = false;
         ssize_t n = socket_receive_all_nonblocking(s->fd, &error,
               s->rx + s->rx_len, target - s->rx_len);
         if (n < 0 || error)
            goto error;
         s->rx_len += (size_t)n;
      }
      else
      {
         if (!tls_recv_exact(s, s->rx + s->rx_len, target - s->rx_len))
            goto error;
         s->rx_len = target;
      }
   }
   return s->rx_len < target ? 1 : 0;
error:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
   return -1;
}

/* One record, decrypted in rx or directly into dst when it fits.
 * The AEADs verify before writing. 1 retains partial input, 0 opens
 * a complete record, -1 fails. */
static int tls_read_record_to(struct ssl_state *s, uint8_t *type,
      const uint8_t **body, size_t *len, uint8_t *dst, size_t dst_cap,
      bool nonblock)
{
   size_t rlen;
   int result = tls_record_part(s, 5, nonblock);
   if (result)
      return result;
   rlen = tls_get16(s->rx + 3);
   if (s->rx[1] != 3 || rlen > TLS_REC_IN_MAX || rlen == 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_RECORD);
      return -1;
   }
   result = tls_record_part(s, 5 + rlen, nonblock);
   if (result)
      return result;
   s->rx_len = 0;
   *type = s->rx[0];

   if (!s->rx_encrypted || (s->v13 && *type == TLS_CT_CCS))
   {
      /* a 1.3 server may send a plaintext ChangeCipherSpec for
       * middlebox compatibility; it carries nothing */
      *body = s->rx + 5;
      *len  = rlen;
   }
   else if (s->v13)
   {
      uint8_t aad[5];
      uint8_t nonce[12];
      uint8_t *p = s->rx + 5;
      uint8_t *o;
      size_t  plen, i;
      int     r;

      if (*type != TLS_CT_APPDATA || rlen < 17)
         goto bad;
      plen = rlen - 16;
      o    = (dst && plen <= dst_cap) ? dst : p;
      aad[0] = s->rx[0]; aad[1] = 3; aad[2] = 3;
      tls_put16(aad + 3, (unsigned)rlen);
      memcpy(nonce, s->siv, 12);
      for (i = 0; i < 8; i++)
         nonce[4 + i] ^= (uint8_t)(s->sseq >> (56 - 8 * i));
      if (tls_suite_is_chacha(s->suite))
         r = aead_decrypt(AEAD_CHACHA20_POLY1305, s->swk, 32, nonce, 12,
               aad, 5, p, plen, p + plen, 16, o);
      else
      {
         const struct aes_gcm_ctx *g = tls_gcm(s, &s->rgcm, s->swk);
         r = g ? aes_gcm_decrypt(g, nonce, 12, aad, 5, p, plen, p + plen, o) : -1;
      }
      if (r != 0)
         goto bad;
      s->sseq++;
      /* inner: content || type || zero padding */
      while (plen && o[plen - 1] == 0)
         plen--;
      if (!plen)
         goto bad;
      *type = o[plen - 1];
      *body = o;
      *len  = plen - 1;
   }
   else if (tls_suite_is_cbc(s->suite))
   {
      /* The padding is checked over the last 256 octets whatever its
       * claimed length, and a bad one is taken as none, so that the
       * MAC is computed and compared either way: a padding error and a
       * MAC error look the same, in the result and in time. */
      const struct aes_ctx *a = tls_cbc(s, &s->rcbc, s->swk);
      size_t   mlen = tls_suite_mac_len(s->suite);
      uint8_t *c    = s->rx + 5 + 16;
      size_t   clen = rlen - 16;
      size_t   dlen, i, maxpad;
      unsigned pad;
      unsigned good;
      uint8_t  hdr[13];
      uint8_t  mac[48];

      if (!a || rlen < 32 || (clen & 15) || clen < mlen + 1)
         goto bad;
      aes_cbc_decrypt(a, s->rx + 5, c, c, clen);
      pad    = c[clen - 1];
      maxpad = clen - mlen - 1;
      if (maxpad > 255)
         maxpad = 255;
      good   = 0u - (unsigned)((size_t)pad <= maxpad);
      for (i = 0; i < 256 && i < clen; i++)
      {
         unsigned in  = 0u - (unsigned)(i <= (size_t)pad);
         unsigned neq = (unsigned)(c[clen - 1 - i] ^ pad);
         good &= ~in | (0u - (unsigned)(neq == 0));
      }
      pad  &= good;
      dlen  = clen - mlen - 1 - pad;
      crypto_store64_be(hdr, s->sseq);
      hdr[8]  = *type;
      hdr[9]  = 3;
      hdr[10] = 3;
      tls_put16(hdr + 11, (unsigned)dlen);
      tls_cbc_mac(s, s->smac, hdr, c, dlen, pad + 1, mac);
      if (!(crypto_memeq_ct(mac, c + dlen, mlen) & good & 1))
         goto bad;
      s->sseq++;
      *body = c;
      *len  = dlen;
   }
   else
   {
      uint8_t aad[13];
      uint8_t nonce[12];
      uint8_t *p = s->rx + 5;
      uint8_t *o;
      size_t  plen;
      size_t  i;

      if (tls_suite_is_chacha(s->suite))
      {
         if (rlen < 16)
            goto bad;
         plen = rlen - 16;
         memcpy(nonce, s->siv, 12);
         for (i = 0; i < 8; i++)
            nonce[4 + i] ^= (uint8_t)(s->sseq >> (56 - 8 * i));
      }
      else
      {
         if (rlen < 8 + 16)
            goto bad;
         plen = rlen - 8 - 16;
         memcpy(nonce, s->siv, 4);
         memcpy(nonce + 4, p, 8);
         p += 8;
      }

      o = (dst && *type == TLS_CT_APPDATA && plen <= dst_cap) ? dst : p;
      crypto_store64_be(aad, s->sseq);
      aad[8]  = *type;
      aad[9]  = 3;
      aad[10] = 3;
      tls_put16(aad + 11, (unsigned)plen);

      if (tls_suite_is_chacha(s->suite))
      {
         if (aead_decrypt(AEAD_CHACHA20_POLY1305, s->swk, 32, nonce, 12,
                  aad, 13, p, plen, p + plen, 16, o) != 0)
            goto bad;
      }
      else
      {
         const struct aes_gcm_ctx *g = tls_gcm(s, &s->rgcm, s->swk);
         if (!g || aes_gcm_decrypt(g, nonce, 12, aad, 13, p, plen, p + plen, o) != 0)
            goto bad;
      }
      s->sseq++;
      *body = o;
      *len  = plen;
   }

   if (*type == TLS_CT_ALERT)
   {
      /* close_notify is a clean end; anything else is an error. */
      s->closed = 1;
      if (*len < 2 || (*body)[1] != 0)
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_ALERT);
      return -1;
   }
   return 0;

bad:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_CIPHER);
   return -1;
}

static int tls_read_record(struct ssl_state *s, uint8_t *type,
      const uint8_t **body, size_t *len)
{
   int result = tls_read_record_to(s, type, body, len, NULL, 0, s->connect_nonblock);
   if (result > 0)
      s->connect_read = true;
   return result;
}

static int tls_send_alert(struct ssl_state *s, uint8_t level, uint8_t desc)
{
   uint8_t a[2];
   a[0] = level;
   a[1] = desc;
   return tls_send_record(s, TLS_CT_ALERT, a, 2);
}

/* ---- handshake messages ------------------------------------------- */

/* Next handshake message from the accumulator, reading records until
 * one is complete; hashed into the transcript. */
static int tls_read_handshake(struct ssl_state *s, uint8_t *msg_type,
      const uint8_t **body, size_t *len)
{
   bool record_read = false;
   for (;;)
   {
      uint8_t type;
      const uint8_t *rb;
      size_t rl;

      if (s->hs_len - s->hs_off >= 4)
      {
         const uint8_t *m = s->hs + s->hs_off;
         size_t mlen = tls_get24(m + 1);
         if (s->hs_len - s->hs_off >= 4 + mlen)
         {
            *msg_type = m[0];
            *body     = m + 4;
            *len      = mlen;
            sha256_stream_update(&s->transcript, m, 4 + mlen);
            sha512_stream_update(&s->transcript384, m, 4 + mlen);
            if (s->cfg.chain_count)
               sha1_stream_update(&s->transcript1, m, 4 + mlen);
            s->hs_off += 4 + mlen;
            return 0;
         }
      }

      /* Pull another record. Consumed messages stay where they are:
       * the parsed Certificate points into this buffer for the rest
       * of the handshake, and a whole handshake fits in it. */
      if (s->connect_nonblock && record_read)
      {
         s->connect_read = true;
         return -1;
      }
      if (tls_read_record(s, &type, &rb, &rl) != 0)
         return -1;
      record_read = true;
      /* a 1.3 server's compatibility ChangeCipherSpec carries nothing */
      if (s->v13 && type == TLS_CT_CCS)
         continue;
      if (type != TLS_CT_HANDSHAKE)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
         return -1;
      }
      if (s->hs_len + rl > TLS_HS_MAX)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
         return -1;
      }
      memcpy(s->hs + s->hs_len, rb, rl);
      s->hs_len += rl;
   }
}

static int tls_send_handshake(struct ssl_state *s, uint8_t msg_type,
      const uint8_t *body, size_t len)
{
   uint8_t *m;
   size_t   off;
   int ret;
   if (len > 0xffffffU || (s->connect_nonblock && s->connect_message))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   if (!(m = (uint8_t*)malloc(4 + len)))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
      return -1;
   }
   m[0] = msg_type;
   m[1] = (uint8_t)(len >> 16);
   m[2] = (uint8_t)(len >> 8);
   m[3] = (uint8_t)len;
   if (len)
      memcpy(m + 4, body, len);
   sha256_stream_update(&s->transcript, m, 4 + len);
   sha512_stream_update(&s->transcript384, m, 4 + len);
   if (s->cfg.chain_count)
      sha1_stream_update(&s->transcript1, m, 4 + len);
   if (s->connect_nonblock)
   {
      s->connect_message = m;
      s->connect_length = 4 + len;
      s->connect_offset = 0;
      return 0;
   }
   /* a certificate chain may need more than one record */
   ret = 0;
   for (off = 0; ret == 0 && off < 4 + len; off += TLS_REC_MAX)
      ret = tls_send_record(s, TLS_CT_HANDSHAKE, m + off,
            4 + len - off < TLS_REC_MAX ? 4 + len - off : TLS_REC_MAX);
   free(m);
   return ret;
}

static int tls13_expand_label_h(size_t hlen, const uint8_t *secret, const char *label,
      const uint8_t *ctx, size_t ctx_len, uint8_t *out, size_t out_len);
static void tls13_hkdf_extract(size_t hlen, const uint8_t *salt, size_t salt_len,
      const uint8_t *ikm, size_t ikm_len, uint8_t *prk);
static void tls13_hmac(size_t hlen, const uint8_t *key, const uint8_t *data,
      size_t len, uint8_t *mac);
static void tls13_empty_hash(size_t hlen, uint8_t *out);

static int tls_send_client_hello(struct ssl_state *s)
{
   /* AES-GCM first where the CPU has AES instructions; ChaCha20-
    * Poly1305 first where AES runs in software (3DS, Vita, older
    * phones), as it costs several times less there. Servers that
    * weigh the client's order pick accordingly. */
   static const uint8_t suites_aes[] = {
      0x13, 0x01, 0x13, 0x03, 0x13, 0x02,              /* TLS 1.3 */
      0xc0, 0x2b, 0xc0, 0x2f, 0xcc, 0xa9, 0xcc, 0xa8, 0xc0, 0x2c, 0xc0, 0x30
   };
   static const uint8_t suites_chacha[] = {
      0x13, 0x03, 0x13, 0x01, 0x13, 0x02,              /* TLS 1.3 */
      0xcc, 0xa9, 0xcc, 0xa8, 0xc0, 0x2b, 0xc0, 0x2f, 0xc0, 0x2c, 0xc0, 0x30
   };
   const uint8_t *suites = crypto_aes_hw() ? suites_aes : suites_chacha;
   size_t   suites_len   = sizeof(suites_aes);
   uint8_t  own[2 * 24];
   uint8_t *h;
   uint8_t *p;
   uint8_t  iplit[16];
   /* No server_name for an IP address: RFC 6066 3 allows host names
    * only, and the certificate is checked against the address anyway. */
   size_t   dlen = (s->domain && !(s->cfg.flags & SSL_RETRO_NO_SNI)
         && !x509_parse_ip(s->domain, iplit))
      ? strlen(s->domain) : 0;
   size_t   ext_len;
   int      ret;
   const struct tls_session *cached = NULL;
   bool cache_open;
   size_t   ticket_len;
   uint8_t *ticket = NULL;
   size_t   cached_sid_len = 0;
   uint8_t  cached_sid[32];
   uint8_t  cached_is13 = 0;
   unsigned cached_suite13 = 0;
   size_t   bhlen = 32;          /* binder hash length: the ticket's suite */
   uint32_t obf_age = 0;

   /* the configured suites, or the default set, and whether 1.3 is
    * among them */
   s->offer13       = 1;
   s->offered_count = 0;
   if (s->cfg.suites)
   {
      unsigned i;
      s->offer13 = 0;
      for (i = 0; i < s->cfg.suite_count && s->offered_count < 24; i++)
      {
         const struct tls_suite_info *si = tls_suite(s->cfg.suites[i]);
         if (!si || (si->kx == TLS_KX_13 && s->cfg.chain_count))
            continue;
         if (si->kx == TLS_KX_13)
            s->offer13 = 1;
         tls_put16(own + 2 * s->offered_count, si->id);
         s->offered[s->offered_count++] = si->id;
      }
      suites     = own;
      suites_len = 2 * s->offered_count;
   }
   else
   {
      unsigned i;
      for (i = 0; i < sizeof(suites_aes) / 2; i++)
         s->offered[s->offered_count++] = tls_get16(suites + 2 * i);
      if (s->cfg.chain_count)
      {
         /* a client certificate runs 1.2: drop the 1.3 suites */
         suites        += 6;
         suites_len    -= 6;
         s->offered_count = 0;
         for (i = 0; i < suites_len / 2; i++)
            s->offered[s->offered_count++] = tls_get16(suites + 2 * i);
         s->offer13 = 0;
      }
   }

   /* the cache entry is copied out here, so nothing below reads it
    * once another thread may be rewriting the slot */
   cache_open = !s->configured && tls_cache_begin(s->connect_nonblock);
   if (cache_open)
      cached = tls_cache_find(s->domain);
   ticket_len = (cached && cached->ticket) ? cached->ticket_len : 0;
   if (ticket_len && (ticket = (uint8_t*)malloc(ticket_len)))
      memcpy(ticket, cached->ticket, ticket_len);
   else
      ticket_len = 0;
   if (cached && cached->sid_len)
   {
      memcpy(cached_sid, cached->sid, cached->sid_len);
      cached_sid_len = cached->sid_len;
   }
   s->cached_suite = 0;
   if (cached && !cached->is13)
   {
      memcpy(s->master, cached->master, sizeof(s->master));
      s->cached_suite = cached->suite;
   }
   if (cached && cached->is13 && ticket_len && s->offer13)
   {
      cached_is13 = 1;
      cached_suite13 = cached->suite;
      memcpy(s->psk, cached->psk, 48);
      obf_age = (uint32_t)((time(NULL) - cached->when) * 1000) + cached->age_add;
   }
   if (cache_open)
      TLS_CACHE_READ_END();
   s->psk_offered  = 0;
   s->psk_accepted = 0;

   if (dlen > 255)
      dlen = 0;

   /* our key share, P-256: 1.3 uses it as is, 1.2 too when the server
    * picks that group */
   if (crypto_random_bytes(s->priv, 32) != 0 || p256_keygen(s->priv, s->pub) != 0
         || crypto_random_bytes(s->xpriv, 32) != 0 || x25519_base(s->xpub, s->xpriv) != 0)
   {
      free(ticket);
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
      return -1;
   }
   if (!(h = (uint8_t*)malloc(400 + dlen + ticket_len)))
   {
      free(ticket);
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
      return -1;
   }
   p = h;
   *p++ = 3; *p++ = 3;                             /* client_version */
   memcpy(p, s->client_random, 32); p += 32;
   /* session id: the cached one, or a random one - alongside a ticket
    * so the server can echo it to signal 1.2 resumption, and in any
    * case for 1.3 middlebox compatibility, where the server echoes it */
   s->offered_sid_len = 0;
   if (cached_sid_len)
   {
      memcpy(s->offered_sid, cached_sid, cached_sid_len);
      s->offered_sid_len = cached_sid_len;
   }
   else
   {
      crypto_random_bytes(s->offered_sid, 32);
      s->offered_sid_len = 32;
   }
   *p++ = (uint8_t)s->offered_sid_len;
   memcpy(p, s->offered_sid, s->offered_sid_len); p += s->offered_sid_len;
   tls_put16(p, (unsigned)suites_len); p += 2;
   memcpy(p, suites, suites_len); p += suites_len;
   *p++ = 1; *p++ = 0;                             /* null compression */

   {
      uint8_t *ext_start = p + 2;
      uint8_t *e = ext_start;

      if (dlen)
      {
         /* server_name: one host_name entry */
         tls_put16(e, 0);                e += 2;
         tls_put16(e, (unsigned)(dlen + 5)); e += 2;
         tls_put16(e, (unsigned)(dlen + 3)); e += 2;
         *e++ = 0;
         tls_put16(e, (unsigned)dlen);   e += 2;
         memcpy(e, s->domain, dlen);     e += dlen;
      }
      /* supported_groups: x25519, secp256r1, secp384r1 */
      tls_put16(e, 10); e += 2; tls_put16(e, 8); e += 2;
      tls_put16(e, 6);  e += 2; tls_put16(e, 29); e += 2; tls_put16(e, 23); e += 2; tls_put16(e, 24); e += 2;
      /* ec_point_formats: uncompressed */
      tls_put16(e, 11); e += 2; tls_put16(e, 2); e += 2; *e++ = 1; *e++ = 0;
      /* signature_algorithms */
      tls_put16(e, 13); e += 2; tls_put16(e, 16); e += 2; tls_put16(e, 14); e += 2;
      tls_put16(e, 0x0403); e += 2;   /* ecdsa_secp256r1_sha256 */
      tls_put16(e, 0x0503); e += 2;   /* ecdsa_secp384r1_sha384 */
      tls_put16(e, 0x0804); e += 2;   /* rsa_pss_rsae_sha256 (1.3) */
      tls_put16(e, 0x0805); e += 2;   /* rsa_pss_rsae_sha384 (1.3) */
      tls_put16(e, 0x0401); e += 2;   /* rsa_pkcs1_sha256 */
      tls_put16(e, 0x0501); e += 2;   /* rsa_pkcs1_sha384 */
      tls_put16(e, 0x0601); e += 2;   /* rsa_pkcs1_sha512 */
      if (s->offer13)
      {
         /* supported_versions: 1.3 then 1.2 */
         tls_put16(e, 43); e += 2; tls_put16(e, 5); e += 2; *e++ = 4;
         tls_put16(e, 0x0304); e += 2; tls_put16(e, 0x0303); e += 2;
         /* key_share: x25519 and secp256r1, so no server needs a retry */
         tls_put16(e, 51); e += 2; tls_put16(e, 2 + 4 + 32 + 4 + 65); e += 2;
         tls_put16(e, 4 + 32 + 4 + 65); e += 2;
         tls_put16(e, 29); e += 2; tls_put16(e, 32); e += 2;
         memcpy(e, s->xpub, 32); e += 32;
         tls_put16(e, 23); e += 2; tls_put16(e, 65); e += 2;
         memcpy(e, s->pub, 65); e += 65;
      }
      /* renegotiation_info: initial, empty */
      tls_put16(e, 0xff01); e += 2; tls_put16(e, 1); e += 2; *e++ = 0;
      /* session_ticket (1.2): the cached ticket, or empty to say we
       * take them; a 1.3 ticket goes in pre_shared_key instead */
      tls_put16(e, 35); e += 2;
      if (ticket_len && !cached_is13)
      {
         tls_put16(e, (unsigned)ticket_len); e += 2;
         memcpy(e, ticket, ticket_len);
         e += ticket_len;
      }
      else
      {
         tls_put16(e, 0); e += 2;
      }
      /* psk_key_exchange_modes: psk_dhe_ke */
      if (s->offer13)
      {
         tls_put16(e, 45); e += 2; tls_put16(e, 2); e += 2; *e++ = 1; *e++ = 1;
      }
      if (cached_is13)
      {
         /* pre_shared_key, last: one identity (the ticket, obfuscated
          * age) and one binder, filled in once the rest is hashed */
         bhlen = cached_suite13 == TLS13_AES_256_GCM_SHA384 ? 48 : 32;
         tls_put16(e, 41); e += 2;
         tls_put16(e, (unsigned)(2 + 2 + ticket_len + 4 + 2 + 1 + bhlen)); e += 2;
         tls_put16(e, (unsigned)(2 + ticket_len + 4)); e += 2;
         tls_put16(e, (unsigned)ticket_len); e += 2;
         memcpy(e, ticket, ticket_len); e += ticket_len;
         e[0] = (uint8_t)(obf_age >> 24); e[1] = (uint8_t)(obf_age >> 16);
         e[2] = (uint8_t)(obf_age >> 8);  e[3] = (uint8_t)obf_age; e += 4;
         tls_put16(e, (unsigned)(bhlen + 1)); e += 2;   /* binders list */
         *e++ = (uint8_t)bhlen;
         memset(e, 0, bhlen); e += bhlen;   /* binder placeholder */
         s->psk_offered = 1;
      }

      ext_len = (size_t)(e - ext_start);
      tls_put16(p, (unsigned)ext_len);
      p = e;
   }

   if (s->psk_offered)
   {
      /* binder = HMAC(binder_key, Hash(header || ClientHello[..binders]))
       * with binder_key from the PSK's early secret */
      static const uint8_t zeros[48] = {0};
      uint8_t early[48], bkey[48], fkey[48], th[48], hdr[4], empty_hash[48];
      size_t  body_len = (size_t)(p - h), trunc = body_len - (bhlen + 3);
      hdr[0] = TLS_HS_CLIENT_HELLO;
      hdr[1] = (uint8_t)(body_len >> 16); hdr[2] = (uint8_t)(body_len >> 8); hdr[3] = (uint8_t)body_len;
      if (bhlen == 48)
      {
         struct sha512_state t = s->transcript384;
         sha512_stream_update(&t, hdr, 4);
         sha512_stream_update(&t, h, trunc);
         sha512_stream_final(&t, th);
      }
      else
      {
         struct sha256_state t = s->transcript;
         sha256_stream_update(&t, hdr, 4);
         sha256_stream_update(&t, h, trunc);
         sha256_stream_final(&t, th);
      }
      tls13_hkdf_extract(bhlen, zeros, bhlen, s->psk, bhlen, early);
      tls13_empty_hash(bhlen, empty_hash);
      if (tls13_expand_label_h(bhlen, early, "res binder", empty_hash, bhlen, bkey, bhlen) != 0
            || tls13_expand_label_h(bhlen, bkey, "finished", NULL, 0, fkey, bhlen) != 0)
      {
         free(h); free(ticket);
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
         return -1;
      }
      tls13_hmac(bhlen, fkey, th, bhlen, h + trunc + 3);
      crypto_memzero(early, 48); crypto_memzero(bkey, 48); crypto_memzero(fkey, 48);
   }
   ret = tls_send_handshake(s, TLS_HS_CLIENT_HELLO, h, (size_t)(p - h));
   free(h);
   free(ticket);
   return ret;
}

static int tls_offered(const struct ssl_state *s, unsigned suite)
{
   unsigned i;
   for (i = 0; i < s->offered_count; i++)
      if (s->offered[i] == suite)
         return 1;
   return 0;
}

static int tls_recv_server_hello(struct ssl_state *s)
{
   uint8_t type;
   const uint8_t *b;
   size_t len, sid;
   unsigned suite;

   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_SERVER_HELLO || len < 38)
      goto bad;
   if (b[0] != 3 || b[1] != 3)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_VERSION);
      return -1;
   }
   memcpy(s->server_random, b + 2, 32);
   sid = b[34];
   if (len < 35 + sid + 3)
      goto bad;
   suite = tls_get16(b + 35 + sid);
   if (!tls_offered(s, suite))
      goto bad;
   if (b[35 + sid + 2] != 0)
      goto bad;   /* compression */
   s->suite = suite;

   /* TLS 1.3: supported_versions says 0x0304, key_share carries the
    * server's share. A HelloRetryRequest (a ServerHello with the
    * fixed random) asks for another group; we offer P-256 only, which
    * every 1.3 server takes, so it is treated as a failure. */
   s->v13 = 0;
   s->tls13_peer_len = 0;
   if (len > 35 + sid + 3 + 2)
   {
      static const uint8_t hrr_random[8] = { 0xcf, 0x21, 0xad, 0x74, 0xe5, 0x9a, 0x61, 0x11 };
      size_t off  = 35 + sid + 3;
      size_t elen = tls_get16(b + off);
      off += 2;
      while (elen >= 4 && off + 4 <= len)
      {
         unsigned etype = tls_get16(b + off);
         size_t   edata = tls_get16(b + off + 2);
         const uint8_t *ed = b + off + 4;
         if (off + 4 + edata > len)
            goto bad;
         if (etype == 43 && edata == 2 && tls_get16(ed) == 0x0304 && s->offer13)
            s->v13 = 1;
         if (etype == 41 && edata == 2 && tls_get16(ed) == 0 && s->psk_offered)
            s->psk_accepted = 1;
         if (etype == 51 && edata >= 4)
         {
            unsigned grp = tls_get16(ed);
            size_t   kl  = tls_get16(ed + 2);
            if (((grp == 23 && kl == 65) || (grp == 29 && kl == 32)) && 4 + kl == edata)
            {
               memcpy(s->tls13_peer, ed + 4, kl);
               s->tls13_peer_len = kl;
               s->group          = grp;
            }
         }
         off  += 4 + edata;
         elen  = (elen >= 4 + edata) ? elen - 4 - edata : 0;
      }
      if (memcmp(s->server_random, hrr_random, 8) == 0)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
         return -1;
      }
   }
   if (s->v13)
   {
      if (!tls_suite_is_13(suite) || !s->tls13_peer_len
            || sid != s->offered_sid_len || memcmp(b + 35, s->offered_sid, sid) != 0)
         goto bad;
      s->resumed = 0;
      crypto_memzero(s->master, sizeof(s->master));
      s->cached_suite = 0;
      s->expect_ticket = 0;
      return 0;
   }
   if (tls_suite_is_13(suite))
      goto bad;

   /* Resumption: the offered id echoed back, and the cached suite. */
   s->resumed = 0;
   if (sid && sid == s->offered_sid_len && memcmp(b + 35, s->offered_sid, sid) == 0
         && !s->configured)
   {
      if (s->cached_suite != suite)
         goto bad;
      s->resumed = 1;
   }
   if (!s->resumed)
      crypto_memzero(s->master, sizeof(s->master));
   s->cached_suite = 0;
   /* extensions: session_ticket (35) present means a ticket follows */
   s->expect_ticket = 0;
   if (len > 35 + sid + 3 + 2)
   {
      size_t off  = 35 + sid + 3;
      size_t elen = tls_get16(b + off);
      off += 2;
      while (elen >= 4 && off + 4 <= len)
      {
         unsigned etype = tls_get16(b + off);
         size_t   edata = tls_get16(b + off + 2);
         if (etype == 35)
            s->expect_ticket = 1;
         off  += 4 + edata;
         elen  = (elen >= 4 + edata) ? elen - 4 - edata : 0;
      }
   }
   if (!s->resumed && sid)
   {
      /* a server-issued id for the cache once the handshake completes */
      memcpy(s->offered_sid, b + 35, sid);
      s->offered_sid_len = sid;
   }
   else if (!s->resumed)
      s->offered_sid_len = 0;
   return 0;

bad:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
   return -1;
}

/* The server's chain against the trust anchors - the connection's own
 * or the bundle - under the connection's verify policy. With an RSA key
 * exchange the leaf's key enciphers rather than signs. */
static int tls_verify_peer(struct ssl_state *s, const uint8_t **ders,
      const size_t *lens, unsigned n)
{
   const struct tls_suite_info *si = tls_suite(s->suite);
   const char *host = (s->cfg.flags & SSL_RETRO_NO_HOSTNAME) ? NULL : s->domain;
   char info[128];

   if (s->verify_mode == 2 || (s->cfg.flags & SSL_RETRO_NO_VERIFY))
   {
      ssl_socket_log_verify_disabled(s->domain);
      return 0;
   }
   if (!s->cfg.trust)
   {
      if (!tls_system_anchors)
         tls_trust_load();
      if (retro_atomic_cas_int(&tls_trust_logged, 0, 1))
         TLS_LOG_TRUST_STORE(tls_system_anchors ? tls_system_source : NULL,
               tls_system_anchors);
   }
   info[0] = '\0';
   if (x509_verify_chain_ex(ders, lens, n, host, time(NULL),
            s->cfg.trust, s->cfg.trust_lens, s->cfg.trust_count,
            (si && si->kx == TLS_KX_RSA) ? X509_VERIFY_KEY_ENCIPHERMENT : 0,
            info, sizeof(info)) != 0)
   {
      ssl_socket_log_verify_fail(s->verify_mode == 0, s->domain, info);
      if (s->verify_mode == 0)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_CERT);
         return -1;
      }
   }
   return 0;
}

/* Certificate: 3-octet total length, then 3-octet length + DER each.
 * Parsed into an array of pointers into the accumulator; the leaf's
 * key is what verifies the ServerKeyExchange. */
static int tls_recv_certificate(struct ssl_state *s, struct x509_cert *leaf)
{
   uint8_t type;
   const uint8_t *b;
   const uint8_t *ders[16];
   size_t lens[16];
   size_t len, total, off;
   unsigned n = 0;

   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_CERTIFICATE || len < 3)
      goto bad;
   total = tls_get24(b);
   if (total + 3 != len)
      goto bad;
   off = 3;
   while (off + 3 <= len && n < 16)
   {
      size_t cl = tls_get24(b + off);
      off += 3;
      if (cl == 0 || off + cl > len)
         goto bad;
      ders[n] = b + off;
      lens[n] = cl;
      n++;
      off += cl;
   }
   if (!n)
      goto bad;
   if (x509_parse(leaf, ders[0], lens[0]) != 0 || leaf->key_type == X509_KEY_NONE)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_CERT);
      return -1;
   }

   return tls_verify_peer(s, ders, lens, n);

bad:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
   return -1;
}

/* ServerKeyExchange: ECParameters (named curve) || point || signed
 * over client_random || server_random || params. */
static int tls_recv_server_kex(struct ssl_state *s, const struct x509_cert *leaf,
      uint8_t *peer, size_t *peer_len)
{
   uint8_t type;
   const uint8_t *b, *params, *sig;
   size_t len, plen, sig_len, point_len;
   unsigned sig_alg;
   uint8_t digest[64];
   size_t  dlen;
   int ok = -1;

   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_SERVER_KEX || len < 4)
      goto bad;
   params = b;
   if (b[0] != 3)                 /* named_curve */
      goto bad;
   s->group  = tls_get16(b + 1);
   point_len = b[3];
   if ((s->group != 23 && s->group != 24 && s->group != 29)
         || (s->group == 23 && point_len != 65)
         || (s->group == 24 && point_len != 97)
         || (s->group == 29 && point_len != 32)
         || len < 4 + point_len + 4)
      goto bad;
   memcpy(peer, b + 4, point_len);
   *peer_len = point_len;
   plen      = 4 + point_len;

   sig_alg = tls_get16(b + plen);
   sig_len = tls_get16(b + plen + 2);
   sig     = b + plen + 4;
   if (plen + 4 + sig_len != len)
      goto bad;

   /* hash: sig_alg high octet is the hash (4 = sha256, 5 = 384, 6 = 512);
    * the rsa_pss_rsae_* schemes (0x0804 / 0x0805) are an exception, and
    * a 1.2 server may pick them once they are offered for 1.3 */
   {
      uint8_t hash = (uint8_t)(sig_alg >> 8);
      uint8_t sigt = (uint8_t)sig_alg;
      int     pss  = 0;
      if (sig_alg == 0x0804) { hash = 4; pss = 1; }
      else if (sig_alg == 0x0805) { hash = 5; pss = 1; }
      if (hash == 4)
      {
         struct sha256_state h;
         sha256_stream_init(&h, 0);
         sha256_stream_update(&h, s->client_random, 32);
         sha256_stream_update(&h, s->server_random, 32);
         sha256_stream_update(&h, params, plen);
         sha256_stream_final(&h, digest);
         dlen = 32;
      }
      else if (hash == 5 || hash == 6)
      {
         struct sha512_state h;
         sha512_stream_init(&h, hash == 5);
         sha512_stream_update(&h, s->client_random, 32);
         sha512_stream_update(&h, s->server_random, 32);
         sha512_stream_update(&h, params, plen);
         sha512_stream_final(&h, digest);
         dlen = hash == 5 ? 48 : 64;
      }
      else
         goto bad;

      if (pss && leaf->key_type == X509_KEY_RSA)
         ok = rsa_pss_verify(leaf->rsa_n, leaf->rsa_n_len,
               leaf->rsa_e, leaf->rsa_e_len,
               dlen == 32 ? RSA_HASH_SHA256 : RSA_HASH_SHA384,
               digest, dlen, sig, sig_len);
      else if (!pss && sigt == 1 && leaf->key_type == X509_KEY_RSA)
         ok = rsa_pkcs1_verify(leaf->rsa_n, leaf->rsa_n_len,
               leaf->rsa_e, leaf->rsa_e_len,
               dlen == 32 ? RSA_HASH_SHA256 : dlen == 48 ? RSA_HASH_SHA384 : RSA_HASH_SHA512,
               digest, dlen, sig, sig_len);
      else if (!pss && sigt == 3 && (leaf->key_type == X509_KEY_P256 || leaf->key_type == X509_KEY_P384))
         ok = x509_verify_ecdsa_digest(leaf, digest, dlen, sig, sig_len);
   }
   if (ok != 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SIGNATURE);
      return -1;
   }
   return 0;

bad:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
   return -1;
}

/* CertificateRequest (RFC 5246 7.4.4): certificate types, signature
 * schemes, CA names. We answer with our chain when it is an RSA one the
 * server takes and one of its schemes is one we sign with, otherwise
 * with an empty Certificate and let the server decide. */
static int tls_parse_cert_request(struct ssl_state *s, const uint8_t *b, size_t len)
{
   static const unsigned prefer[3] = { 0x0401, 0x0501, 0x0201 };
   size_t   nt, ns, i, j;
   int      rsa_ok = 0;

   if (len < 1 || len < 1 + (nt = b[0]) + 2)
      return -1;
   for (i = 0; i < nt; i++)
      if (b[1 + i] == 1)   /* rsa_sign */
         rsa_ok = 1;
   ns = tls_get16(b + 1 + nt);
   if ((ns & 1) || len < 1 + nt + 2 + ns + 2)
      return -1;
   s->cert_requested = 2;
   if (!rsa_ok || !s->cfg.chain_count || !s->cfg.key)
      return 0;
   for (j = 0; j < 3; j++)
      for (i = 0; i < ns; i += 2)
         if (tls_get16(b + 1 + nt + 2 + i) == prefer[j])
         {
            s->cv_alg         = prefer[j];
            s->cert_requested = 1;
            return 0;
         }
   return 0;
}

static int tls_recv_server_done(struct ssl_state *s)
{
   uint8_t type;
   const uint8_t *b;
   size_t len;
   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type == TLS_HS_CERT_REQUEST)
   {
      if (s->cert_requested || tls_parse_cert_request(s, b, len) != 0)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
         return -1;
      }
      return 1;
   }
   if (type != TLS_HS_SERVER_DONE || len != 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   return 0;
}

/* RSA key exchange: a 48-octet premaster, client_version first,
 * encrypted to the server's certificate key. */
static int tls_send_client_kex_rsa(struct ssl_state *s,
      const struct x509_cert *leaf)
{
   uint8_t msg[2 + 512];
   size_t  n_len = leaf->rsa_n_len;
   int     ret;

   if (leaf->key_type != X509_KEY_RSA)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
      return -1;
   }
   while (n_len && leaf->rsa_n[leaf->rsa_n_len - n_len] == 0)
      n_len--;
   s->premaster[0]  = 3;
   s->premaster[1]  = 3;
   s->premaster_len = 48;
   if (n_len > 512 || crypto_random_bytes(s->premaster + 2, 46) != 0
         || rsa_pkcs1_encrypt(leaf->rsa_n, leaf->rsa_n_len,
               leaf->rsa_e, leaf->rsa_e_len, s->premaster, 48,
               msg + 2, n_len) != 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
      return -1;
   }
   tls_put16(msg, (unsigned)n_len);
   ret = tls_send_handshake(s, TLS_HS_CLIENT_KEX, msg, 2 + n_len);
   return ret;
}

static int tls_send_client_kex(struct ssl_state *s, const uint8_t *peer,
      size_t peer_len)
{
   uint8_t msg[1 + 97];
   uint8_t pub[97];
   size_t  slen = s->group == 24 ? 48 : 32;
   size_t  plen = s->group == 23 ? 65 : s->group == 24 ? 97 : 32;
   unsigned tries;
   int r;

   s->premaster_len = slen;
   if (s->group == 29)
   {
      /* X25519: the share made with the ClientHello, shared secret
       * straight from the ladder */
      if (peer_len != 32 || x25519(s->premaster, s->xpriv, peer) != 0)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
         return -1;
      }
      crypto_memzero(s->xpriv, sizeof(s->xpriv));
      msg[0] = 32;
      memcpy(msg + 1, s->xpub, 32);
      return tls_send_handshake(s, TLS_HS_CLIENT_KEX, msg, 33);
   }
   for (tries = 0; tries < 8; tries++)
   {
      if (crypto_random_bytes(s->priv, slen) != 0)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
         return -1;
      }
      r = s->group == 23 ? p256_keygen(s->priv, pub) : p384_keygen(s->priv, pub);
      if (r == 0)
         break;
   }
   if (tries == 8)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
      return -1;
   }
   r = s->group == 23 ? p256_ecdh(s->priv, peer, s->premaster)
                      : p384_ecdh(s->priv, peer, s->premaster);
   crypto_memzero(s->priv, sizeof(s->priv));
   if (r != 0 || peer_len != plen)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
      return -1;
   }

   msg[0] = (uint8_t)plen;
   memcpy(msg + 1, pub, plen);
   return tls_send_handshake(s, TLS_HS_CLIENT_KEX, msg, 1 + plen);
}

/* Certificate: our chain, or nothing when we have none to give. */
static int tls_send_client_cert(struct ssl_state *s)
{
   size_t   total = 0, off;
   unsigned i, n = s->cert_requested == 1 ? s->cfg.chain_count : 0;
   uint8_t *m;
   int      ret;

   for (i = 0; i < n; i++)
   {
      size_t length = s->cfg.chain_lens[i];
      if (length > 0xffffffU - 6 || total > 0xffffffU - 6 - length)
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
         return -1;
      }
      total += 3 + length;
   }
   if (total > 0xffffff - 3 || !(m = (uint8_t*)malloc(3 + total)))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
      return -1;
   }
   m[0] = (uint8_t)(total >> 16);
   m[1] = (uint8_t)(total >> 8);
   m[2] = (uint8_t)total;
   off  = 3;
   for (i = 0; i < n; i++)
   {
      size_t cl = s->cfg.chain_lens[i];
      m[off]     = (uint8_t)(cl >> 16);
      m[off + 1] = (uint8_t)(cl >> 8);
      m[off + 2] = (uint8_t)cl;
      memcpy(m + off + 3, s->cfg.chain[i], cl);
      off += 3 + cl;
   }
   ret = tls_send_handshake(s, TLS_HS_CERTIFICATE, m, 3 + total);
   free(m);
   return ret;
}

/* CertificateVerify: the transcript so far, signed with our key in the
 * scheme picked from the server's CertificateRequest. */
static int tls_send_cert_verify(struct ssl_state *s)
{
   uint8_t  msg[4 + 512];
   uint8_t  digest[48];
   size_t   dlen, n_len = s->cfg.key->n_len;
   const uint8_t *n = s->cfg.key->n;
   enum rsa_hash hash;

   while (n_len && n[0] == 0)
   {
      n++;
      n_len--;
   }
   if (s->cv_alg == 0x0201)
   {
      struct sha1_state t = s->transcript1;
      sha1_stream_final(&t, digest);
      dlen = 20;
      hash = RSA_HASH_SHA1;
   }
   else if (s->cv_alg == 0x0501)
   {
      struct sha512_state t = s->transcript384;
      sha512_stream_final(&t, digest);
      dlen = 48;
      hash = RSA_HASH_SHA384;
   }
   else
   {
      struct sha256_state t = s->transcript;
      sha256_stream_final(&t, digest);
      dlen = 32;
      hash = RSA_HASH_SHA256;
   }
   if (n_len > 512 || rsa_pkcs1_sign(s->cfg.key, hash, digest, dlen,
            msg + 4, n_len) != 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SIGNATURE);
      return -1;
   }
   tls_put16(msg, s->cv_alg);
   tls_put16(msg + 2, (unsigned)n_len);
   return tls_send_handshake(s, TLS_HS_CERTIFICATE_VERIFY, msg, 4 + n_len);
}

/* NewSessionTicket (RFC 5077): lifetime, then the opaque ticket. */
static int tls_recv_new_session_ticket(struct ssl_state *s)
{
   uint8_t type;
   const uint8_t *b;
   size_t len, tlen;
   struct tls_session_put put;

   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != 4 || len < 6)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   tlen = tls_get16(b + 4);
   if (6 + tlen != len || tlen == 0 || tlen > 16384)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   if (s->configured)
      return 0;
   memset(&put, 0, sizeof(put));
   put.what       = TLS_PUT_TICKET;
   put.ticket     = b + 6;
   put.ticket_len = tlen;
   tls_cache_put(s->domain, &put, s->connect_nonblock);
   return 0;
}

/* Master secret and suite into the cache once a full handshake has
 * finished; the server's session id too, when it gave one. */
static void tls_cache_store(struct ssl_state *s)
{
   struct tls_session_put put;
   if (s->configured)
      return;
   memset(&put, 0, sizeof(put));
   put.what    = TLS_PUT_MASTER;
   put.master  = s->master;
   put.suite   = s->suite;
   put.sid     = s->offered_sid;
   put.sid_len = s->offered_sid_len;
   tls_cache_put(s->domain, &put, s->connect_nonblock);
}

/* Key block from a master secret already in s->master. */
static void tls_expand_keys(struct ssl_state *s)
{
   uint8_t key_block[2 * 48 + 2 * 32 + 2 * 12];
   size_t  key_len = tls_suite_key_len(s->suite);
   size_t  mac_len = tls_suite_mac_len(s->suite);
   /* a CBC record carries its IV; the AEADs take a fixed part here */
   size_t  iv_len  = tls_suite_is_cbc(s->suite) ? 0
      : tls_suite_is_chacha(s->suite) ? 12 : 4;
   const uint8_t *p = key_block;

   tls_prf(s, s->master, 48, "key expansion",
         s->server_random, 32, s->client_random, 32,
         key_block, 2 * mac_len + 2 * key_len + 2 * iv_len);
   memcpy(s->cmac, p, mac_len); p += mac_len;
   memcpy(s->smac, p, mac_len); p += mac_len;
   memcpy(s->cwk, p, key_len); p += key_len;
   memcpy(s->swk, p, key_len); p += key_len;
   memcpy(s->civ, p, iv_len);  p += iv_len;
   memcpy(s->siv, p, iv_len);
   crypto_memzero(key_block, sizeof(key_block));
}

static void tls_derive_keys(struct ssl_state *s)
{
   size_t slen = s->premaster_len;
   tls_prf(s, s->premaster, slen, "master secret",
         s->client_random, 32, s->server_random, 32, s->master, 48);
   crypto_memzero(s->premaster, sizeof(s->premaster));
   tls_expand_keys(s);
}

static int tls_send_finished(struct ssl_state *s)
{
   uint8_t hash[48];
   uint8_t verify[12];
   size_t  hlen = tls_transcript(s, hash);
   tls_prf(s, s->master, 48, "client finished", hash, hlen, NULL, 0, verify, 12);
   return tls_send_handshake(s, TLS_HS_FINISHED, verify, 12);
}

static int tls_recv_finished(struct ssl_state *s)
{
   uint8_t hash[48];
   uint8_t verify[12];
   uint8_t type;
   const uint8_t *b;
   size_t len;
   size_t hlen;

   /* Expected value is over the transcript before this message. */
   hlen = tls_transcript(s, hash);
   tls_prf(s, s->master, 48, "server finished", hash, hlen, NULL, 0, verify, 12);

   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_FINISHED || len != 12 || !crypto_memeq_ct(b, verify, 12))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   return 0;
}

/* ---- TLS 1.3 (RFC 8446) ------------------------------------------- */

/* The 1.3 suites hash with SHA-256, except AES-256-GCM-SHA384. */
static size_t tls13_hlen(const struct ssl_state *s)
{
   return s->suite == TLS13_AES_256_GCM_SHA384 ? 48 : 32;
}

static void tls13_hkdf_extract(size_t hlen, const uint8_t *salt, size_t salt_len,
      const uint8_t *ikm, size_t ikm_len, uint8_t *prk)
{
   if (hlen == 48)
      hkdf_sha384_extract(salt, salt_len, ikm, ikm_len, prk);
   else
      hkdf_sha256_extract(salt, salt_len, ikm, ikm_len, prk);
}

static void tls13_hmac(size_t hlen, const uint8_t *key, const uint8_t *data,
      size_t len, uint8_t *mac)
{
   if (hlen == 48)
      hmac_sha384(key, hlen, data, len, mac);
   else
      hmac_sha256(key, hlen, data, len, mac);
}

/* Hash of the transcript so far, for the suite's hash. */
static void tls13_transcript_hash(const struct ssl_state *s, uint8_t *out)
{
   if (tls13_hlen(s) == 48)
   {
      struct sha512_state t = s->transcript384;
      sha512_stream_final(&t, out);
   }
   else
   {
      struct sha256_state t = s->transcript;
      sha256_stream_final(&t, out);
   }
}

static void tls13_empty_hash(size_t hlen, uint8_t *out)
{
   if (hlen == 48)
   {
      struct sha512_state e;
      sha512_stream_init(&e, 1);
      sha512_stream_final(&e, out);
   }
   else
   {
      struct sha256_state e;
      sha256_stream_init(&e, 0);
      sha256_stream_final(&e, out);
   }
}

/* HKDF-Expand-Label(secret, label, context, len) over the suite's hash;
 * @hlen is the hash and secret length. */
static int tls13_expand_label_h(size_t hlen, const uint8_t *secret, const char *label,
      const uint8_t *ctx, size_t ctx_len, uint8_t *out, size_t out_len)
{
   uint8_t info[2 + 1 + 6 + 32 + 1 + 255];   /* a ticket nonce may be 255 octets */
   size_t  llen = strlen(label), n = 0;
   if (llen > 32 || ctx_len > 255)
      return -1;
   tls_put16(info, (unsigned)out_len);            n += 2;
   info[n++] = (uint8_t)(6 + llen);
   memcpy(info + n, "tls13 ", 6);                 n += 6;
   memcpy(info + n, label, llen);                 n += llen;
   info[n++] = (uint8_t)ctx_len;
   if (ctx_len)
   {
      memcpy(info + n, ctx, ctx_len);
      n += ctx_len;
   }
   if (hlen == 48)
      return hkdf_sha384_expand(secret, 48, info, n, out, out_len);
   return hkdf_sha256_expand(secret, 32, info, n, out, out_len);
}

/* the connection's suite decides the hash */
static int tls13_expand_label(const struct ssl_state *s, const uint8_t *secret,
      const char *label, const uint8_t *ctx, size_t ctx_len, uint8_t *out, size_t out_len)
{
   return tls13_expand_label_h(tls13_hlen(s), secret, label, ctx, ctx_len, out, out_len);
}

/* Derive-Secret(secret, label, transcript-so-far) */
static int tls13_derive_secret(const struct ssl_state *s, const uint8_t *secret,
      const char *label, uint8_t *out)
{
   uint8_t th[48];
   size_t  hlen = tls13_hlen(s);
   tls13_transcript_hash(s, th);
   return tls13_expand_label(s, secret, label, th, hlen, out, hlen);
}

/* Traffic keys from a traffic secret into the given key / iv slots. */
static int tls13_traffic_keys(struct ssl_state *s, const uint8_t *secret,
      uint8_t *key, uint8_t *iv)
{
   size_t klen = (tls_suite_is_chacha(s->suite) || tls_suite_is_aes256(s->suite)) ? 32 : 16;
   if (tls13_expand_label(s, secret, "key", NULL, 0, key, klen) != 0
         || tls13_expand_label(s, secret, "iv", NULL, 0, iv, 12) != 0)
      return -1;
   return 0;
}

/* The handshake secrets once the ServerHello is in: shared secret from
 * the key share, then the client and server handshake traffic keys. */
static int tls13_handshake_keys(struct ssl_state *s, const uint8_t *peer, size_t peer_len)
{
   static const uint8_t zeros[48] = {0};
   uint8_t shared[32], early[48], derived[48];
   uint8_t empty_hash[48];
   size_t  hlen = tls13_hlen(s);

   if (s->group == 29)
   {
      if (peer_len != 32 || x25519(shared, s->xpriv, peer) != 0)
         return -1;
   }
   else if (peer_len != 65 || p256_ecdh(s->priv, peer, shared) != 0)
      return -1;
   crypto_memzero(s->xpriv, sizeof(s->xpriv));
   crypto_memzero(s->priv, sizeof(s->priv));
   /* early_secret = Extract(0, PSK) - or Extract(0, 0) without one;
    * derived = Derive-Secret(early, "derived", "") */
   tls13_hkdf_extract(hlen, zeros, hlen, s->psk_accepted ? s->psk : zeros, hlen, early);
   tls13_empty_hash(hlen, empty_hash);
   if (tls13_expand_label(s, early, "derived", empty_hash, hlen, derived, hlen) != 0)
      return -1;
   tls13_hkdf_extract(hlen, derived, hlen, shared, 32, s->hs_secret);
   crypto_memzero(shared, sizeof(shared));
   if (tls13_derive_secret(s, s->hs_secret, "c hs traffic", s->c_hs) != 0
         || tls13_derive_secret(s, s->hs_secret, "s hs traffic", s->s_hs) != 0)
      return -1;
   /* the server encrypts from here; we switch to our handshake keys
    * when we send our Finished */
   if (tls13_traffic_keys(s, s->s_hs, s->swk, s->siv) != 0)
      return -1;
   s->rx_encrypted = 1;
   s->sseq         = 0;
   return 0;
}

/* Application traffic secrets, from the transcript through the
 * server's Finished. */
static int tls13_application_secrets(struct ssl_state *s)
{
   static const uint8_t zeros[48] = {0};
   uint8_t derived[48], master[48], empty_hash[48];
   size_t  hlen = tls13_hlen(s);
   tls13_empty_hash(hlen, empty_hash);
   if (tls13_expand_label(s, s->hs_secret, "derived", empty_hash, hlen, derived, hlen) != 0)
      return -1;
   tls13_hkdf_extract(hlen, derived, hlen, zeros, hlen, master);
   if (tls13_derive_secret(s, master, "c ap traffic", s->c_app) != 0
         || tls13_derive_secret(s, master, "s ap traffic", s->s_app) != 0)
      return -1;
   memcpy(s->master13, master, hlen);
   crypto_memzero(master, sizeof(master));
   crypto_memzero(derived, sizeof(derived));
   return 0;
}

/* verify_data = HMAC(Expand-Label(base, "finished", "", 32), transcript) */
static int tls13_finished_mac(const struct ssl_state *s, const uint8_t *base, uint8_t *out)
{
   uint8_t fk[48], th[48];
   size_t  hlen = tls13_hlen(s);
   if (tls13_expand_label(s, base, "finished", NULL, 0, fk, hlen) != 0)
      return -1;
   tls13_transcript_hash(s, th);
   tls13_hmac(hlen, fk, th, hlen, out);
   crypto_memzero(fk, sizeof(fk));
   return 0;
}

/* Certificate (1.3 shape): request context, then entries of cert +
 * extensions. Verifies the chain and leaves the leaf key in @leaf. */
static int tls13_recv_certificate(struct ssl_state *s, struct x509_cert *leaf)
{
   uint8_t type;
   const uint8_t *b, *ders[16];
   size_t len, off, total, lens[16], n = 0;

   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_CERTIFICATE || len < 4 || b[0] != 0)
      goto bad;
   total = tls_get24(b + 1);
   if (total + 4 != len)
      goto bad;
   off = 4;
   while (off + 3 <= len && n < 16)
   {
      size_t cl = tls_get24(b + off), el;
      off += 3;
      if (cl == 0 || off + cl + 2 > len)
         goto bad;
      ders[n] = b + off;
      lens[n] = cl;
      n++;
      off += cl;
      el   = tls_get16(b + off);
      off += 2 + el;
      if (off > len)
         goto bad;
   }
   if (!n || x509_parse(leaf, ders[0], lens[0]) != 0 || leaf->key_type == X509_KEY_NONE)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_CERT);
      return -1;
   }
   return tls_verify_peer(s, ders, lens, (unsigned)n);

bad:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
   return -1;
}

/* CertificateVerify: the signature covers 64 spaces, the context
 * string, a zero and the transcript hash through Certificate. */
static int tls13_recv_certificate_verify(struct ssl_state *s, const struct x509_cert *leaf)
{
   static const char ctx[] = "TLS 1.3, server CertificateVerify";
   uint8_t type;
   const uint8_t *b, *sig;
   size_t len, sig_len;
   unsigned alg;
   uint8_t content[64 + 33 + 1 + 48];
   uint8_t digest[64];
   size_t  dlen, clen, hlen = tls13_hlen(s);
   int ok = -1;

   /* transcript hash before this message: the accumulator has not been
    * fed the CertificateVerify yet, so take it now */
   tls13_transcript_hash(s, s->cert_hash);
   clen = 64 + 33 + 1 + hlen;
   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_CERTIFICATE_VERIFY || len < 4)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   alg     = tls_get16(b);
   sig_len = tls_get16(b + 2);
   sig     = b + 4;
   if (4 + sig_len != len)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   memset(content, 0x20, 64);
   memcpy(content + 64, ctx, 33);
   content[64 + 33] = 0;
   memcpy(content + 64 + 33 + 1, s->cert_hash, hlen);

   if (alg == 0x0804 || alg == 0x0403)           /* SHA-256 based */
   {
      struct sha256_state h;
      sha256_stream_init(&h, 0);
      sha256_stream_update(&h, content, clen);
      sha256_stream_final(&h, digest);
      dlen = 32;
   }
   else if (alg == 0x0805 || alg == 0x0503)      /* SHA-384 based */
   {
      struct sha512_state h;
      sha512_stream_init(&h, 1);
      sha512_stream_update(&h, content, clen);
      sha512_stream_final(&h, digest);
      dlen = 48;
   }
   else
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SIGNATURE);
      return -1;
   }
   if ((alg == 0x0804 || alg == 0x0805) && leaf->key_type == X509_KEY_RSA)
      ok = rsa_pss_verify(leaf->rsa_n, leaf->rsa_n_len, leaf->rsa_e, leaf->rsa_e_len,
            dlen == 32 ? RSA_HASH_SHA256 : RSA_HASH_SHA384, digest, dlen, sig, sig_len);
   else if ((alg == 0x0403 && leaf->key_type == X509_KEY_P256)
         || (alg == 0x0503 && leaf->key_type == X509_KEY_P384))
      ok = x509_verify_ecdsa_digest(leaf, digest, dlen, sig, sig_len);
   if (ok != 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SIGNATURE);
      return -1;
   }
   return 0;
}

static int tls13_recv_finished(struct ssl_state *s)
{
   uint8_t type, expect[48];
   const uint8_t *b;
   size_t len, hlen = tls13_hlen(s);
   /* the expected MAC is over the transcript before this message */
   if (tls13_finished_mac(s, s->s_hs, expect) != 0)
      return -1;
   if (tls_read_handshake(s, &type, &b, &len) != 0)
      return -1;
   if (type != TLS_HS_FINISHED || len != hlen || !crypto_memeq_ct(b, expect, hlen))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
      return -1;
   }
   return 0;
}

static int tls13_send_finished(struct ssl_state *s)
{
   uint8_t mac[48];
   if (tls13_finished_mac(s, s->c_hs, mac) != 0)
      return -1;
   return tls_send_handshake(s, TLS_HS_FINISHED, mac, tls13_hlen(s));
}

/* A post-handshake message on the application stream: tickets are
 * dropped (no PSK resumption), a KeyUpdate rotates the server keys and
 * is answered with our own when asked. */
static int tls13_post_handshake(struct ssl_state *s, const uint8_t *msg, size_t len,
      bool nonblock)
{
   if (len < 4)
      return -1;
   switch (msg[0])
   {
      case TLS_HS_NEW_SESSION_TICKET:
      {
         /* lifetime(4) age_add(4) nonce<0..255> ticket<1..2^16-1> exts */
         const uint8_t *b = msg + 4;
         size_t bl = len - 4, nl, tl;
         uint32_t age_add;
         uint8_t psk[48];
         struct tls_session_put put;
         if (bl < 9)
            return -1;
         age_add = ((uint32_t)b[4] << 24) | ((uint32_t)b[5] << 16) | ((uint32_t)b[6] << 8) | b[7];
         nl = b[8];
         if (bl < 9 + nl + 2)
            return -1;
         tl = tls_get16(b + 9 + nl);
         if (!tl || tl > 16384 || bl < 9 + nl + 2 + tl)
            return -1;
         if (s->configured)
            return 0;
         /* PSK = Expand-Label(res_master, "resumption", nonce, 32) */
         if (tls13_expand_label(s, s->res_master, "resumption", b + 9, nl, psk, tls13_hlen(s)) != 0)
            return -1;
         memset(&put, 0, sizeof(put));
         put.what       = TLS_PUT_PSK;
         put.ticket     = b + 9 + nl + 2;
         put.ticket_len = tl;
         put.suite      = s->suite;
         put.age_add    = age_add;
         put.psk        = psk;
         tls_cache_put(s->domain, &put, nonblock);
         crypto_memzero(psk, sizeof(psk));
         return 0;
      }
      case TLS_HS_KEY_UPDATE:
      {
         uint8_t next[48];
         size_t  hlen = tls13_hlen(s);
         if (len != 5 || msg[4] > 1)
            return -1;
         if (tls13_expand_label(s, s->s_app, "traffic upd", NULL, 0, next, hlen) != 0)
            return -1;
         memcpy(s->s_app, next, hlen);
         if (tls13_traffic_keys(s, s->s_app, s->swk, s->siv) != 0)
            return -1;
         s->sseq = 0;
         if (msg[4] == 1)
         {
            /* update_requested: rotate ours too, announcing it first */
            uint8_t ku[1] = {0};
            /* In duplex mode the sending side owns our keys: it sends
             * this before its next record, as RFC 8446 4.6.3 asks */
            if (nonblock || tls_duplex(s))
            {
               retro_atomic_store_release_int(&s->key_update, 1);
               return 0;
            }
            if (tls_send_handshake(s, TLS_HS_KEY_UPDATE, ku, 1) != 0)
               return -1;
            if (tls13_expand_label(s, s->c_app, "traffic upd", NULL, 0, next, hlen) != 0)
               return -1;
            memcpy(s->c_app, next, hlen);
            if (tls13_traffic_keys(s, s->c_app, s->cwk, s->civ) != 0)
               return -1;
            s->cseq = 0;
         }
         return 0;
      }
      default:
         return -1;
   }
}

static int tls_handshake_step(struct ssl_state *s)
{
   struct tls_handshake_progress *progress = &s->connect;
   uint8_t type;
   const uint8_t *b;
   size_t len;
   int result;
   static const uint8_t ccs = 1;

   if (s->handshake_done)
      return 1;
   if (progress->phase == TLS_CONNECT_FAILED)
      return -1;
   s->connect_read = s->connect_write = false;
   if (s->connect_nonblock)
   {
      result = tls_connect_output(s);
      if (result < 0)
         goto error;
      if (!result)
         return 0;
   }
   switch (progress->phase)
   {
      case TLS_CONNECT_START:
         sha256_stream_init(&s->transcript, 0);
         sha512_stream_init(&s->transcript384, 1);
         sha1_stream_init(&s->transcript1);
         if (crypto_random_bytes(s->client_random, 32) != 0)
         {
            retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
            goto error;
         }
         if (tls_send_client_hello(s) != 0)
            goto error;
         progress->phase = TLS_CONNECT_HELLO;
         break;
      case TLS_CONNECT_HELLO:
         if (tls_recv_server_hello(s) != 0)
            goto error;
         if (s->v13)
            progress->phase = TLS_CONNECT_KEYS13;
         else if (s->resumed)
         {
            tls_expand_keys(s);
            progress->phase = s->expect_ticket
               ? TLS_CONNECT_TICKET12 : TLS_CONNECT_CCS12;
         }
         else
            progress->phase = TLS_CONNECT_CERT12;
         break;
      case TLS_CONNECT_CERT12:
         if (tls_recv_certificate(s, &progress->leaf) != 0)
            goto error;
         progress->phase = tls_suite(s->suite)
               && tls_suite(s->suite)->kx == TLS_KX_RSA
            ? TLS_CONNECT_DONE12 : TLS_CONNECT_KEX12;
         break;
      case TLS_CONNECT_KEX12:
         if (tls_recv_server_kex(s, &progress->leaf,
                  progress->peer, &progress->peer_len) != 0)
            goto error;
         progress->phase = TLS_CONNECT_DONE12;
         break;
      case TLS_CONNECT_DONE12:
         result = tls_recv_server_done(s);
         if (result < 0)
            goto error;
         if (!result)
            progress->phase = TLS_CONNECT_SEND_CERT12;
         break;
      case TLS_CONNECT_SEND_CERT12:
         tls_cork(s);
         if (s->cert_requested && tls_send_client_cert(s) != 0)
            goto error;
         progress->phase = TLS_CONNECT_SEND_KEX12;
         break;
      case TLS_CONNECT_SEND_KEX12:
         if (tls_suite(s->suite) && tls_suite(s->suite)->kx == TLS_KX_RSA)
            result = tls_send_client_kex_rsa(s, &progress->leaf);
         else
            result = tls_send_client_kex(s, progress->peer, progress->peer_len);
         if (result != 0)
            goto error;
         progress->phase = TLS_CONNECT_SEND_VERIFY12;
         break;
      case TLS_CONNECT_SEND_VERIFY12:
         if (s->cert_requested == 1 && tls_send_cert_verify(s) != 0)
            goto error;
         tls_derive_keys(s);
         progress->phase = TLS_CONNECT_SEND_CCS12;
         break;
      case TLS_CONNECT_SEND_CCS12:
         if (s->resumed)
            tls_cork(s);
         if (tls_send_record(s, TLS_CT_CCS, &ccs, 1) != 0)
            goto error;
         s->tx_encrypted = 1;
         s->cseq = 0;
         progress->phase = TLS_CONNECT_SEND_FIN12;
         break;
      case TLS_CONNECT_SEND_FIN12:
         if (tls_send_finished(s) != 0 || tls_uncork(s) != 0)
            goto error;
         progress->phase = s->resumed ? TLS_CONNECT_COMPLETE12
            : (s->expect_ticket ? TLS_CONNECT_TICKET12 : TLS_CONNECT_CCS12);
         break;
      case TLS_CONNECT_TICKET12:
         if (tls_recv_new_session_ticket(s) != 0)
            goto error;
         progress->phase = TLS_CONNECT_CCS12;
         break;
      case TLS_CONNECT_CCS12:
         if (tls_read_record(s, &type, &b, &len) != 0)
            goto error;
         if (type != TLS_CT_CCS || len != 1 || b[0] != 1)
         {
            retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
            goto error;
         }
         s->rx_encrypted = 1;
         s->sseq = 0;
         progress->phase = TLS_CONNECT_FIN12;
         break;
      case TLS_CONNECT_FIN12:
         if (tls_recv_finished(s) != 0)
            goto error;
         progress->phase = s->resumed
            ? TLS_CONNECT_SEND_CCS12 : TLS_CONNECT_COMPLETE12;
         break;
      case TLS_CONNECT_COMPLETE12:
         tls_cache_store(s);
         s->handshake_done = 1;
         /* duplex: the socket nonblocking now, so that neither side
          * sets its mode from then on */
         if (tls_duplex(s))
            tls_set_block(s, false);
         break;
      case TLS_CONNECT_KEYS13:
         if (tls13_handshake_keys(s, s->tls13_peer, s->tls13_peer_len) != 0)
         {
            retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_KEX);
            goto error;
         }
         progress->phase = TLS_CONNECT_EXT13;
         break;
      case TLS_CONNECT_EXT13:
         if (tls_read_handshake(s, &type, &b, &len) != 0)
            goto error;
         if (type != TLS_HS_ENCRYPTED_EXTENSIONS)
         {
            retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
            goto error;
         }
         s->resumed = s->psk_accepted ? 1 : 0;
         progress->phase = s->psk_accepted
            ? TLS_CONNECT_FIN13 : TLS_CONNECT_CERT13;
         break;
      case TLS_CONNECT_CERT13:
         if (tls13_recv_certificate(s, &progress->leaf) != 0)
            goto error;
         progress->phase = TLS_CONNECT_VERIFY13;
         break;
      case TLS_CONNECT_VERIFY13:
         if (tls13_recv_certificate_verify(s, &progress->leaf) != 0)
            goto error;
         progress->phase = TLS_CONNECT_FIN13;
         break;
      case TLS_CONNECT_FIN13:
         if (tls13_recv_finished(s) != 0 || tls13_application_secrets(s) != 0)
            goto error;
         progress->phase = TLS_CONNECT_SEND_CCS13;
         break;
      case TLS_CONNECT_SEND_CCS13:
         tls_cork(s);
         s->tx_encrypted = 0;
         if (tls_send_record(s, TLS_CT_CCS, &ccs, 1) != 0
               || tls13_traffic_keys(s, s->c_hs, s->cwk, s->civ) != 0)
            goto error;
         s->tx_encrypted = 1;
         s->cseq = 0;
         progress->phase = TLS_CONNECT_SEND_FIN13;
         break;
      case TLS_CONNECT_SEND_FIN13:
         if (tls13_send_finished(s) != 0 || tls_uncork(s) != 0)
            goto error;
         progress->phase = TLS_CONNECT_COMPLETE13;
         break;
      case TLS_CONNECT_COMPLETE13:
         if (tls13_derive_secret(s, s->master13, "res master", s->res_master) != 0)
            goto error;
         crypto_memzero(s->master13, sizeof(s->master13));
         crypto_memzero(s->psk, sizeof(s->psk));
         if (tls13_traffic_keys(s, s->c_app, s->cwk, s->civ) != 0
               || tls13_traffic_keys(s, s->s_app, s->swk, s->siv) != 0)
            goto error;
         s->cseq = s->sseq = 0;
         crypto_memzero(s->hs_secret, sizeof(s->hs_secret));
         crypto_memzero(s->c_hs, sizeof(s->c_hs));
         crypto_memzero(s->s_hs, sizeof(s->s_hs));
         s->handshake_done = 1;
         /* duplex: the socket nonblocking now, so that neither side
          * sets its mode from then on */
         if (tls_duplex(s))
            tls_set_block(s, false);
         break;
      case TLS_CONNECT_FAILED:
         return -1;
      default:
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
         goto error;
   }
   if (!s->handshake_done)
      return 0;
   s->hs_len = s->hs_off = 0;
   memset(progress, 0, sizeof(*progress));
   return 1;
error:
   if (s->connect_read)
      return 0;
   progress->phase = TLS_CONNECT_FAILED;
   return -1;
}

static int tls_handshake(struct ssl_state *s)
{
   int result;
   do
      result = tls_handshake_step(s);
   while (result == 0);
   return result < 0 ? -1 : 0;
}

/* ---- public API --------------------------------------------------- */

void ssl_socket_set_verify_mode(unsigned mode)
{
   retro_atomic_store_release_int(&tls_verify_mode_setting, (int)mode);
}

void* ssl_socket_init(int fd, const char *domain)
{
   struct ssl_state *s = (struct ssl_state*)calloc(1, sizeof(*s));
   if (!s)
      return NULL;
   s->verify_mode = (unsigned)retro_atomic_load_acquire_int(&tls_verify_mode_setting);
   retro_atomic_int_init(&s->last_err, 0);
   retro_atomic_int_init(&s->key_update, 0);
   /* No Nagle on a TLS socket. Everything RetroArch does over TLS is
    * request-then-reply, and with Nagle the first request after a
    * resumed 1.2 handshake waits behind the unacknowledged Finished
    * for the server's delayed ACK: 40 ms on every such connection. */
#ifdef TCP_NODELAY
   {
      int one = 1;
      setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, (const char*)&one, sizeof(one));
   }
#endif
   s->fd     = fd;
   /* A copy: the connection can outlive the caller's string - net_http
    * pools it after the transfer that opened it is gone, and a TLS 1.3
    * ticket arriving later is filed under this name. */
   s->domain = domain ? strdup(domain) : NULL;
   s->rx     = (uint8_t*)malloc(TLS_RX_SIZE);
   s->hs     = (uint8_t*)malloc(TLS_HS_MAX);
   s->cork   = (uint8_t*)malloc(TLS_CORK_MAX);
   if (!s->rx || !s->hs || !s->cork || (domain && !s->domain))
   {
      free(s->cork);
      free(s->rx);
      free(s->hs);
      free((char*)s->domain);
      free(s);
      return NULL;
   }
   return s;
}

int ssl_socket_retro_configure(void *state_data,
      const struct ssl_socket_retro_config *cfg)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   unsigned i;
   int      any = !cfg->suites;

   for (i = 0; !any && i < cfg->suite_count; i++)
   {
      const struct tls_suite_info *si = tls_suite(cfg->suites[i]);
      if (si && !(si->kx == TLS_KX_13 && cfg->chain_count))
         any = 1;
   }
   if (!s || !any || (cfg->chain_count && !cfg->key))
      return -1;
   /* A duplex connection's sending side has its record buffer from
    * the start, rather than taking it on its first send */
   if ((cfg->flags & SSL_RETRO_DUPLEX) && !s->tx
         && !(s->tx = (uint8_t*)malloc(5 + TLS_REC_MAX + TLS_REC_OVERHEAD)))
      return -1;
   s->cfg        = *cfg;
   s->configured = 1;
   return 0;
}

unsigned ssl_socket_retro_version(void *state_data)
{
   const struct ssl_state *s = (const struct ssl_state*)state_data;
   if (!s || !s->handshake_done)
      return 0;
   return s->v13 ? 0x0304 : 0x0303;
}

unsigned ssl_socket_retro_suite(void *state_data)
{
   const struct ssl_state *s = (const struct ssl_state*)state_data;
   if (!s || !s->handshake_done)
      return 0;
   return s->suite;
}

int ssl_socket_retro_was_resumed(void *state_data)
{
   const struct ssl_state *s = (const struct ssl_state*)state_data;
   return s && s->handshake_done && s->resumed;
}

int ssl_socket_last_error(void *state_data)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   return s ? retro_atomic_load_relaxed_int(&s->last_err) : 0;
}

int ssl_socket_handshake_step(void *state_data, bool *read, bool *write)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   int result;
   if (read)
      *read = false;
   if (write)
      *write = false;
   if (!s || s->closed || s->connect.phase == TLS_CONNECT_FAILED)
      return -1;
   if (s->handshake_done)
      return 1;
   if (!s->connect_nonblock)
   {
      if (!tls_set_block(s, false))
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
         s->connect.phase = TLS_CONNECT_FAILED;
         return -1;
      }
      s->connect_nonblock = true;
   }
   result = tls_handshake_step(s);
   if (result > 0)
      s->connect_nonblock = false;
   if (read)
      *read = s->connect_read;
   if (write)
      *write = s->connect_write;
   return result;
}

int ssl_socket_connect(void *state_data,
      void *data, bool timeout_enable, bool nonblock)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   (void)nonblock;

   if (timeout_enable)
   {
      if (!socket_connect_with_timeout(s->fd, data, 5000))
         return -1;
      s->fd_mode = 0;   /* left nonblocking by the connect */
      if (!tls_set_block(s, true))
         return -1;
   }
   else if (socket_connect(s->fd, data))
      return -1;

   if (tls_handshake(s) != 0)
   {
      if (!s->closed)
         tls_send_alert(s, 2, 40);   /* fatal handshake_failure */
      return -1;
   }
   return 1;
}

/* Points s->pt at the next application record's plaintext: in @dst
 * when given and the record fits @dst_cap, else in s->rx. */
static int tls_post_step(struct ssl_state *s, bool nonblock)
{
   const uint8_t *message = s->hs + s->hs_off;
   size_t available = s->hs_len - s->hs_off;
   size_t length;
   if (available < 4)
      return 0;
   length = tls_get24(message + 1);
   if (length > TLS_HS_MAX - 4)
      return -1;
   if (available < length + 4)
      return 0;
   if (tls13_post_handshake(s, message, length + 4, nonblock) != 0)
      return -1;
   s->hs_off += length + 4;
   if (s->hs_off == s->hs_len)
      s->hs_len = s->hs_off = 0;
   return 1;
}

static int tls_fill(struct ssl_state *s, uint8_t *dst, size_t dst_cap,
      bool nonblock)
{
   uint8_t type;
   const uint8_t *b;
   size_t len;

   for (;;)
   {
      int result;
      /* Sending what is owed, unless another thread does the sending */
      if (nonblock && !tls_duplex(s))
      {
         result = tls_control_push(s);
         if (result < 0)
            return -1;
      }
      else if (!tls_duplex(s)
            && (retro_atomic_load_acquire_int(&s->key_update)
               || s->cork_off < s->cork_len)
            && tls_tx_drain_blocking(s) != 0)
         return -1;
      if (s->v13)
      {
         result = tls_post_step(s, nonblock);
         if (result < 0)
            goto bad_handshake;
         if (result > 0)
         {
            if (nonblock)
               return 1;
            continue;
         }
      }
      result = tls_read_record_to(s, &type, &b, &len, dst, dst_cap, nonblock);
      if (result)
         return result;
      if (type == TLS_CT_APPDATA)
      {
         if (s->v13 && s->hs_len != s->hs_off)
            goto bad_handshake;
         s->pt     = b;
         s->pt_len = len;
         s->pt_off = 0;
         return 0;
      }
      /* A 1.3 server sends tickets and key updates on the application
       * stream; anything else after the handshake (a HelloRequest, a
       * CCS) is ignored. Alerts were handled in tls_read_record. */
      if (s->v13 && type == TLS_CT_HANDSHAKE)
      {
         if (s->hs_len == s->hs_off && len >= 4)
         {
            size_t length = tls_get24(b + 1);
            if (length <= len - 4)
            {
               if (tls13_post_handshake(s, b, length + 4, nonblock) != 0)
                  goto bad_handshake;
               b += length + 4;
               len -= length + 4;
            }
         }
         if (s->hs_off)
         {
            memmove(s->hs, s->hs + s->hs_off, s->hs_len - s->hs_off);
            s->hs_len -= s->hs_off;
            s->hs_off = 0;
         }
         if (len > TLS_HS_MAX - s->hs_len)
            goto bad_handshake;
         memcpy(s->hs + s->hs_len, b, len);
         s->hs_len += len;
      }
      if (nonblock)
         return 1;
   }
bad_handshake:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_HANDSHAKE);
   return -1;
}

int ssl_socket_receive_all_blocking(void *state_data, void *data_, size_t len)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   uint8_t *data       = (uint8_t*)data_;

   tls_set_block(s, true);
   while (len)
   {
      size_t avail = s->pt_len - s->pt_off;
      if (!avail)
      {
         if (tls_fill(s, data, len, false) != 0)
            return -1;
         if (s->pt == data)
         {
            /* decrypted in place in the caller's buffer */
            s->pt_off = s->pt_len;
            data     += s->pt_len;
            len      -= s->pt_len;
         }
         continue;
      }
      if (avail > len)
         avail = len;
      memcpy(data, s->pt + s->pt_off, avail);
      s->pt_off += avail;
      data      += avail;
      len       -= avail;
   }
   return 1;
}

ssize_t ssl_socket_receive_all_nonblocking(void *state_data,
      bool *error, void *data_, size_t len)
{
   /* At most one record/message per call; partial input stays in rx. */
   struct ssl_state *s = (struct ssl_state*)state_data;
   uint8_t *data       = (uint8_t*)data_;
   size_t   got        = 0;

   *error = false;
   if (!len)
      return 0;
   if (s->pt_len == s->pt_off)
   {
      int result;
      /* The end of the stream - close_notify, or the connection gone -
       * is -1 with *error set, as a plain socket and the library
       * backends report it: net_http ends a body that runs to the close
       * on it. A 0 here would read as "nothing yet", and such a body
       * would never finish. */
      if (s->closed)
      {
         *error = true;
         return -1;
      }
      if (!tls_set_block(s, false))
      {
         retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
         *error = true;
         return -1;
      }
      result = tls_fill(s, data, len, true);
      if (result < 0)
      {
         *error = true;
         return -1;
      }
      if (result > 0)
         return 0;
      if (s->pt == data)
      {
         /* decrypted in place in the caller's buffer */
         s->pt_off = s->pt_len;
         return (ssize_t)s->pt_len;
      }
   }
   got = s->pt_len - s->pt_off;
   if (got > len)
      got = len;
   memcpy(data, s->pt + s->pt_off, got);
   s->pt_off += got;
   return (ssize_t)got;
}

int ssl_socket_send_all_blocking(void *state_data, const void *data_,
      size_t len, bool no_signal)
{
   struct ssl_state *s  = (struct ssl_state*)state_data;
   const uint8_t *data  = (const uint8_t*)data_;
   (void)no_signal;

   tls_set_block(s, true);
   if (tls_tx_drain_blocking(s) != 0)
      return -1;
   while (len)
   {
      size_t n = len < TLS_REC_MAX ? len : TLS_REC_MAX;
      if (tls_send_record(s, TLS_CT_APPDATA, data, n) != 0)
         return -1;
      data += n;
      len  -= n;
   }
   return 1;
}

/* Push the pending record as far as the socket takes it now.
 * 1: nothing left pending, 0: the socket is full, -1: error. */
static int tls_tx_push(struct ssl_state *s)
{
   ssize_t n;
   if (s->tx_off >= s->tx_len)
      return 1;
   if (!tls_set_block(s, false))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
      return -1;
   }
   if ((n = socket_send_all_nonblocking(s->fd, s->tx + s->tx_off,
               s->tx_len - s->tx_off, true)) < 0)
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
      return -1;
   }
   s->tx_off += (size_t)n;
   return s->tx_off >= s->tx_len;
}

/* Reuse the handshake cork for a KeyUpdate, behind any sealed application
 * record. Rotate client keys only once its old-key announcement is sealed. */
static int tls_control_push(struct ssl_state *s)
{
   int result = tls_tx_push(s);
   if (result <= 0)
      return result;
   if (s->cork_off >= s->cork_len
         && retro_atomic_load_acquire_int(&s->key_update))
   {
      static const uint8_t update[5] = {TLS_HS_KEY_UPDATE, 0, 0, 1, 0};
      uint8_t next[48];
      size_t hlen = tls13_hlen(s);
      if (tls_seal_record(s, TLS_CT_HANDSHAKE, update, sizeof(update),
               s->cork, &s->cork_len) != 0
            || tls13_expand_label(s, s->c_app, "traffic upd", NULL, 0,
               next, hlen) != 0)
         return -1;
      memcpy(s->c_app, next, hlen);
      if (tls13_traffic_keys(s, s->c_app, s->cwk, s->civ) != 0)
         return -1;
      s->cseq = 0;
      s->cork_off = 0;
      retro_atomic_store_relaxed_int(&s->key_update, 0);
   }
   if (s->cork_off < s->cork_len)
   {
      ssize_t n;
      if (!tls_set_block(s, false))
         goto error;
      n = socket_send_all_nonblocking(s->fd, s->cork + s->cork_off,
            s->cork_len - s->cork_off, true);
      if (n < 0)
         goto error;
      s->cork_off += (size_t)n;
      if (s->cork_off < s->cork_len)
         return 0;
      s->cork_off = s->cork_len = 0;
   }
   return retro_atomic_load_relaxed_int(&s->key_update) ? 0 : 1;
error:
   retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_SOCKET);
   return -1;
}

bool ssl_socket_retro_pending(void *state_data, bool *write)
{
   const struct ssl_state *s = (const struct ssl_state*)state_data;
   size_t available;
   if (!write)
      return false;
   *write = false;
   if (!s)
      return false;
   available = s->hs_len - s->hs_off;
   /* The sending side's state is not this thread's to read in duplex
    * mode, and nothing is sent from here then */
   if (!tls_duplex(s))
      *write = s->tx_off < s->tx_len || s->cork_off < s->cork_len
            || retro_atomic_load_relaxed_int(&s->key_update);
   if (s->pt_off < s->pt_len)
      return true;
   if (available >= 4)
   {
      size_t length = tls_get24(s->hs + s->hs_off + 1);
      return length > TLS_HS_MAX - 4 || available >= length + 4;
   }
   return false;
}

ssize_t ssl_socket_send_all_nonblocking(void *state_data, const void *data_,
      size_t len, bool no_signal)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   const uint8_t *data = (const uint8_t*)data_;
   size_t taken        = 0;
   (void)no_signal;

   if (!s->tx && !(s->tx = (uint8_t*)malloc(5 + TLS_REC_MAX + TLS_REC_OVERHEAD)))
   {
      retro_atomic_store_relaxed_int(&s->last_err, TLS_ERR_MEMORY);
      return -1;
   }

   /* Seal a record only once the previous one is fully on the wire, so
    * at most one record is ever held back; what is taken is sealed,
    * and what the socket has not taken yet goes out on the next call
    * or ssl_socket_flush_nonblocking(). */
   for (;;)
   {
      size_t n;
      int    r = tls_control_push(s);
      if (r < 0)
         return -1;
      if (!r || taken == len)
         break;
      n = len - taken;
      if (n > TLS_REC_MAX)
         n = TLS_REC_MAX;
      if (tls_seal_record(s, TLS_CT_APPDATA, data + taken, n,
               s->tx, &s->tx_len) != 0)
         return -1;
      s->tx_off = 0;
      taken    += n;
   }
   return (ssize_t)taken;
}

int ssl_socket_flush_nonblocking(void *state_data)
{
   return tls_control_push((struct ssl_state*)state_data);
}

void ssl_socket_close(void *state_data)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   if (!s || s->fd < 0)
      return;
   if (!s->notified)
      ssl_socket_close_notify(s);
   socket_close(s->fd);
   s->fd = -1;
   s->closed = 1;
}

int ssl_socket_close_notify(void *state_data)
{
   static const uint8_t alert[2] = {1, 0};
   struct ssl_state *s = (struct ssl_state*)state_data;
   size_t length;
   if (     !s || s->fd < 0 || !s->handshake_done || s->closed || s->notified
         || s->tx_off < s->tx_len
         || retro_atomic_load_relaxed_int(&s->key_update)
         || s->cork_off < s->cork_len
         || !tls_set_block(s, false)
         || tls_seal_record(s, TLS_CT_ALERT, alert, sizeof(alert),
               s->cork, &length) != 0)
      return -1;
   s->notified = 1;
   return socket_send_all_nonblocking(s->fd, s->cork, length, true)
      == (ssize_t)length ? 0 : -1;
}

void ssl_socket_free(void *state_data)
{
   struct ssl_state *s = (struct ssl_state*)state_data;
   if (!s)
      return;
   crypto_memzero(s->master, sizeof(s->master));
   crypto_memzero(s->cwk, sizeof(s->cwk));
   crypto_memzero(s->swk, sizeof(s->swk));
   crypto_memzero(&s->wgcm, sizeof(s->wgcm));
   crypto_memzero(&s->rgcm, sizeof(s->rgcm));
   free(s->connect_message);
   free(s->rx);
   free(s->hs);
   free(s->cork);
   free(s->tx);
   free((char*)s->domain);
   free(s);
}

/* Weak no-op logging hooks so libretro-common links standalone;
 * RetroArch's network/tls_log.c provides the real ones. Under griffin
 * both are in one unit, where a weak twin would be a redefinition, and
 * MSVC has no weak symbols. */
#if (defined(__GNUC__) || defined(__clang__)) && !defined(HAVE_GRIFFIN)
__attribute__((weak))
void ssl_socket_log_verify_fail(int mode_required, const char *domain,
      const char *verify_info)
{
   (void)mode_required;
   (void)domain;
   (void)verify_info;
}

__attribute__((weak))
void ssl_socket_log_verify_disabled(const char *domain)
{
   (void)domain;
}

__attribute__((weak))
void ssl_socket_log_trust_store(const char *source, int anchors)
{
   (void)source;
   (void)anchors;
}
#endif
