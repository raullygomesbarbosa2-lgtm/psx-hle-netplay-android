/* Copyright  (C) 2010-2020 The RetroArch team
 *
 * ---------------------------------------------------------------------------------------
 * The following license statement only applies to this file (net_socket.c).
 * ---------------------------------------------------------------------------------------
 *
 * Permission is hereby granted, free of charge,
 * to any person obtaining a copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation the rights to
 * use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software,
 * and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 * IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 * WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#include <stdio.h>

#include <net/net_socket_ssl.h>
#include <net/net_socket.h>
#include <encodings/base64.h>
#include <streams/file_stream.h>
#include <string/stdstring.h>
#include <compat/strl.h>

#include <bearssl.h>

struct ssl_state
{
   int fd;
   int handshake_state; /* 0: setup, 1: active, 2: complete,
                         * 3: close_notify sent, -1: failed */
   char domain[256];
   br_ssl_client_context sc;
   br_x509_minimal_context xc;
   uint8_t iobuf[BR_SSL_BUFSIZE_BIDI];
};

/* TODO/FIXME - static global variables */
static br_x509_trust_anchor TAs[500] = {};
static size_t TAs_NUM = 0;

static uint8_t* current_vdn;
static size_t current_vdn_size;
/* Set by vdn_append when a realloc() fails during DN accumulation.
 * BearSSL's x509 decoder drives vdn_append as a void-returning
 * callback, so we have no failure channel to hand back mid-decode;
 * instead we latch this flag, skip further appends, and let
 * append_cert_x509 observe it after the decoder returns. */
static bool current_vdn_failed;

static uint8_t* blobdup(const void * src, size_t len)
{
   uint8_t *ret = (uint8_t*)malloc(len);
   /* Pre-patch: no NULL check, so the next line memcpy'd into NULL
    * on OOM and crashed.  Return NULL and make it the caller's
    * problem - all three call sites below now propagate the NULL
    * back out of append_cert_x509. */
   if (!ret)
      return NULL;
   memcpy(ret, src, len);
   return ret;
}
static void vdn_append(void* dest_ctx, const void * src, size_t len)
{
   uint8_t *tmp;
   if (current_vdn_failed)
      return;
   /* Use a tmp pointer: the pre-patch form
    *     current_vdn = (uint8_t*)realloc(current_vdn, ...)
    * overwrote current_vdn with NULL on realloc failure, leaking
    * the original buffer, and the subsequent memcpy then
    * dereferenced NULL.  The callback signature is 'void' so we
    * cannot signal to the decoder to stop - we just latch the
    * flag and short-circuit subsequent invocations. */
   if (!(tmp = (uint8_t*)realloc(current_vdn, current_vdn_size + len)))
   {
      current_vdn_failed = true;
      return;
   }
   current_vdn = tmp;
   memcpy(current_vdn + current_vdn_size, src, len);
   current_vdn_size += len;
}

static bool append_cert_x509(void* x509, size_t len)
{
   br_x509_pkey* pk;
   br_x509_decoder_context dc;
   br_x509_trust_anchor* ta = &TAs[TAs_NUM];

   current_vdn              = NULL;
   current_vdn_size         = 0;
   current_vdn_failed       = false;

   br_x509_decoder_init(&dc, vdn_append, NULL);
   br_x509_decoder_push(&dc, x509, len);

   /* If any vdn_append realloc failed during decoding, whatever
    * bytes we did accumulate in current_vdn are incomplete; drop
    * the DN buffer and abandon this trust anchor. */
   if (current_vdn_failed)
   {
      free(current_vdn);
      return false;
   }

   pk                       = br_x509_decoder_get_pkey(&dc);
   if (!pk || !br_x509_decoder_isCA(&dc))
   {
      /* Pre-existing leak: the original code returned here without
       * freeing current_vdn.  Ownership had not yet been transferred
       * to ta->dn.data, so the buffer was orphaned. */
      free(current_vdn);
      return false;
   }

   ta->dn.len               = current_vdn_size;
   ta->dn.data              = current_vdn;
   ta->flags                = BR_X509_TA_CA;

   switch (pk->key_type)
   {
      case BR_KEYTYPE_RSA:
         ta->pkey.key_type     = BR_KEYTYPE_RSA;
         ta->pkey.key.rsa.nlen = pk->key.rsa.nlen;
         ta->pkey.key.rsa.n    = blobdup(pk->key.rsa.n, pk->key.rsa.nlen);
         ta->pkey.key.rsa.elen = pk->key.rsa.elen;
         ta->pkey.key.rsa.e    = blobdup(pk->key.rsa.e, pk->key.rsa.elen);
         /* If either blobdup OOM'd, we cannot install a half-built
          * trust anchor - BearSSL dereferences ta->pkey during
          * every handshake against a cert that chains to this TA,
          * and a NULL .n or .e is a crash. */
         if (!ta->pkey.key.rsa.n || !ta->pkey.key.rsa.e)
         {
            free(ta->pkey.key.rsa.n);
            free(ta->pkey.key.rsa.e);
            free(current_vdn);
            ta->pkey.key.rsa.n = NULL;
            ta->pkey.key.rsa.e = NULL;
            ta->dn.data        = NULL;
            return false;
         }
         break;
      case BR_KEYTYPE_EC:
         ta->pkey.key_type     = BR_KEYTYPE_EC;
         ta->pkey.key.ec.curve = pk->key.ec.curve;
         ta->pkey.key.ec.qlen  = pk->key.ec.qlen;
         ta->pkey.key.ec.q     = blobdup(pk->key.ec.q, pk->key.ec.qlen);
         if (!ta->pkey.key.ec.q)
         {
            free(current_vdn);
            ta->dn.data = NULL;
            return false;
         }
         break;
      default:
         /* Pre-existing leak: same pattern as the '!pk || !isCA'
          * early return above.  current_vdn was orphaned. */
         free(current_vdn);
         ta->dn.data = NULL;
         return false;
   }

   TAs_NUM++;
   return true;
}

/* Every certificate in @certs_pem (NUL-terminated) decoded where it
 * lies, over its own base64, and added as a trust anchor, which copies
 * what it keeps. Stops when the anchor table is full. */
static void append_certs_pem_x509(char *certs_pem)
{
   static const char begin[] = "-----BEGIN CERTIFICATE-----";
   static const char end_[]  = "-----END CERTIFICATE-----";
   char *p = certs_pem;

   while (TAs_NUM < sizeof(TAs) / sizeof(TAs[0]))
   {
      char  *b, *stop;
      size_t n;
      if (!(b = strstr(p, begin)))
         break;
      b += STRLEN_CONST(begin);
      if (!(stop = strstr(b, end_)))
         break;
      p = stop + STRLEN_CONST(end_);
      n = unbase64_into(b, (size_t)(stop - b), (unsigned char*)b);
      if (n != (size_t)-1 && n)
         append_cert_x509(b, n);
   }
}

/* TODO: not thread safe, rthreads doesn't provide any
 * statically allocatable mutex/etc */
static void initialize(void)
{
   static bool tried = false;
   void   *certs_pem = NULL;
   if (tried)
      return;
   /* filestream_read_file appends a NUL; a missing bundle is not read
    * again at every connection */
   if (filestream_read_file("/etc/ssl/certs/ca-certificates.crt",
            &certs_pem, NULL))
      append_certs_pem_x509((char*)certs_pem);
   free(certs_pem);
   tried = true;
}

/* BearSSL's br_ssl_client_init_full (below) always performs full
 * verification and fails closed on a bad chain, which is the REQUIRED
 * policy. The OPTIONAL/DISABLED opt-out has no native BearSSL equivalent
 * (it would need a permissive end_chain X.509 vtable), so this backend
 * keeps verifying whatever mode is selected. */
void ssl_socket_set_verify_mode(unsigned mode)
{
   (void)mode;
}

void* ssl_socket_init(int fd, const char *domain)
{
   struct ssl_state *state = (struct ssl_state*)calloc(1, sizeof(*state));

   /* NULL-check before any of the br_ssl_* calls below dereference
    * state.  The pre-patch form segfaulted on OOM at the first
    * br_ssl_client_init_full(&state->sc, ...) call.  Caller
    * (net_http.c line 1030) already NULL-checks our return. */
   if (!state)
      return NULL;

   initialize();

   br_ssl_client_init_full(&state->sc, &state->xc, TAs, TAs_NUM);
   br_ssl_engine_set_buffer(&state->sc.eng,
         state->iobuf, sizeof(state->iobuf), true);
   br_ssl_client_reset(&state->sc, domain, false);

   state->fd = fd;
   if (domain)
      strlcpy(state->domain, domain, sizeof(state->domain));
   return state;
}

static bool process_inner(struct ssl_state *state, bool blocking)
{
   bool dummy = false;
   size_t buflen;
   ssize_t bytes;
   uint8_t *buf = br_ssl_engine_sendrec_buf(&state->sc.eng, &buflen);

   if (buflen)
   {
      if (blocking)
         bytes = (socket_send_all_blocking(state->fd, buf, buflen, true)
               ? buflen
               : -1);
      else
         bytes = socket_send_all_nonblocking(state->fd, buf, buflen, true);

      if (bytes > 0)
         br_ssl_engine_sendrec_ack(&state->sc.eng, bytes);
      if (bytes < 0)
         return false;
      /* if we did something, return immediately so we
       * don't try to read if Bear still wants to send */
      return true;
   }

   buf = br_ssl_engine_recvrec_buf(&state->sc.eng, &buflen);
   if (buflen)
   {
      /* A blocking read waits for the server's next bytes, but no
       * longer than SSL_SOCKET_IO_TIMEOUT_MS: a server that goes silent
       * would otherwise hold recv() for good. */
      if (blocking)
      {
         bool rd = true;
         if (     !socket_wait(state->fd, &rd, NULL, SSL_SOCKET_IO_TIMEOUT_MS)
               || !rd)
            return false;
      }
      /* if the socket is blocking, socket_receive_all_nonblocking blocks,
       * but only to read at least 1 byte which is exactly what we want */
      bytes = socket_receive_all_nonblocking(state->fd, &dummy, buf, buflen);
      if (bytes > 0)
         br_ssl_engine_recvrec_ack(&state->sc.eng, bytes);
      if (bytes < 0 || dummy)
         return false;
   }

   return true;
}

int ssl_socket_last_error(void *state_data)
{
   struct ssl_state *state = (struct ssl_state*)state_data;
   if (!state)
      return 0;
   return br_ssl_engine_last_error(&state->sc.eng);
}

/* Weak no-op logging hooks; RetroArch overrides these in network/tls_log.c.
 * See net_socket_ssl_mbed.c for why they are weak and not in griffin. */
#if (defined(__GNUC__) || defined(__clang__)) && !defined(HAVE_GRIFFIN)
__attribute__((weak))
void ssl_socket_log_verify_fail(int mode_required, const char *domain,
      const char *verify_info)
{
   (void)mode_required; (void)domain; (void)verify_info;
}

__attribute__((weak))
void ssl_socket_log_verify_disabled(const char *domain)
{
   (void)domain;
}
#endif

/* A handshake that ended on the certificate goes to the verify hook,
 * as the other backends' refusals do. BearSSL always verifies, so every
 * such failure is a required one. */
static void ssl_bear_report_verify(struct ssl_state *state)
{
   char info[64];
   int err = br_ssl_engine_last_error(&state->sc.eng);

   if (err <= BR_ERR_X509_OK || err >= BR_ERR_X509_OK + 32)
      return;
   switch (err)
   {
      case BR_ERR_X509_EXPIRED:
         strlcpy(info, "certificate expired or not yet valid", sizeof(info));
         break;
      case BR_ERR_X509_BAD_SERVER_NAME:
         strlcpy(info, "certificate does not match the host", sizeof(info));
         break;
      case BR_ERR_X509_NOT_TRUSTED:
         strlcpy(info, "certificate is not trusted", sizeof(info));
         break;
      default:
         sprintf(info, "BearSSL X.509 error %d", err);
         break;
   }
   ssl_socket_log_verify_fail(1, state->domain, info);
}

int ssl_socket_handshake_step(void *state_data, bool *read, bool *write)
{
   struct ssl_state *state = (struct ssl_state*)state_data;
   unsigned status;
   if (read)
      *read = false;
   if (write)
      *write = false;
   if (!state || state->handshake_state < 0)
      return -1;
   if (state->handshake_state >= 2)
      return 1;
   if (!state->handshake_state)
   {
      if (!socket_set_block(state->fd, false))
         goto error;
      state->handshake_state = 1;
   }
   if (!process_inner(state, false))
      goto error;
   status = br_ssl_engine_current_state(&state->sc.eng);
   if (status & BR_SSL_CLOSED)
      goto error;
   if (status & BR_SSL_SENDAPP)
   {
      state->handshake_state = 2;
      return 1;
   }
   if (read)
      *read = (status & BR_SSL_RECVREC) != 0;
   if (write)
      *write = (status & BR_SSL_SENDREC) != 0;
   return 0;
error:
   state->handshake_state = -1;
   ssl_bear_report_verify(state);
   return -1;
}

int ssl_socket_connect(void *state_data,
      void *data, bool timeout_enable, bool nonblock)
{
   struct ssl_state *state = (struct ssl_state*)state_data;
   int result;
   bool read, write;
   (void)nonblock;
   if (!state)
      return -1;
   if (timeout_enable)
   {
      if (!socket_connect_with_timeout(state->fd, data, 5000))
         return -1;
   }
   else if (socket_connect(state->fd, data))
      return -1;
   while ((result = ssl_socket_handshake_step(state, &read, &write)) == 0)
   {
      if ((read || write)
            && (!socket_wait(state->fd, &read, &write, SSL_SOCKET_IO_TIMEOUT_MS)
               || !(read || write)))
      {
         state->handshake_state = -1;
         return -1;
      }
   }
   if (result < 0 || !socket_set_block(state->fd, true))
      return -1;
   return 1;
}

ssize_t ssl_socket_receive_all_nonblocking(void *state_data,
      bool *err, void *data_, size_t len)
{
   size_t __len;
   uint8_t *bear_data;
   struct ssl_state *state = (struct ssl_state*)state_data;
   socket_set_block(state->fd, false);
   if (!process_inner(state, false))
   {
      *err = true;
      return -1;
   }
   bear_data = br_ssl_engine_recvapp_buf(&state->sc.eng, &__len);
   if (__len > len)
      __len = len;
   /* recvapp_buf returns NULL when it has nothing; memcpy() declares
    * its pointers nonnull even for a zero length, so the copy has to
    * sit under the same guard as the ack. */
   if (__len)
   {
      memcpy(data_, bear_data, __len);
      br_ssl_engine_recvapp_ack(&state->sc.eng, __len);
   }
   return __len;
}

int ssl_socket_receive_all_blocking(void *state_data,
      void *data_, size_t len)
{
   size_t __len;
   struct ssl_state *state = (struct ssl_state*)state_data;
   uint8_t           *data = (uint8_t*)data_;
   uint8_t *         bear_data;

   socket_set_block(state->fd, true);

   for (;;)
   {
      bear_data = br_ssl_engine_recvapp_buf(&state->sc.eng, &__len);
      if (__len > len)
         __len = len;
      /* Same as the nonblocking path: bear_data is NULL when the
       * engine has no plaintext ready, so only copy under the guard. */
      if (__len)
      {
         memcpy(data, bear_data, __len);
         br_ssl_engine_recvapp_ack(&state->sc.eng, __len);
      }
      data += __len;
      len -= __len;

      if (len)
         process_inner(state, true);
      else
         break;
   }
   return 1;
}

int ssl_socket_send_all_blocking(void *state_data,
      const void *data_, size_t len, bool no_signal)
{
   size_t __len;
   struct ssl_state *state = (struct ssl_state*)state_data;
   const     uint8_t *data = (const uint8_t*)data_;
   uint8_t *         bear_data;

   socket_set_block(state->fd, true);

   for (;;)
   {
      bear_data = br_ssl_engine_sendapp_buf(&state->sc.eng, &__len);
      if (__len > len)
         __len = len;
      memcpy(bear_data, data_, __len);
      if (__len)
         br_ssl_engine_sendapp_ack(&state->sc.eng, __len);
      data += __len;
      len  -= __len;

      if (len)
         process_inner(state, true);
      else
         break;
   }

   br_ssl_engine_flush(&state->sc.eng, false);
   process_inner(state, false);
   return 1;
}

/* Takes what fits in the engine's output buffer now and pushes what the
 * socket will take.  0 means the engine is full of records the socket
 * has not taken yet; ssl_socket_flush_nonblocking() moves them on. */
ssize_t ssl_socket_send_all_nonblocking(void *state_data,
      const void *data_, size_t len, bool no_signal)
{
   size_t __len;
   uint8_t *bear_data;
   struct ssl_state *state = (struct ssl_state*)state_data;
   (void)no_signal;

   if (br_ssl_engine_current_state(&state->sc.eng) == BR_SSL_CLOSED)
      return -1;
   socket_set_block(state->fd, false);
   /* Make room first: records already sealed go before new ones. */
   if (!process_inner(state, false))
      return -1;
   bear_data = br_ssl_engine_sendapp_buf(&state->sc.eng, &__len);
   if (__len > len)
      __len = len;
   /* sendapp_buf returns NULL with nothing free; memcpy() declares its
    * pointers nonnull even for a zero length. */
   if (__len)
   {
      memcpy(bear_data, data_, __len);
      br_ssl_engine_sendapp_ack(&state->sc.eng, __len);
      br_ssl_engine_flush(&state->sc.eng, false);
      if (!process_inner(state, false))
         return -1;
   }
   return (ssize_t)__len;
}

int ssl_socket_flush_nonblocking(void *state_data)
{
   size_t buflen;
   struct ssl_state *state = (struct ssl_state*)state_data;

   if (br_ssl_engine_current_state(&state->sc.eng) == BR_SSL_CLOSED)
      return -1;
   socket_set_block(state->fd, false);
   br_ssl_engine_flush(&state->sc.eng, false);
   /* process_inner() sends at most one batch per call and stops when
    * the socket does; loop while it makes progress. */
   for (;;)
   {
      size_t before;
      br_ssl_engine_sendrec_buf(&state->sc.eng, &before);
      if (!before)
         return 1;
      if (!process_inner(state, false))
         return -1;
      br_ssl_engine_sendrec_buf(&state->sc.eng, &buflen);
      if (buflen >= before)
         return 0;
   }
}

int ssl_socket_close_notify(void *state_data)
{
   struct ssl_state *state = (struct ssl_state*)state_data;
   if (     !state || state->fd < 0 || state->handshake_state != 2
         || !socket_set_block(state->fd, false))
      return -1;
   br_ssl_engine_close(&state->sc.eng);
   process_inner(state, false);
   /* Sent: no second one at the close */
   state->handshake_state = 3;
   return 0;
}

void ssl_socket_close(void *state_data)
{
   struct ssl_state *state = (struct ssl_state*)state_data;
   if (!state || state->fd < 0)
      return;
   ssl_socket_close_notify(state);
   socket_close(state->fd);
   state->fd = -1;
   state->handshake_state = -1;
}

void ssl_socket_free(void *state_data)
{
   struct ssl_state *state = (struct ssl_state*)state_data;
   /* BearSSL does zero allocations of its own,
    * so other than this struct, there is nothing to free */
   free(state);
}
