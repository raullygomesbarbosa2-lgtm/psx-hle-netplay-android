package com.swordfish.libretrodroid;

/** Receives a copy of the stereo signed 16-bit PCM produced by the active Libretro core. */
public interface AudioCaptureListener {
    void onAudioSamples(short[] interleavedStereo, int sampleRate, int frames);
}
