plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.psxhlenative.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.psxhlenative.app"
        minSdk = 23
        targetSdk = 29
        versionCode = 52
        versionName = "1.0.52-projection-service-fix"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("com.github.swordfish90:libretrodroid:0.14.0")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
