package com.psxhlenative.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder

class ProjectionService : Service() {
    inner class LocalBinder : Binder() {
        fun service(): ProjectionService = this@ProjectionService
    }

    private val binder = LocalBinder()
    @Volatile private var projection: MediaProjection? = null

    fun currentProjection(): MediaProjection? = projection

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotificationChannel()
        val notificationBuilder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
        }
        val notification = notificationBuilder
            .setContentTitle("NEXPLAY PS")
            .setContentText("Espelhamento ativo para o P2")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            @Suppress("DEPRECATION")
            startForeground(NOTIFICATION_ID, notification)
        }

        if (projection == null) {
            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
            val consent = if (Build.VERSION.SDK_INT >= 33) {
                intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION")
                intent?.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            if (resultCode != 0 && consent != null) {
                projection = runCatching {
                    (getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager)
                        .getMediaProjection(resultCode, consent)
                }.getOrNull()
            }
            if (projection == null) {
                stopSelf(startId)
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL_ID, "Espelhamento NEXPLAY PS", NotificationManager.IMPORTANCE_LOW)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        projection?.let { p -> runCatching { p.stop() } }
        projection = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(STOP_FOREGROUND_REMOVE) else {
            @Suppress("DEPRECATION")
            stopForeground(true)
        }
        super.onDestroy()
    }

    companion object {
        const val EXTRA_RESULT_CODE = "nexplay.resultCode"
        const val EXTRA_RESULT_DATA = "nexplay.resultData"
        private const val CHANNEL_ID = "nexplay_mirror"
        private const val NOTIFICATION_ID = 3041
    }
}
