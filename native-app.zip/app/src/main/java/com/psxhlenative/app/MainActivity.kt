package com.psxhlenative.app

import android.app.AlertDialog
import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.util.Base64
import android.content.Context
import android.content.pm.ActivityInfo
import android.view.InputDevice
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.io.InputStream
import java.io.BufferedInputStream
import java.util.zip.ZipInputStream
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.TimeUnit
import kotlin.math.hypot

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(12, 15, 21)
    private val panel = Color.rgb(23, 28, 38)
    private val accent = Color.rgb(48, 224, 139)
    private val firebaseApiKey = "AIzaSyBnS2Uuvyx46hcuPSKWlbW2B0vNsSXeoXU"
    private lateinit var root: android.view.ViewGroup
    private lateinit var status: TextView
    private var retroView: GLRetroView? = null
    private var userId = ""
    private var userEmail = ""
    private var gamerName = ""
    private var idToken = ""
    private var refreshToken = ""
    private var emailVerified = false
    private var authMode = "login"
    private var activeTab = "home"
    private var pendingGameFile: File? = null
    private var currentGameFile: File? = null
    private var shareConsentPrompted = false
    private var netSocket: WebSocket? = null
    private var roomCode = ""
    private var roomRole = ""
    private var peerConnected = false
    private var peerApproved = false
    private var remoteControllerMode = false
    private var remoteButtons = 0xffff
    private var remoteLX = 128
    private var remoteLY = 128
    private val socketClient by lazy { OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).build() }
    private val recentGames = mutableListOf<String>()
    private val chatLines = mutableListOf<String>()
    private var chatLogView: TextView? = null
    private var dialogChatView: TextView? = null
    private var triggerLDown = false
    private var triggerRDown = false
    private var remoteGameImage: android.widget.ImageView? = null
    private var remoteVideoWait: TextView? = null
    private var latestRemoteBitmap: Bitmap? = null
    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var captureThread: HandlerThread? = null
    private var lastStreamFrameAt = 0L
    private var screenWidth = 0
    private var screenHeight = 0
    private var restoringSession = false

    private val pickGame = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importGame(uri)
    }

    // ACTION_OPEN_DOCUMENT / SAF is the supported Android 6+ file path and grants durable read access.
    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching { contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            importGame(uri, zipOnly = true)
        }
    }

    // Fallback for OEM pickers which fail to expose ZIPs through SAF.
    private val pickZipDocument = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) importGame(uri, zipOnly = true, allowPickerFallback = false)
    }

    private val captureConsent = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val data = result.data
        if (result.resultCode == Activity.RESULT_OK && data != null) startScreenShare(result.resultCode, data)
        else { shareConsentPrompted = false; showMessage("A captura não foi autorizada. Sem a confirmação do Android no P1, o P2 não recebe a imagem do jogo.") }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        restoreSessionAndRoom()
    }

    private fun sessionPrefs() = getSharedPreferences("nexplay_session", Context.MODE_PRIVATE)

    private fun saveSession() {
        sessionPrefs().edit()
            .putString("userId", userId)
            .putString("email", userEmail)
            .putString("gamerName", gamerName)
            .putString("refreshToken", refreshToken)
            .putBoolean("emailVerified", emailVerified)
            .apply()
    }

    private fun saveRoom() {
        sessionPrefs().edit().putString("roomCode", roomCode).putString("roomRole", roomRole).apply()
    }

    private fun restoreSessionAndRoom() {
        val prefs = sessionPrefs()
        refreshToken = prefs.getString("refreshToken", "").orEmpty()
        userId = prefs.getString("userId", "").orEmpty()
        userEmail = prefs.getString("email", "").orEmpty()
        gamerName = prefs.getString("gamerName", "").orEmpty()
        emailVerified = prefs.getBoolean("emailVerified", false)
        roomCode = prefs.getString("roomCode", "").orEmpty()
        roomRole = prefs.getString("roomRole", "").orEmpty()
        if (refreshToken.isBlank()) { showHomeScreen(); return }
        restoringSession = true
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(20), dp(20), dp(20), dp(20)); setBackgroundColor(bg) }
        root.addView(label("NEXPLAY PS", 24, Color.WHITE, true).apply { gravity = Gravity.CENTER })
        root.addView(label("Restaurando tua sessão…", 14, Color.LTGRAY, false).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
        setContentView(root)
        lifecycleScope.launch {
            val restored = withContext(Dispatchers.IO) {
                runCatching {
                    val token = postForm("https://securetoken.googleapis.com/v1/token?key=$firebaseApiKey", "grant_type=refresh_token&refresh_token=${urlEncode(refreshToken)}")
                    val newRefresh = token.optString("refresh_token", refreshToken)
                    val newId = token.getString("id_token")
                    val info = postJson("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=$firebaseApiKey", JSONObject().put("idToken", newId))
                    val user = info.getJSONArray("users").getJSONObject(0)
                    Triple(token, user, newRefresh)
                }
            }
            restored.onSuccess { (token, user, newRefresh) ->
                idToken = token.getString("id_token")
                refreshToken = newRefresh
                userId = user.optString("localId", userId)
                userEmail = user.optString("email", userEmail)
                gamerName = user.optString("displayName", userEmail.substringBefore('@'))
                emailVerified = user.optBoolean("emailVerified", false)
                saveSession()
                restoringSession = false
                if (emailVerified && roomCode.length == 6 && roomRole in setOf("p1", "p2")) connectRoom() else showHomeScreen()
            }.onFailure { error ->
                restoringSession = false
                val reason = error.message.orEmpty()
                val tokenRevoked = reason.contains("INVALID_REFRESH_TOKEN", true) || reason.contains("USER_DISABLED", true) || reason.contains("TOKEN_EXPIRED", true)
                if (tokenRevoked) {
                    sessionPrefs().edit().remove("refreshToken").remove("userId").remove("email").remove("gamerName").remove("emailVerified").remove("roomCode").remove("roomRole").apply()
                    userId = ""; userEmail = ""; gamerName = ""; idToken = ""; refreshToken = ""; emailVerified = false; roomCode = ""; roomRole = ""
                    showHomeScreen()
                    showMessage("A sessão expirou ou foi revogada. Entra novamente com teu e-mail e senha.")
                } else {
                    // Network/provider errors must not silently sign the player out or erase their room.
                    showHomeScreen()
                    if (emailVerified && roomCode.length == 6 && roomRole in setOf("p1", "p2")) connectRoom()
                    showMessage("Sem conexão para atualizar a sessão agora. Mantive teu login salvo; vou tentar conectar à sala.")
                }
            }
        }
    }

    private fun showHomeScreen() {
        remoteControllerMode = false
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        retroView = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(16))
            setBackgroundColor(bg)
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = label("NEXPLAY PS", 24, Color.WHITE, true)
        head.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(label(if (userId.isNotEmpty()) gamerName else "Android nativo", 12, accent, true))
        root.addView(head)
        root.addView(label("ANDROID 6+  ·  PCSX-REARMED  ·  HLE", 10, Color.GRAY, true).apply {
            setPadding(0, dp(3), 0, dp(13))
        })

        if (userId.isEmpty()) {
            showLoginContent()
        } else if (!emailVerified) {
            showVerificationContent()
        } else {
            if (activeTab == "home" || activeTab == "solo" || activeTab == "games") activeTab = "netplay"
            showNavigation()
            when (activeTab) {
                "account" -> showAccountContent()
                else -> showNetPlayContent()
            }
        }
        setContentView(root)
    }

    private fun showNavigation() {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(10)) }
        listOf("netplay" to "MULTIPLAYER", "account" to "CONTA").forEach { (tab, title) ->
            val b = button(title, if (activeTab == tab) accent else Color.rgb(35, 43, 56)).apply {
                textSize = 9f
                setPadding(dp(7), dp(11), dp(7), dp(11))
                setOnClickListener { activeTab = tab; showHomeScreen() }
            }
            row.addView(b, LinearLayout.LayoutParams(0, dp(43), 1f).apply { marginEnd = dp(3) })
        }
        root.addView(row)
    }

    private fun showLoginContent() {
        root.addView(label("ENTRAR NA SUA CONTA", 20, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(6)) })
        root.addView(label("Crie ou acesse sua conta por e-mail, como no projeto original. Confirme o endereço para liberar os modos.", 13, Color.LTGRAY, false).apply { setPadding(0, 0, 0, dp(12)) })
        val card = card()
        val nameField = if (authMode == "register") edit("Nome de jogador") else null
        nameField?.let { card.addView(it, fieldParams()) }
        val emailField = edit("E-mail").apply { inputType = 33 }
        val passwordField = edit("Senha").apply { inputType = 129 }
        card.addView(emailField, fieldParams())
        card.addView(passwordField, fieldParams())
        val submit = button(if (authMode == "register") "CRIAR CONTA" else "ENTRAR", accent)
        submit.setOnClickListener {
            val email = emailField.text.toString().trim()
            val pass = passwordField.text.toString()
            val name = nameField?.text?.toString()?.trim().orEmpty()
            if (email.isBlank() || pass.length < 6 || (authMode == "register" && name.length < 2)) {
                showMessage("Preenche o e-mail, senha com pelo menos 6 caracteres e nome de jogador válido.")
                return@setOnClickListener
            }
            submit.isEnabled = false
            lifecycleScope.launch {
                val result = withContext(Dispatchers.IO) { authenticate(email, pass, name, authMode == "register") }
                submit.isEnabled = true
                result.onSuccess { authResult ->
                    userId = authResult.optString("localId")
                    userEmail = authResult.optString("email", email)
                    gamerName = authResult.optString("displayName", name.ifBlank { email.substringBefore('@') })
                    idToken = authResult.optString("idToken")
                    refreshToken = authResult.optString("refreshToken")
                    emailVerified = authResult.optBoolean("emailVerified", false)
                    activeTab = "home"
                    if (authMode == "register") {
                        sendVerificationEmail()
                        emailVerified = false
                    }
                    saveSession()
                    showHomeScreen()
                }.onFailure { showMessage(it.message ?: "Falha no login.") }
            }
        }
        card.addView(submit, fieldParams())
        val switch = button(if (authMode == "register") "JÁ TENHO CONTA · ENTRAR" else "CRIAR UMA CONTA", Color.rgb(35, 43, 56))
        switch.setOnClickListener { authMode = if (authMode == "register") "login" else "register"; showHomeScreen() }
        card.addView(switch, fieldParams())
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        root.addView(label("O acesso Firebase depende de e-mail/senha estar habilitado no projeto original.", 11, Color.GRAY, false).apply { setPadding(0, dp(12), 0, 0) })
    }

    private data class AuthResult(val json: JSONObject)

    private fun authenticate(email: String, password: String, displayName: String, create: Boolean): Result<JSONObject> = runCatching {
        val endpoint = if (create) "accounts:signUp" else "accounts:signInWithPassword"
        val result = postJson("https://identitytoolkit.googleapis.com/v1/$endpoint?key=$firebaseApiKey", JSONObject().apply {
            put("email", email); put("password", password); put("returnSecureToken", true)
        })
        if (create) {
            val update = postJson("https://identitytoolkit.googleapis.com/v1/accounts:update?key=$firebaseApiKey", JSONObject().apply {
                put("idToken", result.getString("idToken")); put("displayName", displayName); put("returnSecureToken", true)
            })
            result.put("displayName", displayName)
            if (update.has("idToken")) result.put("idToken", update.getString("idToken"))
            result.put("emailVerified", false)
        } else {
            val info = postJson("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=$firebaseApiKey", JSONObject().put("idToken", result.getString("idToken")))
            val user = info.getJSONArray("users").getJSONObject(0)
            result.put("emailVerified", user.optBoolean("emailVerified", false))
            result.put("displayName", user.optString("displayName", email.substringBefore('@')))
        }
        result
    }

    private fun sendVerificationEmail() {
        lifecycleScope.launch(Dispatchers.IO) {
            runCatching { postJson("https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=$firebaseApiKey", JSONObject().put("requestType", "VERIFY_EMAIL").put("idToken", idToken)) }
        }
    }

    private fun refreshAndCheckVerification() {
        lifecycleScope.launch {
            val check = withContext(Dispatchers.IO) {
                runCatching {
                    val token = postForm("https://securetoken.googleapis.com/v1/token?key=$firebaseApiKey", "grant_type=refresh_token&refresh_token=${urlEncode(refreshToken)}")
                    idToken = token.getString("id_token")
                    refreshToken = token.getString("refresh_token")
                    val info = postJson("https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=$firebaseApiKey", JSONObject().put("idToken", idToken))
                    info.getJSONArray("users").getJSONObject(0).optBoolean("emailVerified", false)
                }
            }
            check.onSuccess { verified ->
                emailVerified = verified
                saveSession()
                if (!verified) showMessage("Ainda consta como não confirmado. Abre o link enviado ao teu e-mail e tenta de novo.")
                showHomeScreen()
            }.onFailure { showMessage(it.message ?: "Não consegui conferir a confirmação.") }
        }
    }

    private fun showVerificationContent() {
        root.addView(label("CONFIRMA TEU E-MAIL", 20, Color.WHITE, true).apply { setPadding(0, dp(10), 0, dp(8)) })
        root.addView(label("Enviamos o link para $userEmail. Depois de confirmar, toca no botão abaixo.", 14, Color.LTGRAY, false).apply { setPadding(0, 0, 0, dp(16)) })
        val check = button("JÁ CONFIRMEI O E-MAIL", accent)
        check.setOnClickListener { refreshAndCheckVerification() }
        root.addView(check, fieldParams())
        val resend = button("REENVIAR LINK", Color.rgb(35, 43, 56))
        resend.setOnClickListener { sendVerificationEmail(); showMessage("Pedido de reenvio enviado.") }
        root.addView(resend, fieldParams())
        val change = button("SAIR / TROCAR CONTA", Color.rgb(35, 43, 56))
        change.setOnClickListener { clearSession(); showHomeScreen() }
        root.addView(change, fieldParams())
    }

    private fun showModeHome() {
        activeTab = "netplay"
        showNetPlayContent()
    }

    private fun showSoloContent() {
        root.addView(label("MODO SOLO", 20, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(10)) })
        root.addView(label("Escolhe um arquivo de disco PS1. Formatos aceitos dependem do PCSX-ReARMed; jogos e BIOS não vêm incluídos.", 13, Color.LTGRAY, false).apply { setPadding(0, 0, 0, dp(14)) })
        val open = button("ABRIR IMAGEM DE JOGO", accent)
        open.setOnClickListener { pickGame.launch(arrayOf("*/*")) }
        root.addView(open, fieldParams())
        val openZip = button("ABRIR JOGO EM ARQUIVO ZIP", Color.rgb(35, 43, 56))
        openZip.setOnClickListener { openZipPicker() }
        root.addView(openZip, fieldParams())
        root.addView(label("O ZIP pode conter BIN ou BIN+CUE; o app extrai e abre o disco. Também aceita ISO, IMG, CHD e PBP pelo botão acima.", 11, Color.GRAY, false).apply { setPadding(0, dp(6), 0, 0) })
    }

    private fun showNetPlayContent() {
        root.addView(label("MULTIPLAYER · SALAS", 20, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(6)) })
        root.addView(label("Login confirmado: $gamerName", 12, accent, false).apply { setPadding(0, 0, 0, dp(10)) })
        val card = card()
        val codeField = edit("Código de 6 caracteres").apply { setText(roomCode) }
        card.addView(label("P1 cria a sala, escolhe a ISO e libera o P2. P2 só informa o código: não precisa de arquivo de jogo.", 13, Color.LTGRAY, false).apply { setPadding(0, 0, 0, dp(10)) })
        card.addView(codeField, fieldParams())
        val create = button("CRIAR SALA · P1", accent)
        create.setOnClickListener {
            roomCode = randomRoomCode()
            roomRole = "p1"
            codeField.setText(roomCode)
            connectRoom()
        }
        card.addView(create, fieldParams())
        val join = button("ENTRAR NA SALA · P2", Color.rgb(35, 43, 56))
        join.setOnClickListener {
            val code = codeField.text.toString().uppercase().filter { it.isLetterOrDigit() }.take(6)
            if (code.length != 6) { showMessage("O código da sala precisa ter 6 caracteres."); return@setOnClickListener }
            roomCode = code; roomRole = "p2"; connectRoom()
        }
        card.addView(join, fieldParams())
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        if (roomCode.isNotEmpty()) {
            root.addView(label("SALA $roomCode · ${if (roomRole == "p1") "P1 / HOST" else "P2 / CONVIDADO"}", 17, accent, true).apply { setPadding(0, dp(14), 0, dp(6)) })
            root.addView(label(if (!peerConnected) "Conectando à sala…" else if (roomRole == "p1") "P2 ${if (peerApproved) "entrou no jogo" else "aguardando conexão ou ISO do P1"}" else "Na sala do P1 · aguardando o mesmo jogo", 12, Color.LTGRAY, false))
            val roomChat = button("CHAT DA SALA", Color.rgb(35, 43, 56))
            roomChat.setOnClickListener { openRoomChat() }
            root.addView(roomChat, fieldParams())
            if (roomRole == "p1") {
                val chooseGame = button("ESCOLHER ISO PARA A SALA · P1", accent)
                chooseGame.setOnClickListener { activeTab = "netplay"; pickGame.launch(arrayOf("*/*")) }
                root.addView(chooseGame, fieldParams())
                val chooseZip = button("ESCOLHER ZIP PARA A SALA · P1", Color.rgb(35, 43, 56))
                chooseZip.setOnClickListener { activeTab = "netplay"; openZipPicker() }
                root.addView(chooseZip, fieldParams())
                root.addView(label("O P2 é liberado automaticamente quando estiver conectado e o P1 iniciar a ISO.", 11, Color.GRAY, false).apply { setPadding(0, dp(4), 0, dp(8)) })
            }
            if (roomRole == "p2" && peerApproved) {
                root.addView(label("P2 liberado automaticamente: entrando no jogo do P1 sem ISO local.", 11, accent, false).apply { setPadding(0, dp(8), 0, dp(4)) })
            }
            if (roomRole == "p2") {
                root.addView(label("P2 não precisa escolher nem enviar ISO. O P1 inicia o jogo e libera a sala.", 11, Color.GRAY, false).apply { setPadding(0, dp(8), 0, dp(4)) })
                if (peerApproved) {
                    root.addView(label("CONTROLES P2 · comandos enviados ao host", 12, accent, true).apply { setPadding(0, dp(8), 0, dp(4)) })
                    root.addView(makeNetPlayControls(), LinearLayout.LayoutParams(-1, dp(205)))
                }
            }
            val disconnect = button("SAIR DA SALA", Color.rgb(54, 37, 43))
            disconnect.setOnClickListener { stopScreenShare(); currentGameFile = null; shareConsentPrompted = false; netSocket?.close(1000, "leave"); netSocket = null; roomCode = ""; roomRole = ""; peerConnected = false; peerApproved = false; saveRoom(); showHomeScreen() }
            root.addView(disconnect, fieldParams())
        }
    }

    private fun connectRoom() {
        saveRoom()
        netSocket?.close(1000, "reconnect")
        peerConnected = false
        val url = "wss://psx-hle-netplay-android.onrender.com/ws/netplay?roomCode=${urlEncode(roomCode)}&uid=${urlEncode(userId)}&gamerTag=${urlEncode(gamerName)}&role=$roomRole"
        val req = Request.Builder().url(url).build()
        netSocket = socketClient.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                runOnUiThread { peerConnected = true; if (retroView == null && !remoteControllerMode) showHomeScreen(); if (roomRole == "p1") sendRoomControl() }
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                runOnUiThread {
                    runCatching {
                        val msg = JSONObject(text)
                        when (msg.optString("type")) {
                            "room:state" -> {
                                val previousPeerConnected = peerConnected
                                val wasApproved = peerApproved
                                peerConnected = msg.optBoolean(if (roomRole == "p1") "p2Connected" else "p1Connected")
                                peerApproved = msg.optBoolean("p2Approved")
                                if (roomRole == "p1" && peerConnected && retroView != null && (!peerApproved || !previousPeerConnected)) {
                                    peerApproved = true
                                    sendRoomControl()
                                    requestScreenShareOnce()
                                }
                                if (roomRole == "p2" && peerConnected && peerApproved && !remoteControllerMode) launchRemoteControllerScreen()
                                else if (roomRole == "p2" && remoteControllerMode && !peerApproved) {
                                    remoteControllerMode = false
                                    restoreSystemBars()
                                    showHomeScreen()
                                }
                                if (roomRole == "p1" && peerApproved && !wasApproved && retroView != null) requestScreenShareOnce()
                                if (retroView == null && !remoteControllerMode) showHomeScreen()
                            }
                            "netplay:frame" -> {
                                if (roomRole == "p2") {
                                    val encoded = msg.optJSONObject("data")?.optString("img", "").orEmpty()
                                    if (encoded.isNotEmpty()) decodeRemoteFrame(encoded)
                                }
                            }
                            "netplay:chat" -> {
                                val who = msg.optString("name", "Jogador")
                                val text = msg.optString("text", "")
                                if (text.isNotBlank()) {
                                    chatLines.add("$who: $text")
                                    if (chatLines.size > 60) chatLines.removeAt(0)
                                    chatLogView?.text = chatLines.joinToString("\n")
                                    dialogChatView?.text = chatLines.joinToString("\n")
                                }
                            }
                            "netplay:input" -> if (roomRole == "p1" && peerApproved) {
                                val mask = msg.optInt("buttons", 0xffff)
                                val mappings = listOf(
                                    (1 shl 0) to KeyEvent.KEYCODE_BUTTON_SELECT, (1 shl 3) to KeyEvent.KEYCODE_BUTTON_START,
                                    (1 shl 4) to KeyEvent.KEYCODE_DPAD_UP, (1 shl 5) to KeyEvent.KEYCODE_DPAD_RIGHT,
                                    (1 shl 6) to KeyEvent.KEYCODE_DPAD_DOWN, (1 shl 7) to KeyEvent.KEYCODE_DPAD_LEFT,
                                    (1 shl 8) to KeyEvent.KEYCODE_BUTTON_L2, (1 shl 9) to KeyEvent.KEYCODE_BUTTON_R2,
                                    (1 shl 10) to KeyEvent.KEYCODE_BUTTON_L1, (1 shl 11) to KeyEvent.KEYCODE_BUTTON_R1,
                                    (1 shl 12) to KeyEvent.KEYCODE_BUTTON_X, (1 shl 13) to KeyEvent.KEYCODE_BUTTON_A,
                                    (1 shl 14) to KeyEvent.KEYCODE_BUTTON_B, (1 shl 15) to KeyEvent.KEYCODE_BUTTON_Y
                                )
                                mappings.forEach { (bit, key) -> retroView?.sendKeyEvent(if (mask and bit == 0) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, key, 1) }
                                val lx = (msg.optInt("lx", 128) - 128) / 127f
                                val ly = (msg.optInt("ly", 128) - 128) / 127f
                                retroView?.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, lx, ly, 1)
                            }
                        }
                    }
                }
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                runOnUiThread { peerConnected = false; showMessage("Falha ao conectar à sala: ${t.message ?: "sem resposta"}"); if (retroView == null && !remoteControllerMode) showHomeScreen() }
            }
        })
        showHomeScreen()
    }

    private fun sendRoomControl() {
        val title = currentGameFile?.name ?: pendingGameFile?.name ?: "PlayStation 1"
        netSocket?.send(JSONObject().put("type", "room:control").put("p2Approved", peerApproved).put("p2CanSelectCharacter", true).put("gameId", "ps1").put("gameTitle", title).toString())
    }

    private fun requestScreenShareOnce() {
        if (shareConsentPrompted || mediaProjection != null || roomRole != "p1" || !peerApproved || !peerConnected || retroView == null) return
        shareConsentPrompted = true
        requestScreenShare()
    }

    private fun showGamesContent() {
        root.addView(label("BIBLIOTECA DESTA SESSÃO", 20, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(10)) })
        if (recentGames.isEmpty()) root.addView(label("Ainda não escolheste um jogo nesta sessão.", 13, Color.LTGRAY, false))
        recentGames.forEach { name -> modeCard(name, "Abrir no emulador nativo") { showMessage("Escolhe novamente o arquivo do jogo pelo seletor Android.") } }
        val add = button("ESCOLHER JOGO", accent)
        add.setOnClickListener { activeTab = "solo"; showHomeScreen() }
        root.addView(add, fieldParams())
    }

    private fun showAccountContent() {
        root.addView(label("CONTA", 20, Color.WHITE, true).apply { setPadding(0, dp(8), 0, dp(8)) })
        root.addView(label("$gamerName\n$userEmail", 14, Color.LTGRAY, false).apply { setPadding(0, 0, 0, dp(14)) })
        root.addView(label("A sessão fica salva neste aparelho quando você sai do jogo. Para sair da conta, usa o botão abaixo.", 12, Color.GRAY, false).apply { setPadding(0, 0, 0, dp(12)) })
        val logout = button("SAIR DA CONTA", Color.rgb(54, 37, 43))
        logout.setOnClickListener { netSocket?.close(1000, "signout"); clearSession(); showHomeScreen() }
        root.addView(logout, fieldParams())
    }

    private fun openZipPicker() {
        // Android 6 OEM file apps sometimes need legacy shared-storage read access for their non-SAF URI fallback.
        if (android.os.Build.VERSION.SDK_INT in 23..32) {
            if (checkSelfPermission(android.Manifest.permission.READ_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE), REQUEST_ZIP_STORAGE)
                return
            }
            val roots = externalStorageRoots()
            if (roots.isNotEmpty()) showZipRootPicker(roots) else launchZipDocumentPicker()
        } else launchZipDocumentPicker()
    }

    private fun launchZipDocumentPicker() {
        // SAF wildcard: scoped-storage Android versions and providers with arbitrary MIME labels.
        pickZip.launch(arrayOf("*/*"))
    }

    private fun externalStorageRoots(): List<File> {
        val roots = linkedSetOf<File>()
        runCatching { roots.add(android.os.Environment.getExternalStorageDirectory().canonicalFile) }
        if (android.os.Build.VERSION.SDK_INT >= 19) {
            getExternalFilesDirs(null).filterNotNull().forEach { appDir ->
                val raw = appDir.absolutePath
                val marker = raw.indexOf("/Android/data/")
                if (marker > 0) runCatching { roots.add(File(raw.substring(0, marker)).canonicalFile) }
            }
        }
        return roots.filter { it.exists() && it.isDirectory && it.canRead() }.distinctBy { it.absolutePath }
    }

    private fun showZipRootPicker(roots: List<File>) {
        if (roots.size == 1) { showZipFileBrowser(roots.first(), roots.first()); return }
        val names = roots.mapIndexed { index, root ->
            val label = if (index == 0) "Armazenamento interno" else "Cartão/armazenamento ${index + 1}"
            "$label · ${root.absolutePath}"
        }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Onde está o ZIP?")
            .setItems(names) { _, which -> roots.getOrNull(which)?.let { showZipFileBrowser(it, it) } }
            .setNeutralButton("Seletor Android") { _, _ -> launchZipDocumentPicker() }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showZipFileBrowser(directory: File, storageRoot: File) {
        val safeRoot = runCatching { storageRoot.canonicalFile }.getOrElse { storageRoot.absoluteFile }
        val current = runCatching { directory.canonicalFile }.getOrElse { safeRoot }
        if (!current.path.startsWith(safeRoot.path)) { showMessage("Essa pasta está fora do armazenamento permitido."); return }
        val dirs = current.listFiles()?.filter { it.isDirectory && !it.isHidden && it.canRead() }?.sortedBy { it.name.lowercase() }.orEmpty()
        val zips = current.listFiles()?.filter { it.isFile && !it.isHidden && it.canRead() && it.name.endsWith(".zip", true) }?.sortedBy { it.name.lowercase() }.orEmpty()
        val entries = mutableListOf<Pair<String, File?>>()
        if (current.path != safeRoot.path) entries.add("⬆ .." to current.parentFile)
        dirs.forEach { entries.add("📁 ${it.name}" to it) }
        zips.forEach { entries.add("📦 ${it.name} · ${formatBytes(it.length())}" to it) }
        val labels = entries.map { it.first }.toTypedArray()
        val dialog = AlertDialog.Builder(this)
            .setTitle("Escolher ZIP · ${current.name.ifBlank { "Armazenamento" }}")
            .setItems(labels) { _, which ->
                val chosen = entries.getOrNull(which)?.second ?: return@setItems
                if (chosen.isDirectory) showZipFileBrowser(chosen, safeRoot) else importGame(Uri.fromFile(chosen), zipOnly = true, allowPickerFallback = false)
            }
            .setNeutralButton("Seletor Android") { _, _ -> launchZipDocumentPicker() }
            .setNegativeButton("Cancelar", null)
        if (entries.isEmpty()) dialog.setMessage("Nenhum ZIP nesta pasta. Abre uma pasta para procurar ou usa Seletor Android.")
        dialog.show()
    }

    private fun formatBytes(bytes: Long): String = when {
        bytes >= 1024L * 1024L * 1024L -> String.format(java.util.Locale.US, "%.2f GB", bytes / (1024.0 * 1024.0 * 1024.0))
        bytes >= 1024L * 1024L -> String.format(java.util.Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0))
        bytes >= 1024L -> String.format(java.util.Locale.US, "%.1f KB", bytes / 1024.0)
        else -> "$bytes B"
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_ZIP_STORAGE) {
            if (grantResults.isNotEmpty() && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                val roots = externalStorageRoots()
                if (roots.isNotEmpty()) showZipRootPicker(roots) else launchZipDocumentPicker()
            }
            else showMessage("Para ler ZIP pelo gerenciador antigo do Android 6, autoriza o acesso aos arquivos e tenta novamente. O seletor SAF ainda não acessa o arquivo desse provedor sem essa permissão.")
        }
    }

    companion object { private const val REQUEST_ZIP_STORAGE = 4206 }

    private fun importGame(uri: Uri, zipOnly: Boolean = false, allowPickerFallback: Boolean = true) {
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val name = queryDisplayName(uri) ?: "ps1-game.iso"
                    val safeName = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._ -]"), "_").ifBlank { "ps1-game.iso" }
                    val source = openUriInputStream(uri) ?: error("Não consegui ler o arquivo escolhido. Tenta o seletor ZIP integrado ou move o arquivo para Downloads.")
                    prepareSelectedGame(source, safeName, zipOnly)
                }
            }
            result.onSuccess { file ->
                pendingGameFile = file
                if (!recentGames.contains(file.name)) recentGames.add(0, file.name)
                launchNativeGame(file)
            }.onFailure { error ->
                val message = error.message ?: "Falha ao importar o arquivo."
                val accessFailure = error is java.io.FileNotFoundException || message.contains("gerenciador", true) || message.contains("No such file", true) || message.contains("acesso", true)
                if (zipOnly && allowPickerFallback && accessFailure) {
                    // Retry through the older Android content picker if the SAF provider itself cannot read the item.
                    pickZipDocument.launch("*/*")
                } else showMessage(message)
            }
        }
    }

    private fun prepareSelectedGame(input: InputStream, displayName: String, zipOnly: Boolean): File {
        val buffered = BufferedInputStream(input)
        buffered.mark(8)
        val signature = ByteArray(4)
        val count = buffered.read(signature)
        buffered.reset()
        val isZip = count >= 4 && signature[0] == 0x50.toByte() && signature[1] == 0x4b.toByte() && (
            (signature[2] == 0x03.toByte() && signature[3] == 0x04.toByte()) ||
            (signature[2] == 0x05.toByte() && signature[3] == 0x06.toByte()) ||
            (signature[2] == 0x07.toByte() && signature[3] == 0x08.toByte())
        )
        if (zipOnly && !isZip) error("O arquivo escolhido não é ZIP. Escolhe um arquivo .zip.")
        val gameFile = if (isZip) {
            extractPsxZip(buffered, displayName)
        } else {
            val importDir = File(filesDir, "game_imports")
            if (!importDir.exists() && !importDir.mkdirs()) error("Não consegui criar a pasta privada de jogos.")
            val target = File(importDir, "${System.currentTimeMillis()}_$displayName")
            buffered.use { source -> FileOutputStream(target).use { out ->
                val buffer = ByteArray(64 * 1024)
                while (true) {
                    val n = source.read(buffer)
                    if (n < 0) break
                    if (filesDir.usableSpace < n + 8L * 1024L * 1024L) error("Espaço livre insuficiente no aparelho para copiar esse jogo.")
                    out.write(buffer, 0, n)
                }
            } }
            target
        }
        if (!gameFile.exists() || gameFile.length() <= 0L) error("O arquivo do jogo está vazio.")
        return gameFile
    }

    private fun openUriInputStream(uri: Uri): InputStream? {
        runCatching { contentResolver.openInputStream(uri) }.getOrNull()?.let { return it }
        runCatching { contentResolver.openAssetFileDescriptor(uri, "r")?.createInputStream() }.getOrNull()?.let { return it }
        runCatching { contentResolver.openFileDescriptor(uri, "r")?.let { android.os.ParcelFileDescriptor.AutoCloseInputStream(it) } }.getOrNull()?.let { return it }
        val candidatePaths = linkedSetOf<String>()
        if (uri.scheme.equals("file", true)) uri.path?.let(candidatePaths::add)
        // Android 6 external-storage documents often expose a usable raw path only through documentId.
        runCatching {
            if (android.os.Build.VERSION.SDK_INT >= 19 && android.provider.DocumentsContract.isDocumentUri(this, uri) && uri.authority == "com.android.externalstorage.documents") {
                val docId = android.provider.DocumentsContract.getDocumentId(uri)
                val split = docId.split(":", limit = 2)
                if (split.size == 2 && split[0].equals("primary", true)) {
                    candidatePaths.add(File(android.os.Environment.getExternalStorageDirectory(), split[1]).absolutePath)
                }
            }
        }
        // Legacy MediaStore/OEM providers may expose the filesystem path in _data.
        runCatching {
            contentResolver.query(uri, arrayOf("_data"), null, null, null)?.use { cursor ->
                val index = cursor.getColumnIndex("_data")
                if (index >= 0 && cursor.moveToFirst()) cursor.getString(index)?.let(candidatePaths::add)
            }
        }
        for (path in candidatePaths) {
            val file = File(path)
            if (file.isFile && file.canRead()) runCatching { FileInputStream(file) }.getOrNull()?.let { return it }
        }
        return null
    }

    private fun InputStream.readNBytesCompat(length: Int): ByteArray {
        val buffer = ByteArray(length)
        var offset = 0
        while (offset < length) {
            val count = read(buffer, offset, length - offset)
            if (count <= 0) break
            offset += count
        }
        return if (offset == length) buffer else buffer.copyOf(offset)
    }

    private fun extractPsxZip(input: java.io.InputStream, archiveName: String): File {
        val importsRoot = File(filesDir, "psx_imports")
        if (!importsRoot.exists() && !importsRoot.mkdirs()) error("Não consegui criar a pasta para extrair o ZIP.")
        val rootDir = File(importsRoot, "${archiveName.substringBeforeLast('.')}_${System.currentTimeMillis()}")
        if (!rootDir.mkdirs()) error("Não consegui criar uma pasta para extrair a BIN do ZIP.")
        var count = 0
        val reserveBytes = minOf(64L * 1024L * 1024L, maxOf(4L * 1024L * 1024L, rootDir.usableSpace / 50L))
        val found = mutableListOf<File>()
        ZipInputStream(BufferedInputStream(input)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                count++
                if (count > 10000) error("O ZIP tem entradas demais e foi recusado.")
                val raw = entry.name.replace('\\', '/')
                if (raw.startsWith("/") || raw.split('/').any { it == ".." }) error("O ZIP contém um caminho inseguro.")
                if (entry.isDirectory) { zip.closeEntry(); continue }
                val destination = File(rootDir, raw).canonicalFile
                if (!destination.path.startsWith(rootDir.canonicalPath + File.separator)) error("O ZIP contém um caminho fora da pasta permitida.")
                val parent = destination.parentFile ?: error("O caminho da BIN dentro do ZIP é inválido.")
                if (!parent.exists() && !parent.mkdirs()) error("Não consegui criar uma pasta interna durante a extração do ZIP.")
                if (!parent.isDirectory || !parent.canWrite()) error("Sem acesso para gravar o jogo extraído do ZIP.")
                FileOutputStream(destination).use { out ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = zip.read(buffer)
                        if (n < 0) break
                        if (rootDir.usableSpace < n.toLong() + reserveBytes) error("O ZIP é maior do que o espaço livre disponível para extraí-lo. Libera espaço ou escolhe um ZIP menor.")
                        out.write(buffer, 0, n)
                    }
                }
                if (destination.extension.lowercase() in setOf("cue", "iso", "bin", "img", "chd", "pbp", "mdf", "toc", "cbn", "m3u", "exe")) found.add(destination)
                zip.closeEntry()
            }
        }
        if (found.isEmpty()) error("Não achei uma imagem PS1 compatível dentro do ZIP.")
        val cue = found.firstOrNull { it.extension.equals("cue", true) }
        val list = found.firstOrNull { it.extension.equals("m3u", true) }
        val bin = found.filter { it.extension.equals("bin", true) && it.length() > 0L }.maxByOrNull { it.length() }
        val discImage = found.filter { it.extension.lowercase() in setOf("iso", "chd", "pbp", "img", "mdf", "cbn", "exe", "toc") && it.length() > 0L }.maxByOrNull { it.length() }
        return cue ?: list ?: bin ?: discImage ?: error("O ZIP não contém uma BIN, ISO ou outra imagem de disco PS1 válida.")
    }

    private fun queryDisplayName(uri: Uri): String? {
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) return c.getString(0) }
        }
        if (uri.scheme.equals("file", true)) return uri.path?.let { File(it).name }
        return uri.lastPathSegment
    }

    private fun launchNativeGame(gameFile: File) {
        if (userId.isEmpty() || !emailVerified) { activeTab = "account"; showHomeScreen(); return }
        currentGameFile = gameFile
        val systemDir = File(filesDir, "system").apply { mkdirs() }
        val saveDir = File(filesDir, "saves").apply { mkdirs() }
        val coreFile = File(applicationInfo.nativeLibraryDir, "pcsx_rearmed_libretro_android.so")
        if (!coreFile.exists()) { showMessage("O núcleo PS1 não foi encontrado dentro do APK."); return }

        applyImmersiveLandscape()
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val stage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(stage, FrameLayout.LayoutParams(-1, -1))
        val data = GLRetroViewData(this).apply {
            coreFilePath = coreFile.absolutePath
            gameFilePath = gameFile.absolutePath
            systemDirectory = systemDir.absolutePath
            savesDirectory = saveDir.absolutePath
            shader = ShaderConfig.Default
            preferLowLatencyAudio = true
            rumbleEventsEnabled = true
        }
        val view = GLRetroView(this, data)
        retroView = view
        lifecycle.addObserver(view)
        stage.addView(view, FrameLayout.LayoutParams(-1, -1))
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = rounded(Color.argb(105, 8, 12, 18), dp(12), Color.argb(70, 120, 140, 160))
        }
        val back = button("‹", Color.argb(120, 30, 40, 52)).apply {
            textSize = 20f
            setPadding(dp(10), dp(3), dp(10), dp(3))
            setOnClickListener { leaveGameToMenu() }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(36)))
        header.addView(label("NEXPLAY PS · ${gameFile.name}", 11, Color.WHITE, true).apply { setPadding(dp(9), 0, 0, 0); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }, LinearLayout.LayoutParams(0, dp(38), 1f))
        stage.addView(header, FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP))
        if (roomCode.isNotEmpty()) addInGameChat(stage)
        stage.addView(makeControls(), FrameLayout.LayoutParams(-1, dp(132), Gravity.BOTTOM))
        setContentView(root)
        if (roomRole == "p1") {
            // Starting the ISO is the release event: no second button is needed.
            if (peerConnected) peerApproved = true
            sendRoomControl()
            if (peerApproved) requestScreenShareOnce()
        }
        lifecycleScope.launch {
            view.getGLRetroEvents().collect { event ->
                if (event == GLRetroView.GLRetroEvents.SurfaceCreated) {
                    // PCSX-ReARMed uses the DualShock subclass for analog axes; a plain digital pad ignores stick axes.
                    view.setControllerType(0, 517)
                    view.setControllerType(1, 517)
                }
            }
        }
        lifecycleScope.launch { view.getGLRetroErrors().collect { code -> runOnUiThread { showMessage("Núcleo não iniciou este arquivo (erro $code).") } } }
    }

    private fun applyImmersiveLandscape() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        )
    }

    private fun restoreSystemBars() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
    }

    private fun leaveGameToMenu() {
        retroView?.let { it.onDestroy(); lifecycle.removeObserver(it) }
        retroView = null
        stopScreenShare()
        shareConsentPrompted = false
        // Leaving the game returns both players to the still-connected room, but keeps the account logged in.
        if (roomRole == "p1" && peerApproved) {
            peerApproved = false
            sendRoomControl()
        }
        if (remoteControllerMode) remoteControllerMode = false
        restoreSystemBars()
        activeTab = if (roomCode.isNotEmpty()) "netplay" else "solo"
        showHomeScreen()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && retroView != null) applyImmersiveLandscape()
    }

    private fun requestScreenShare() {
        if (roomRole != "p1" || roomCode.isBlank() || !peerConnected || !peerApproved) {
            showMessage("P1 precisa estar conectado e liberar o jogador P2 antes de iniciar o compartilhamento.")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Compartilhar a tela do P1?")
            .setMessage("O Android vai mostrar uma confirmação do sistema. Se autorizar, a captura da tela do jogo e dos controles será enviada ao jogador P2 enquanto esta sessão estiver aberta.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Continuar") { _, _ ->
                val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                captureConsent.launch(manager.createScreenCaptureIntent())
            }
            .show()
    }

    private fun startScreenShare(resultCode: Int, data: android.content.Intent) {
        stopScreenShare()
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val projection = manager.getMediaProjection(resultCode, data)
            mediaProjection = projection
            val size = android.graphics.Point()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealSize(size)
            val landscapeWidth = maxOf(size.x, size.y)
            val landscapeHeight = minOf(size.x, size.y)
            val ratio = landscapeWidth.toFloat() / landscapeHeight.coerceAtLeast(1)
            var w = (480f).toInt()
            var h = (w / ratio).toInt()
            w = (w / 16) * 16
            h = maxOf(16, (h / 16) * 16)
            screenWidth = w
            screenHeight = h
            val density = resources.displayMetrics.densityDpi
            captureThread = HandlerThread("NexPlayScreenShare").apply { start() }
            val handler = Handler(captureThread!!.looper)
            val reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            imageReader = reader
            reader.setOnImageAvailableListener({ source -> captureAndSend(source) }, handler)
            virtualDisplay = projection.createVirtualDisplay(
                "NEXPLAY PS room stream",
                w,
                h,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                handler
            )
            val callback = object : MediaProjection.Callback() {
                override fun onStop() { runOnUiThread { stopScreenShare() } }
            }
            projection.registerCallback(callback, handler)
            showMessage("Compartilhamento autorizado. O Android está transmitindo a tela do P1 para o P2 enquanto o jogo estiver aberto.")
        } catch (t: Throwable) {
            stopScreenShare()
            showMessage("Não consegui iniciar o espelhamento nesta versão do Android: ${t.message ?: "erro desconhecido"}")
        }
    }

    private fun captureAndSend(reader: ImageReader) {
        val image = try { reader.acquireLatestImage() } catch (_: Throwable) { null } ?: return
        image.use { frame ->
            val now = SystemClock.elapsedRealtime()
            if (now - lastStreamFrameAt < 150L || roomRole != "p1" || !peerConnected || !peerApproved) return
            if (netSocket == null || (netSocket?.queueSize() ?: 0L) > 500_000L) return
            lastStreamFrameAt = now
            try {
                val plane = frame.planes.firstOrNull() ?: return
                val src = plane.buffer.duplicate()
                val rowStride = plane.rowStride
                val pixelStride = plane.pixelStride
                val raw = ByteArray(screenWidth * screenHeight * 4)
                for (y in 0 until minOf(screenHeight, frame.height)) {
                    val srcRow = y * rowStride
                    val dstRow = y * screenWidth * 4
                    for (x in 0 until minOf(screenWidth, frame.width)) {
                        val srcIndex = srcRow + x * pixelStride
                        val dstIndex = dstRow + x * 4
                        if (srcIndex + 3 < src.limit() && dstIndex + 3 < raw.size) {
                            raw[dstIndex] = src.get(srcIndex)
                            raw[dstIndex + 1] = src.get(srcIndex + 1)
                            raw[dstIndex + 2] = src.get(srcIndex + 2)
                            raw[dstIndex + 3] = src.get(srcIndex + 3)
                        }
                    }
                }
                val bitmap = Bitmap.createBitmap(screenWidth, screenHeight, Bitmap.Config.ARGB_8888)
                bitmap.copyPixelsFromBuffer(java.nio.ByteBuffer.wrap(raw))
                var encoded = encodeJpeg(bitmap, 42)
                if (encoded.size > 250_000) {
                    val smaller = Bitmap.createScaledBitmap(bitmap, maxOf(160, screenWidth * 2 / 3), maxOf(90, screenHeight * 2 / 3), true)
                    encoded = encodeJpeg(smaller, 35)
                    smaller.recycle()
                }
                bitmap.recycle()
                if (encoded.size > 280_000) return
                val imageData = "data:image/jpeg;base64," + Base64.encodeToString(encoded, Base64.NO_WRAP)
                val payload = JSONObject().put("type", "netplay:frame").put("data", JSONObject().put("img", imageData)).toString()
                netSocket?.send(payload)
            } catch (_: Throwable) {
                // Skip a malformed/late frame; the next ImageReader callback supplies a fresh one.
            }
        }
    }

    private fun encodeJpeg(bitmap: Bitmap, quality: Int): ByteArray {
        val output = java.io.ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, quality, output)
        return output.toByteArray()
    }

    private fun decodeRemoteFrame(dataUri: String) {
        lifecycleScope.launch(Dispatchers.Default) {
            runCatching {
                val payload = dataUri.substringAfter(",", dataUri)
                val bytes = Base64.decode(payload, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            }.getOrNull()?.let { bitmap ->
                withContext(Dispatchers.Main) {
                    latestRemoteBitmap?.recycle()
                    latestRemoteBitmap = bitmap
                    remoteGameImage?.setImageBitmap(bitmap)
                    remoteVideoWait?.visibility = View.GONE
                }
            }
        }
    }

    private fun stopScreenShare() {
        try { virtualDisplay?.release() } catch (_: Throwable) { }
        virtualDisplay = null
        try { imageReader?.setOnImageAvailableListener(null, null); imageReader?.close() } catch (_: Throwable) { }
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Throwable) { }
        mediaProjection = null
        captureThread?.quitSafely()
        captureThread = null
        screenWidth = 0
        screenHeight = 0
    }

    private fun launchRemoteControllerScreen() {
        if (roomRole != "p2" || !peerApproved) return
        remoteControllerMode = true
        applyImmersiveLandscape()
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val stage = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(stage, FrameLayout.LayoutParams(-1, -1))
        val video = android.widget.ImageView(this).apply { scaleType = android.widget.ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.BLACK); setImageBitmap(latestRemoteBitmap) }
        remoteGameImage = video
        stage.addView(video, FrameLayout.LayoutParams(-1, -1))
        val message = label("CONECTADO À SALA\nAguardando o vídeo do P1…", 15, Color.LTGRAY, true).apply { gravity = Gravity.CENTER; textAlignment = View.TEXT_ALIGNMENT_CENTER; setBackgroundColor(Color.argb(70, 0, 0, 0)) }
        remoteVideoWait = message
        stage.addView(message, FrameLayout.LayoutParams(-1, -1))
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(4)); background = rounded(Color.argb(105, 8, 12, 18), dp(12), Color.argb(70, 120, 140, 160)) }
        val back = button("‹", Color.argb(120, 30, 40, 52)).apply { setOnClickListener { remoteControllerMode = false; restoreSystemBars(); showHomeScreen() } }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(36)))
        header.addView(label("NEXPLAY PS · ${currentGameFile?.name ?: "JOGO DO P1"}", 11, Color.WHITE, true).apply { setPadding(dp(8), 0, 0, 0); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }, LinearLayout.LayoutParams(0, dp(38), 1f))
        stage.addView(header, FrameLayout.LayoutParams(-1, dp(46), Gravity.TOP))
        addInGameChat(stage)
        stage.addView(makeNetPlayControls(), FrameLayout.LayoutParams(-1, dp(135), Gravity.BOTTOM))
        setContentView(root)
        applyImmersiveLandscape()
    }

    private fun sendChatMessage(text: String): Boolean {
        val clean = text.trim().take(400)
        if (clean.isEmpty()) return false
        return netSocket?.send(JSONObject().put("type", "netplay:chat").put("text", clean).toString()) == true
    }

    private fun openRoomChat() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(6)) }
        box.addView(label("Conversa da sala $roomCode", 16, Color.WHITE, true).apply { setPadding(0, 0, 0, dp(8)) })
        val history = TextView(this).apply { text = chatLines.joinToString("\n"); textSize = 12f; setTextColor(Color.DKGRAY); setPadding(dp(5), dp(5), dp(5), dp(5)) }
        dialogChatView = history
        val scroll = ScrollView(this).apply { addView(history); isFillViewport = true }
        box.addView(scroll, LinearLayout.LayoutParams(-1, dp(190)))
        val input = EditText(this).apply { hint = "Escreve uma mensagem"; setSingleLine(true) }
        box.addView(input, fieldParams())
        val dialog = AlertDialog.Builder(this).setView(box).setNegativeButton("Fechar", null).create()
        val send = button("ENVIAR", accent)
        box.addView(send, LinearLayout.LayoutParams(-1, dp(42)))
        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (sendChatMessage(text)) input.text.clear()
            else if (text.isNotEmpty()) showMessage("Ainda não há conexão ativa com a sala.")
        }
        dialog.setOnDismissListener { dialogChatView = null }
        dialog.show()
    }

    private fun addInGameChat(stage: FrameLayout) {
        val toggle = button("CHAT", accent)
        stage.addView(toggle, FrameLayout.LayoutParams(dp(68), dp(42), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(10), dp(10), 0) })
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = rounded(Color.rgb(16, 20, 28), dp(14), accent)
            visibility = View.GONE
            elevation = dp(12).toFloat()
        }
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(label("CHAT · SALA $roomCode", 11, Color.WHITE, true), LinearLayout.LayoutParams(0, dp(32), 1f))
        val close = button("×", Color.rgb(43, 52, 66)).apply { setPadding(dp(11), dp(5), dp(11), dp(5)) }
        head.addView(close)
        panel.addView(head)
        val history = TextView(this).apply {
            text = chatLines.joinToString("\n")
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(dp(6), dp(5), dp(6), dp(5))
            gravity = Gravity.BOTTOM
        }
        chatLogView = history
        val scroll = ScrollView(this).apply { addView(history); isFillViewport = true }
        panel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val compose = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val input = EditText(this).apply {
            hint = "Escreve uma mensagem"
            textSize = 12f
            setTextColor(Color.WHITE)
            setHintTextColor(Color.LTGRAY)
            setSingleLine(true)
            setPadding(dp(8), 0, dp(8), 0)
            background = rounded(Color.rgb(31, 38, 49), dp(9), Color.rgb(65, 78, 96))
        }
        compose.addView(input, LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
        val send = button("ENVIAR", accent).apply { textSize = 9f; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        send.setOnClickListener {
            val text = input.text.toString().trim().take(400)
            if (text.isNotEmpty() && sendChatMessage(text)) {
                input.text.clear()
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            } else if (text.isNotEmpty()) showMessage("Ainda não há conexão com a sala para enviar o chat.")
        }
        compose.addView(send, LinearLayout.LayoutParams(-2, dp(40)))
        panel.addView(compose, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(4) })
        val params = FrameLayout.LayoutParams(dp(290), dp(230), Gravity.TOP or Gravity.END).apply { setMargins(0, dp(58), dp(10), 0) }
        stage.addView(panel, params)
        toggle.setOnClickListener { panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE; if (panel.visibility == View.VISIBLE) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) } }
        close.setOnClickListener { panel.visibility = View.GONE }
    }

    private fun makeNetPlayControls(): View {
                val outer = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(4), dp(5), dp(4)); background = rounded(Color.argb(54, 23, 28, 38), dp(14), Color.argb(30, 80, 100, 120)) }
        val stick = AnalogStick(this) { x, y, _ ->
            remoteLX = (128 + x * 127).toInt().coerceIn(0, 255)
            remoteLY = (128 + y * 127).toInt().coerceIn(0, 255)
            setRemoteButton(KeyEvent.KEYCODE_DPAD_LEFT, x < -0.35f)
            setRemoteButton(KeyEvent.KEYCODE_DPAD_RIGHT, x > 0.35f)
            setRemoteButton(KeyEvent.KEYCODE_DPAD_UP, y < -0.35f)
            setRemoteButton(KeyEvent.KEYCODE_DPAD_DOWN, y > 0.35f)
            sendRemotePad()
        }
        outer.addView(stick, LinearLayout.LayoutParams(0, -1, 1f))
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val keys = listOf("△" to (1 shl 12), "□" to (1 shl 15), "○" to (1 shl 13), "×" to (1 shl 14), "L1" to (1 shl 10), "R1" to (1 shl 11), "SELECT" to (1 shl 0), "START" to (1 shl 3))
        keys.chunked(4).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            group.forEach { (text, bit) -> row.addView(remoteButton(text, bit), LinearLayout.LayoutParams(dp(if (text.length > 2) 54 else 42), dp(40)).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) }) }
            center.addView(row)
        }
        outer.addView(center, LinearLayout.LayoutParams(0, -1, 1.5f))
        return outer
    }

    private fun remoteButton(text: String, bit: Int): TextView = TextView(this).apply {
        this.text = text; textSize = if (text.length > 2) 9f else 15f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.argb(135, 31, 38, 49), dp(10), Color.argb(90, 125, 145, 165))
        setOnTouchListener { v, e ->
            if (!peerApproved || netSocket == null) return@setOnTouchListener true
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { remoteButtons = remoteButtons and bit.inv(); v.alpha = .7f; sendRemotePad(); true }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { remoteButtons = remoteButtons or bit; v.alpha = 1f; sendRemotePad(); true }
                else -> true
            }
        }
    }

    private fun setRemoteButton(key: Int, pressed: Boolean) {
        val bit = when (key) {
            KeyEvent.KEYCODE_BUTTON_SELECT -> 1 shl 0
            KeyEvent.KEYCODE_BUTTON_START -> 1 shl 3
            KeyEvent.KEYCODE_DPAD_UP -> 1 shl 4
            KeyEvent.KEYCODE_DPAD_RIGHT -> 1 shl 5
            KeyEvent.KEYCODE_DPAD_DOWN -> 1 shl 6
            KeyEvent.KEYCODE_DPAD_LEFT -> 1 shl 7
            KeyEvent.KEYCODE_BUTTON_L2 -> 1 shl 8
            KeyEvent.KEYCODE_BUTTON_R2 -> 1 shl 9
            KeyEvent.KEYCODE_BUTTON_L1 -> 1 shl 10
            KeyEvent.KEYCODE_BUTTON_R1 -> 1 shl 11
            KeyEvent.KEYCODE_BUTTON_X -> 1 shl 12
            KeyEvent.KEYCODE_BUTTON_A -> 1 shl 13
            KeyEvent.KEYCODE_BUTTON_B -> 1 shl 14
            KeyEvent.KEYCODE_BUTTON_Y -> 1 shl 15
            else -> return
        }
        remoteButtons = if (pressed) remoteButtons and bit.inv() else remoteButtons or bit
        sendRemotePad()
    }

    private fun sendRemotePad() {
        if (roomRole == "p2" && peerApproved) {
            netSocket?.send(JSONObject().put("type", "netplay:input").put("buttons", remoteButtons).put("lx", remoteLX).put("ly", remoteLY).toString())
        }
    }

    private fun makeControls(): View {
        val outer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(5), dp(4), dp(5), dp(4)); background = rounded(Color.argb(54, 23, 28, 38), dp(14), Color.argb(30, 80, 100, 120)) }
        val shoulder = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf("L2" to KeyEvent.KEYCODE_BUTTON_L2, "L1" to KeyEvent.KEYCODE_BUTTON_L1).forEach { (t,k) -> shoulder.addView(controlButton(t,k), LinearLayout.LayoutParams(0, dp(28), 1f).apply { marginEnd = dp(5) }) }
        shoulder.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        listOf("R1" to KeyEvent.KEYCODE_BUTTON_R1, "R2" to KeyEvent.KEYCODE_BUTTON_R2).forEach { (t,k) -> shoulder.addView(controlButton(t,k), LinearLayout.LayoutParams(0, dp(28), 1f).apply { marginStart = dp(5) }) }
        outer.addView(shoulder, LinearLayout.LayoutParams(-1, dp(30)))
        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        val stick = AnalogStick(this) { x, y, down ->
            if (roomRole == "p2" && peerApproved) {
                remoteLX = (128 + x * 127).toInt().coerceIn(0, 255)
                remoteLY = (128 + y * 127).toInt().coerceIn(0, 255)
                sendRemotePad()
            } else {
                retroView?.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, x, y, 0)
                retroView?.sendMotionEvent(
                    GLRetroView.MOTION_SOURCE_DPAD,
                    if (kotlin.math.abs(x) > 0.35f) kotlin.math.sign(x) else 0f,
                    if (kotlin.math.abs(y) > 0.35f) kotlin.math.sign(y) else 0f,
                    0
                )
            }
        }
        body.addView(stick, LinearLayout.LayoutParams(0, -1, 1.1f))
        val mid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        mid.addView(controlButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT), LinearLayout.LayoutParams(dp(65), dp(34)).apply { rightMargin = dp(4) })
        mid.addView(controlButton("START", KeyEvent.KEYCODE_BUTTON_START), LinearLayout.LayoutParams(dp(65), dp(34)))
        body.addView(mid, LinearLayout.LayoutParams(0, -1, 1.4f))
        val face = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        face.addView(controlButton("△", KeyEvent.KEYCODE_BUTTON_X), LinearLayout.LayoutParams(dp(40), dp(32)))
        val middle = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        middle.addView(controlButton("□", KeyEvent.KEYCODE_BUTTON_Y), LinearLayout.LayoutParams(dp(40), dp(32)))
        middle.addView(View(this), LinearLayout.LayoutParams(dp(22), dp(32)))
        middle.addView(controlButton("○", KeyEvent.KEYCODE_BUTTON_A), LinearLayout.LayoutParams(dp(40), dp(32)))
        face.addView(middle)
        face.addView(controlButton("×", KeyEvent.KEYCODE_BUTTON_B), LinearLayout.LayoutParams(dp(40), dp(32)))
        body.addView(face, LinearLayout.LayoutParams(0, -1, 1f))
        outer.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private inner class AnalogStick(context: Context, val changed: (Float, Float, Boolean) -> Unit) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        private var dx = 0f
        private var dy = 0f
        private var active = false
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val radius = minOf(width, height) * .38f
            val cx = width / 2f; val cy = height / 2f
            paint.style = Paint.Style.FILL; paint.color = Color.argb(42, 50, 224, 139); canvas.drawCircle(cx, cy, radius, paint)
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(2).toFloat(); paint.color = accent; canvas.drawCircle(cx, cy, radius, paint)
            paint.style = Paint.Style.FILL; paint.color = if (active) Color.rgb(75, 237, 168) else Color.rgb(118, 139, 154)
            canvas.drawCircle(cx + dx * radius, cy + dy * radius, radius * .42f, paint)
        }
        override fun onTouchEvent(event: MotionEvent): Boolean {
            val r = minOf(width, height) * .38f
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                    active = true
                    var x = ((event.x - width / 2f) / r).coerceIn(-1f, 1f)
                    var y = ((event.y - height / 2f) / r).coerceIn(-1f, 1f)
                    val mag = hypot(x, y)
                    if (mag > 1f) { x /= mag; y /= mag }
                    dx = x; dy = y; changed(x, y, true); invalidate(); return true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    active = false; dx = 0f; dy = 0f; changed(0f, 0f, false); invalidate(); performClick(); return true
                }
            }
            return true
        }
        override fun performClick(): Boolean { super.performClick(); return true }
    }

    private fun controlButton(text: String, key: Int): TextView = TextView(this).apply {
        this.text = text; textSize = if (text.length > 2) 9f else 16f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
        background = rounded(Color.argb(120, 31, 38, 49), dp(10), Color.argb(100, 125, 145, 165)); isFocusable = false
        setOnTouchListener { v, e -> when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { if (roomRole == "p2" && peerApproved) setRemoteButton(key, true) else retroView?.sendKeyEvent(KeyEvent.ACTION_DOWN, key); v.alpha = .7f; true }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (roomRole == "p2" && peerApproved) setRemoteButton(key, false) else retroView?.sendKeyEvent(KeyEvent.ACTION_UP, key); v.alpha = 1f; true }
            else -> true
        } }
    }

    private fun modeCard(title: String, desc: String, action: () -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(14), dp(16), dp(14)); background = rounded(panel, dp(15), Color.rgb(44, 54, 67)); isClickable = true; setOnClickListener { action() } }
        box.addView(label(title, 16, Color.WHITE, true)); box.addView(label(desc, 12, Color.LTGRAY, false).apply { setPadding(0, dp(6), 0, 0) })
        return box.also { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) }) }
    }

    private fun card() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(16)); background = rounded(panel, dp(16), Color.rgb(44, 54, 67)) }
    private fun edit(hintText: String) = EditText(this).apply { hint = hintText; setSingleLine(true); textSize = 14f; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setPadding(dp(12), 0, dp(12), 0); background = rounded(Color.rgb(15, 18, 25), dp(10), Color.rgb(55, 66, 82)) }
    private fun fieldParams() = LinearLayout.LayoutParams(-1, dp(48)).apply { bottomMargin = dp(8) }
    private fun button(text: String, color: Int) = TextView(this).apply { this.text = text; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; setTextColor(if (color == accent) Color.rgb(4, 20, 13) else Color.WHITE); gravity = Gravity.CENTER; setPadding(dp(10), dp(10), dp(10), dp(10)); background = rounded(color, dp(12), color); isClickable = true; isFocusable = true }
    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { this.text = text; textSize = size.toFloat(); setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD }
    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply { setColor(fill); cornerRadius = radius.toFloat(); setStroke(dp(1), stroke) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun showMessage(message: String) = AlertDialog.Builder(this).setMessage(message).setPositiveButton("OK", null).show()
    private fun clearSession() {
        sessionPrefs().edit().clear().apply()
        userId = ""; userEmail = ""; gamerName = ""; idToken = ""; refreshToken = ""; emailVerified = false; authMode = "login"
        roomCode = ""; roomRole = ""; peerConnected = false; peerApproved = false; currentGameFile = null; shareConsentPrompted = false
        stopScreenShare()
    }
    private fun randomRoomCode(): String = (1..6).map { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random() }.joinToString("")
    private fun urlEncode(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun postJson(url: String, json: JSONObject): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 15000; readTimeout = 15000; doOutput = true; setRequestProperty("Content-Type", "application/json") }
        conn.outputStream.use { it.write(json.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val body = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        val result = JSONObject(body)
        if (code !in 200..299) {
            val error = result.optJSONObject("error")?.optString("message") ?: "HTTP $code"
            throw IllegalStateException(when (error.substringBefore(':')) {
                "EMAIL_EXISTS" -> "Este e-mail já tem conta. Escolhe Entrar."
                "INVALID_LOGIN_CREDENTIALS", "EMAIL_NOT_FOUND", "INVALID_PASSWORD" -> "E-mail ou senha incorretos."
                "OPERATION_NOT_ALLOWED" -> "O Firebase ainda não habilitou login por e-mail/senha."
                "WEAK_PASSWORD" -> "A senha precisa ter pelo menos 6 caracteres."
                else -> error
            })
        }
        return result
    }

    private fun postForm(url: String, body: String): JSONObject {
        val conn = (URL(url).openConnection() as HttpURLConnection).apply { requestMethod = "POST"; connectTimeout = 15000; readTimeout = 15000; doOutput = true; setRequestProperty("Content-Type", "application/x-www-form-urlencoded") }
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val text = (if (code in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
        val result = JSONObject(text)
        if (code !in 200..299) throw IllegalStateException(result.optJSONObject("error")?.optString("message") ?: "HTTP $code")
        return result
    }

    override fun onGenericMotionEvent(event: MotionEvent?): Boolean {
        if (event != null && (event.source and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK or InputDevice.SOURCE_DPAD) != 0)) {
            val hatX = event.getAxisValue(MotionEvent.AXIS_HAT_X)
            val hatY = event.getAxisValue(MotionEvent.AXIS_HAT_Y)
            val leftX = event.getAxisValue(MotionEvent.AXIS_X)
            val leftY = event.getAxisValue(MotionEvent.AXIS_Y)
            val rightX = event.getAxisValue(MotionEvent.AXIS_Z)
            val rightY = event.getAxisValue(MotionEvent.AXIS_RZ)
            val lt = event.getAxisValue(MotionEvent.AXIS_LTRIGGER).coerceAtLeast(event.getAxisValue(MotionEvent.AXIS_BRAKE))
            val rt = event.getAxisValue(MotionEvent.AXIS_RTRIGGER).coerceAtLeast(event.getAxisValue(MotionEvent.AXIS_GAS))
            if (roomRole == "p2" && remoteControllerMode && peerApproved) {
                val effectiveX = if (kotlin.math.abs(hatX) > 0.5f) hatX else leftX
                val effectiveY = if (kotlin.math.abs(hatY) > 0.5f) hatY else leftY
                setRemoteButton(KeyEvent.KEYCODE_DPAD_LEFT, effectiveX < -0.5f)
                setRemoteButton(KeyEvent.KEYCODE_DPAD_RIGHT, effectiveX > 0.5f)
                setRemoteButton(KeyEvent.KEYCODE_DPAD_UP, effectiveY < -0.5f)
                setRemoteButton(KeyEvent.KEYCODE_DPAD_DOWN, effectiveY > 0.5f)
                remoteLX = (128 + leftX * 127).toInt().coerceIn(0, 255)
                remoteLY = (128 + leftY * 127).toInt().coerceIn(0, 255)
                sendRemotePad()
            } else {
                val effectiveX = if (kotlin.math.abs(hatX) > 0.5f) hatX else leftX
                val effectiveY = if (kotlin.math.abs(hatY) > 0.5f) hatY else leftY
                retroView?.sendMotionEvent(
                    GLRetroView.MOTION_SOURCE_DPAD,
                    if (kotlin.math.abs(effectiveX) > 0.5f) kotlin.math.sign(effectiveX) else 0f,
                    if (kotlin.math.abs(effectiveY) > 0.5f) kotlin.math.sign(effectiveY) else 0f,
                    0
                )
                retroView?.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, leftX, leftY, 0)
                retroView?.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_RIGHT, rightX, rightY, 0)
            }
            val newL = lt > 0.5f
            val newR = rt > 0.5f
            if (newL != triggerLDown) { triggerLDown = newL; if (roomRole == "p2" && remoteControllerMode) setRemoteButton(KeyEvent.KEYCODE_BUTTON_L2, newL) else retroView?.sendKeyEvent(if (newL) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BUTTON_L2) }
            if (newR != triggerRDown) { triggerRDown = newR; if (roomRole == "p2" && remoteControllerMode) setRemoteButton(KeyEvent.KEYCODE_BUTTON_R2, newR) else retroView?.sendKeyEvent(if (newR) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BUTTON_R2) }
            return true
        }
        return super.onGenericMotionEvent(event)
    }
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val device = event.device
        val fromController = device != null && (device.sources and (InputDevice.SOURCE_GAMEPAD or InputDevice.SOURCE_JOYSTICK or InputDevice.SOURCE_DPAD) != 0)
        val standardPadKey = event.keyCode in setOf(KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1, KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR)
        if ((retroView != null || (remoteControllerMode && roomRole == "p2" && peerApproved)) && (fromController || standardPadKey || KeyEvent.isGamepadButton(event.keyCode))) {
            if (roomRole == "p2" && peerApproved) {
                setRemoteButton(event.keyCode, event.action == KeyEvent.ACTION_DOWN)
            } else {
                retroView?.sendKeyEvent(event.action, event.keyCode, if (roomRole == "p1") 0 else 0)
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }
    @Deprecated("Use OnBackPressedDispatcher")
    override fun onBackPressed() {
        when {
            retroView != null -> leaveGameToMenu()
            remoteControllerMode -> { remoteControllerMode = false; restoreSystemBars(); showHomeScreen() }
            else -> super.onBackPressed()
        }
    }

    override fun onDestroy() { stopScreenShare(); netSocket?.close(1000, "app closed"); socketClient.dispatcher.executorService.shutdown(); super.onDestroy() }
}
