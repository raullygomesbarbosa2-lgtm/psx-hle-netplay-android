package com.psxhlenative.app

import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    private val bg = Color.rgb(12, 15, 21)
    private val panel = Color.rgb(23, 28, 38)
    private val accent = Color.rgb(48, 224, 139)
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var retroView: GLRetroView? = null
    private var currentGameName: String = ""

    private val pickGame = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importAndLaunch(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showLibraryScreen()
    }

    private fun showLibraryScreen() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(18))
            setBackgroundColor(bg)
        }
        val brand = label("PSX HLE", 26, Color.WHITE, true)
        root.addView(brand)
        root.addView(label("EMULADOR NATIVO · SEM WEBVIEW · SEM BIOS EXTERNA", 11, accent, true).apply {
            setPadding(0, dp(5), 0, dp(18))
        })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = rounded(panel, dp(18), Color.rgb(44, 54, 67))
        }
        card.addView(label("JOGAR NO ANDROID", 18, Color.WHITE, true))
        card.addView(label("Escolhe uma imagem de disco PS1 (.cue, .iso, .bin, .chd). O jogo roda no próprio aparelho com PCSX-ReARMed e BIOS HLE interna.", 14, Color.LTGRAY, false).apply {
            setPadding(0, dp(10), 0, dp(18))
        })
        val choose = button("ESCOLHER JOGO", accent)
        choose.setOnClickListener { pickGame.launch(arrayOf("*/*")) }
        card.addView(choose)
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        root.addView(label("Sem jogos incluídos. Abre um arquivo de jogo que você já possui.", 12, Color.GRAY, false).apply {
            setPadding(dp(2), dp(15), 0, dp(6))
        })
        status = label("Pronto para abrir um jogo.", 13, Color.rgb(190, 202, 216), false).apply {
            setPadding(dp(2), dp(8), 0, dp(8))
        }
        root.addView(status)
        setContentView(root)
    }

    private fun importAndLaunch(uri: Uri) {
        status.text = "Copiando a imagem para o armazenamento privado…"
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) {
                try {
                    val name = queryDisplayName(uri) ?: "ps1-game.iso"
                    val safeName = name.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._ -]"), "_")
                    val gameFile = File(cacheDir, safeName)
                    contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(gameFile).use { output -> input.copyTo(output) }
                    } ?: error("Não foi possível abrir esse arquivo.")
                    if (gameFile.length() < 2048L) error("Arquivo muito pequeno ou inválido para um disco de PS1.")
                    Pair(gameFile, null as String?)
                } catch (t: Throwable) {
                    Pair(null, t.message ?: "Falha ao importar a imagem.")
                }
            }
            if (result.first == null) {
                status.text = result.second
                return@launch
            }
            currentGameName = result.first!!.name
            launchNativeGame(result.first!!)
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) return cursor.getString(0)
        }
        return uri.lastPathSegment
    }

    private fun launchNativeGame(gameFile: File) {
        status.text = "Carregando núcleo PlayStation 1 nativo…"
        val systemDir = File(filesDir, "system").apply { mkdirs() }
        val saveDir = File(filesDir, "saves").apply { mkdirs() }
        val coreFile = File(applicationInfo.nativeLibraryDir, "pcsx_rearmed_libretro_android.so")
        if (!coreFile.exists()) {
            status.text = "Núcleo PS1 não foi empacotado no APK (${coreFile.name})."
            return
        }

        root.removeAllViews()
        root.setPadding(dp(10), dp(8), dp(10), dp(8))
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(label("PSX HLE NATIVO", 17, Color.WHITE, true))
        titleCol.addView(label(gameFile.name, 11, accent, false))
        top.addView(titleCol, LinearLayout.LayoutParams(0, -2, 1f))
        val change = button("TROCAR", Color.rgb(39, 52, 68)).apply {
            setOnClickListener { pickGame.launch(arrayOf("*/*")) }
        }
        top.addView(change)
        root.addView(top, LinearLayout.LayoutParams(-1, dp(52)))

        val stage = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            background = rounded(Color.BLACK, dp(9), Color.rgb(58, 69, 81))
            clipToOutline = true
        }
        root.addView(stage, LinearLayout.LayoutParams(-1, 0, 1f).apply {
            topMargin = dp(5); bottomMargin = dp(5)
        })

        val data = GLRetroViewData(this).apply {
            coreFilePath = coreFile.absolutePath
            gameFilePath = gameFile.absolutePath
            systemDirectory = systemDir.absolutePath
            savesDirectory = saveDir.absolutePath
            shader = ShaderConfig.Default
            preferLowLatencyAudio = true
            rumbleEventsEnabled = true
        }
        val view = GLRetroView(this, data)
        retroView = view
        lifecycle.addObserver(view)
        stage.addView(view, FrameLayout.LayoutParams(-1, -1))

        status = label("Iniciando PCSX-ReARMed…", 11, Color.LTGRAY, false).apply {
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(5), 0, dp(5), 0)
        }
        root.addView(status, LinearLayout.LayoutParams(-1, dp(24)))
        root.addView(makeControls(), LinearLayout.LayoutParams(-1, dp(230)))
        setContentView(root)
        status.text = "Jogo carregado no núcleo nativo. HLE entra em ação se não houver BIOS instalada."

        lifecycleScope.launch {
            view.getGLRetroErrors().collect { code ->
                status.text = "O núcleo não conseguiu iniciar este jogo (erro $code). Escolhe outro arquivo de disco PS1."
            }
        }
    }

    private fun makeControls(): View {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(4), dp(4), dp(2))
            background = rounded(panel, dp(14), Color.rgb(39, 46, 58))
        }
        val shoulder = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf("L1" to KeyEvent.KEYCODE_BUTTON_L1, "L2" to KeyEvent.KEYCODE_BUTTON_L2).forEach { (t,k) -> shoulder.addView(controlButton(t,k), weighted()) }
        shoulder.addView(View(this), weighted())
        listOf("R1" to KeyEvent.KEYCODE_BUTTON_R1, "R2" to KeyEvent.KEYCODE_BUTTON_R2).forEach { (t,k) -> shoulder.addView(controlButton(t,k), weighted()) }
        outer.addView(shoulder, LinearLayout.LayoutParams(-1, dp(43)))

        val body = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; weightSum = 3f }
        val dpad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        dpad.addView(controlButton("▲", KeyEvent.KEYCODE_DPAD_UP), LinearLayout.LayoutParams(dp(46), dp(43)))
        val lr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        lr.addView(controlButton("◀", KeyEvent.KEYCODE_DPAD_LEFT), LinearLayout.LayoutParams(dp(46), dp(43)))
        lr.addView(View(this), LinearLayout.LayoutParams(dp(34), dp(43)))
        lr.addView(controlButton("▶", KeyEvent.KEYCODE_DPAD_RIGHT), LinearLayout.LayoutParams(dp(46), dp(43)))
        dpad.addView(lr)
        dpad.addView(controlButton("▼", KeyEvent.KEYCODE_DPAD_DOWN), LinearLayout.LayoutParams(dp(46), dp(43)))
        body.addView(dpad, LinearLayout.LayoutParams(0, -2, 1f))

        val middle = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val startSelect = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        startSelect.addView(controlButton("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT), LinearLayout.LayoutParams(dp(76), dp(42)).apply { rightMargin = dp(6) })
        startSelect.addView(controlButton("START", KeyEvent.KEYCODE_BUTTON_START), LinearLayout.LayoutParams(dp(76), dp(42)))
        middle.addView(startSelect)
        body.addView(middle, LinearLayout.LayoutParams(0, -2, 1f))

        val face = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        face.addView(controlButton("△", KeyEvent.KEYCODE_BUTTON_X), LinearLayout.LayoutParams(dp(45), dp(42)))
        val faceMid = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        faceMid.addView(controlButton("□", KeyEvent.KEYCODE_BUTTON_Y), LinearLayout.LayoutParams(dp(45), dp(42)))
        faceMid.addView(View(this), LinearLayout.LayoutParams(dp(32), dp(42)))
        faceMid.addView(controlButton("○", KeyEvent.KEYCODE_BUTTON_A), LinearLayout.LayoutParams(dp(45), dp(42)))
        face.addView(faceMid)
        face.addView(controlButton("×", KeyEvent.KEYCODE_BUTTON_B), LinearLayout.LayoutParams(dp(45), dp(42)))
        body.addView(face, LinearLayout.LayoutParams(0, -2, 1f))
        outer.addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        return outer
    }

    private fun weighted() = LinearLayout.LayoutParams(0, dp(39), 1f).apply { marginEnd = dp(4) }

    private fun controlButton(text: String, key: Int): TextView {
        val v = TextView(this).apply {
            this.text = text
            textSize = if (text.length > 2) 10f else 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(Color.rgb(31, 38, 49), dp(11), Color.rgb(65, 78, 96))
            isFocusable = false
            setOnTouchListener { view, event ->
                val r = retroView
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { r?.sendKeyEvent(KeyEvent.ACTION_DOWN, key); view.alpha = 0.72f; true }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { r?.sendKeyEvent(KeyEvent.ACTION_UP, key); view.alpha = 1f; true }
                    else -> true
                }
            }
        }
        return v
    }

    private fun button(text: String, color: Int): TextView = TextView(this).apply {
        this.text = text
        textSize = 12f
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (color == accent) Color.rgb(4, 20, 13) else Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(15), dp(11), dp(15), dp(11))
        background = rounded(color, dp(13), color)
        isClickable = true
        isFocusable = true
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(fill: Int, radius: Int, stroke: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radius.toFloat()
        setStroke(dp(1), stroke)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        retroView?.sendKeyEvent(KeyEvent.ACTION_DOWN, keyCode)
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        retroView?.sendKeyEvent(KeyEvent.ACTION_UP, keyCode)
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Use onBackPressedDispatcher")
    override fun onBackPressed() {
        if (retroView == null) {
            super.onBackPressed()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Sair do jogo?")
            .setMessage("O jogo será fechado. Quer voltar à tela inicial do emulador?")
            .setNegativeButton("Continuar jogando", null)
            .setPositiveButton("Sair do jogo") { _, _ -> finish() }
            .show()
    }
}
