# NEXPLAY PS native Android

Native Android frontend (no WebView), minimum Android 6.0/API 23, ARM64 and ARMv7. Uses LibretroDroid with PCSX-ReARMed/HLE. No games or BIOS are bundled; users must supply lawful game files.

## Experimental P2 local-game transfer

The P1 release action sends the selected game file through the room relay in bounded chunks. P2 does not browse for or manually import an ISO; the received file is opened locally in its own emulator, and this experimental path ignores mirrored video frames. CUE/M3U selection is packaged with sibling files into a ZIP. Transfers are limited to 1.5 GB and require sufficient storage and a stable connection.

The app relays P2 controller input to P1 and host controller input to P2. This is an experimental dual-local-core input relay, not a complete GGPO implementation: there is no frame-indexed rollback/replay scheduler, no demonstrated synchronization guarantee, and no real two-phone gameplay test. Different device speeds and network latency can desynchronize games. Do not claim netplay is proven until tested end-to-end.

The current Render relay forwards host frame-channel payloads and P2 input messages; an external test confirmed a small custom game chunk made it from P1 to P2. That validates transport only, not large ISO transfers, local boot, input timing, or gameplay.


Build 36 no-video transfer reliability: receiving/base64 decoding/random-access file writes run on a background dispatcher instead of the Android UI thread. The transfer sends in 32-chunk windows and waits for an ACK over room chat before continuing; both roles show progress and can retry. The P1 release path does not launch Android screen capture or transmit frames. This still is not validated GGPO/rollback synchronization and requires real two-device testing.


Build 37 uses Android versionCode 37 so it can update older installed APKs in place. The room screen no longer suggests screen capture; ACK control messages are hidden from chat.


Build 38: on P2, the local PS1 surface is hosted inside the portrait room/play screen, with the game rendered on that device, chat and on-screen controls visible. It does not launch screen capture or show a mirrored P1 frame.


Build 39: P2 now opens the received game through the same landscape full-screen emulator surface used by P1, preserving the screenshot-style on-screen controls and chat overlay; no separate portrait game layout, screen capture or video stream. P1 sends an explicit game-start marker immediately after release so P2 updates its state before file chunks arrive.


Build 40 fixes P2 room-state redraws during release: once the host grants access, the P2 immediately switches from the room waiting screen to a landscape loading screen with progress text and chat. WebSocket room updates no longer redraw that screen; after the transfer completes it is replaced by the local emulator surface. No screen capture or video stream is launched.


Build 41 switches the room back to P1 screen mirroring as explicitly requested. P1 taps release and grants Android MediaProjection consent. P2 sees the live frame in a landscape display, has its own chat and controller overlay, and sends input to the host. The mirror is 640px wide, JPEG quality adapts to a 120KB target, uses latest-frame capture/decoding and drops stale frames. The P1 header and bottom virtual-control strip are masked black in transmitted frames so P1 controls are not shown to P2. Capture requires user confirmation on the P1 device. Smoothness depends on device/network; this build has not been tested end-to-end on two physical phones.


Build 42: P2 stays on the mirror view until the host revokes access or disconnects; the stream uses FIT_CENTER to preserve the source aspect ratio on phones with different screens. P1 release button updates to show stream state.


Build 43 computes the streamed UI-mask bands from Android dp density and real display dimensions so the full P1 virtual-controller bar (including shoulder buttons) and header/release button are excluded across different phone screen densities. P2 exits the mirror view if the host disconnects or revokes access.

Build 45 adds adaptive mirroring profiles based on total RAM and CPU cores: lower-end phones use 480px frames and lower JPEG quality, middle devices use 560px, and stronger devices use 640px. Capture/encode cadence adapts to measured processing time and WebSocket queue pressure, dropping stale frames rather than building latency. It can reduce resource pressure but cannot guarantee smooth motion on every old device or poor network. Not yet tested on the user's physical phones.

Build 47: AudioPlaybackCapture now targets API 29, captures only the NEXPLAY app UID while matching GAME/MEDIA/UNKNOWN native audio usage, sends an AAC AudioSpecificConfig to the P2 and supports an audio-config request/replay when the P2 joins late. It requires Android 10+ and the P1's RECORD_AUDIO approval; audio behavior still requires physical-device verification. P2 reports missing audio/decoder status rather than silently appearing active. The P2 controller remains a large PlayStation-style layout with separated L1/L2/R1/R2, face buttons and analog stick. The P1's open chat panel is masked in transmitted frames. For privacy, Android 6–13 requires Notification Policy access and Do Not Disturb before any frames are sent (stream pauses if protection is disabled); Android 14+ asks the user to share only the NEXPLAY app window. Physical-device audio/video/network testing is still required.


Build 48 prioritizes audio packets over queued video: video frames pause if the WebSocket queue exceeds 65KB and JPEG frames target <=72KB; AAC packets may queue up to 360KB to avoid being starved by images. P2 requests/replays audio config on join. The P1 status waits for actual capture output and P2 reports decoder/playback state; this still needs two-phone verification. Android 6 does not provide Android AudioPlaybackCapture, so internal game audio on API 23–28 is not supported by this path.
