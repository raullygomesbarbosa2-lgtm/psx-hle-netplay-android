# NEXPLAY PS (Android)

Frontend Android nativo, sem WebView e sem navegador. Usa LibretroDroid com PCSX-ReARMed/HLE. Android mínimo 6.0 (API 23), ARM64 e ARMv7.

Recursos desta linha: login Firebase por e-mail/senha e confirmação; Solo; criação/entrada em sala pelo relay; chat textual encaminhado pelo relay; espelhamento do ecrã P1 para P2 mediante consentimento explícito da captura de ecrã do Android; importação ZIP por Android 6–12 ZIP picker integrado baseado em READ_EXTERNAL_STORAGE, navega armazenamento interno e volumes removíveis sem depender do provedor SAF; Android 13+ usa SAF. ZIP é lido por stream direto, valida PK e extrai BIN/CUE sem limite fixo de tamanho, condicionado ao espaço livre e margem para o sistema; rotação automática para paisagem durante a sessão do jogo; analógico virtual; encaminhamento de entradas de controles Android reconhecidos (gamepad/joystick/d-pad, USB ou Bluetooth) usando eventos e eixos Android convencionais.

Limitações que não devem ser anunciadas como resolvidas: o app nativo ainda não transmite a imagem de jogo do P1 para o P2 nem sincroniza dois núcleos de emulação. O P2 recebe comandos pelo relay, mas isso não é prova de netplay completo. O suporte de controle varia conforme o dispositivo/controlador e seu mapeamento Android; não há garantia para literalmente todos os modelos.

O usuário seleciona arquivo próprio pelo seletor Android; ZIP comum de PS1 é extraído com limite e validação de caminhos. Não há jogos nem BIOS incluídos. PCSX-ReARMed pode recorrer ao HLE interno quando não encontra BIOS; compatibilidade varia por jogo.

Build: Gradle 8.9, JDK 17, Android SDK 35. CI baixa binários do núcleo dos links oficiais em `THIRD_PARTY_NOTICES.txt`. Consulte os notices para licenças GPL.


Multiplayer flow: the P1 host selects and runs the game ISO/ZIP; P2 joins by room code without importing a game. Once P1 releases P2 from the in-game overlay, the relay state automatically opens P2 remote view. P1 must accept Android MediaProjection consent; otherwise P2 will not receive video. This remains screen mirroring, not deterministic dual-emulator netplay, and requires two-device end-to-end validation.


Latest UX behavior: the Android native UI has Multiplayer and Account navigation only. Login refresh token and room code/role are stored in private app preferences and restored with Firebase token refresh; transient network failures do not erase the saved session. Leaving the emulator returns to the room without sign-out. The P1 ISO launch or a P2 joining an already running P1 game automatically marks P2 approved; P2 joins without selecting any local ISO. P1 must accept MediaProjection system consent for screen mirroring, which Android does not permit bypassing. This is still a host screen stream, not deterministic netplay, and must be verified on actual Marshmallow devices.
