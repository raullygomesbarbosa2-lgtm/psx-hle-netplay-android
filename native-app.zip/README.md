# PSX HLE Nativo (Android)

Frontend Android nativo, sem WebView, sem site incorporado e sem navegador. Usa LibretroDroid com o núcleo PCSX-ReARMed, que pode recorrer ao HLE interno quando não há BIOS compatível. Android mínimo 6.0 (API 23), ARM64 e ARMv7.

O usuário seleciona uma imagem própria por meio do seletor de arquivos do Android. O arquivo é copiado ao cache privado do app. Não há jogos nem BIOS incluídos. O formato testado só será confirmado após teste em aparelho; o núcleo aceita os formatos que PCSX-ReARMed suporta.

Build: Gradle 8.9, JDK 17, Android SDK 35. O CI baixa os binários do core dos links oficiais indicados em `THIRD_PARTY_NOTICES.txt` e os empacota no APK. A source do app está aqui; consulte os notices para as licenças GPL.
