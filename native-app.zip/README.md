# NEXPLAY PS (Android)

Frontend Android nativo, sem WebView e sem navegador. Usa LibretroDroid com PCSX-ReARMed/HLE. Android mínimo 6.0 (API 23), ARM64 e ARMv7.

Recursos desta linha: login Firebase por e-mail/senha e confirmação; Solo; criação/entrada em sala pelo relay; chat textual encaminhado pelo relay; espelhamento do ecrã P1 para P2 mediante consentimento explícito da captura de ecrã do Android; importação ZIP por Android 6–12 ZIP picker integrado baseado em READ_EXTERNAL_STORAGE, navega armazenamento interno e volumes removíveis sem depender do provedor SAF; Android 13+ usa SAF. ZIP é lido por stream direto, valida PK e extrai BIN/CUE sem limite fixo de tamanho, condicionado ao espaço livre e margem para o sistema; rotação automática para paisagem durante a sessão do jogo; analógico virtual; encaminhamento de entradas de controles Android reconhecidos (gamepad/joystick/d-pad, USB ou Bluetooth) usando eventos e eixos Android convencionais.

Limitações que não devem ser anunciadas como resolvidas: o app nativo ainda não transmite a imagem de jogo do P1 para o P2 nem sincroniza dois núcleos de emulação. O P2 recebe comandos pelo relay, mas isso não é prova de netplay completo. O suporte de controle varia conforme o dispositivo/controlador e seu mapeamento Android; não há garantia para literalmente todos os modelos.

O usuário seleciona arquivo próprio pelo seletor Android; ZIP comum de PS1 é extraído com limite e validação de caminhos. Não há jogos nem BIOS incluídos. PCSX-ReARMed pode recorrer ao HLE interno quando não encontra BIOS; compatibilidade varia por jogo.

Build: Gradle 8.9, JDK 17, Android SDK 35. CI baixa binários do núcleo dos links oficiais em `THIRD_PARTY_NOTICES.txt`. Consulte os notices para licenças GPL.
