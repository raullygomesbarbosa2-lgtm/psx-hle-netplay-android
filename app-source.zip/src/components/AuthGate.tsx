import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  GoogleAuthProvider,
  sendEmailVerification,
  signInWithEmailAndPassword,
  signInWithPopup,
  signOut,
  updateProfile,
  User,
} from 'firebase/auth';
import { Lock, Mail, RefreshCw, ShieldCheck } from 'lucide-react';
import { auth } from '../firebase/firebaseClient';

interface AuthGateProps {
  currentUser: User | null;
  onVerifiedRefresh: () => Promise<void>;
}

export const AuthGate: React.FC<AuthGateProps> = ({ currentUser, onVerifiedRefresh }) => {
  const [mode, setMode] = useState<'register' | 'login'>('register');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [infoMsg, setInfoMsg] = useState<string | null>(null);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setInfoMsg(null);
    setBusy(true);

    try {
      if (mode === 'register') {
        const cleanName = displayName.trim();
        if (cleanName.length < 2) {
          setErrorMsg('Informe um nome de jogador com pelo menos 2 caracteres.');
          setBusy(false);
          return;
        }
        const cred = await createUserWithEmailAndPassword(auth, email.trim(), password);
        await updateProfile(cred.user, { displayName: cleanName });
        await sendEmailVerification(cred.user);
        setInfoMsg(
          'Conta criada! Enviamos um link de confirmação para o seu e-mail. Confirme-o para liberar o emulador Solo e NetPlay.',
        );
      } else {
        await signInWithEmailAndPassword(auth, email.trim(), password);
      }
    } catch (err: unknown) {
      const code = (err as { code?: string }).code ?? '';
      if (code === 'auth/operation-not-allowed') {
        setErrorMsg(
          'O provedor E-mail/Senha ainda precisa ser ativado no Firebase Console (Authentication -> Sign-in method -> E-mail/senha). Enquanto isso, você também pode entrar com Google abaixo.',
        );
      } else if (code === 'auth/email-already-in-use') {
        setErrorMsg('Este e-mail já está cadastrado. Troque para a aba "Entrar".');
      } else if (code === 'auth/weak-password') {
        setErrorMsg('A senha precisa ter pelo menos 6 caracteres.');
      } else if (code === 'auth/invalid-credential' || code === 'auth/wrong-password') {
        setErrorMsg('E-mail ou senha inválidos.');
      } else {
        setErrorMsg(err instanceof Error ? err.message : 'Falha na autenticação.');
      }
    } finally {
      setBusy(false);
    }
  };

  const handleGoogleLogin = async () => {
    setErrorMsg(null);
    setInfoMsg(null);
    setBusy(true);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao entrar com Google.');
    } finally {
      setBusy(false);
    }
  };

  const handleResendVerification = async () => {
    if (!currentUser) return;
    setErrorMsg(null);
    setBusy(true);
    try {
      await sendEmailVerification(currentUser);
      setInfoMsg('Novo e-mail de verificação enviado! Verifique sua caixa de entrada e spam.');
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Erro ao reenviar verificação.');
    } finally {
      setBusy(false);
    }
  };

  const handleCheckVerified = async () => {
    setErrorMsg(null);
    setBusy(true);
    try {
      await onVerifiedRefresh();
      if (auth.currentUser && !auth.currentUser.emailVerified) {
        setErrorMsg('Seu e-mail ainda consta como não verificado. Clique no link enviado para sua caixa de entrada.');
      }
    } finally {
      setBusy(false);
    }
  };

  // Unverified signed-in user waiting screen
  if (currentUser && !currentUser.emailVerified) {
    return (
      <div className="min-h-[calc(100vh-72px)] flex items-center justify-center px-6 py-12">
        <div className="max-w-lg w-full bg-[#171A21] border border-[#262B36] rounded-xl p-8 space-y-6">
          <div className="space-y-2">
            <p className="text-xs font-medium text-amber-400">Verificação de E-mail Obrigatória</p>
            <h1 className="font-display text-2xl font-bold text-white">
              Confirme seu e-mail para liberar o PlayStation 1
            </h1>
            <p className="text-sm text-slate-400 leading-relaxed">
              O acesso aos modos Solo e NetPlay exige conta com e-mail verificado. Enviamos a confirmação para{' '}
              <span className="text-slate-200 font-medium">{currentUser.email}</span>.
            </p>
          </div>

          {errorMsg && (
            <div className="text-sm text-red-300 bg-red-950/40 border border-red-900/60 rounded-lg p-3">
              {errorMsg}
            </div>
          )}
          {infoMsg && (
            <div className="text-sm text-emerald-300 bg-emerald-950/40 border border-emerald-900/60 rounded-lg p-3">
              {infoMsg}
            </div>
          )}

          <div className="flex flex-col sm:flex-row gap-3">
            <button
              type="button"
              onClick={handleCheckVerified}
              disabled={busy}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <RefreshCw className="w-4 h-4" />
              Já Confirmei o E-mail
            </button>
            <button
              type="button"
              onClick={handleResendVerification}
              disabled={busy}
              className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium bg-[#20242E] hover:bg-[#2A303D] text-slate-200 border border-[#2E3543] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <Mail className="w-4 h-4" />
              Reenviar Link
            </button>
          </div>

          <div className="pt-4 border-t border-[#262B36] flex items-center justify-between text-xs text-slate-400">
            <span>Ou acesse instantaneamente via Google:</span>
            <button
              type="button"
              onClick={() => signOut(auth)}
              className="text-slate-300 hover:text-white underline whitespace-nowrap shrink-0"
            >
              Trocar de Conta
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-6 py-10 lg:py-16">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
        <div className="lg:col-span-7 bg-[#171A21] border border-[#262B36] rounded-xl overflow-hidden flex flex-col justify-between">
          <div className="relative h-64 sm:h-80 lg:h-full min-h-[300px]">
            <img
              src="/src/assets/images/ps1_console_studio_1795445729900.jpg"
              alt="Console PlayStation 1 HLE Studio com dois controles"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0F1115] via-[#0F1115]/55 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 sm:p-8 space-y-3">
              <div className="flex items-center gap-2 text-xs text-blue-400 font-medium">
                <span>Núcleo HLE sem BIOS</span>
                <span aria-hidden="true">·</span>
                <span>ISOs de qualquer tamanho</span>
                <span aria-hidden="true">·</span>
                <span>NetPlay P1/P2</span>
              </div>
              <h1 className="font-display text-3xl sm:text-4xl font-bold text-white leading-tight max-w-xl">
                PlayStation 1 com HLE Direto e Multiplayer à Distância
              </h1>
              <p className="text-sm text-slate-300 max-w-xl leading-relaxed">
                Crie sua conta de e-mail para desbloquear o modo Solo e criar ou entrar em salas NetPlay onde o P1 administra o acesso do P2 e diferencia os jogos.
              </p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 bg-[#171A21] border border-[#262B36] rounded-xl p-6 sm:p-8 flex flex-col justify-between space-y-6">
          <div className="space-y-5">
            <div className="flex items-center justify-between gap-4">
              <h2 className="font-display text-xl font-semibold text-white">
                Acesso Obrigatório
              </h2>
              <div className="flex items-center gap-1 p-1 bg-[#0F1115] border border-[#262B36] rounded-lg">
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setErrorMsg(null);
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    mode === 'register'
                      ? 'bg-[#232834] text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Criar Conta
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMsg(null);
                  }}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    mode === 'login'
                      ? 'bg-[#232834] text-white'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Entrar
                </button>
              </div>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Não é possível jogar Solo nem Multiplayer NetPlay antes de criar e confirmar uma conta.
            </p>

            {errorMsg && (
              <div className="text-xs text-red-300 bg-red-950/40 border border-red-900/60 rounded-lg p-3 leading-relaxed">
                {errorMsg}
              </div>
            )}
            {infoMsg && (
              <div className="text-xs text-emerald-300 bg-emerald-950/40 border border-emerald-900/60 rounded-lg p-3 leading-relaxed">
                {infoMsg}
              </div>
            )}

            <form onSubmit={handleEmailAuth} className="space-y-4">
              {mode === 'register' && (
                <div className="space-y-1.5">
                  <label className="block text-xs font-medium text-slate-300">
                    Nome de Jogador (P1 / P2)
                  </label>
                  <input
                    type="text"
                    required
                    minLength={2}
                    maxLength={40}
                    value={displayName}
                    onChange={(e) => setDisplayName(e.target.value)}
                    placeholder="Ex: RaullyPSX"
                    className="w-full px-3.5 py-2.5 text-sm bg-[#0F1115] border border-[#262B36] focus:border-blue-500 rounded-lg text-white placeholder-slate-500 outline-none"
                  />
                </div>
              )}

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-slate-300">E-mail</label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="voce@exemplo.com"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#0F1115] border border-[#262B36] focus:border-blue-500 rounded-lg text-white placeholder-slate-500 outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-medium text-slate-300">Senha</label>
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Mínimo 6 caracteres"
                  className="w-full px-3.5 py-2.5 text-sm bg-[#0F1115] border border-[#262B36] focus:border-blue-500 rounded-lg text-white placeholder-slate-500 outline-none"
                />
              </div>

              <button
                type="submit"
                disabled={busy}
                className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium bg-blue-600 hover:bg-blue-500 disabled:opacity-60 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
              >
                <Lock className="w-4 h-4" />
                {mode === 'register' ? 'Criar Conta com E-mail' : 'Entrar com E-mail'}
              </button>
            </form>

            <div className="relative flex items-center py-1">
              <div className="flex-grow border-t border-[#262B36]" />
              <span className="px-3 text-xs text-slate-500">ou acesso verificado</span>
              <div className="flex-grow border-t border-[#262B36]" />
            </div>

            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={busy}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-medium bg-[#20242E] hover:bg-[#2A303D] disabled:opacity-60 text-slate-100 border border-[#2E3543] rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Entrar com Conta Google (Verificada)
            </button>
          </div>

          <div className="pt-4 border-t border-[#262B36] text-xs text-slate-400 flex items-center justify-between">
            <span>Autenticação Firebase</span>
            <span className="font-mono text-slate-300">Solo + NetPlay bloqueados sem conta</span>
          </div>
        </div>
      </div>
    </div>
  );
};
