import React, { useCallback, useEffect, useRef, useState } from 'react';
import { createIdlePadState, PSX_BTN, PsxPadState } from '../emulator/types';

interface DualShockPadProps {
  portLabel: string;
  disabled?: boolean;
  onChange: (state: PsxPadState) => void;
}

const KEY_MAP: Record<string, number> = {
  ArrowUp: PSX_BTN.UP,
  KeyW: PSX_BTN.UP,
  ArrowDown: PSX_BTN.DOWN,
  KeyS: PSX_BTN.DOWN,
  ArrowLeft: PSX_BTN.LEFT,
  KeyA: PSX_BTN.LEFT,
  ArrowRight: PSX_BTN.RIGHT,
  KeyD: PSX_BTN.RIGHT,
  KeyX: PSX_BTN.CROSS,
  KeyK: PSX_BTN.CROSS,
  KeyZ: PSX_BTN.SQUARE,
  KeyJ: PSX_BTN.SQUARE,
  KeyC: PSX_BTN.CIRCLE,
  KeyL: PSX_BTN.CIRCLE,
  KeyV: PSX_BTN.TRIANGLE,
  KeyI: PSX_BTN.TRIANGLE,
  KeyQ: PSX_BTN.L1,
  KeyE: PSX_BTN.R1,
  Digit1: PSX_BTN.L2,
  Digit3: PSX_BTN.R2,
  Enter: PSX_BTN.START,
  ShiftRight: PSX_BTN.SELECT,
  ShiftLeft: PSX_BTN.SELECT,
};

export const DualShockPad: React.FC<DualShockPadProps> = ({
  portLabel,
  disabled = false,
  onChange,
}) => {
  const activeMaskRef = useRef<number>(0);
  const [pressedMask, setPressedMask] = useState<number>(0);

  const emitState = useCallback(
    (mask: number) => {
      activeMaskRef.current = mask;
      setPressedMask(mask);
      const state: PsxPadState = {
        ...createIdlePadState(),
        buttons: (~mask) & 0xffff,
      };
      onChange(state);
    },
    [onChange],
  );

  const pressBtn = useCallback(
    (bit: number) => {
      if (disabled) return;
      emitState(activeMaskRef.current | bit);
    },
    [disabled, emitState],
  );

  const releaseBtn = useCallback(
    (bit: number) => {
      emitState(activeMaskRef.current & ~bit);
    },
    [emitState],
  );

  useEffect(() => {
    if (disabled) {
      emitState(0);
      return;
    }

    const onKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      if (target && (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.tagName === 'SELECT')) {
        return;
      }
      const bit = KEY_MAP[e.code];
      if (bit !== undefined) {
        e.preventDefault();
        if ((activeMaskRef.current & bit) === 0) {
          emitState(activeMaskRef.current | bit);
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      const bit = KEY_MAP[e.code];
      if (bit !== undefined) {
        emitState(activeMaskRef.current & ~bit);
      }
    };

    const onBlur = () => emitState(0);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [disabled, emitState]);

  const isDown = (bit: number) => (pressedMask & bit) !== 0;

  const btnBind = (bit: number) => ({
    onPointerDown: (e: React.PointerEvent) => {
      e.preventDefault();
      pressBtn(bit);
    },
    onPointerUp: () => releaseBtn(bit),
    onPointerLeave: () => releaseBtn(bit),
    onPointerCancel: () => releaseBtn(bit),
  });

  return (
    <div className="bg-[#171A21] border border-[#262B36] rounded-xl p-4 select-none">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-3 border-b border-[#262B36]">
        <div className="flex items-center gap-2 text-xs text-slate-300">
          <span className="font-semibold text-white">{portLabel}</span>
          <span aria-hidden="true" className="text-slate-600">·</span>
          <span className="text-slate-400">DualShock Digital/HLE</span>
        </div>
        <div className="text-xs font-mono text-slate-400 tabular-nums">
          Setas/WASD · Z □ · X × · C ○ · V △ · Enter Start
        </div>
      </div>

      {/* Shoulder L2/L1 & R1/R2 */}
      <div className="flex items-center justify-between gap-4 mb-4">
        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.L2)}
            className={`min-w-[44px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors ${
              isDown(PSX_BTN.L2)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            L2
          </button>
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.L1)}
            className={`min-w-[44px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors ${
              isDown(PSX_BTN.L1)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            L1
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.R1)}
            className={`min-w-[44px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors ${
              isDown(PSX_BTN.R1)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            R1
          </button>
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.R2)}
            className={`min-w-[44px] h-9 px-3 text-xs font-mono font-medium rounded-md border transition-colors ${
              isDown(PSX_BTN.R2)
                ? 'bg-blue-600 border-blue-400 text-white'
                : 'bg-[#0F1115] border-[#2B313E] text-slate-300 hover:bg-[#1E232D]'
            }`}
          >
            R2
          </button>
        </div>
      </div>

      {/* Main Pad Layout */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-6">
        {/* D-Pad */}
        <div className="grid grid-cols-3 gap-1.5 w-[138px]">
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Cima"
            {...btnBind(PSX_BTN.UP)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.UP)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ▲
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Esquerda"
            {...btnBind(PSX_BTN.LEFT)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.LEFT)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ◀
          </button>
          <div className="h-11 rounded-md bg-[#12151B] border border-[#222732]" />
          <button
            type="button"
            disabled={disabled}
            aria-label="Direita"
            {...btnBind(PSX_BTN.RIGHT)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.RIGHT)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ▶
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Baixo"
            {...btnBind(PSX_BTN.DOWN)}
            className={`h-11 rounded-md border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.DOWN)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#20242E] text-slate-200 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ▼
          </button>
          <div />
        </div>

        {/* Select & Start */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.SELECT)}
            className={`px-3 py-2 text-xs font-mono rounded-md border transition-colors whitespace-nowrap shrink-0 ${
              isDown(PSX_BTN.SELECT)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#0F1115] text-slate-300 border-[#2B313E] hover:bg-[#1E232D]'
            }`}
          >
            SELECT
          </button>
          <button
            type="button"
            disabled={disabled}
            {...btnBind(PSX_BTN.START)}
            className={`px-3 py-2 text-xs font-mono rounded-md border transition-colors whitespace-nowrap shrink-0 ${
              isDown(PSX_BTN.START)
                ? 'bg-slate-200 text-slate-900 border-white'
                : 'bg-[#0F1115] text-slate-300 border-[#2B313E] hover:bg-[#1E232D]'
            }`}
          >
            START
          </button>
        </div>

        {/* Action Face Buttons */}
        <div className="grid grid-cols-3 gap-1.5 w-[138px]">
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Triângulo"
            {...btnBind(PSX_BTN.TRIANGLE)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.TRIANGLE)
                ? 'bg-emerald-500 text-white border-emerald-300'
                : 'bg-[#20242E] text-emerald-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            △
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Quadrado"
            {...btnBind(PSX_BTN.SQUARE)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.SQUARE)
                ? 'bg-pink-500 text-white border-pink-300'
                : 'bg-[#20242E] text-pink-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            □
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Círculo"
            {...btnBind(PSX_BTN.CIRCLE)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.CIRCLE)
                ? 'bg-red-500 text-white border-red-300'
                : 'bg-[#20242E] text-red-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ○
          </button>
          <div />
          <button
            type="button"
            disabled={disabled}
            aria-label="Cruz"
            {...btnBind(PSX_BTN.CROSS)}
            className={`h-11 rounded-full border text-sm font-bold transition-transform active:scale-95 ${
              isDown(PSX_BTN.CROSS)
                ? 'bg-blue-500 text-white border-blue-300'
                : 'bg-[#20242E] text-blue-400 border-[#2E3543] hover:bg-[#2A303D]'
            }`}
          >
            ×
          </button>
          <div />
        </div>
      </div>
    </div>
  );
};
