import React from 'react';

interface State {
  hasError: boolean;
  errorMessage: string;
}

export class ErrorBoundary extends React.Component<{ children: React.ReactNode }, State> {
  constructor(props: { children: React.ReactNode }) {
    super(props);
    this.state = { hasError: false, errorMessage: '' };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, errorMessage: error.message };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-[#0F1115] text-[#E5E7EB] flex items-center justify-center p-6">
          <div className="max-w-lg w-full bg-[#171A21] border border-[#262B36] rounded-xl p-6 space-y-4">
            <h2 className="font-display text-xl font-semibold text-white">
              Erro na Sessão do Emulador
            </h2>
            <p className="text-sm text-slate-400">
              Ocorreu uma falha inesperada na comunicação com os dados da sessão.
            </p>
            <pre className="text-xs font-mono bg-[#0F1115] border border-[#262B36] rounded-lg p-3 overflow-auto max-h-40 text-red-300">
              {this.state.errorMessage}
            </pre>
            <button
              type="button"
              onClick={() => this.setState({ hasError: false, errorMessage: '' })}
              className="px-4 py-2 text-sm font-medium bg-blue-600 hover:bg-blue-500 text-white rounded-lg transition-colors whitespace-nowrap shrink-0"
            >
              Recarregar Interface
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
