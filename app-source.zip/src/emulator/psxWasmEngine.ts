import { IsoMountInfo, PSX_BTN, PsxPadState } from './types';

const EJS_DATA_PATH = 'https://cdn.emulatorjs.org/stable/data/';

export interface WasmSafetyCheckResult {
  blockedReason: string | null;
  requiresStreamingPrompt: boolean;
  sizeMb: number;
  limitMb: number;
  isMobile: boolean;
}

export function checkBrowserWasmMemorySafety(info: IsoMountInfo): WasmSafetyCheckResult {
  const sizeMb = info.fileSizeBytes / (1024 * 1024);
  const isCompressedArchive =
    info.serial === 'ZIP-PACK' || info.serial === '7Z-PACK' || info.serial === 'RAR-PACK';

  if (info.serial === 'ECM-PACK') {
    return {
      blockedReason:
        'Arquivo .ECM detectado. Descompacte primeiro para .BIN/.ISO antes de carregar no emulador.',
      requiresStreamingPrompt: false,
      sizeMb,
      limitMb: 0,
      isMobile: false,
    };
  }

  if (isCompressedArchive && sizeMb > 64) {
    return {
      blockedReason: `Arquivo compactado grande (${sizeMb.toFixed(1)} MB) em ${info.serial}. Descompacte o arquivo para .ISO, .BIN ou .CHD no aparelho antes de abrir para evitar falta de memória na aba do navegador.`,
      requiresStreamingPrompt: false,
      sizeMb,
      limitMb: 64,
      isMobile: false,
    };
  }

  const ua = typeof navigator !== 'undefined' ? navigator.userAgent : '';
  const isMobile = /Android|iPhone|iPad|Mobile/i.test(ua);
  const deviceMem =
    typeof navigator !== 'undefined'
      ? ((navigator as unknown as { deviceMemory?: number }).deviceMemory ?? 4)
      : 4;
  const limitMb = isMobile ? (deviceMem >= 8 ? 220 : 140) : 550;

  return {
    blockedReason: null,
    requiresStreamingPrompt: sizeMb > limitMb,
    sizeMb,
    limitMb,
    isMobile,
  };
}

interface EjsGameManager {
  FS: {
    readFile: (path: string) => Uint8Array;
    writeFile: (path: string, data: Uint8Array) => void;
    analyzePath: (path: string) => { exists: boolean };
  };
  Module: {
    abort?: () => void;
    pauseMainLoop?: () => void;
    AL?: {
      currentCtx?: {
        sources?: Array<{ gain?: { context?: AudioContext } }>;
      };
    };
  };
  functions: {
    restart: () => void;
    simulateInput: (player: number, index: number, value: number) => void;
    toggleMainLoop: (playing: number) => void;
    getSaveFilePath: () => string;
    saveSaveFiles: () => void;
    loadSaveFiles: () => void;
    getFrameNum: () => number;
  };
  toggleMainLoop: (playing: number) => void;
  restart: () => void;
  getState: () => Uint8Array;
  loadState: (state: Uint8Array) => void;
}

interface EjsInstance {
  started: boolean;
  paused: boolean;
  canvas?: HTMLCanvasElement;
  elements?: {
    parent?: HTMLElement;
  };
  gameManager?: EjsGameManager;
  on: (event: string, cb: () => void) => void;
  setVolume: (vol: number) => void;
  toggleFullscreen: (force?: boolean) => void;
}

declare global {
  interface Window {
    EmulatorJS?: new (selector: string, config: Record<string, unknown>) => EjsInstance;
    EJS_emulator?: EjsInstance;
    __psxWebglPatched?: boolean;
  }
}

let ejsAssetsPromise: Promise<void> | null = null;
let allowCaptureForNextCanvas = false;

function patchCanvasForCapture(): void {
  if (window.__psxWebglPatched) return;
  window.__psxWebglPatched = true;

  const origGetContext = HTMLCanvasElement.prototype.getContext;
  // Only enable preserveDrawingBuffer when NetPlay P1 frame streaming is active to conserve mobile GPU RAM
  HTMLCanvasElement.prototype.getContext = function (
    this: HTMLCanvasElement,
    contextId: string,
    options?: unknown,
  ) {
    if (
      allowCaptureForNextCanvas &&
      (contextId === 'webgl2' || contextId === 'webgl' || contextId === 'experimental-webgl') &&
      this.classList.contains('ejs_canvas')
    ) {
      const merged = Object.assign({}, (options as Record<string, unknown>) || {}, {
        preserveDrawingBuffer: true,
      });
      return origGetContext.call(this, contextId as 'webgl2', merged as WebGLContextAttributes);
    }
    return origGetContext.call(this, contextId as '2d', options as CanvasRenderingContext2DSettings);
  } as typeof HTMLCanvasElement.prototype.getContext;
}

export function loadEjsRuntime(): Promise<void> {
  if (window.EmulatorJS) {
    return Promise.resolve();
  }
  if (ejsAssetsPromise) {
    return ejsAssetsPromise;
  }

  ejsAssetsPromise = new Promise<void>((resolve, reject) => {
    patchCanvasForCapture();

    if (!document.querySelector('link[data-ejs-css="1"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = `${EJS_DATA_PATH}emulator.min.css`;
      link.setAttribute('data-ejs-css', '1');
      document.head.appendChild(link);
    }

    const script = document.createElement('script');
    script.src = `${EJS_DATA_PATH}emulator.min.js`;
    script.async = true;
    script.onload = () => {
      if (window.EmulatorJS) {
        resolve();
      } else {
        ejsAssetsPromise = null;
        reject(new Error('Núcleo EmulatorJS PS1 não inicializou corretamente.'));
      }
    };
    script.onerror = () => {
      ejsAssetsPromise = null;
      reject(
        new Error(
          'Não foi possível baixar o núcleo PCSX-ReARMed WASM. Verifique sua conexão com a internet.',
        ),
      );
    };
    document.body.appendChild(script);
  });

  return ejsAssetsPromise;
}

const BIT_TO_EJS_INDEX: Array<[number, number]> = [
  [PSX_BTN.CROSS, 0],
  [PSX_BTN.SQUARE, 1],
  [PSX_BTN.SELECT, 2],
  [PSX_BTN.START, 3],
  [PSX_BTN.UP, 4],
  [PSX_BTN.DOWN, 5],
  [PSX_BTN.LEFT, 6],
  [PSX_BTN.RIGHT, 7],
  [PSX_BTN.CIRCLE, 8],
  [PSX_BTN.TRIANGLE, 9],
  [PSX_BTN.L1, 10],
  [PSX_BTN.R1, 11],
  [PSX_BTN.L2, 12],
  [PSX_BTN.R2, 13],
  [PSX_BTN.L3, 14],
  [PSX_BTN.R3, 15],
];

export class PsxWasmEngine {
  private instance: EjsInstance | null = null;
  private container: HTMLElement | null = null;
  private started = false;
  private lastPadMask: [number, number] = [0xffff, 0xffff];
  private audioEnabled = true;

  async mountDisc(params: {
    container: HTMLElement;
    containerId: string;
    file: File;
    audioEnabled: boolean;
    enableFrameCapture?: boolean;
    onReady?: () => void;
    onGameStart?: () => void;
  }): Promise<void> {
    this.destroy();
    this.container = params.container;
    this.audioEnabled = params.audioEnabled;
    this.started = false;
    this.lastPadMask = [0xffff, 0xffff];

    await loadEjsRuntime();
    if (!window.EmulatorJS) {
      throw new Error('Runtime PCSX-ReARMed WASM indisponível.');
    }

    allowCaptureForNextCanvas = Boolean(params.enableFrameCapture);

    // Ensure container has exact id selector and clean DOM
    params.container.id = params.containerId;
    params.container.innerHTML = '';

    const config: Record<string, unknown> = {
      gameUrl: params.file,
      gameName: params.file.name,
      dataPath: EJS_DATA_PATH,
      system: 'psx',
      // No external BIOS -> uses PCSX-ReARMed built-in HLE BIOS
      biosUrl: undefined,
      color: '#2563EB',
      backgroundColor: '#090B10',
      startOnLoad: true,
      disableCue: true,
      hideSettings: true,
      noAutoFocus: false,
      cacheLimit: 0,
      disableDatabases: true,
      volume: params.audioEnabled ? 0.75 : 0,
      language: 'pt-BR',
      defaultControllers: { 0: {}, 1: {}, 2: {}, 3: {} },
      virtualGamepadSettings: [],
      buttonOpts: {
        playPause: false,
        restart: false,
        mute: false,
        settings: false,
        fullscreen: false,
        saveState: false,
        loadState: false,
        screenRecord: false,
        gamepad: false,
        cheat: false,
        volume: false,
        saveSavFiles: false,
        loadSavFiles: false,
        quickSave: false,
        quickLoad: false,
        screenshot: false,
        cacheManager: false,
        exitEmulation: false,
      },
      defaultOptions: {
        shader: 'disabled',
        'psx-bios': 'hle',
      },
    };

    const inst = new window.EmulatorJS(`#${params.containerId}`, config);
    this.instance = inst;
    window.EJS_emulator = inst;

    await new Promise<void>((resolve) => {
      let resolved = false;
      const done = () => {
        if (!resolved) {
          resolved = true;
          resolve();
        }
      };

      inst.on('ready', () => {
        params.onReady?.();
      });

      inst.on('start', () => {
        this.started = true;
        inst.setVolume(this.audioEnabled ? 0.75 : 0);
        params.onGameStart?.();
        done();
      });

      // Fallback safeguard in case event already fired or user clicks start overlay
      setTimeout(done, 20000);
    });
  }

  resumeAudio(): void {
    try {
      const sources = this.instance?.gameManager?.Module?.AL?.currentCtx?.sources;
      sources?.forEach((src) => {
        const ctx = src.gain?.context;
        if (ctx && ctx.state === 'suspended') {
          void ctx.resume();
        }
      });
    } catch {
      // Ignore
    }
  }

  isRunning(): boolean {
    return Boolean(this.instance && this.started);
  }

  getFrameCount(): number {
    try {
      return this.instance?.gameManager?.functions.getFrameNum() ?? 0;
    } catch {
      return 0;
    }
  }

  applyPadState(port: 0 | 1, state: PsxPadState): void {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return;

    const prev = this.lastPadMask[port];
    const next = state.buttons & 0xffff;
    if (prev === next) return;
    this.lastPadMask[port] = next;

    for (const [bit, idx] of BIT_TO_EJS_INDEX) {
      const wasPressed = (prev & bit) === 0;
      const isPressed = (next & bit) === 0;
      if (wasPressed !== isPressed) {
        try {
          gm.functions.simulateInput(port, idx, isPressed ? 1 : 0);
        } catch {
          // Ignore transient input errors during core reset
        }
      }
    }
  }

  setPaused(paused: boolean): void {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return;
    try {
      gm.toggleMainLoop(paused ? 0 : 1);
      const sources = gm.Module?.AL?.currentCtx?.sources;
      sources?.forEach((src) => {
        const ctx = src.gain?.context;
        if (ctx) {
          if (paused && ctx.state === 'running') void ctx.suspend();
          if (!paused && ctx.state === 'suspended') void ctx.resume();
        }
      });
    } catch {
      // Ignore audio/loop state errors
    }
  }

  setMuted(muted: boolean): void {
    this.audioEnabled = !muted;
    try {
      this.instance?.setVolume(muted ? 0 : 0.75);
    } catch {
      // Ignore volume errors
    }
  }

  restart(): void {
    try {
      this.instance?.gameManager?.restart();
    } catch {
      // Ignore restart errors
    }
  }

  captureFrameDataUrl(offscreen: HTMLCanvasElement): string | null {
    const canvas =
      this.instance?.canvas ??
      (this.container?.querySelector('canvas.ejs_canvas') as HTMLCanvasElement | null);
    if (!canvas || canvas.width === 0 || canvas.height === 0) return null;
    const ctx = offscreen.getContext('2d');
    if (!ctx) return null;
    try {
      ctx.imageSmoothingEnabled = false;
      ctx.drawImage(canvas, 0, 0, offscreen.width, offscreen.height);
      return offscreen.toDataURL('image/jpeg', 0.62);
    } catch {
      return null;
    }
  }

  exportMemoryCardSram(): string | null {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return null;
    try {
      gm.functions.saveSaveFiles();
      const savePath = gm.functions.getSaveFilePath();
      if (!savePath || !gm.FS.analyzePath(savePath).exists) {
        return null;
      }
      const bytes = gm.FS.readFile(savePath);
      if (bytes.length === 0 || bytes.length > 650_000) return null;
      let bin = '';
      for (let i = 0; i < bytes.length; i++) {
        bin += String.fromCharCode(bytes[i]);
      }
      return btoa(bin);
    } catch {
      return null;
    }
  }

  importMemoryCardSram(encoded: string): boolean {
    const gm = this.instance?.gameManager;
    if (!gm || !this.started) return false;
    try {
      const bin = atob(encoded);
      const bytes = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) {
        bytes[i] = bin.charCodeAt(i);
      }
      const savePath = gm.functions.getSaveFilePath();
      if (!savePath) return false;
      gm.FS.writeFile(savePath, bytes);
      gm.functions.loadSaveFiles();
      return true;
    } catch {
      return false;
    }
  }

  destroy(): void {
    const inst = this.instance;
    this.started = false;
    this.instance = null;
    if (inst) {
      try {
        inst.gameManager?.toggleMainLoop(0);
      } catch {
        // Ignore
      }
      try {
        const sources = inst.gameManager?.Module?.AL?.currentCtx?.sources;
        sources?.forEach((src) => {
          void src.gain?.context?.close?.();
        });
      } catch {
        // Ignore
      }
      try {
        inst.gameManager?.Module?.abort?.();
      } catch {
        // Ignore
      }
      try {
        inst.elements?.parent?.remove();
      } catch {
        // Ignore
      }
    }
    if (this.container) {
      this.container.innerHTML = '';
      this.container = null;
    }
    if (window.EJS_emulator === inst) {
      window.EJS_emulator = undefined;
    }
  }
}
