import { PsxGpu } from './psxGpu';
import { StreamingIsoReader } from './streamingIsoReader';
import { PsxPadState, createIdlePadState } from './types';

export class PsxMemory {
  readonly ram = new Uint8Array(2 * 1024 * 1024);
  readonly ramView = new DataView(this.ram.buffer);
  readonly scratchpad = new Uint8Array(1024);
  readonly scratchView = new DataView(this.scratchpad.buffer);
  readonly bios = new Uint8Array(512 * 1024);
  readonly biosView = new DataView(this.bios.buffer);

  iStat = 0;
  iMask = 0;
  dpcr = 0x07654321;
  dicr = 0;
  private dmaBase = new Uint32Array(7);
  private dmaBcr = new Uint32Array(7);
  private dmaChcr = new Uint32Array(7);

  // Root Counters (0, 1, 2)
  private tmrVal = new Uint32Array(3);
  private tmrMode = new Uint32Array(3);
  private tmrTarget = new Uint32Array(3);

  // Joypad SPI state (0x1F801040)
  private joyCtrl = 0;
  private joyMode = 0;
  private joyStep = 0;
  private joyRxFifo: number[] = [];

  // CD-ROM Controller state (0x1F801800..03)
  private cdStatus = 0x18; // Parameter empty, response ready when pushed
  private cdParams: number[] = [];
  private cdResp: number[] = [];
  private cdIrqFlags = 0;
  private cdIrqMask = 0x1f;
  private cdTargetLba = 0;
  private cdSectorBuf = new Uint8Array(2048);
  private cdSectorCursor = 0;
  cdReads = 0;
  pendingCdLbaQueue: number[] = [];
  isoReader: StreamingIsoReader | null = null;

  pad1: PsxPadState = createIdlePadState();
  pad2: PsxPadState = createIdlePadState();
  gpu: PsxGpu;

  constructor(gpu: PsxGpu) {
    this.gpu = gpu;
    this.initHleBiosStubs();
  }

  reset(): void {
    this.ram.fill(0);
    this.scratchpad.fill(0);
    this.iStat = 0;
    this.iMask = 0;
    this.dpcr = 0x07654321;
    this.dicr = 0;
    this.dmaBase.fill(0);
    this.dmaBcr.fill(0);
    this.dmaChcr.fill(0);
    this.tmrVal.fill(0);
    this.tmrMode.fill(0);
    this.tmrTarget.fill(0);
    this.joyCtrl = 0;
    this.joyMode = 0;
    this.joyStep = 0;
    this.joyRxFifo = [];
    this.cdStatus = 0x18;
    this.cdParams = [];
    this.cdResp = [];
    this.cdIrqFlags = 0;
    this.cdTargetLba = 0;
    this.cdSectorCursor = 0;
    this.cdReads = 0;
    this.pendingCdLbaQueue = [];
    this.initHleBiosStubs();
  }

  tickTimers(cycles: number): void {
    for (let i = 0; i < 3; i++) {
      this.tmrVal[i] = (this.tmrVal[i] + cycles) & 0xffff;
    }
  }

  private initHleBiosStubs(): void {
    this.bios.fill(0);
    this.biosView.setUint32(0, 0x03e00008, true);
    this.biosView.setUint32(4, 0x00000000, true);
    for (const vec of [0xa0, 0xb0, 0xc0]) {
      this.ramView.setUint32(vec, 0x03e00008, true);
      this.ramView.setUint32(vec + 4, 0x00000000, true);
    }
  }

  private mapPhysical(addr: number): number {
    addr = addr >>> 0;
    if (addr >= 0x80000000 && addr < 0xa0000000) return addr - 0x80000000;
    if (addr >= 0xa0000000 && addr < 0xc0000000) return addr - 0xa0000000;
    return addr;
  }

  private bcdToInt(b: number): number {
    return ((b >> 4) & 0xf) * 10 + (b & 0xf);
  }

  private execCdCommand(cmd: number): void {
    this.cdResp = [];
    if (cmd === 0x01 || cmd === 0x0a) {
      // Getstat / Init
      this.cdResp.push(0x02);
      this.cdIrqFlags = 0x03;
    } else if (cmd === 0x02) {
      // Setloc(mm, ss, ff)
      const mm = this.bcdToInt(this.cdParams[0] ?? 0);
      const ss = this.bcdToInt(this.cdParams[1] ?? 2);
      const ff = this.bcdToInt(this.cdParams[2] ?? 0);
      this.cdTargetLba = Math.max(0, mm * 60 * 75 + ss * 75 + ff - 150);
      if (!this.isoReader?.getCachedSector(this.cdTargetLba)) {
        this.pendingCdLbaQueue.push(this.cdTargetLba);
      }
      this.cdResp.push(0x02);
      this.cdIrqFlags = 0x03;
    } else if (cmd === 0x06 || cmd === 0x1b) {
      // ReadN / ReadS
      const cached = this.isoReader?.getCachedSector(this.cdTargetLba);
      if (cached) {
        this.cdSectorBuf.set(cached.subarray(0, 2048));
        this.cdSectorCursor = 0;
        this.cdReads++;
      } else {
        this.pendingCdLbaQueue.push(this.cdTargetLba);
      }
      this.cdTargetLba++;
      this.cdResp.push(0x22);
      this.cdIrqFlags = 0x01; // INT1 Data Ready
      this.iStat |= 0x0004;
    } else if (cmd === 0x19) {
      // Test(subfn)
      this.cdResp.push(0x98, 0x06, 0x10, 0xc3);
      this.cdIrqFlags = 0x03;
    } else if (cmd === 0x1a) {
      // GetID
      this.cdResp.push(0x02, 0x00, 0x20, 0x00, 0x53, 0x43, 0x45, 0x41); // "SCEA"
      this.cdIrqFlags = 0x02;
    } else {
      this.cdResp.push(0x02);
      this.cdIrqFlags = 0x03;
    }
    this.cdParams = [];
  }

  private joyTransferByte(tx: number): void {
    const port = (this.joyCtrl >> 13) & 1;
    const pad = port === 1 ? this.pad2 : this.pad1;
    if (tx === 0x01) {
      this.joyStep = 1;
      this.joyRxFifo.push(0xff);
    } else if (this.joyStep === 1) {
      this.joyStep = 2;
      this.joyRxFifo.push(0x41); // Digital Pad ID
    } else if (this.joyStep === 2) {
      this.joyStep = 3;
      this.joyRxFifo.push(0x5a);
    } else if (this.joyStep === 3) {
      this.joyStep = 4;
      this.joyRxFifo.push(pad.buttons & 0xff);
    } else if (this.joyStep === 4) {
      this.joyStep = 0;
      this.joyRxFifo.push((pad.buttons >>> 8) & 0xff);
    } else {
      this.joyRxFifo.push(0xff);
    }
  }

  read8(addr: number): number {
    const p = this.mapPhysical(addr);
    if (p < 0x00800000) return this.ram[p & 0x1fffff];
    if (p >= 0x1f800000 && p < 0x1f800400) return this.scratchpad[p - 0x1f800000];
    if (p >= 0x1fc00000 && p < 0x1fc80000) return this.bios[p - 0x1fc00000];
    if (p === 0x1f801040) return this.joyRxFifo.shift() ?? 0xff;
    if (p === 0x1f801800) {
      const hasResp = this.cdResp.length > 0 ? 0x20 : 0;
      const hasData = this.cdSectorCursor < 2048 ? 0x40 : 0;
      return (this.cdStatus & 0x1f) | hasResp | hasData;
    }
    if (p === 0x1f801801) return this.cdResp.shift() ?? 0;
    if (p === 0x1f801802) {
      if (this.cdSectorCursor < 2048) return this.cdSectorBuf[this.cdSectorCursor++];
      return 0;
    }
    if (p === 0x1f801803) return this.cdIrqFlags | 0xe0;
    return 0;
  }

  read16(addr: number): number {
    const p = this.mapPhysical(addr) & ~1;
    if (p < 0x00800000) return this.ramView.getUint16(p & 0x1fffff, true);
    if (p >= 0x1f800000 && p < 0x1f800400) return this.scratchView.getUint16(p - 0x1f800000, true);
    if (p >= 0x1fc00000 && p < 0x1fc80000) return this.biosView.getUint16(p - 0x1fc00000, true);
    if (p === 0x1f801044) return 0x0007 | (this.joyRxFifo.length > 0 ? 2 : 0); // JOY_STAT
    if (p === 0x1f801048) return this.joyMode;
    if (p === 0x1f80104a) return this.joyCtrl;
    if (p === 0x1f801070) return this.iStat & 0xffff;
    if (p === 0x1f801074) return this.iMask & 0xffff;
    if (p >= 0x1f801100 && p <= 0x1f80112f) {
      const idx = (p - 0x1f801100) >> 4;
      const reg = p & 0xf;
      if (reg === 0) return this.tmrVal[idx] & 0xffff;
      if (reg === 4) return this.tmrMode[idx] & 0xffff;
      if (reg === 8) return this.tmrTarget[idx] & 0xffff;
    }
    return 0;
  }

  read32(addr: number): number {
    const p = this.mapPhysical(addr) & ~3;
    if (p < 0x00800000) return this.ramView.getUint32(p & 0x1fffff, true);
    if (p >= 0x1f800000 && p < 0x1f800400) return this.scratchView.getUint32(p - 0x1f800000, true);
    if (p >= 0x1fc00000 && p < 0x1fc80000) return this.biosView.getUint32(p - 0x1fc00000, true);
    if (p === 0x1f801070) return this.iStat >>> 0;
    if (p === 0x1f801074) return this.iMask >>> 0;
    if (p === 0x1f801810) return this.gpu.readGpuData();
    if (p === 0x1f801814) return this.gpu.gpuStat >>> 0;
    if (p === 0x1f8010f0) return this.dpcr >>> 0;
    if (p === 0x1f8010f4) return this.dicr >>> 0;
    if (p >= 0x1f801100 && p <= 0x1f80112f) return this.read16(p);
    return 0;
  }

  write8(addr: number, val: number): void {
    const p = this.mapPhysical(addr);
    val &= 0xff;
    if (p < 0x00800000) {
      this.ram[p & 0x1fffff] = val;
      return;
    }
    if (p >= 0x1f800000 && p < 0x1f800400) {
      this.scratchpad[p - 0x1f800000] = val;
      return;
    }
    if (p === 0x1f801040) {
      this.joyTransferByte(val);
      return;
    }
    if (p === 0x1f801800) {
      this.cdStatus = (this.cdStatus & ~3) | (val & 3);
      return;
    }
    const bank = this.cdStatus & 3;
    if (p === 0x1f801801 && bank === 0) {
      this.execCdCommand(val);
    } else if (p === 0x1f801802 && bank === 0) {
      this.cdParams.push(val);
    } else if (p === 0x1f801802 && bank === 1) {
      this.cdIrqMask = val;
    } else if (p === 0x1f801803 && bank === 1) {
      this.cdIrqFlags &= ~(val & 0x1f);
    }
  }

  write16(addr: number, val: number): void {
    const p = this.mapPhysical(addr) & ~1;
    val &= 0xffff;
    if (p < 0x00800000) {
      this.ramView.setUint16(p & 0x1fffff, val, true);
      return;
    }
    if (p >= 0x1f800000 && p < 0x1f800400) {
      this.scratchView.setUint16(p - 0x1f800000, val, true);
      return;
    }
    if (p === 0x1f801048) this.joyMode = val;
    if (p === 0x1f80104a) {
      this.joyCtrl = val;
      if ((val & 0x0002) === 0) this.joyStep = 0;
    }
    if (p === 0x1f801070) this.iStat &= val;
    if (p === 0x1f801074) this.iMask = val;
    if (p >= 0x1f801100 && p <= 0x1f80112f) {
      const idx = (p - 0x1f801100) >> 4;
      const reg = p & 0xf;
      if (reg === 0) this.tmrVal[idx] = val;
      if (reg === 4) this.tmrMode[idx] = val;
      if (reg === 8) this.tmrTarget[idx] = val;
    }
  }

  write32(addr: number, val: number): void {
    const p = this.mapPhysical(addr) & ~3;
    val = val >>> 0;
    if (p < 0x00800000) {
      this.ramView.setUint32(p & 0x1fffff, val, true);
      return;
    }
    if (p >= 0x1f800000 && p < 0x1f800400) {
      this.scratchView.setUint32(p - 0x1f800000, val, true);
      return;
    }
    if (p === 0x1f801070) {
      this.iStat &= val;
      return;
    }
    if (p === 0x1f801074) {
      this.iMask = val;
      return;
    }
    if (p === 0x1f801810) {
      this.gpu.writeGp0(val);
      return;
    }
    if (p === 0x1f801814) {
      this.gpu.writeGp1(val);
      return;
    }
    if (p === 0x1f8010f0) {
      this.dpcr = val;
      return;
    }
    if (p === 0x1f8010f4) {
      this.dicr = val;
      return;
    }
    if (p >= 0x1f801080 && p < 0x1f8010f0) {
      const ch = ((p - 0x1f801080) >> 4) & 7;
      const reg = p & 0xf;
      if (reg === 0) this.dmaBase[ch] = val & 0x00ffffff;
      else if (reg === 4) this.dmaBcr[ch] = val;
      else if (reg === 8) {
        this.dmaChcr[ch] = val;
        if (val & 0x01000000) {
          this.executeDma(ch);
          this.dmaChcr[ch] &= ~0x01000000;
        }
      }
    }
  }

  private executeDma(ch: number): void {
    const chcr = this.dmaChcr[ch];
    const syncMode = (chcr >>> 9) & 3;
    let addr = this.dmaBase[ch] & 0x1ffffc;

    if (ch === 3) {
      // CDROM -> RAM DMA
      const words = Math.min(512, this.dmaBcr[ch] & 0xffff || 512);
      for (let i = 0; i < words && this.cdSectorCursor + 3 < 2048; i++) {
        const w =
          this.cdSectorBuf[this.cdSectorCursor] |
          (this.cdSectorBuf[this.cdSectorCursor + 1] << 8) |
          (this.cdSectorBuf[this.cdSectorCursor + 2] << 16) |
          (this.cdSectorBuf[this.cdSectorCursor + 3] << 24);
        this.ramView.setUint32((addr + i * 4) & 0x1fffff, w >>> 0, true);
        this.cdSectorCursor += 4;
      }
      this.cdReads++;
      return;
    }

    if (ch === 6 && syncMode === 0) {
      const count = this.dmaBcr[ch] & 0xffff || 0x10000;
      for (let i = count; i > 0; i--) {
        const next = i === 1 ? 0x00ffffff : (addr - 4) & 0x1ffffc;
        this.ramView.setUint32(addr & 0x1fffff, next, true);
        addr = (addr - 4) & 0x1ffffc;
      }
      return;
    }

    if (ch === 2 && syncMode === 2) {
      let safety = 0;
      while (safety++ < 4096) {
        const header = this.ramView.getUint32(addr & 0x1fffff, true);
        const words = (header >>> 24) & 0xff;
        for (let i = 1; i <= words; i++) {
          const w = this.ramView.getUint32((addr + i * 4) & 0x1fffff, true);
          this.gpu.writeGp0(w);
        }
        if ((header & 0x00ffffff) === 0x00ffffff) break;
        addr = header & 0x1ffffc;
      }
    } else if (ch === 2 && (syncMode === 0 || syncMode === 1)) {
      const blocks = (this.dmaBcr[ch] >>> 16) || 1;
      const words = (this.dmaBcr[ch] & 0xffff) * blocks;
      for (let i = 0; i < words && i < 65536; i++) {
        const w = this.ramView.getUint32((addr + i * 4) & 0x1fffff, true);
        this.gpu.writeGp0(w);
      }
    }
  }

  writeString(addr: number, str: string): void {
    const p = this.mapPhysical(addr) & 0x1fffff;
    for (let i = 0; i < str.length; i++) {
      this.ram[(p + i) & 0x1fffff] = str.charCodeAt(i) & 0xff;
    }
    this.ram[(p + str.length) & 0x1fffff] = 0;
  }

  readCString(addr: number, maxLen = 96): string {
    let p = this.mapPhysical(addr) & 0x1fffff;
    let out = '';
    for (let i = 0; i < maxLen; i++) {
      const ch = this.ram[p & 0x1fffff];
      if (ch === 0) break;
      out += String.fromCharCode(ch);
      p++;
    }
    return out;
  }
}
