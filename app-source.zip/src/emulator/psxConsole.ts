import { PsxCpu } from './psxCpu';
import { PsxGpu } from './psxGpu';
import { PsxHleBios } from './psxHleBios';
import { PsxMemory } from './psxMemory';
import { PsxSpu } from './psxSpu';
import { StreamingIsoReader } from './streamingIsoReader';
import { EmulatorTelemetry, IsoMountInfo, PsxPadState } from './types';

export class PsxConsole {
  readonly gpu = new PsxGpu();
  readonly spu = new PsxSpu();
  readonly mem = new PsxMemory(this.gpu);
  readonly hle = new PsxHleBios(this.mem, this.spu);
  readonly cpu = new PsxCpu(this.mem, this.hle);

  private rafId: number | null = null;
  private running = false;
  private paused = false;
  private mountedDisc: IsoMountInfo | null = null;
  private isoReader: StreamingIsoReader | null = null;
  private activeGameId = '';
  private activeGameTitle = '';
  private externalExeLoaded = false;

  private fps = 0;
  private frameCounter = 0;
  private lastFpsSample = performance.now();
  private onFrameCallback: ((rgba: Uint8ClampedArray, telemetry: EmulatorTelemetry) => void) | null = null;

  onFrame(cb: (rgba: Uint8ClampedArray, telemetry: EmulatorTelemetry) => void): void {
    this.onFrameCallback = cb;
  }

  private loadPsxExeIntoRam(exeBytes: Uint8Array): { pc0: number; gp0: number; sp0: number } {
    const view = new DataView(exeBytes.buffer, exeBytes.byteOffset, exeBytes.byteLength);
    const pc0 = view.getUint32(0x10, true) >>> 0;
    const gp0 = view.getUint32(0x14, true) >>> 0;
    const tAddr = view.getUint32(0x18, true) >>> 0;
    const tSize = view.getUint32(0x1c, true) >>> 0;
    const sAddr = view.getUint32(0x30, true) >>> 0;

    const payload = exeBytes.subarray(2048);
    const copyLen = Math.min(payload.length, tSize || payload.length, 0x1fffff);
    const physStart = tAddr & 0x1fffff;
    for (let i = 0; i < copyLen; i++) {
      this.mem.ram[(physStart + i) & 0x1fffff] = payload[i];
    }

    return {
      pc0: pc0 || 0x80010000,
      gp0: gp0 || 0x80090000,
      sp0: sAddr || 0x801fff00,
    };
  }

  async bootUserFile(file: File): Promise<IsoMountInfo> {
    this.spu.unlock();
    this.stop();
    this.gpu.reset();
    this.mem.reset();
    this.hle.reset();

    const reader = new StreamingIsoReader(file);
    this.isoReader = reader;
    this.mem.isoReader = reader;
    this.hle.setIsoReader(reader);

    const { info, bootExeBytes } = await reader.mount();

    this.mountedDisc = info;
    this.activeGameId = info.serial.replace(/[^a-zA-Z0-9_-]/g, '_');
    this.activeGameTitle = info.recognizedTitle.title || info.volumeLabel || file.name;
    this.externalExeLoaded = Boolean(bootExeBytes && bootExeBytes.length >= 2048);

    this.hle.bootLog.push(`[ISO] Montado: ${this.activeGameTitle} (${info.serial})`);
    this.hle.bootLog.push(`[ISO] Setor ${info.sectorSize || 2048}B · ${info.totalSectors} setores · Boot ${info.bootExePath}`);

    if (bootExeBytes && bootExeBytes.length >= 2048) {
      const magic = new TextDecoder('ascii').decode(bootExeBytes.subarray(0, 8));
      if (magic === 'PS-X EXE') {
        const { pc0, gp0, sp0 } = this.loadPsxExeIntoRam(bootExeBytes);
        this.hle.bootLog.push(`[EXE] PS-X EXE carregado: PC=0x${pc0.toString(16).toUpperCase()} GP=0x${gp0.toString(16).toUpperCase()}`);
        this.cpu.reset(pc0, gp0, sp0);
      } else {
        this.cpu.reset(0x80010000, 0x80090000, 0x801fff00);
      }
    } else {
      this.hle.bootLog.push('[ISO] Aviso: SYSTEM.CNF/PS-X EXE não encontrado na raiz.');
      this.cpu.reset(0x80010000, 0x80090000, 0x801fff00);
    }

    this.spu.playSfx('boot');
    this.startLoop();
    return info;
  }

  private renderIsoHleTelemetryOverlay(): void {
    const disc = this.mountedDisc;
    if (!disc) return;

    this.gpu.drawRect(0, 0, 320, 240, 0x0b0e14);
    this.gpu.drawRect(0, 0, 320, 38, 0x131924);
    this.gpu.drawText(12, 8, 'PS1 HLE CORE - SEM BIOS', 0x60a5fa, 1);
    this.gpu.drawText(12, 22, disc.recognizedTitle.title.slice(0, 30), 0xf8fafc, 1);

    const sizeMb = (disc.fileSizeBytes / (1024 * 1024)).toFixed(1);
    this.gpu.drawText(12, 50, `SERIAL: ${disc.serial}`, 0x10b981, 1);
    this.gpu.drawText(12, 64, `REGIAO: ${disc.recognizedTitle.region}  ${disc.recognizedTitle.maxPlayers}P`, 0xe5e7eb, 1);
    this.gpu.drawText(12, 78, `ISO: ${sizeMb} MB (${disc.sectorSize || 2048}B)`, 0x94a3b8, 1);
    this.gpu.drawText(12, 92, `BOOT: ${disc.bootExePath.slice(0, 24)}`, 0xf59e0b, 1);
    this.gpu.drawText(12, 108, `PC: 0X${this.cpu.pc.toString(16).toUpperCase()}`, 0x60a5fa, 1);
    this.gpu.drawText(12, 122, `CICLOS: ${this.cpu.cycles}  CD: ${this.mem.cdReads}`, 0xe5e7eb, 1);

    const p1Active = (~this.mem.pad1.buttons) & 0xffff;
    const p2Active = (~this.mem.pad2.buttons) & 0xffff;
    this.gpu.drawRect(12, 144, 296, 56, 0x171c26);
    this.gpu.drawText(20, 154, `PAD1: 0X${p1Active.toString(16).toUpperCase().padStart(4, '0')}`, 0x3b82f6, 1);
    this.gpu.drawText(20, 168, `PAD2: 0X${p2Active.toString(16).toUpperCase().padStart(4, '0')}`, 0xef4444, 1);
    this.gpu.drawText(
      20,
      184,
      this.externalExeLoaded ? 'EXE EM RAM (AGUARDANDO VRAM/HW)' : 'ISO MONTADA (SEM EXE BOOTAVEL)',
      0x10b981,
      1,
    );
  }

  private pumpCdPrefetch(): void {
    if (!this.isoReader || this.mem.pendingCdLbaQueue.length === 0) return;
    const batch = this.mem.pendingCdLbaQueue.splice(0, 4);
    for (const lba of batch) {
      void this.isoReader.readSector(lba);
    }
  }

  private startLoop(): void {
    this.running = true;
    this.paused = false;
    this.frameCounter = 0;
    this.lastFpsSample = performance.now();

    const tick = () => {
      if (!this.running) return;
      if (!this.paused) {
        this.pumpCdPrefetch();
        if (this.externalExeLoaded) {
          this.cpu.stepFrame(45_000);
        }
        if (this.gpu.vramWrites < 32) {
          this.renderIsoHleTelemetryOverlay();
        }

        const rgba = this.gpu.renderToRgba();
        this.frameCounter++;
        const now = performance.now();
        if (now - this.lastFpsSample >= 500) {
          this.fps = Math.round((this.frameCounter * 1000) / (now - this.lastFpsSample));
          this.frameCounter = 0;
          this.lastFpsSample = now;
        }

        if (this.onFrameCallback) {
          this.onFrameCallback(rgba, this.getTelemetry());
        }
      }
      this.rafId = requestAnimationFrame(tick);
    };

    this.rafId = requestAnimationFrame(tick);
  }

  setPadState(port: 1 | 2, state: PsxPadState): void {
    if (port === 1) this.mem.pad1 = state;
    else this.mem.pad2 = state;
  }

  setPaused(paused: boolean): void {
    this.paused = paused;
  }

  exportMemoryCardState(): string {
    const header = {
      gameId: this.activeGameId || 'PSX_DISC',
      pc: this.cpu.pc >>> 0,
      gpSlice: Array.from(this.mem.ram.subarray(0x00090000, 0x00090080)),
      savedAt: Date.now(),
    };
    return btoa(JSON.stringify(header));
  }

  importMemoryCardState(encoded: string): boolean {
    try {
      const parsed = JSON.parse(atob(encoded)) as { gpSlice?: number[] };
      if (Array.isArray(parsed.gpSlice)) {
        for (let i = 0; i < Math.min(parsed.gpSlice.length, 128); i++) {
          this.mem.ram[0x00090000 + i] = parsed.gpSlice[i] & 0xff;
        }
        this.spu.playSfx('score');
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  getTelemetry(): EmulatorTelemetry {
    return {
      running: this.running,
      paused: this.paused,
      fps: this.fps,
      pc: this.cpu.pc >>> 0,
      sp: this.cpu.regs[29] >>> 0,
      cycles: this.cpu.cycles,
      vramWrites: this.gpu.vramWrites,
      cdReads: this.mem.cdReads,
      pad1Mask: (~this.mem.pad1.buttons) & 0xffff,
      pad2Mask: (~this.mem.pad2.buttons) & 0xffff,
      biosMode: 'HLE_NO_BIOS',
      mountedDisc: this.mountedDisc,
      activeGameTitle: this.activeGameTitle,
      activeGameId: this.activeGameId,
      hleLogs: [...this.hle.bootLog],
    };
  }

  stop(): void {
    this.running = false;
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }
}
