import { PsxHleBios } from './psxHleBios';
import { PsxMemory } from './psxMemory';

export class PsxCpu {
  readonly regs = new Int32Array(32);
  hi = 0;
  lo = 0;
  pc = 0xbfc00000;
  nextPc = 0xbfc00004;
  cycles = 0;

  private cop0 = new Uint32Array(32);
  private gteData = new Int32Array(32);
  private gteCtrl = new Int32Array(32);

  private mem: PsxMemory;
  private hle: PsxHleBios;

  constructor(mem: PsxMemory, hle: PsxHleBios) {
    this.mem = mem;
    this.hle = hle;
  }

  reset(entryPc = 0xbfc00000, gp = 0, sp = 0x801fff00): void {
    this.regs.fill(0);
    this.hi = 0;
    this.lo = 0;
    this.pc = entryPc >>> 0;
    this.nextPc = (this.pc + 4) >>> 0;
    this.regs[28] = gp | 0;
    this.regs[29] = sp | 0;
    this.regs[30] = sp | 0;
    this.regs[31] = 0xbfc00000 | 0;
    this.cycles = 0;
    this.cop0.fill(0);
    this.cop0[12] = 0x10900000;
    this.gteData.fill(0);
    this.gteCtrl.fill(0);
  }

  private signExtend16(val: number): number {
    return (val << 16) >> 16;
  }

  private signExtend8(val: number): number {
    return (val << 24) >> 24;
  }

  private executeGte(cmd: number): void {
    const op = cmd & 0x3f;
    const sf = (cmd & 0x80000) !== 0 ? 12 : 0;

    if (op === 0x01 || op === 0x30) {
      // RTPS / RTPT perspective transform
      const count = op === 0x30 ? 3 : 1;
      for (let v = 0; v < count; v++) {
        const vx = this.signExtend16(this.gteData[v * 2] & 0xffff);
        const vy = this.signExtend16((this.gteData[v * 2] >>> 16) & 0xffff);
        const vz = this.signExtend16(this.gteData[v * 2 + 1] & 0xffff);
        const r11 = this.signExtend16(this.gteCtrl[0] & 0xffff);
        const r12 = this.signExtend16((this.gteCtrl[0] >>> 16) & 0xffff);
        const r13 = this.signExtend16(this.gteCtrl[1] & 0xffff);
        const r21 = this.signExtend16((this.gteCtrl[1] >>> 16) & 0xffff);
        const r22 = this.signExtend16(this.gteCtrl[2] & 0xffff);
        const r23 = this.signExtend16((this.gteCtrl[2] >>> 16) & 0xffff);
        const r31 = this.signExtend16(this.gteCtrl[3] & 0xffff);
        const r32 = this.signExtend16((this.gteCtrl[3] >>> 16) & 0xffff);
        const r33 = this.signExtend16(this.gteCtrl[4] & 0xffff);

        const trx = this.gteCtrl[5];
        const tryy = this.gteCtrl[6];
        const trz = this.gteCtrl[7];
        const ofx = this.gteCtrl[24];
        const ofy = this.gteCtrl[25];
        const h = this.gteCtrl[26] & 0xffff;

        const mac1 = (trx + ((r11 * vx + r12 * vy + r13 * vz) >> sf)) | 0;
        const mac2 = (tryy + ((r21 * vx + r22 * vy + r23 * vz) >> sf)) | 0;
        const mac3 = Math.max(1, (trz + ((r31 * vx + r32 * vy + r33 * vz) >> sf)) | 0);

        this.gteData[25] = mac1;
        this.gteData[26] = mac2;
        this.gteData[27] = mac3;
        this.gteData[19] = mac3;

        const div = h / Math.max(1, mac3);
        const sx = Math.max(-1024, Math.min(1023, ((ofx + mac1 * div * 65536) >> 16) | 0));
        const sy = Math.max(-1024, Math.min(1023, ((ofy + mac2 * div * 65536) >> 16) | 0));
        this.gteData[12] = this.gteData[13];
        this.gteData[13] = this.gteData[14];
        this.gteData[14] = (sx & 0xffff) | ((sy & 0xffff) << 16);
      }
    } else if (op === 0x06) {
      // NCLIP
      const sx0 = this.signExtend16(this.gteData[12] & 0xffff);
      const sy0 = this.signExtend16((this.gteData[12] >>> 16) & 0xffff);
      const sx1 = this.signExtend16(this.gteData[13] & 0xffff);
      const sy1 = this.signExtend16((this.gteData[13] >>> 16) & 0xffff);
      const sx2 = this.signExtend16(this.gteData[14] & 0xffff);
      const sy2 = this.signExtend16((this.gteData[14] >>> 16) & 0xffff);
      this.gteData[24] = sx0 * (sy1 - sy2) + sx1 * (sy2 - sy0) + sx2 * (sy0 - sy1);
    } else if (op === 0x2d) {
      // AVSZ3
      const zsf3 = this.signExtend16(this.gteCtrl[29] & 0xffff);
      const avg = (zsf3 * (this.gteData[17] + this.gteData[18] + this.gteData[19])) >> 12;
      this.gteData[24] = avg;
      this.gteData[7] = Math.max(0, Math.min(0xffff, avg));
    }
  }

  stepFrame(maxInstructions = 140_000): void {
    this.hle.frameRequestedYield = false;
    let count = 0;

    while (count < maxInstructions && !this.hle.frameRequestedYield) {
      this.step();
      count++;
    }
    this.mem.tickTimers(count);
    this.mem.iStat |= 0x0001;

    // Trigger CPU IRQ if COP0 IEC & IM2 are enabled
    if ((this.mem.iStat & this.mem.iMask) !== 0 && (this.cop0[12] & 0x401) === 0x401) {
      this.cop0[14] = this.pc >>> 0;
      this.cop0[13] = 0x00000400;
      this.pc = 0x80000080;
      this.nextPc = 0x80000084;
    }
  }

  step(): void {
    const physPc = this.pc & 0x1fffffff;
    if (physPc === 0x000000a0 || physPc === 0x000000b0 || physPc === 0x000000c0) {
      this.hle.dispatchVector(physPc, this.regs);
      this.pc = this.regs[31] >>> 0;
      this.nextPc = (this.pc + 4) >>> 0;
      this.cycles += 12;
      return;
    }

    const instr = this.mem.read32(this.pc) >>> 0;
    const currentPc = this.pc;
    let jumpTarget = (this.nextPc + 4) >>> 0;

    const op = (instr >>> 26) & 0x3f;
    const rs = (instr >>> 21) & 0x1f;
    const rt = (instr >>> 16) & 0x1f;
    const rd = (instr >>> 11) & 0x1f;
    const shamt = (instr >>> 6) & 0x1f;
    const funct = instr & 0x3f;
    const imm = instr & 0xffff;
    const simm = this.signExtend16(imm);
    const target = instr & 0x03ffffff;

    const r = this.regs;

    switch (op) {
      case 0x00: {
        switch (funct) {
          case 0x00: r[rd] = r[rt] << shamt; break;
          case 0x02: r[rd] = r[rt] >>> shamt; break;
          case 0x03: r[rd] = r[rt] >> shamt; break;
          case 0x04: r[rd] = r[rt] << (r[rs] & 0x1f); break;
          case 0x06: r[rd] = r[rt] >>> (r[rs] & 0x1f); break;
          case 0x07: r[rd] = r[rt] >> (r[rs] & 0x1f); break;
          case 0x08: jumpTarget = r[rs] >>> 0; break;
          case 0x09: {
            const ret = (currentPc + 8) >>> 0;
            jumpTarget = r[rs] >>> 0;
            r[rd] = ret | 0;
            break;
          }
          case 0x0c:
            this.hle.dispatchSyscall((instr >>> 6) & 0xfffff, r);
            break;
          case 0x0d:
            this.hle.frameRequestedYield = true;
            break;
          case 0x10: r[rd] = this.hi | 0; break;
          case 0x11: this.hi = r[rs] | 0; break;
          case 0x12: r[rd] = this.lo | 0; break;
          case 0x13: this.lo = r[rs] | 0; break;
          case 0x18: {
            const prod = BigInt(r[rs]) * BigInt(r[rt]);
            this.lo = Number(prod & 0xffffffffn) | 0;
            this.hi = Number((prod >> 32n) & 0xffffffffn) | 0;
            break;
          }
          case 0x19: {
            const prod = BigInt(r[rs] >>> 0) * BigInt(r[rt] >>> 0);
            this.lo = Number(prod & 0xffffffffn) | 0;
            this.hi = Number((prod >> 32n) & 0xffffffffn) | 0;
            break;
          }
          case 0x1a:
            if (r[rt] !== 0) {
              this.lo = (r[rs] / r[rt]) | 0;
              this.hi = (r[rs] % r[rt]) | 0;
            }
            break;
          case 0x1b:
            if ((r[rt] >>> 0) !== 0) {
              this.lo = ((r[rs] >>> 0) / (r[rt] >>> 0)) | 0;
              this.hi = ((r[rs] >>> 0) % (r[rt] >>> 0)) | 0;
            }
            break;
          case 0x20:
          case 0x21: r[rd] = (r[rs] + r[rt]) | 0; break;
          case 0x22:
          case 0x23: r[rd] = (r[rs] - r[rt]) | 0; break;
          case 0x24: r[rd] = r[rs] & r[rt]; break;
          case 0x25: r[rd] = r[rs] | r[rt]; break;
          case 0x26: r[rd] = r[rs] ^ r[rt]; break;
          case 0x27: r[rd] = ~(r[rs] | r[rt]); break;
          case 0x2a: r[rd] = r[rs] < r[rt] ? 1 : 0; break;
          case 0x2b: r[rd] = (r[rs] >>> 0) < (r[rt] >>> 0) ? 1 : 0; break;
          default: break;
        }
        break;
      }
      case 0x01: {
        const branch =
          (rt === 0x00 && r[rs] < 0) ||
          (rt === 0x01 && r[rs] >= 0) ||
          (rt === 0x10 && r[rs] < 0) ||
          (rt === 0x11 && r[rs] >= 0);
        if (rt === 0x10 || rt === 0x11) r[31] = (currentPc + 8) | 0;
        if (branch) jumpTarget = (this.nextPc + (simm << 2)) >>> 0;
        break;
      }
      case 0x02:
        jumpTarget = ((this.nextPc & 0xf0000000) | (target << 2)) >>> 0;
        break;
      case 0x03:
        r[31] = (currentPc + 8) | 0;
        jumpTarget = ((this.nextPc & 0xf0000000) | (target << 2)) >>> 0;
        break;
      case 0x04:
        if (r[rs] === r[rt]) jumpTarget = (this.nextPc + (simm << 2)) >>> 0;
        break;
      case 0x05:
        if (r[rs] !== r[rt]) jumpTarget = (this.nextPc + (simm << 2)) >>> 0;
        break;
      case 0x06:
        if (r[rs] <= 0) jumpTarget = (this.nextPc + (simm << 2)) >>> 0;
        break;
      case 0x07:
        if (r[rs] > 0) jumpTarget = (this.nextPc + (simm << 2)) >>> 0;
        break;
      case 0x08:
      case 0x09: r[rt] = (r[rs] + simm) | 0; break;
      case 0x0a: r[rt] = r[rs] < simm ? 1 : 0; break;
      case 0x0b: r[rt] = (r[rs] >>> 0) < (simm >>> 0) ? 1 : 0; break;
      case 0x0c: r[rt] = r[rs] & imm; break;
      case 0x0d: r[rt] = r[rs] | imm; break;
      case 0x0e: r[rt] = r[rs] ^ imm; break;
      case 0x0f: r[rt] = (imm << 16) | 0; break;
      case 0x10:
        if (rs === 0x00) r[rt] = this.cop0[rd] | 0;
        else if (rs === 0x04) this.cop0[rd] = r[rt] >>> 0;
        else if (instr === 0x42000010) {
          this.cop0[12] = (this.cop0[12] & ~0xf) | ((this.cop0[12] >>> 2) & 0xf);
        }
        break;
      case 0x12:
        if ((rs & 0x10) !== 0) this.executeGte(instr);
        else if (rs === 0x00) r[rt] = this.gteData[rd];
        else if (rs === 0x02) r[rt] = this.gteCtrl[rd];
        else if (rs === 0x04) this.gteData[rd] = r[rt];
        else if (rs === 0x06) this.gteCtrl[rd] = r[rt];
        break;
      case 0x20: r[rt] = this.signExtend8(this.mem.read8((r[rs] + simm) >>> 0)); break;
      case 0x21: r[rt] = this.signExtend16(this.mem.read16((r[rs] + simm) >>> 0)); break;
      case 0x22: { // LWL
        const addr = (r[rs] + simm) >>> 0;
        const word = this.mem.read32(addr & ~3) >>> 0;
        const shift = addr & 3;
        const mask = 0x00ffffff >>> (shift * 8);
        r[rt] = ((r[rt] & mask) | (word << ((3 - shift) * 8))) | 0;
        break;
      }
      case 0x23: r[rt] = this.mem.read32((r[rs] + simm) >>> 0) | 0; break;
      case 0x24: r[rt] = this.mem.read8((r[rs] + simm) >>> 0) & 0xff; break;
      case 0x25: r[rt] = this.mem.read16((r[rs] + simm) >>> 0) & 0xffff; break;
      case 0x26: { // LWR
        const addr = (r[rs] + simm) >>> 0;
        const word = this.mem.read32(addr & ~3) >>> 0;
        const shift = addr & 3;
        const mask = shift === 0 ? 0 : (0xffffff00 << ((3 - shift) * 8)) >>> 0;
        r[rt] = ((r[rt] & mask) | (word >>> (shift * 8))) | 0;
        break;
      }
      case 0x28: this.mem.write8((r[rs] + simm) >>> 0, r[rt]); break;
      case 0x29: this.mem.write16((r[rs] + simm) >>> 0, r[rt]); break;
      case 0x2a: { // SWL
        const addr = (r[rs] + simm) >>> 0;
        const aligned = addr & ~3;
        const cur = this.mem.read32(aligned) >>> 0;
        const shift = addr & 3;
        const mask = (0xffffff00 << (shift * 8)) >>> 0;
        this.mem.write32(aligned, (cur & mask) | ((r[rt] >>> 0) >>> ((3 - shift) * 8)));
        break;
      }
      case 0x2b: this.mem.write32((r[rs] + simm) >>> 0, r[rt]); break;
      case 0x2e: { // SWR
        const addr = (r[rs] + simm) >>> 0;
        const aligned = addr & ~3;
        const cur = this.mem.read32(aligned) >>> 0;
        const shift = addr & 3;
        const mask = shift === 0 ? 0 : (0x00ffffff >>> ((3 - shift) * 8));
        this.mem.write32(aligned, (cur & mask) | ((r[rt] << (shift * 8)) >>> 0));
        break;
      }
      default:
        break;
    }

    r[0] = 0;
    this.pc = this.nextPc;
    this.nextPc = jumpTarget;
    this.cycles++;
  }
}
