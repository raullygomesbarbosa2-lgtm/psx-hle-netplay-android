import express from 'express';
import http from 'http';
import path from 'path';
import { fileURLToPath } from 'url';
import { WebSocketServer, WebSocket } from 'ws';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface PeerClient {
  ws: WebSocket;
  uid: string;
  gamerTag: string;
  role: 'p1' | 'p2';
}

interface ServerRoomState {
  roomCode: string;
  hostUid: string;
  p1: PeerClient | null;
  p2: PeerClient | null;
  p2Approved: boolean;
  p2CanSelectCharacter: boolean;
  gameId: string;
  gameTitle: string;
  p1Character: string;
  p2Character: string;
  lastFramePayload: string | null;
}

const rooms = new Map<string, ServerRoomState>();

function getOrCreateRoom(roomCode: string): ServerRoomState {
  let room = rooms.get(roomCode);
  if (!room) {
    room = {
      roomCode,
      hostUid: '',
      p1: null,
      p2: null,
      p2Approved: false,
      p2CanSelectCharacter: true,
      gameId: 'aguardando-iso',
      gameTitle: 'Aguardando ISO PS1 do Host',
      p1Character: 'Controle 1 / Slot A',
      p2Character: 'Controle 2 / Slot B',
      lastFramePayload: null,
    };
    rooms.set(roomCode, room);
  }
  return room;
}

function safeSend(ws: WebSocket | null | undefined, payload: unknown): void {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(payload));
  }
}

function broadcastRoomState(room: ServerRoomState): void {
  const snapshot = {
    type: 'room:state',
    roomCode: room.roomCode,
    p1Connected: Boolean(room.p1 && room.p1.ws.readyState === WebSocket.OPEN),
    p1Name: room.p1?.gamerTag ?? '',
    p2Connected: Boolean(room.p2 && room.p2.ws.readyState === WebSocket.OPEN),
    p2Uid: room.p2?.uid ?? '',
    p2Name: room.p2?.gamerTag ?? '',
    p2Approved: room.p2Approved,
    p2CanSelectCharacter: room.p2CanSelectCharacter,
    gameId: room.gameId,
    gameTitle: room.gameTitle,
    p1Character: room.p1Character,
    p2Character: room.p2Character,
  };
  safeSend(room.p1?.ws, snapshot);
  safeSend(room.p2?.ws, snapshot);
}

async function startServer(): Promise<void> {
  const app = express();
  app.use(express.json({ limit: '1mb' }));

  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', activeRooms: rooms.size });
  });

  const server = http.createServer(app);

  const wss = new WebSocketServer({ noServer: true });

  server.on('upgrade', (request, socket, head) => {
    const url = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`);
    if (url.pathname !== '/ws/netplay') {
      return;
    }
    wss.handleUpgrade(request, socket, head, (ws) => {
      wss.emit('connection', ws, request);
    });
  });

  wss.on('connection', (ws, request) => {
    const url = new URL(request.url ?? '/', `http://${request.headers.host ?? 'localhost'}`);
    const roomCode = (url.searchParams.get('roomCode') ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
    const uid = (url.searchParams.get('uid') ?? '').slice(0, 128);
    const gamerTag = (url.searchParams.get('gamerTag') ?? 'Jogador').slice(0, 40);
    const role = url.searchParams.get('role') === 'p1' ? 'p1' : 'p2';

    if (roomCode.length !== 6 || !uid) {
      ws.close(1008, 'Invalid NetPlay room parameters');
      return;
    }

    const room = getOrCreateRoom(roomCode);
    const peer: PeerClient = { ws, uid, gamerTag, role };

    if (role === 'p1') {
      if (room.hostUid && room.hostUid !== uid) {
        safeSend(ws, { type: 'room:error', message: 'Esta sala já possui outro Host P1.' });
        ws.close(1008, 'Host conflict');
        return;
      }
      room.hostUid = uid;
      if (room.p1 && room.p1.ws !== ws && room.p1.ws.readyState === WebSocket.OPEN) {
        room.p1.ws.close(1000, 'Replaced by new P1 session');
      }
      room.p1 = peer;
    } else {
      if (room.p2 && room.p2.uid !== uid && room.p2.ws.readyState === WebSocket.OPEN) {
        safeSend(ws, { type: 'room:error', message: 'Sala já ocupada por outro convidado P2.' });
        ws.close(1008, 'Room full');
        return;
      }
      if (room.p2 && room.p2.ws !== ws && room.p2.ws.readyState === WebSocket.OPEN) {
        room.p2.ws.close(1000, 'Replaced by new P2 session');
      }
      room.p2 = peer;
    }

    broadcastRoomState(room);
    if (role === 'p2' && room.p2Approved && room.lastFramePayload) {
      safeSend(ws, { type: 'netplay:frame', data: JSON.parse(room.lastFramePayload) });
    }

    ws.on('message', (raw) => {
      let msg: Record<string, unknown>;
      try {
        msg = JSON.parse(raw.toString()) as Record<string, unknown>;
      } catch {
        return;
      }

      const msgType = typeof msg.type === 'string' ? msg.type : '';

      if (msgType === 'room:control' && role === 'p1') {
        if (typeof msg.p2Approved === 'boolean') {
          room.p2Approved = msg.p2Approved;
        }
        if (typeof msg.p2CanSelectCharacter === 'boolean') {
          room.p2CanSelectCharacter = msg.p2CanSelectCharacter;
        }
        if (typeof msg.gameId === 'string') {
          room.gameId = msg.gameId.slice(0, 64);
        }
        if (typeof msg.gameTitle === 'string') {
          room.gameTitle = msg.gameTitle.slice(0, 80);
        }
        if (typeof msg.p1Character === 'string') {
          room.p1Character = msg.p1Character.slice(0, 40);
        }
        if (typeof msg.p2Character === 'string') {
          room.p2Character = msg.p2Character.slice(0, 40);
        }
        if (msg.kickP2 === true && room.p2) {
          room.p2Approved = false;
          safeSend(room.p2.ws, { type: 'room:kicked', message: 'O administrador P1 encerrou seu acesso.' });
          room.p2.ws.close(1000, 'Access revoked by P1');
          room.p2 = null;
        }
        broadcastRoomState(room);
        return;
      }

      if (msgType === 'room:p2_character' && role === 'p2') {
        if (room.p2Approved && room.p2CanSelectCharacter && typeof msg.p2Character === 'string') {
          room.p2Character = msg.p2Character.slice(0, 40);
          broadcastRoomState(room);
        }
        return;
      }

      if (msgType === 'netplay:input' && role === 'p2') {
        if (!room.p2Approved) {
          return;
        }
        safeSend(room.p1?.ws, {
          type: 'netplay:input',
          buttons: typeof msg.buttons === 'number' ? msg.buttons : 0xffff,
          lx: typeof msg.lx === 'number' ? msg.lx : 128,
          ly: typeof msg.ly === 'number' ? msg.ly : 128,
          seq: typeof msg.seq === 'number' ? msg.seq : 0,
        });
        return;
      }

      if (msgType === 'netplay:frame' && role === 'p1') {
        if (msg.data && typeof msg.data === 'object') {
          const serialized = JSON.stringify(msg.data);
          if (serialized.length < 400_000) {
            room.lastFramePayload = serialized;
            if (room.p2Approved) {
              safeSend(room.p2?.ws, { type: 'netplay:frame', data: msg.data });
            }
          }
        }
        return;
      }
    });

    ws.on('close', () => {
      if (role === 'p1' && room.p1?.ws === ws) {
        room.p1 = null;
        broadcastRoomState(room);
      } else if (role === 'p2' && room.p2?.ws === ws) {
        room.p2 = null;
        broadcastRoomState(room);
      }
      if (!room.p1 && !room.p2) {
        rooms.delete(roomCode);
      }
    });
  });

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const port = Number(process.env.PORT || 3000);
  server.listen(port, '0.0.0.0', () => {
    console.log(`PSX HLE NetPlay server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
