// Payload-First Security Test Spec for PSX HLE NetPlay Firestore Rules
// Covers the 12 adversarial Dirty Dozen scenarios documented in security_spec.md.

export const DIRTY_DOZEN_CASES = [
  { id: 1, name: 'Unverified Email Write', collection: 'users', expected: 'PERMISSION_DENIED' },
  { id: 2, name: 'Identity Spoofing on User', collection: 'users', expected: 'PERMISSION_DENIED' },
  { id: 3, name: 'PII Cross-Read', collection: 'users', expected: 'PERMISSION_DENIED' },
  { id: 4, name: 'Ghost Field Injection', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 5, name: 'ID Poisoning', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 6, name: 'Timestamp Forgery', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 7, name: 'P2 Self-Approval', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 8, name: 'P2 Unauthorized Character Change', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 9, name: 'Host Hijack', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 10, name: 'Closed Room Resurrection', collection: 'rooms', expected: 'PERMISSION_DENIED' },
  { id: 11, name: 'Oversized Memory Card Exhaustion', collection: 'saveStates', expected: 'PERMISSION_DENIED' },
  { id: 12, name: 'Blanket Save Listing Spoof', collection: 'saveStates', expected: 'PERMISSION_DENIED' },
] as const;
