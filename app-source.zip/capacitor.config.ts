import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.psxhlenetplay.android',
  appName: 'PSX HLE NetPlay',
  webDir: 'dist',
  server: {
    url: process.env.PSX_APP_URL || 'https://psx-hle-netplay.onrender.com',
    cleartext: false,
    allowNavigation: ['psx-hle-netplay.onrender.com', '*.firebaseapp.com', '*.googleapis.com', '*.emulatorjs.org', '*.emulatorjs.net'],
  },
  android: {
    allowMixedContent: false,
  },
};

export default config;
